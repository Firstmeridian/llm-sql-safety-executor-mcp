"""Seal final CTE-body checks; preserve all previous source/Host attribution."""
import difflib,gzip,hashlib,json,re,subprocess
from pathlib import Path
from urllib.parse import unquote
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/cte_header_2026_10_15"
sha=lambda b:hashlib.sha256(b).hexdigest()
def read_result(name):
    p=OUT/name
    if not p.exists():p=OUT/(name+".gz")
    b=p.read_bytes();return json.loads(gzip.decompress(b) if p.suffix==".gz" else b)
def read_log(name):
    p=Path("/tmp")/name
    return p.read_text() if p.exists() else gzip.decompress((OUT/(name+".gz")).read_bytes()).decode()
source={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in (".py",".md")}
baseline=read_result("baseline_source.json")
changed=[name for name in source if source[name]!=baseline[name]]
assert changed==["src/sql_safety_executor/core/policy.py"]
previous={}
for name in ("lexical_identity_2026_10_15","pragma_identity_2026_10_15","sqlite_prefix_2026_10_15","real_tasks_2026_10_15","schema_binding_2026_10_15"):
    directory=ROOT/"docs/validation/v3.8"/name
    rows=json.loads((directory/"manifest.json").read_text())["artifacts"]
    for row in rows:assert sha((directory/row["path"]).read_bytes())==row["sha256"],(name,row["path"])
    previous[name]=len(rows)
assert baseline==json.loads((ROOT/"docs/validation/v3.8/lexical_identity_2026_10_15/automation.json").read_text())["source_sha256"]
before=read_result("before-calls.json.gz");after=read_result("after-calls.json.gz")
assert before["source_sha256"]==baseline and after["source_sha256"]==source
assert before["total_calls"]==after["total_calls"]==80
for old,new in zip(before["records"],after["records"]):
    assert (old["mode"],old["admitted"],old["requests"])==(new["mode"],new["admitted"],new["requests"])
    assert len(old["requests"])==len(new["requests"])==20
    assert all(not r["isError"] for r in new["calls"][:8])
    assert all(r["isError"] for r in new["calls"][8:13]+new["calls"][14:19])
    assert {r["name"] for r in old["calls"][7]["structuredContent"]["skills"]}=={"sleep","benchmark","get-lock","file","account","safe-user"}
    assert {r["name"] for r in new["calls"][7]["structuredContent"]["skills"]}=={"safe-user"}
    assert all(r["structuredContent"]["error_code"]==("unknown_function" if old["admitted"] else "relation_scope_unresolved") for r in old["calls"][:5])
wheel=read_result("installed_wheel.json")
assert wheel["total_calls"]==80 and wheel["source_files_verified"]==69
assert source=={"src/"+name:value for name,value in wheel["installed_source_sha256"].items()}
mysql=read_result("live_mysql.json.gz")
assert mysql["source_sha256"]==source and mysql["checks"]=={"passed":12,"failed":0}
matrix=read_result("header_scan_matrix.json.gz")
assert matrix["source_sha256"]==source
assert (matrix["native_cases"],matrix["previously_allowed"],matrix["after_denied"],matrix["positive_controls"],matrix["earlier_shape_denials"])==(576,96,576,12,192)
assert all(not r["after_allowed"] for r in matrix["records"]) and all(r["allowed"] for r in matrix["controls"])
contexts=read_result("boundary_context_audit.json.gz")
assert contexts["source_sha256"]==source
assert (contexts["candidate_suffixes"],contexts["native_valid_cases"],contexts["scope_misses"],contexts["approved_refusals"])==(109,1000,0,0)
relations=read_result("adjacent_audit.json")
assert relations["source_sha256"]==source
assert (relations["candidate_names"],relations["native_valid_cases"],relations["unapproved_scope_misses"],relations["approved_conservative_refusals"])==(97,542,0,18)
assert all(r["quoted_recovery_allowed"] for r in relations["records"] if not r["approved_allowed"])
origin=read_result("origin_check.json")
assert len(origin["records"])==5
assert all(r["before_header_097"]["allowed"] and not r["after_header_097"]["allowed"] for r in origin["records"])
assert [r["before_lexical_096"]["allowed"] for r in origin["records"]]==[True,True,True,False,False]
for path in origin["stage_refs"].values():
    old=json.loads((OUT/path).resolve().read_text())
    assert all(value==source[name] for name,value in old.items() if name not in {"src/sql_safety_executor/core/policy.py","src/sql_safety_executor/core/sql.py"})
full=read_log("v381-cte-header-full.log")
match=re.search(r"(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s",full)
assert match and match.group(1,2,3)==("1517","4","73")
assert "132 passed, 2 warnings in 4.78s" in read_log("v381-cte-header-focused.log")
assert "0 errors, 0 warnings" in read_log("v381-cte-header-pyright.log")
assert "Installed prompt resources and routing guidance valid" in read_log("v381-cte-header-prompt.log")
for p in Path("/tmp").glob("v381-cte-header-*.log"):
    (OUT/(p.name+".gz")).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in Path(__file__).parent.glob("*.py"):
    (OUT/(p.name+".gz")).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
old=gzip.decompress((OUT/"baseline_policy.py.gz").read_bytes()).decode()
(OUT/"change_from_prior.patch").write_text("".join(difflib.unified_diff(old.splitlines(keepends=True),(ROOT/changed[0]).read_text().splitlines(keepends=True),fromfile="before/"+changed[0],tofile="after/"+changed[0])))
for name in ("installed_wheel.json","adjacent_audit.json"):
    p=OUT/name
    if p.exists():
        (OUT/(name+".gz")).write_bytes(gzip.compress(p.read_bytes(),mtime=0));p.unlink()
before_native=read_result("native_before_restart.json");checkpoint=read_result("native_refresh_checkpoint.json")
assert [r["args"] for r in before_native["records"]]==[r["args"] for r in checkpoint["records"]]
assert all(r["raw"]["structuredContent"]["error_code"]=="relation_scope_unresolved" for r in before_native["records"]+checkpoint["records"])
automation={"version":"3.8.1","source_sha256":source,"test_source_sha256":{p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted((ROOT/"tests").rglob("*.py"))},
    "changed_production_files":changed,"new_regressions":132,"focused":{"passed":132,"warnings":2,"seconds":4.78},
    "full_suite":{"passed":1517,"skipped":4,"warnings":73,"seconds":float(match[4]),"mysql_optin":False,"performance_comparison":False},
    "pyright":{"errors":0,"warnings":0},"prompt_contract":"passed","baseline_client_calls":80,"after_client_calls":80,"installed_cli_stdio_calls":80,"current_source_real_mysql_checks":12,
    "header_matrix":{"native_cases":576,"prior_allowances_closed":96,"function_denials":384,"earlier_shape_denials":192,"normal_controls":12},
    "relation_context_matrix":{"native_valid_cases":1000,"scope_misses":0,"approved_refusals":0},
    "repeated_relation_matrix":{"native_valid_cases":542,"scope_misses":0,"conservative_refusals":18,"quoted_recoveries":18},
    "origin_check":"Pre-existing lock/delay header exclusion omission; 096 consolidation also introduced file/account regression; archived-source reconstruction kept distinct from native Host",
    "previous_lexical_patch_native":{"passed":10,"failed":0,"source_reference":"../lexical_identity_2026_10_15/automation.json"},
    "resident_host":"Current source/package accepted; native identical probes still show old relation_scope_unresolved, final maintainer restart pending",
    "configured_database_writes":False,"production_config_changes":False,"new_model_usage_or_latency_claim":False,"prior_artifact_counts_verified":previous,
    "retained_attempts":[{"artifact":"v381-cte-header-matrix-initial.log.gz","reason":"Initial matrix wrongly required the function-specific code even where MATERIALIZED was already denied by earlier statement-shape policy; final data separates 192 unchanged earlier refusals"}]}
if (OUT/"native_after_restart.json").exists():
    native=read_result("native_after_restart.json")
    assert native["checks"]["failed"]==0 and native["checks"]["passed"]==10
    assert [r["args"] for r in native["records"][:2]]==[r["args"] for r in before_native["records"]]
    assert [r["raw"]["structuredContent"]["error_code"] for r in native["records"][:2]]==["expensive_function_denied","server_state_denied"]
    automation["resident_host"]="Same-input native checks and controls passed after maintainer restart"
    automation["resident_host_checks"]=native["checks"]
(OUT/"automation.json").write_text(json.dumps(automation,ensure_ascii=False,indent=2)+"\n")
links=0
for line in subprocess.check_output(["git","status","--porcelain"],cwd=ROOT,text=True).splitlines():
    p=ROOT/line[3:]
    if not p.is_file() or p.suffix!=".md":continue
    for target in re.findall(r"\]\(([^)\n]+)\)",p.read_text()):
        target=target.strip().strip("<>")
        if "://" in target or target.startswith(("#","mailto:","data:")):continue
        filename=target.split("#",1)[0]
        if filename:
            resolved=(p.parent/unquote(filename)).resolve()
            assert resolved==OUT/"manifest.json" or resolved.exists(),(p,filename)
            links+=1
for name in ("DESIGN_RISK_REGISTER.md","DESIGN_RISK_REGISTER_ZH.md"):
    lines=(ROOT/"docs/security"/name).read_text().splitlines()
    ids=[m[1] for line in lines if (m:=re.match(r"^\| DRR-2026-(\d{3}) \|",line))]
    assert sorted(ids)==[f"{i:03}" for i in range(1,98)]
    i=next(i for i,line in enumerate(lines) if line.startswith("| DRR-2026-097 |"))
    assert lines[i-1].startswith("| DRR-2026-096 |")
draft=(ROOT/"local_archive/v381_review/commit-message-complete-v381.txt").read_text()
assert len(draft)<850 and sum(line.startswith("- ") for line in draft.splitlines())==7 and "through 097" in draft and "including CTE bodies" in draft
subprocess.run(["git","diff","--check"],cwd=ROOT,check=True)
assert not subprocess.check_output(["git","diff","--","pyproject.toml","uv.lock"],cwd=ROOT)
(OUT/"document_checks.json").write_text(json.dumps({"local_file_links":links,"bilingual_drr_ids":97,"latest_drr_contiguous":True,"commit_draft_bullets":7,"commit_draft_characters":len(draft),"diff_check":"passed","scope":"Changed Markdown local targets and latest DRR; not every remote link or anchor"},indent=2)+"\n")
manifest={"version":"3.8.1","source_reference":"automation.json#source_sha256","recording_profile":"Source/test hashes, compressed native private truth and application records/check logs, available Host content/structuredContent/isError; not full protocol frames",
    "omitted":["Full JSON-RPC frames/notifications","No new model usage/cost or measured latency comparison","No real locking/delay/file/account function execution or MySQL ANSI_QUOTES grammar assertion"],
    "cleanup":"Task-private SQLite/CLI/install processes and directories auto-cleaned; configured resident/database/TOML untouched","prior_evidence":"Prior manifests byte-verified; previous native/model results not relabeled","artifacts":[]}
for p in sorted(OUT.iterdir()):
    if not p.is_file() or p.name=="manifest.json":continue
    b=p.read_bytes();row={"path":p.name,"bytes":len(b),"sha256":sha(b)}
    if p.suffix==".gz":
        raw=gzip.decompress(b);row.update(uncompressed_bytes=len(raw),uncompressed_sha256=sha(raw))
    manifest["artifacts"].append(row)
(OUT/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"full_passed":1517,"new_regressions":132,"source_files":len(source),"test_files":len(automation["test_source_sha256"]),"changed":changed,"calls_per_stage":80,"installed_calls":80,"live_mysql":12,"native_header_cases":576,"prior_allowances_closed":96,"context_cases":1000,"repeated_cases":542,"local_links":links,"drr_ids":97,"draft_characters":len(draft),"artifacts":len(manifest["artifacts"]),"resident_host":automation["resident_host"]}))
