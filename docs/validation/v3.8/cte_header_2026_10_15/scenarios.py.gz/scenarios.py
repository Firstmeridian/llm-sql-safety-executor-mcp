"""Identical private Client/installed stdio requests around CTE header scanning."""
from fastmcp import Client
from fastmcp.client.transports import StdioTransport
import sqlite3

CASES=[
    ("sleep","SLEEP(0)","expensive_function_denied"),
    ("benchmark","BENCHMARK(0,1)","expensive_function_denied"),
    ("get-lock","GET_LOCK('fixture',0)","lock_function_denied"),
    ("file","LOAD_FILE(NULL)","file_operation_denied"),
    ("account","USER()","server_state_denied"),
]
def wrapped(call):
    return f'WITH "x"(n) AS (SELECT {call}) SELECT n FROM "x"'
SAFE="WITH user(n) AS (SELECT 7) SELECT n FROM user"
def populate_fixture(directory,admitted=True):
    directory.mkdir(exist_ok=True)
    with sqlite3.connect(directory/"fixture.sqlite") as db:
        db.executescript("CREATE TABLE orders(n);INSERT INTO orders VALUES(7);")
        for _,call,_ in CASES:
            name=call.split("(")[0];db.create_function(name,-1,lambda *args:7)
            assert db.execute(wrapped(call)).fetchall()==[(7,)]
    (directory/"server.toml").write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="demo"\n')
    read='mode="all"' if admitted else 'mode="allowlist"\ntables=["orders"]'
    (directory/"connections.toml").write_text('schema_version=1\n[connections.demo]\ntype="sqlite"\n[connections.demo.sqlite]\npath="fixture.sqlite"\n[connections.demo.read]\n'+read+'\n')
    (directory/"skills.toml").write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=false\n[skills.audit]\npath="audit.jsonl"\n')
    sqls={name:wrapped(call) for name,call,_ in CASES};sqls["safe-user"]=SAFE
    for name,sql in sqls.items():
        skill=directory/"skills"/name;skill.mkdir(parents=True)
        (skill/"skill_def.md").write_text(f"---\nname: {name}\ntype: query\nsource: query.sql\nrisk: low\ndescription: CTE declaration body boundary\nparams: {{}}\n---\n")
        (skill/"query.sql").write_text(sql)
async def check_client(client,mode,*,admitted,expect_fixed):
    names=[name for name,_,_ in CASES]+["safe-user"]
    requests=[("query",{"sql":wrapped(call)}) for _,call,_ in CASES]
    requests += [("query",{"sql":'WITH "x"(n) AS (SELECT 7) SELECT n FROM "x"'}),("query",{"sql":SAFE}),("list_skills",{"detail_level":"full","available_only":False})]
    requests += [("get_skill_detail",{"skill_name":name,"detail_level":"full"}) for name in names]
    requests += [("execute_query_skill",{"skill_name":name,"params":{}}) for name in names]
    records=[]
    for tool,args in requests:
        r=await client.call_tool(tool,args,raise_on_error=False)
        records.append({"tool":tool,"arguments":args,"isError":r.is_error,"structuredContent":r.structured_content,
            "content":[c.model_dump(mode="json",exclude_none=True) for c in r.content],"meta":r.meta})
    assert records[6]["structuredContent"]["data"]==[{"n":7}]
    if admitted:assert records[5]["structuredContent"]["data"]==[{"n":7}]
    else:assert records[5]["structuredContent"]["error_code"]=="relation_scope_unresolved"
    listed={s["name"] for s in records[7]["structuredContent"]["skills"]}
    if expect_fixed:
        assert listed=={"safe-user"},listed
        for record,(_,_,code) in zip(records[:5],CASES):
            assert not record["isError"] and record["structuredContent"]["error_code"]==code
        assert all(r["isError"] for r in records[8:13]+records[14:19])
    else:
        assert listed==set(names),listed
        assert all(r["structuredContent"]["error_code"]==("unknown_function" if admitted else "relation_scope_unresolved") for r in records[:5])
    assert records[19]["structuredContent"]["data"]==[{"n":7}]
    return {"mode":mode,"admitted":admitted,"readiness_check_schema":False,"requests":requests,"calls":records}
async def check_installed(target,fixture,logs):
    import sys
    records=[]
    for mode in ("legacy","auto"):
        for admitted in (False,True):
            stage=fixture/f"{mode}-{admitted}";populate_fixture(stage,admitted)
            transport=StdioTransport(command=sys.executable,args=["-m","sql_safety_executor","serve","--config",str(stage/"server.toml")],
                env={"PYTHONPATH":str(target)},cwd=str(stage),keep_alive=False,log_file=logs/f"installed-{mode}-{admitted}.log")
            async with Client(transport,mode=mode) as client:
                records.append(await check_client(client,mode,admitted=admitted,expect_fixed=True))
    return records
