"""Compare two archived stages without changing imports or historical records."""
import gzip,hashlib,json,sqlite3
from pathlib import Path
from types import ModuleType
from sql_safety_executor.core.policy import _validate_sql_query_policy
from sql_safety_executor.database.models import ConnectionPolicy
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/cte_header_2026_10_15"
stages={}
for label,folder in [("before_lexical_096","lexical_identity_2026_10_15"),("before_header_097","cte_header_2026_10_15")]:
    directory=ROOT/"docs/validation/v3.8"/folder
    source=json.loads((directory/"baseline_source.json").read_text())
    modules={}
    for name in ("sql","policy"):
        raw=gzip.decompress((directory/f"baseline_{name}.py.gz").read_bytes())
        assert hashlib.sha256(raw).hexdigest()==source[f"src/sql_safety_executor/core/{name}.py"]
        module=ModuleType("sql_safety_executor.core._origin_"+label+"_"+name);module.__package__="sql_safety_executor.core"
        exec(compile(raw,f"archived_{label}_{name}.py","exec"),module.__dict__);modules[name]=module
    modules["policy"].classify_sql_statement=modules["sql"].classify_sql_statement
    modules["policy"].has_unsafe_mysql_comment_semantics=modules["sql"].has_unsafe_mysql_comment_semantics
    stages[label]={"policy":modules["policy"]._validate_sql_query_policy,"baseline_ref":f"../{folder}/baseline_source.json"}
records=[];p=ConnectionPolicy(read_mode="all",allowed_tables=frozenset({"*"}))
for call in ("SLEEP(0)","BENCHMARK(0,1)","GET_LOCK('fixture',0)","LOAD_FILE(NULL)","USER()"):
    sql=f'WITH "x"(n) AS (SELECT {call}) SELECT n FROM "x"'
    with sqlite3.connect(":memory:") as db:
        db.create_function(call.split("(")[0],-1,lambda *args:7)
        truth=[list(r) for r in db.execute(sql).fetchall()]
        assert truth==[[7]]
    row={"sql":sql,"native_rows":truth}
    for label,stage in stages.items():
        d=stage["policy"](None,sql,p)
        row[label]={"allowed":d.allowed,"code":d.error_code}
    current=_validate_sql_query_policy(None,sql,p)
    row["after_header_097"]={"allowed":current.allowed,"code":current.error_code}
    assert row["before_header_097"]["allowed"] and not current.allowed
    assert row["before_lexical_096"]["allowed"]==(call.split("(")[0] in {"SLEEP","BENCHMARK","GET_LOCK"})
    records.append(row)
data={"scope":"Hash-verified archived-module reconstruction plus direct native private SQLite UDF truth; not historical native Host observations",
    "stage_refs":{label:stage["baseline_ref"] for label,stage in stages.items()},"records":records,
    "conclusion":"Lock/delay declaration exclusion omission predates 096; routing file/account calls through the shared scanner in 096 extended that omission to those categories. 097 repairs the header exclusion boundary."}
(OUT/"origin_check.json").write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"checked":len(records),"prior_lock_delay_omission":3,"096_file_account_regression":2,"after_denied":5}))
