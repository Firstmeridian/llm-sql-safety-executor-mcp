"""Source-attributed baseline and final application records; private fixtures only."""
import argparse,asyncio,gzip,hashlib,json,tempfile
from pathlib import Path
from fastmcp import Client
from sql_safety_executor import create_server,load_config
from scenarios import populate_fixture,check_client
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/cte_header_2026_10_15"
p=argparse.ArgumentParser();p.add_argument("--stage",choices=("before","after"),required=True);args=p.parse_args()
OUT.mkdir(parents=True,exist_ok=True)
source={f.relative_to(ROOT).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if f.is_file() and f.suffix in (".py",".md")}
async def main():
    records=[]
    for mode in ("legacy","auto"):
        for admitted in (False,True):
            with tempfile.TemporaryDirectory(prefix="v381-cte-header-") as directory:
                stage=Path(directory);populate_fixture(stage,admitted)
                server=create_server(load_config(stage/"server.toml"))
                try:
                    async with Client(server,mode=mode) as client:
                        records.append(await check_client(client,mode,admitted=admitted,expect_fixed=args.stage=="after"))
                finally:server.gateway_runtime.close()
    data={"version":"3.8.1","stage":args.stage,"source_sha256":source,"total_calls":sum(len(r["requests"]) for r in records),"records":records,
        "recording_profile":"Application content/structuredContent/isError/meta, not full protocol frames","configured_database_writes":False}
    (OUT/f"{args.stage}-calls.json.gz").write_bytes(gzip.compress((json.dumps(data,ensure_ascii=False,indent=2)+"\n").encode(),mtime=0))
    if args.stage=="before":
        assert source==json.loads((ROOT/"docs/validation/v3.8/lexical_identity_2026_10_15/automation.json").read_text())["source_sha256"]
        (OUT/"baseline_source.json").write_text(json.dumps(source,indent=2)+"\n")
        for name in ("policy",):
            (OUT/f"baseline_{name}.py.gz").write_bytes(gzip.compress((ROOT/f"src/sql_safety_executor/core/{name}.py").read_bytes(),mtime=0))
    print(json.dumps({"stage":args.stage,"calls":data["total_calls"]}))
asyncio.run(main())
