"""Verify the expanded assessment without changing older sealed evidence."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[5]
HERE = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    if path.exists():
        return json.loads(path.read_text())
    return json.loads(gzip.decompress(path.with_suffix(path.suffix + '.gz').read_bytes()))


def expected_columns(rows):
    answer = []
    for r in rows:
        if r[6] == 1:
            continue
        entry = dict(column_name=r[1], data_type=r[2], nullable='NO' if r[3] else 'YES',
            key_type='PRI' if r[5] else '', default_value=r[4])
        if r[6] in (2, 3):
            entry['generation_type'] = {2: 'virtual', 3: 'stored'}[r[6]]
        answer.append(entry)
    return answer


def expected_indexes(truth):
    answer = []
    for entry in truth['indexes']:
        _, name, unique, origin, partial = entry['listed']
        parts = [p for p in entry['parts'] if p[5] == 1]
        index = dict(name=name, primary=origin == 'pk', unique=bool(unique),
            columns=[p[2] for p in parts], key_parts=[dict(column=p[2],
            sort_order='desc' if p[3] else 'asc', collation=p[4]) for p in parts], partial=bool(partial))
        if any(p[1] == -2 for p in parts):
            index['has_expression'] = True
        answer.append(index)
    pk = [r for r in sorted(truth['columns'], key=lambda r: r[5]) if r[5]]
    if pk and not any(i['primary'] for i in answer):
        answer.append(dict(name=None, primary=True, unique=True, columns=[r[1] for r in pk],
            key_parts=[dict(column=r[1], sort_order=None, collation=None) for r in pk], partial=False))
    return sorted(answer, key=lambda i: (not i['primary'], i['name'] or ''))


before = read(HERE / 'baseline/current.json')
source, wheel = [read(HERE / ('evidence/' + n + '.json')) for n in ['source', 'installed']]
assert source['calls'] == wheel['calls'] and source['truth'] == wheel['truth']
assert source['package'] != wheel['package']
assert len(source['truth']) == 16 and len(source['calls']) == len(wheel['calls']) == 92
known_order_limits = set()
for data in [source, wheel]:
    assert data['fixtures_cleaned'] and data['database_unchanged']
    counts = {}
    for call in data['calls']:
        result = call['structured']
        assert not call['isError'] and json.loads(call['content'][0]['text']) == result
        key = call['transport'] + ':' + call['mode']
        counts[key] = counts.get(key, 0) + 1
        if call['tool'] == 'describe_table':
            truth = data['truth'][call['case']]
            assert result['success'] and result['indexes_status'] == 'complete'
            assert result['columns'] == expected_columns(truth['columns'])
            assert result['column_count'] == len(result['columns'])
            assert result['indexes'] == expected_indexes(truth)
        elif call['case'] in {'compact', 'ungrouped'}:
            assert result['success'] and result['total_columns'] == 25 and result['total_tables'] == 14
            for group in result['schema_groups']:
                for table in group['tables']:
                    rows = data['truth'][table['name']]['columns']
                    assert group['columns'] == [[r[1], r[2]] for r in rows if r[6] != 1]
                    members = [r[1] for r in rows if r[5]]
                    assert group['primary_key'] == members
                    positions = [r[1] for r in sorted(rows, key=lambda r: r[5]) if r[5]]
                    if positions != members:
                        known_order_limits.add(table['name'])
            if call['case'] == 'ungrouped':
                assert result['schema_group_count'] == 14
            else:
                assert result['schema_group_count'] == 11
                by_table = {t['name']: group for group in result['schema_groups'] for t in group['tables']}
                # False-like defaults must remain distinct in the grouping signature.
                assert len({id(by_table[n]) for n in ['defaults_none', 'defaults_null', 'defaults_zero', 'defaults_empty', 'defaults_expr']}) == 5
        elif call['case'] == 'full':
            assert result['total_columns'] == 25 and result['total_tables'] == 14
            for name, table in result['schema'].items():
                expected = [dict(name=c['column_name'], type=c['data_type'], nullable=c['nullable'],
                    key=c['key_type'], default=c['default_value'],
                    **({'generation_type': c['generation_type']} if 'generation_type' in c else {}))
                    for c in expected_columns(data['truth'][name]['columns'])]
                assert table['columns'] == expected
        elif call['case'] == 'rowid_alias':
            assert result['data'] == [{'a': 7, 'b': 'x'}]
        elif call['case'] == 'generated_mix':
            assert result['data'] == [{'base': 7, 'gv': 8, 'gs': '7'}]
        else:
            assert not result['success']
            assert result['error_code'] == {'secret_denied': 'table_access_denied', 'sleep_denied': 'expensive_function_denied'}[call['case']]
    assert counts == {t + ':' + m: 23 for t in ['inprocess', 'stdio'] for m in ['auto', 'legacy']}
assert known_order_limits == {'composite_desc', 'without_rowid', 'repeated_pk'}
live = read(HERE / 'evidence/mysql_live.json')
assert live['objects'] == 8 and live['single_batch_equal'] and not live['primary_key_mismatches']
component = read(HERE / 'evidence/mysql_component.json')
assert component['compact_inference_from_flags'] == ['n'] and not component['actual_primary_indexes']
for name, digest in before['resources'].items():
    assert sha(ROOT / name) == digest
    relative = name.removeprefix('src/sql_safety_executor/')
    assert sha(Path(wheel['package']) / relative) == digest
for name, digest in before['private_toml_sha256'].items():
    assert sha(ROOT / name) == digest
records = 0
for spec in before['prior_seals']:
    manifest = ROOT / spec['manifest']
    assert sha(manifest) == spec['sha256']
    data = read(manifest)
    items = data['files'].items() if isinstance(data['files'], dict) else ((v['path'], v) for v in data['files'])
    paths = {}
    count = 0
    for name, meta in items:
        path = next(p for p in [manifest.parent / name, manifest.parent.parent / name, ROOT / name] if p.is_file())
        paths[name] = path
        assert sha(path) == (meta['sha256'] if isinstance(meta, dict) else meta)
        if isinstance(meta, dict):
            if 'bytes' in meta:
                assert path.stat().st_size == meta['bytes']
            if 'decoded_sha256' in meta:
                raw = gzip.decompress(path.read_bytes())
                assert hashlib.sha256(raw).hexdigest() == meta['decoded_sha256'] and len(raw) == meta['decoded_bytes']
        count += 1
    for name, meta in data.get('compressed_decoded_records', {}).items():
        raw = gzip.decompress(paths[name].read_bytes())
        assert hashlib.sha256(raw).hexdigest() == meta.get('decoded_sha256', meta.get('sha256'))
        assert len(raw) == meta.get('decoded_bytes', meta.get('bytes'))
    assert count == spec['files']
    records += count
assert len(before['prior_seals']) == 69 and records == 2154
summary = dict(source_calls=92, installed_calls=92, application_records_equal=True,
    sqlite_objects=16, tables=14, views=2, columns_in_tables=25, calls_per_mode_transport=23,
    schema_projection_and_indexes_match_native=True, defaults_not_collapsed=True,
    known_DRR141_order_limits=sorted(known_order_limits),
    new_confirmed_P1_P2=0, new_independent_production_defects=0,
    mysql_existing_tables=8, mysql_columns=sum(len(t['columns']) for t in live['catalog'].values()),
    mysql_single_batch_equal=True, mysql_live_primary_key_mismatches=[],
    mysql_unique_flag_boundary='Officially documented possibility confirmed only with synthetic catalog; not reproduced on the eight live tables',
    repeated_pk_boundary='table_xinfo gives per-column positions; index_xinfo preserves repeated key parts. Member positions alone are not full physical index structure.',
    capability_gaps='MySQL generated/invisible markers, full type specifications and full DDL are outside current documented projection; not reclassified as new regressions.',
    resources_unchanged=77, installed_resources_match=77, private_tomls_unchanged=3,
    prior_manifests_unchanged=69, prior_records_unchanged=2154,
    builds=0, installs=0, full_suite_runs=0, native_host_calls=0, model_trials=0,
    limitations='Bounded assessment only. No new MySQL fixture, server-version matrix, exhaustive audit, measured performance or model-token conclusion.')
(HERE / 'evidence/assessment.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
