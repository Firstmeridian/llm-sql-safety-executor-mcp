"""Bounded adjacent metadata assessment; only disposable SQLite is written."""
import argparse
import asyncio
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile

from fastmcp import Client
from fastmcp.client.transports import StdioTransport
from sql_safety_executor import create_server, load_config
import sql_safety_executor
from sql_safety_executor.database.registry import create_adapter
from sql_safety_executor.database.models import DatabaseConfig, ConnectionPolicy
from sql_safety_executor.database.mysql import MySQLAdapter


def quote(name):
    return '"' + name.replace('"', '""') + '"'


def write_toml(path, data):
    def value(v):
        if isinstance(v, dict):
            return '{' + ','.join(json.dumps(k) + '=' + value(x) for k, x in v.items()) + '}'
        if isinstance(v, list):
            return '[' + ','.join(value(x) for x in v) + ']'
        return json.dumps(v, ensure_ascii=False)
    path.write_text('\n'.join(json.dumps(k) + '=' + value(v) for k, v in data.items()) + '\n')


DDL = '''
CREATE TABLE rowid_alias(a INTEGER PRIMARY KEY, b TEXT);
INSERT INTO rowid_alias VALUES(7,'x');
CREATE TABLE rowid_desc(a INTEGER PRIMARY KEY DESC, b TEXT);
CREATE TABLE composite_desc(a TEXT COLLATE NOCASE, b INTEGER, PRIMARY KEY(b DESC,a ASC));
CREATE TABLE without_rowid(a TEXT COLLATE NOCASE, b INTEGER, PRIMARY KEY(b DESC,a ASC)) WITHOUT ROWID;
CREATE TABLE unique_mix(a TEXT,b INTEGER,UNIQUE(a,b),UNIQUE(b));
CREATE TABLE defaults_none(n TEXT);
CREATE TABLE defaults_null(n TEXT DEFAULT NULL);
CREATE TABLE defaults_zero(n INTEGER DEFAULT 0);
CREATE TABLE defaults_empty(n TEXT DEFAULT '');
CREATE TABLE defaults_expr(n TEXT DEFAULT (lower('A')));
CREATE TABLE generated_mix(base INTEGER,gv AS(base+1) VIRTUAL,gs TEXT AS(base||'') STORED);
INSERT INTO generated_mix(base) VALUES(7);
CREATE INDEX ix_generated ON generated_mix(gv DESC,gs ASC);
CREATE TABLE "dot.K x"("a b" TEXT,"K" INTEGER,"f  " TEXT);
CREATE INDEX "ix.'' K" ON "dot.K x"("a b" COLLATE RTRIM DESC,"f  " ASC);
CREATE TABLE expression_partial(a TEXT,b INTEGER);
CREATE INDEX ix_expression ON expression_partial(lower(a) COLLATE NOCASE DESC,b ASC) WHERE b<1;
CREATE TABLE repeated_pk(a TEXT,b INTEGER,PRIMARY KEY(b,a,b));
CREATE VIEW expression_view AS SELECT 7 AS n;
CREATE VIEW cast_view AS SELECT CAST(7 AS TEXT) AS n;
CREATE TABLE secret(n TEXT);
INSERT INTO secret VALUES('private');
'''


def truth_for(db, name):
    columns = [list(r) for r in db.execute(f'PRAGMA main.table_xinfo({quote(name)})')]
    indexes = []
    for row in db.execute(f'PRAGMA main.index_list({quote(name)})'):
        indexes.append({'listed': list(row), 'parts': [list(r) for r in db.execute(f'PRAGMA main.index_xinfo({quote(row[1])})')]})
    return {'columns': columns, 'indexes': indexes}


async def sqlite_probe(output, scope):
    calls, truth = [], {}
    with tempfile.TemporaryDirectory(prefix='v382-metadata-expanded-') as temporary:
        folder = Path(temporary)
        database = folder / 'fixture.sqlite'
        with sqlite3.connect(database) as db:
            db.executescript(DDL)
            names = [r[0] for r in db.execute("SELECT name FROM sqlite_schema WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' AND name!='secret' ORDER BY name")]
            truth = {name: truth_for(db, name) for name in names}
            truth_values = {name: [list(r) for r in db.execute(sql)] for name, sql in {
                'rowid_alias': 'SELECT a,b FROM rowid_alias',
                'generated_mix': 'SELECT base,gv,gs FROM generated_mix'}.items()}
        digest = hashlib.sha256(database.read_bytes()).hexdigest()
        write_toml(folder / 'server.toml', {'schema_version': 1, 'server': {'default_connection': 'scoped'},
            'files': {'connections': 'connections.toml'}, 'tools': {'table_summary': True}})
        # Component declarations preserve a single name containing a dot.
        write_toml(folder / 'connections.toml', {'schema_version': 1, 'connections': {'scoped': {
            'type': 'sqlite', 'sqlite': {'path': str(database)},
            'read': {'mode': 'allowlist', 'relations': [{'schema': 'main', 'name': n} for n in names]}}}})
        for transport in ['inprocess', 'stdio']:
            for mode in ['auto', 'legacy']:
                server = create_server(load_config(folder / 'server.toml')) if transport == 'inprocess' else None
                target = server or StdioTransport(command=sys.executable, args=[str(Path(__file__).resolve()), '--child', str(folder / 'server.toml')], env={})
                try:
                    async with asyncio.timeout(45), Client(target, mode=mode) as client:
                        cases = [(n, 'describe_table', {'table_name': n}) for n in names]
                        cases += [('compact', 'get_full_schema', {'detail_level': 'compact'}),
                                  ('ungrouped', 'get_full_schema', {'detail_level': 'compact', 'group_identical': False}),
                                  ('full', 'get_full_schema', {'detail_level': 'full'}),
                                  ('rowid_alias', 'query', {'sql': 'SELECT a,b FROM main.rowid_alias'}),
                                  ('generated_mix', 'query', {'sql': 'SELECT base,gv,gs FROM main.generated_mix'}),
                                  ('secret_denied', 'query', {'sql': 'SELECT n FROM main.secret'}),
                                  ('sleep_denied', 'query', {'sql': 'SELECT SLEEP(0)'})]
                        for case, tool, arguments in cases:
                            result = await client.call_tool(tool, {'connection_id': 'scoped', **arguments}, raise_on_error=False)
                            row = {'transport': transport, 'mode': mode, 'case': case, 'tool': tool,
                                'isError': result.is_error, 'structured': result.structured_content,
                                'content': [c.model_dump(mode='json', exclude_none=True) for c in result.content]}
                            assert not result.is_error and json.loads(row['content'][0]['text']) == row['structured']
                            assert row['structured']['success'] == (not case.endswith('_denied'))
                            calls.append(row)
                finally:
                    if server:
                        server.gateway_runtime.close()
        assert hashlib.sha256(database.read_bytes()).hexdigest() == digest
    output.write_text(json.dumps({'scope': scope, 'package': str(Path(sql_safety_executor.__file__).parent),
        'sqlite_version': sqlite3.sqlite_version, 'truth': truth, 'truth_values': truth_values,
        'calls': calls, 'database_unchanged': True, 'fixtures_cleaned': not Path(temporary).exists()}, indent=2) + '\n')
    print(json.dumps({'calls': len(calls), 'objects': len(truth), 'scope': scope}))


def mysql_probe(output):
    config = load_config('config/server.toml').connections['trade_analysis_mysql']
    adapter = create_adapter(config=config)
    try:
        tables = adapter._execute_metadata(
            "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=:s AND TABLE_TYPE='BASE TABLE' ORDER BY TABLE_NAME LIMIT 100",
            'assessing existing metadata', params={'s': adapter.metadata_schema})
        names = [r[0] for r in tables if config.policy.allows_metadata_table(r[0], adapter.metadata_schema)]
        catalog, mismatches = {}, []
        for name in names:
            columns = adapter.get_columns(name)
            indexes = adapter.get_indexes(name)
            actual = next((i['columns'] for i in indexes if i['primary']), [])
            advertised = [c['column_name'] for c in columns if c['key_type'] == 'PRI']
            catalog[name] = {'columns': columns, 'indexes': indexes, 'primary_key_from_column_flags': advertised,
                'primary_key_from_indexes': actual}
            if advertised != actual:
                mismatches.append(name)
        # Bounded single/batch identity check, with no data reads or object writes.
        batch = adapter.get_columns_batch(names)
        assert all(batch[n] == catalog[n]['columns'] for n in names)
        output.write_text(json.dumps({'scope': 'Read-only existing configured alias; no DDL or business data writes',
            'connection_id': config.connection_id, 'objects': len(names), 'catalog': catalog,
            'primary_key_mismatches': mismatches, 'single_batch_equal': True}, default=str, indent=2) + '\n')
        print(json.dumps({'objects': len(names), 'primary_key_mismatches': mismatches}))
    finally:
        adapter.close()


def mysql_component(output):
    # An independently documented catalog possibility, not a live server reproduction.
    adapter = MySQLAdapter(DatabaseConfig('component', 'mysql', 10, 5,
        ConnectionPolicy(allowed_tables=frozenset({'*'}), read_mode='all'), mysql_database='fixture'))
    def catalog(sql, operation, **kwargs):
        if 'INFORMATION_SCHEMA.COLUMNS' in sql and 'IS_VISIBLE' in sql:
            return [('IS_VISIBLE',)]
        if 'INFORMATION_SCHEMA.STATISTICS' in sql:
            return [('unique_n', 0, 1, 'n', 'BTREE', None, 'A', 'YES')]
        if sql.startswith('SELECT TABLE_NAME'):
            return [('unique_only', 'n', 'int', 'NO', 'PRI', None)]
        return [('n', 'int', 'NO', 'PRI', None)]
    adapter._execute_metadata = catalog
    columns = adapter.get_columns('unique_only')
    batch = adapter.get_columns_batch(['unique_only'])
    indexes = adapter.get_indexes('unique_only')
    output.write_text(json.dumps({'scope': 'Component catalog fixture only; not a live MySQL reproduction',
        'input_columns': [['n', 'int', 'NO', 'PRI', None]], 'columns': columns, 'batch': batch,
        'indexes': indexes, 'compact_inference_from_flags': [c['column_name'] for c in columns if c['key_type'] == 'PRI'],
        'actual_primary_indexes': [i for i in indexes if i['primary']]}, indent=2) + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path)
    parser.add_argument('--scope', default='source')
    parser.add_argument('--child', type=Path)
    parser.add_argument('--mysql-live', action='store_true')
    parser.add_argument('--mysql-component', action='store_true')
    args = parser.parse_args()
    if args.child:
        create_server(load_config(args.child)).run(transport='stdio', show_banner=False)
    else:
        assert args.output and not args.output.exists()
        if args.mysql_live:
            mysql_probe(args.output)
        elif args.mysql_component:
            mysql_component(args.output)
        else:
            asyncio.run(sqlite_probe(args.output, args.scope))
