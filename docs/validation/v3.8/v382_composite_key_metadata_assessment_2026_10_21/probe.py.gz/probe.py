"""Assess compact primary-key membership versus native index order in isolation."""
import argparse
import asyncio
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile

from fastmcp import Client
from fastmcp.client.transports import StdioTransport
from sql_safety_executor import create_server, load_config
import sql_safety_executor

parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path)
parser.add_argument('--scope', default='source')
parser.add_argument('--child', type=Path)
args = parser.parse_args()


def save(path, data):
    def value(v):
        if isinstance(v, dict):
            return '{' + ','.join(json.dumps(k) + '=' + value(x) for k, x in v.items()) + '}'
        if isinstance(v, list):
            return '[' + ','.join(value(x) for x in v) + ']'
        return json.dumps(v, ensure_ascii=False)
    path.write_text('\n'.join(json.dumps(k) + '=' + value(v) for k, v in data.items()) + '\n')


async def main():
    assert args.output and not args.output.exists()
    calls, truth = [], {}
    with tempfile.TemporaryDirectory(prefix='v382-pk-order-') as temporary:
        folder = Path(temporary)
        database = folder / 'fixture.sqlite'
        names = []
        with sqlite3.connect(database) as db:
            for kind, suffix in [('ordinary', ''), ('without_rowid', ' WITHOUT ROWID')]:
                for direction, key in [('ab', 'a,b'), ('ba', 'b,a')]:
                    name = kind + '_' + direction
                    names.append(name)
                    db.execute(f'CREATE TABLE {name}(a INTEGER NOT NULL,b INTEGER NOT NULL,PRIMARY KEY({key})){suffix}')
                    db.execute(f'INSERT INTO {name} VALUES(7,99)')
                    rows = [list(r) for r in db.execute(f"PRAGMA main.table_xinfo('{name}')")]
                    truth[name] = {'columns': rows, 'primary_key': [r[1] for r in sorted(rows, key=lambda r:r[5]) if r[5]],
                                   'index_list': [list(r) for r in db.execute(f"PRAGMA main.index_list('{name}')")]}
        digest = hashlib.sha256(database.read_bytes()).hexdigest()
        save(folder / 'server.toml', {'schema_version': 1, 'server': {'default_connection': 'scoped'},
             'files': {'connections': 'connections.toml'}, 'tools': {'table_summary': True}})
        save(folder / 'connections.toml', {'schema_version': 1, 'connections': {'scoped': {
             'type': 'sqlite', 'sqlite': {'path': str(database)},
             'read': {'mode': 'allowlist', 'tables': names}}}})
        for transport in ['inprocess', 'stdio']:
            for mode in ['auto', 'legacy']:
                server = create_server(load_config(folder / 'server.toml')) if transport == 'inprocess' else None
                target = server or StdioTransport(command=sys.executable, args=[str(Path(__file__).resolve()), '--child', str(folder / 'server.toml')], env={})
                try:
                    async with Client(target, mode=mode) as client:
                        cases = [(n, 'describe_table', {'table_name': n}) for n in names]
                        cases += [(n, 'query', {'sql': f'SELECT a,b FROM main.{n}'}) for n in names]
                        cases += [('compact', 'get_full_schema', {'detail_level': 'compact'}),
                                  ('ungrouped', 'get_full_schema', {'detail_level': 'compact', 'group_identical': False}),
                                  ('full', 'get_full_schema', {'detail_level': 'full'})]
                        for case, tool, arguments in cases:
                            arguments = {'connection_id': 'scoped', **arguments}
                            result = await client.call_tool(tool, arguments, raise_on_error=False)
                            row = {'transport': transport, 'mode': mode, 'case': case, 'tool': tool, 'arguments': arguments,
                                   'isError': result.is_error, 'structured': result.structured_content,
                                   'content': [c.model_dump(mode='json', exclude_none=True) for c in result.content]}
                            assert not result.is_error and row['structured']['success']
                            assert json.loads(row['content'][0]['text']) == row['structured']
                            calls.append(row)
                finally:
                    if server:
                        server.gateway_runtime.close()
        assert hashlib.sha256(database.read_bytes()).hexdigest() == digest
    output = {'scope': args.scope, 'package': str(Path(sql_safety_executor.__file__).parent),
              'sqlite_version': sqlite3.sqlite_version, 'truth': truth, 'calls': calls,
              'fixtures_cleaned': not Path(temporary).exists(), 'database_unchanged': True}
    args.output.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({'calls': len(calls), 'objects': len(truth), 'scope': args.scope}))


if __name__ == '__main__':
    if args.child:
        create_server(load_config(args.child)).run(transport='stdio', show_banner=False)
    else:
        asyncio.run(main())
