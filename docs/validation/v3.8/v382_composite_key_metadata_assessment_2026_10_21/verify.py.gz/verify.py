"""Verify the scoped metadata limitation, not an authorization or grouping breach."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text()) if path.exists() else json.loads(gzip.decompress(path.with_suffix(path.suffix + '.gz').read_bytes()))


before = read(HERE / 'baseline/current.json')
source, wheel = [read(HERE / ('evidence/' + n + '.json')) for n in ['source', 'installed']]
assert len(source['calls']) == len(wheel['calls']) == 44
assert source['calls'] == wheel['calls'] and source['truth'] == wheel['truth']
for data in [source, wheel]:
    assert data['fixtures_cleaned'] and data['database_unchanged']
    groups = {}
    for row in data['calls']:
        value = row['structured']
        assert not row['isError'] and value['success']
        assert json.loads(row['content'][0]['text']) == value
        key = row['transport'] + ':' + row['mode']
        groups[key] = groups.get(key, 0) + 1
        if row['tool'] == 'describe_table':
            assert next(i['columns'] for i in value['indexes'] if i['primary']) == data['truth'][row['case']]['primary_key']
        if row['tool'] == 'query':
            assert value['data'] == [{'a': 7, 'b': 99}]
        if row['case'] in {'compact', 'ungrouped'}:
            assert all(g['primary_key'] == ['a', 'b'] for g in value['schema_groups'])
            assert value['schema_group_count'] == (1 if row['case'] == 'compact' else 4)
            assert value['grouping_basis'] == ('adapter_visible_column_metadata_and_order' if row['case'] == 'compact' else 'none')
    assert groups == {t + ':' + m: 11 for t in ['inprocess', 'stdio'] for m in ['auto', 'legacy']}
for name, digest in before['resources'].items():
    assert sha(ROOT / name) == digest
for name, digest in before['private_toml_sha256'].items():
    assert sha(ROOT / name) == digest
count = 0
for spec in before['prior_seals']:
    manifest = ROOT / spec['manifest']
    assert sha(manifest) == spec['sha256']
    data = read(manifest)
    items = data['files'].items() if isinstance(data['files'], dict) else ((v['path'], v) for v in data['files'])
    paths = {}
    size = 0
    for name, file in items:
        p = next(p for p in [manifest.parent / name, manifest.parent.parent / name, ROOT / name] if p.is_file())
        paths[name] = p
        assert sha(p) == (file['sha256'] if isinstance(file, dict) else file)
        if isinstance(file, dict):
            if 'bytes' in file:
                assert p.stat().st_size == file['bytes']
            if 'decoded_sha256' in file:
                decoded = gzip.decompress(p.read_bytes())
                assert hashlib.sha256(decoded).hexdigest() == file['decoded_sha256'] and len(decoded) == file['decoded_bytes']
        size += 1
    for name, file in data.get('compressed_decoded_records', {}).items():
        decoded = gzip.decompress(paths[name].read_bytes())
        assert hashlib.sha256(decoded).hexdigest() == file.get('decoded_sha256', file.get('sha256'))
        assert len(decoded) == file.get('decoded_bytes', file.get('bytes'))
    assert size == spec['files']
    count += size
assert len(before['prior_seals']) == 67 and count == 2133
historical = {}
for name in ['core/schema.py', 'database/sqlite.py']:
    data = subprocess.check_output(['git', 'show', '2c0a9e78252849f127a5dc8367f5c42d5209c609:src/sql_safety_executor/' + name], cwd=ROOT).decode()
    historical[name] = '\n'.join(l for l in data.splitlines() if 'primary_key' in l or 'key_type' in l or 'for column in columns_data' in l)
assert '"key_type": "PRI" if row[5] else ""' in historical['database/sqlite.py']
(HERE / 'evidence/historical_code.json').write_text(json.dumps({'commit': '2c0a9e7', 'scope': 'Source comparison only, not old-version Client replay', 'excerpts': historical}, indent=2) + '\n')
summary = {'finding': 'DRR-2026-141', 'classification': 'Existing nonblocking P3 information limitation; compact primary_key lists membership in table-column order, not actual composite-key order',
           'source_calls': 44, 'installed_calls': 44, 'source_wheel_equal': True,
           'groups_per_side': groups, 'objects': 4, 'native_primary_keys': {n:t['primary_key'] for n,t in source['truth'].items()},
           'compact_members_all': ['a', 'b'], 'compact_group_count': 1, 'ungrouped_group_count': 4,
           'describe_index_order_correct': True, 'raw_results_correct': True,
           'not_a_breach_of_documented_grouping_scope': True, 'production_implementation': 'not changed',
           'resources_unchanged': 77, 'private_tomls_unchanged': 3, 'prior_manifests_unchanged': 67, 'prior_records_unchanged': count,
           'new_native_host_calls': 0, 'new_model_trials': 0, 'new_builds': 0, 'new_full_suite_runs': 0,
           'limits': 'Four isolated SQLite composite-key fixtures; no live MySQL metadata or new resident test. Baseline age based on source comparison only. No authorization, result or measured performance regression shown.'}
(HERE / 'evidence/assessment.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
