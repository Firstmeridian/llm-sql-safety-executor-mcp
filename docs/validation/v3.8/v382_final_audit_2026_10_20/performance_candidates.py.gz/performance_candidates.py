"""Measure audit-only candidates, without changing runtime implementation."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
from statistics import median
from time import perf_counter_ns
from types import SimpleNamespace

from sql_safety_executor import load_config
from sql_safety_executor.core import policy as policy_module
from sql_safety_executor.database.models import ConnectionPolicy
from sql_safety_executor.database.semantics import DialectContext

ROOT = Path(__file__).resolve().parents[4]
E = Path(__file__).resolve().parents[1] / 'evidence'
parser = argparse.ArgumentParser()
parser.add_argument('--mysql', action='store_true')
args = parser.parse_args()
OUT = E / ('mysql_column_candidate.json' if args.mysql else 'startup_candidate.json')
assert not OUT.exists()


def paired(a, b, repeats, warmups):
    observations = []
    for i in range(warmups + repeats):
        functions = [('A', a), ('B', b)] if i % 2 == 0 else [('B', b), ('A', a)]
        row = {'phase': 'warmup' if i < warmups else 'timed', 'order': [label for label, _ in functions]}
        for label, function in functions:
            start = perf_counter_ns()
            result = function()
            row[label + '_ms'] = (perf_counter_ns() - start) / 1e6
        observations.append(row)
    timed = [row for row in observations if row['phase'] == 'timed']
    return {'records': observations, 'pairs': repeats, 'warmup_pairs': warmups,
            'A_median_ms': median(row['A_ms'] for row in timed),
            'B_median_ms': median(row['B_ms'] for row in timed),
            'paired_relative_median_percent': median((row['B_ms'] / row['A_ms'] - 1) * 100 for row in timed),
            'pairs_faster': sum(row['B_ms'] < row['A_ms'] for row in timed)}


if not args.mysql:
    policy = ConnectionPolicy(allowed_tables=frozenset({'*'}), allow_union=True)
    runtime = SimpleNamespace(registry=SimpleNamespace(get_config=lambda: SimpleNamespace(policy=policy)))
    contexts = [DialectContext('sqlite'), *[DialectContext('mysql', frozenset(modes)) for modes in (
        (), ('ANSI_QUOTES',), ('NO_BACKSLASH_ESCAPES',), ('ANSI_QUOTES', 'NO_BACKSLASH_ESCAPES'))]]

    def proposed(sql):
        first = None
        for context in contexts:
            decision = policy_module._analysis_decision(policy_module.analyze_sql(sql, context), policy, require_union=False)
            if first is None:
                first = decision
            if decision.allowed:
                return decision
        return first

    corpus = json.loads(gzip.decompress((ROOT / 'local_archive/v382_review/20261020_dialect_comments_not/evidence/after_matrix.json.gz').read_bytes()))['cases']
    original_analysis = policy_module.analyze_sql
    count = 0

    def counted(*values, **keywords):
        global count
        count += 1
        return original_analysis(*values, **keywords)

    policy_module.analyze_sql = counted
    checks = []
    try:
        for case in corpus:
            count = 0
            a = policy_module._validate_sql_template_startup_policy(runtime, case['sql'])
            count_a = count
            count = 0
            b = proposed(case['sql'])
            assert a == b, case
            checks.append({'id': case['id'], 'same_complete_decision': True,
                           'current_analyses': count_a, 'prototype_analyses': count})
    finally:
        policy_module.analyze_sql = original_analysis
    sqls = ['SELECT 7 AS n', 'SELECT n FROM orders',
            'WITH chosen AS (SELECT 7 AS n) SELECT n FROM chosen',
            'SELECT n FROM orders WHERE n BETWEEN 1 AND 7'] * 5

    def original_batch():
        return [policy_module._validate_sql_template_startup_policy(runtime, sql) for sql in sqls]

    def proposed_batch():
        return [proposed(sql) for sql in sqls]

    assert original_batch() == proposed_batch()
    result = {'candidate': 'Stop Query Skill startup candidate checking at first allow',
              'implemented': False, 'corpus_complete_decisions': checks,
              'timed_templates_per_batch': len(sqls), **paired(original_batch, proposed_batch, 30, 5),
              'limits': 'Pure warm classifier microbenchmark only, no disk/YAML/discovery/FastMCP/DB/model/installed or native performance claim. Input corpus is a boundary sample. Actual startup still uses current implementation; rejected templates still visit all five candidates.'}
else:
    from sqlalchemy import event
    from sql_safety_executor.database.mysql import MySQLAdapter
    config = load_config(ROOT / 'config/server.toml')
    adapter = MySQLAdapter(config.connections['sakila_mysql'])
    events = []
    try:
        assert adapter.connect()
        adapter.resolve_analysis_context()
        directory = adapter.get_table_directory()
        names = [row['table_name'] for row in directory
                 if config.connections['sakila_mysql'].policy.allows_metadata_relation(
                     __import__('sql_safety_executor.database.relations', fromlist=['RelationReference']).RelationReference(row['table_name'], adapter.metadata_schema))]
        assert 1 < len(names) <= 200

        def before_cursor(conn, cursor, statement, parameters, context, many):
            events.append('columns' if 'INFORMATION_SCHEMA.COLUMNS' in statement else 'timeout_setup' if statement.startswith('SET SESSION MAX_EXECUTION_TIME') else 'other')

        event.listen(adapter._engine, 'before_cursor_execute', before_cursor)

        def original_columns():
            return {name: adapter.get_columns(name) for name in names}

        params = {'schema_name': adapter.metadata_schema, **{f'table_{index}': name for index, name in enumerate(names)}}
        placeholders = ','.join(':' + name for name in params if name != 'schema_name')
        sql = ('SELECT TABLE_NAME,COLUMN_NAME,DATA_TYPE,IS_NULLABLE,COLUMN_KEY,COLUMN_DEFAULT '
               'FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=:schema_name '
               'AND TABLE_NAME IN (' + placeholders + ') ORDER BY TABLE_NAME,ORDINAL_POSITION')

        def proposed_columns():
            values = {name: [] for name in names}
            rows = adapter._execute_metadata(sql, 'audit-only bounded column candidate', params=params)
            for row in rows:
                # Exact selected catalog names; do not let a database collation
                # comparison introduce any additional projected name.
                if row[0] in values:
                    values[row[0]].append(dict(zip(('column_name', 'data_type', 'nullable', 'key_type', 'default_value'), row[1:])))
            return values

        original = original_columns()
        current_counts = {key: events.count(key) for key in set(events)}
        events.clear()
        candidate = proposed_columns()
        candidate_counts = {key: events.count(key) for key in set(events)}
        assert original == candidate
        event.remove(adapter._engine, 'before_cursor_execute', before_cursor)

        def checked_candidate():
            observed = proposed_columns()
            assert observed == original
            return observed

        def checked_original():
            observed = original_columns()
            assert observed == original
            return observed

        timing = paired(checked_original, checked_candidate, 12, 3)
        schema_digest = hashlib.sha256(json.dumps(original, ensure_ascii=False, default=str, sort_keys=True).encode()).hexdigest()
        result = {'candidate': 'Bounded selected-table column metadata query', 'implemented': False,
                  'connection_id': 'sakila_mysql', 'returned_tables': len(names),
                  'columns': sum(len(columns) for columns in original.values()),
                  'exact_projection_equal': True, 'schema_digest': schema_digest,
                  'counted_original': current_counts, 'counted_prototype': candidate_counts,
                  **timing, 'configured_business_writes': False,
                  'limits': 'One current MySQL instance, warm adapter metadata work only, not full schema tool/stdio/model timings. No cold/concurrent/schema-change/low-case-0 or partial-failure compatibility claim. Candidate is not wired into production; adapter API, authorization-before-truncation, ordering and error semantics need separate design/regressions. Existing per-operation timeout setup is retained, not cached.'}
    finally:
        adapter.close()
OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({name: result[name] for name in ('candidate','implemented','A_median_ms','B_median_ms','paired_relative_median_percent','pairs_faster')}))
