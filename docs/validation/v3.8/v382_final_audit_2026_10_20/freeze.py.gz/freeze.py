"""Freeze the accepted runtime and all previous seals for this audit only."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
E = BATCH / 'evidence'
E.mkdir(exist_ok=True)
OUT = E / 'before.json'
assert not OUT.exists()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
parent = ROOT / 'local_archive/v382_review/20261020_dialect_comments_not'
previous = json.loads((parent / 'resident_restart/evidence/native_plan.json').read_text())['previous_seals']
paths = [ROOT / item['manifest'] for item in previous]
paths += [parent / 'resident_restart/manifest.json', ROOT / 'docs/validation/v3.8/v382_dialect_comments_not_2026_10_20/resident_restart/manifest.json']
seals = []
for manifest in paths:
    files = json.loads(manifest.read_text())['files']
    entries = files.items() if isinstance(files, dict) else ((item['path'], item) for item in files)
    for name, entry in entries:
        path = manifest.parent / name
        assert digest(path) == entry['sha256'] and path.stat().st_size == entry['bytes']
    seals.append({'manifest': str(manifest.relative_to(ROOT)), 'sha256': digest(manifest), 'file_count': len(files)})
assert len(seals) == 29 and sum(item['file_count'] for item in seals) == 701
resources = {str(path.relative_to(ROOT / 'src/sql_safety_executor')): digest(path)
             for path in sorted((ROOT / 'src/sql_safety_executor').rglob('*'))
             if path.is_file() and path.suffix in {'.py', '.md'}}
assert resources == json.loads((parent / 'evidence/verification.json').read_text())['runtime_resources']
snapshot = {'frozen_utc': datetime.now(timezone.utc).isoformat(), 'version': '3.8.2',
            'scope': 'Read-only source/behavior/performance and documentation audit; exploratory tail-comment finding precedes freeze. No runtime fix is authorized by this check-only request.',
            'resources': resources, 'previous_seals': seals,
            'preserved_files': {name: digest(ROOT / name) for name in ('README.md', 'README_ZH.md', 'pyproject.toml', 'uv.lock')}}
OUT.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'resources': len(resources), 'old_manifests': len(seals), 'old_file_records': 701}))
