"""Native SQLite, both Client modes, startup Skills and frozen/HEAD analysis."""
import asyncio
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tarfile
import tempfile

from sql_safety_executor import create_server, load_config
from sql_safety_executor.core.analysis import _tokens, analyze_sql
from sql_safety_executor.core.managed_sql import check_managed_sql
from sql_safety_executor.core.policy import _analysis_decision
from sql_safety_executor.database.models import ConnectionPolicy
from sql_safety_executor.database.semantics import DialectContext
from sql_safety_executor.mcp.bootstrap import prepare_framework
from sqlglot.errors import ParseError

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
OUT = BATCH / 'evidence/tail_comments.json.gz'
assert not OUT.exists()
prepare_framework()
from fastmcp import Client

base = ['SELECT 7 AS n', 'WITH chosen AS (SELECT 7 AS n) SELECT n FROM chosen',
        'SELECT n FROM orders', 'EXPLAIN SELECT n FROM orders']
tails = ['', ';', ' /* tail */', '; /* tail */', '; -- tail\n', ' /* a */; /* b */',
         '; /* tail */\n-- more\n', '; /*+ SET_VAR(x=1) */']
cases = [{'id': f'b{b}_t{t}', 'sql': statement + tail}
         for b, statement in enumerate(base) for t, tail in enumerate(tails)]
policy = ConnectionPolicy(allowed_tables=frozenset({'orders'}), allow_union=True)
records = []
with sqlite3.connect(':memory:') as db:
    db.executescript('CREATE TABLE orders(n);INSERT INTO orders VALUES(7);')
    before = list(db.iterdump())
    for case in cases:
        native = [list(row) for row in db.execute(case['sql']).fetchall()]
        projections = {}
        for dialect in ('sqlite', 'mysql'):
            context = DialectContext(dialect, default_schema='main' if dialect == 'sqlite' else 'fixture')
            analysis = analyze_sql(case['sql'], context)
            decision = _analysis_decision(analysis, policy)
            lexer, tokens = _tokens(case['sql'], context)
            try:
                trees = lexer.parser().parse(tokens, case['sql'])
                tree_types = [type(tree).__name__ for tree in trees if tree is not None]
            except ParseError:
                # Diagnostic only: project analysis separately unwraps SQLite
                # EXPLAIN; raw upstream parsing is not the product verdict.
                tree_types = ['raw_parser_ParseError']
            projections[dialect] = {'allowed': decision.allowed, 'error_code': decision.error_code,
                                    'unsupported': analysis.unsupported,
                                    'tree_types': tree_types}
        records.append({**case, 'native_sqlite_rows': native if not case['sql'].startswith('EXPLAIN') else None,
                        'native_sqlite_succeeds': True, 'analysis': projections})
    assert before == list(db.iterdump())

# Import complete frozen package roots in independent processes; do not mix old
# analysis with current siblings or use a HEAD baseline for uncommitted changes.
program = '''import json,sys
from pathlib import Path
import sql_safety_executor
from sql_safety_executor.core.analysis import analyze_sql
from sql_safety_executor.database.semantics import DialectContext
root=Path(sys.argv[1]).resolve()
assert Path(sql_safety_executor.__file__).resolve().is_relative_to(root)
inputs=json.loads(sys.stdin.read())
print(json.dumps({"resources":{str(p.relative_to(root/"sql_safety_executor")):__import__("hashlib").sha256(p.read_bytes()).hexdigest() for p in (root/"sql_safety_executor").rglob("*") if p.is_file() and p.suffix in {".py",".md"}},"results":[{"id":c["id"],"status":(a:=analyze_sql(c["sql"],DialectContext("sqlite"))).status,"unsupported":a.unsupported} for c in inputs]}))'''
baselines = {}
for label in ('accepted_before_comments', 'HEAD_2c0a9e7'):
    with tempfile.TemporaryDirectory(prefix='audit-frozen-') as temporary:
        directory = Path(temporary)
        if label == 'accepted_before_comments':
            archive = ROOT / 'local_archive/v382_review/20261020_dialect_comments_not/evidence/before_runtime.tar.gz'
            with tarfile.open(archive) as source:
                source.extractall(directory, filter='data')
            package_root = directory
        else:
            data = subprocess.check_output(['git', 'archive', '--format=tar', 'HEAD', 'src/sql_safety_executor'], cwd=ROOT)
            with tarfile.open(fileobj=io.BytesIO(data)) as source:
                source.extractall(directory, filter='data')
            package_root = directory / 'src'
        environment = {**os.environ, 'PYTHONPATH': str(package_root)}
        response = subprocess.run([sys.executable, '-c', program, str(package_root)], input=json.dumps(cases),
                                  cwd=directory, env=environment, text=True, capture_output=True, check=True)
        result = json.loads(response.stdout)
        if label == 'accepted_before_comments':
            expected = json.loads((ROOT / 'local_archive/v382_review/20261020_dialect_comments_not/evidence/before.json').read_text())['resources']
            assert result['resources'] == {name.removeprefix('sql_safety_executor/'): value for name, value in expected.items()}
        baselines[label] = result


async def clients():
    output = []
    for mode in ('auto', 'legacy'):
        with tempfile.TemporaryDirectory(prefix='tail-comment-client-') as temporary:
            root = Path(temporary)
            with sqlite3.connect(root / 'fixture.sqlite') as db:
                db.executescript('CREATE TABLE orders(n);INSERT INTO orders VALUES(7);')
            for name, sql in [('tail-comment-read', 'SELECT n FROM main.orders; /* tail */'),
                              ('plain-read', 'SELECT n FROM main.orders;')]:
                directory = root / 'skills' / name
                directory.mkdir(parents=True)
                (directory / 'skill_def.md').write_text('---\nname: '+name+'\ntype: query\nsource: query.sql\nrisk: low\ndescription: Tail comment audit\ndatabases: [sqlite]\ntables: [main.orders]\nparams: {}\n---\n')
                (directory / 'query.sql').write_text(sql)
            (root / 'server.toml').write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="fixture"\n')
            (root / 'connections.toml').write_text('schema_version=1\n[connections.fixture]\ntype="sqlite"\nsqlite.path="fixture.sqlite"\nread.mode="allowlist"\nread.tables=["orders"]\n')
            (root / 'skills.toml').write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=true\n[skills.audit]\npath="audit.jsonl"\n')
            server = create_server(load_config(root / 'server.toml'))
            cached = sorted(server.gateway_runtime.catalog.get_skills_cache())
            assert cached == ['plain-read']
            async with Client(server, mode=mode) as client:
                calls = [('query', {'sql': 'SELECT n FROM main.orders; /* tail */'}),
                         ('query', {'sql': 'SELECT n FROM main.orders;'}),
                         ('list_skills', {'detail_level': 'full', 'available_only': False}),
                         ('get_skill_detail', {'skill_name': 'tail-comment-read'}),
                         ('execute_query_skill', {'skill_name': 'tail-comment-read', 'params': {}})]
                rows = []
                for tool, arguments in calls:
                    result = await client.call_tool(tool, arguments, raise_on_error=False)
                    rows.append({'tool': tool, 'arguments': arguments, 'isError': result.is_error,
                                 'structured': result.structured_content,
                                 'content': [part.model_dump(mode='json', exclude_none=True) for part in result.content]})
                assert rows[0]['structured']['error_code'] == 'multiple_statements'
                assert rows[1]['structured']['data'] == [{'n': 7}]
                assert [item['name'] for item in rows[2]['structured']['skills']] == ['plain-read']
                assert rows[3]['isError'] and rows[4]['isError']
                output.append({'mode': mode, 'protocol': client.protocol_version, 'startup_skills': cached, 'calls': rows})
            server.gateway_runtime.close()
            with sqlite3.connect(root / 'fixture.sqlite') as db:
                assert db.execute('SELECT n FROM orders').fetchall() == [(7,)]
    return output


result = {'cases': records, 'baselines': baselines, 'clients': asyncio.run(clients()),
          'managed_tail_control': check_managed_sql('UPDATE orders SET n=7; /* tail */', DialectContext('sqlite')).allowed,
          'scope': 'Thirty-two native-valid SQLite statements and shape projections, complete frozen/HEAD imports and ten real in-process Client calls. Expected defect is retained. No runtime patch/configured database write or full protocol-frame claim.'}
assert result['managed_tail_control']
OUT.write_bytes(gzip.compress(json.dumps(result, ensure_ascii=False, default=str, indent=2).encode(), mtime=0))
print(json.dumps({'sqlite_cases': len(records), 'sqlite_shape_refusals': sum(not item['analysis']['sqlite']['allowed'] for item in records),
                  'client_calls': 10, 'baseline_defects': {name: sum('multiple_statements' in item['unsupported'] for item in result['results']) for name, result in baselines.items()}}))
