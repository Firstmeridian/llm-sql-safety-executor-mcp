"""Independent existing-mode MySQL truth for constant trailing-comment reads."""
import json
from pathlib import Path

from sql_safety_executor import load_config
from sql_safety_executor.database.mysql import MySQLAdapter

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parents[1] / 'evidence/mysql_tail_truth.json'
assert not OUT.exists()
config = load_config(ROOT / 'config/server.toml')
adapter = MySQLAdapter(config.connections['orders_demo_mysql'])
records = []
try:
    assert adapter.connect()
    context = adapter.resolve_analysis_context()
    with adapter._engine.connect() as db:
        for sql in ('SELECT 7 AS n; /* tail */', 'SELECT 7 AS n; -- tail\n',
                    'WITH chosen AS (SELECT 7 AS n) SELECT n FROM chosen; /* tail */',
                    'EXPLAIN SELECT 7 AS n; /* tail */'):
            rows = [dict(row._mapping) for row in db.exec_driver_sql(sql).fetchall()]
            assert rows
            if not sql.startswith('EXPLAIN'):
                assert rows == [{'n': 7}]
            records.append({'sql': sql, 'native_succeeds': True, 'data': rows if not sql.startswith('EXPLAIN') else None})
finally:
    adapter.close()
OUT.write_text(json.dumps({'records': records, 'scope': 'Four native MySQL constant/CTE/non-executing plan reads under unchanged configured modes. No table/data read, business write, mode/global change or MCP-policy bypass execution.'}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'native_mysql_reads': len(records), 'passed': True}))
