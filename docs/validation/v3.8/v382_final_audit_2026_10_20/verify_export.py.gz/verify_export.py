"""Verify and publish this audit; expected defects remain explicitly open."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote
import zipfile

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
E = BATCH / 'evidence'
PUBLIC = ROOT / 'docs/validation/v3.8/v382_final_audit_2026_10_20'
assert not (E / 'summary.json').exists()
assert not (BATCH / 'manifest.json').exists() and not (PUBLIC / 'manifest.json').exists()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
before = json.loads((E / 'before.json').read_text())
resources = {str(path.relative_to(ROOT / 'src/sql_safety_executor')): digest(path)
             for path in (ROOT / 'src/sql_safety_executor').rglob('*')
             if path.is_file() and path.suffix in {'.py', '.md'}}
assert resources == before['resources'] and len(resources) == 77
for name, expected in before['preserved_files'].items():
    assert digest(ROOT / name) == expected, name
verified = 0
for record in before['previous_seals']:
    manifest = ROOT / record['manifest']
    assert digest(manifest) == record['sha256']
    files = json.loads(manifest.read_text())['files']
    entries = files.items() if isinstance(files, dict) else ((item['path'], item) for item in files)
    for name, item in entries:
        path = manifest.parent / name
        assert digest(path) == item['sha256'] and path.stat().st_size == item['bytes']
        verified += 1
assert verified == 701 and len(before['previous_seals']) == 29
wheel = next((ROOT / 'local_archive/v382_review/20261020_dialect_comments_not/evidence/dist').glob('*.whl'))
with zipfile.ZipFile(wheel) as archive:
    for name, expected in resources.items():
        assert hashlib.sha256(archive.read('sql_safety_executor/' + name)).hexdigest() == expected

tail = json.loads(gzip.decompress((E / 'tail_comments.json.gz').read_bytes()))
colon = json.loads(gzip.decompress((E / 'managed_colons.json.gz').read_bytes()))
native = json.loads((E / 'native_application.json').read_text())
mysql = json.loads((E / 'mysql_tail_truth.json').read_text())
startup = json.loads((E / 'startup_candidate.json').read_text())
columns = json.loads((E / 'mysql_column_candidate.json').read_text())
assert len(tail['cases']) == 32
assert sum(not item['analysis']['sqlite']['allowed'] for item in tail['cases']) == 20
assert all(item['native_sqlite_succeeds'] for item in tail['cases'])
assert sum(len(item['calls']) for item in tail['clients']) == 10
assert len(tail['baselines']) == 2 and tail['managed_tail_control']
assert len(colon['static']) == 12 and len(colon['baselines']) == 2
assert sum(len(item['calls']) for item in colon['clients']) == 12
assert all(item['execution_transport_parameters'] == ['n'] and len(item['raw_text_parameters']) == 2
           and item['shape_allowed'] and 'exactly match SQL named binds' in item['validation_error']
           for item in colon['static'])
assert len(native['records']) == 4 and len(mysql['records']) == 4
for item in native['records']:
    result = item['result']
    assert not result.get('isError', False)
    payload = result['structuredContent']
    assert json.loads(result['content'][0]['text']) == payload
    assert payload['connection_id'] == item['arguments']['connection_id']
    if '/* tail */' in item['arguments']['sql']:
        assert payload['success'] is False and payload['error_code'] == 'multiple_statements'
    else:
        assert payload['success'] is True and payload['data'] == [{'n': 7}]
assert all(item['native_succeeds'] for item in mysql['records'])
assert len(startup['corpus_complete_decisions']) == 89
assert all(item['same_complete_decision'] for item in startup['corpus_complete_decisions'])
assert sum(item['current_analyses'] for item in startup['corpus_complete_decisions']) == 445
assert sum(item['prototype_analyses'] for item in startup['corpus_complete_decisions']) == 262
assert startup['implemented'] is columns['implemented'] is False
assert columns['exact_projection_equal'] and columns['returned_tables'] == 16 and columns['columns'] == 89
assert columns['counted_original'] == {'columns': 16, 'timeout_setup': 16}
assert columns['counted_prototype'] == {'columns': 1, 'timeout_setup': 1}
for candidate, timed, warm in ((startup, 30, 5), (columns, 12, 3)):
    assert candidate['pairs'] == timed and candidate['warmup_pairs'] == warm
    assert len(candidate['records']) == timed + warm

names = subprocess.check_output(['git', 'diff', '--name-only', '--', '*.md'], cwd=ROOT, text=True).splitlines()
names += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', '*.md'], cwd=ROOT, text=True).splitlines()
names += [str(path.relative_to(ROOT)) for path in BATCH.rglob('*.md')]
names += ['local_archive/v382_review/README.md', 'local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md']
checked = 0
for name in sorted(set(names)):
    file = ROOT / name
    if not file.is_file():
        continue
    for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^\n)]*)\)', file.read_text()):
        target = target.strip().split(' "', 1)[0].strip('<>')
        if not target or re.match(r'[a-zA-Z][a-zA-Z0-9+.-]*:', target):
            continue
        path = unquote(target.split('#', 1)[0])
        if path:
            assert (file.parent / path).exists(), (name, path)
            checked += 1
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)

sources = ['before.json', 'tail_comments.json.gz', 'managed_colons.json.gz', 'native_application.json',
           'mysql_tail_truth.json', 'startup_candidate.json', 'mysql_column_candidate.json',
           'tail_comments_parser_diagnostic_failure.log']
references = {}
for name in sources:
    source = E / name
    filename = name if name.endswith('.gz') else name + '.gz'
    destination = PUBLIC / filename
    assert not destination.exists()
    destination.write_bytes(source.read_bytes() if name.endswith('.gz') else gzip.compress(source.read_bytes(), mtime=0))
    references[name] = {'file': filename, 'sha256': digest(destination), 'bytes': destination.stat().st_size}
for path in sorted((BATCH / 'scripts').glob('*.py')):
    (PUBLIC / (path.name + '.gz')).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
summary = {
    'verified_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'audit_completed_two_open_functional_findings',
    'runtime_changes': False, 'dependency_or_private_config_changes': False,
    'configured_business_writes': False, 'version': '3.8.2',
    'findings': [{'id': 'DRR-2026-124', 'priority': 'P2', 'status': 'open', 'existing_in_both_complete_old_packages': True},
                 {'id': 'DRR-2026-125', 'priority': 'P2', 'status': 'open', 'existing_in_both_complete_old_packages': True}],
    'sqlite_native_cases': 32, 'expected_current_sqlite_shape_refusals': 20,
    'managed_binding_comparisons': 12, 'in_process_client_calls': 22,
    'current_host_constant_calls': 4, 'independent_mysql_reads': 4,
    'startup_prototype': {'implemented': False, 'identical_complete_decisions': 89, 'analysis_counts': [445, 262],
                          **{name: startup[name] for name in ('A_median_ms', 'B_median_ms', 'pairs', 'warmup_pairs', 'paired_relative_median_percent')}},
    'column_prototype': {'implemented': False, 'selected_tables': 16, 'columns': 89, 'column_queries': [16, 1],
                         'timeout_setups': [16, 1], **{name: columns[name] for name in ('A_median_ms', 'B_median_ms', 'pairs', 'warmup_pairs', 'paired_relative_median_percent')}},
    'previous_manifests_verified': 29, 'previous_file_records_verified': 701,
    'runtime_resources_unchanged_and_matching_wheel': 77, 'README_and_frozen_dependency_files_unchanged': True,
    'markdown_local_links_verified': checked, 'diff_check_passed': True, 'evidence': references,
    'limits': 'Audit observations, not repaired-feature acceptance or proof of no other defects. No new full-suite/installed/complete-model/provider-usage or complete-wire claim. Candidate times are pure startup classification and warm adapter-column phases, not delivered tool/model speedups. Earlier evidence keeps attribution. Duplicate successful Client console logs remain local; selected initial diagnostic failure retained. No authorizer/state-cache bypass or automatic statistics maintenance.',
}
for path in (E / 'summary.json', PUBLIC / 'summary.json'):
    path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
for root in (BATCH, PUBLIC):
    files = {}
    for path in sorted(root.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.name == 'manifest.json':
            continue
        data = path.read_bytes()
        files[str(path.relative_to(root))] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    (root / 'manifest.json').write_text(json.dumps({'date': '2026-10-20',
        'checkpoint': 'audit_completed_two_open_functional_findings',
        'scope': 'Read-only audit and unimplemented performance prototypes; DRR-124/125 remain open. Python caches excluded; all parent seals retained.',
        'files': files}, ensure_ascii=False, indent=2) + '\n')
    print(str(root.relative_to(ROOT)), len(files), 'files sealed')
print(json.dumps({'open_findings': 2, 'unchanged_runtime_resources': 77, 'prior_file_records_verified': 701,
                  'in_process_client_calls': 22, 'native_calls': 4, 'markdown_links_verified': checked}))
