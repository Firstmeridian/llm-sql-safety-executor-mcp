"""Check plan-binding/transport disagreement and real Skill-loading effects."""
import asyncio
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tarfile
import tempfile

from sqlalchemy import text
from sql_safety_executor import create_server, load_config
from sql_safety_executor.core.managed_sql import check_managed_sql
from sql_safety_executor.database.semantics import DialectContext
from sql_safety_executor.database.transport import statement_text
from sql_safety_executor.mcp.bootstrap import prepare_framework
from sql_safety_executor.skills.mutation import ManagedMutationPlan, ManagedMutationValue, validate_managed_mutation_plan

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parents[1] / 'evidence/managed_colons.json.gz'
assert not OUT.exists()
prepare_framework()
from fastmcp import Client

statements = ["UPDATE orders SET note=':business', n=:n",
              'UPDATE /* :comment */ orders SET n=:n',
              'UPDATE orders SET ":business"=:n']
static = []
with sqlite3.connect(':memory:') as db:
    db.executescript('CREATE TABLE orders(n,note,":business");INSERT INTO orders VALUES(7,NULL,NULL);')
    snapshot = list(db.iterdump())
    for sql in statements:
        assert db.execute('EXPLAIN ' + sql, {'n': 7}).fetchall()
        for context in (DialectContext('sqlite'), DialectContext('mysql', frozenset({'ANSI_QUOTES'}))):
            for parser in ('sqlglot', 'sqlparse'):
                plan = ManagedMutationPlan(sql, (ManagedMutationValue.constant('n', 7),), 1)
                decision = check_managed_sql(sql, context, parser)
                assert decision.allowed
                try:
                    validate_managed_mutation_plan(plan, parser=parser, context=context)
                except TypeError as error:
                    message = str(error)
                else:
                    raise AssertionError('Expected binding disagreement disappeared')
                current = sorted(text(sql).compile().params)
                transport = sorted(statement_text(sql, context).compile().params)
                assert transport == ['n'] and len(current) == 2
                static.append({'sql': sql, 'dialect': context.dialect, 'parser': parser,
                               'shape_allowed': True, 'validation_error': message,
                               'raw_text_parameters': current, 'execution_transport_parameters': transport})
    assert snapshot == list(db.iterdump())

program = '''import inspect,json,sys
from pathlib import Path
import sql_safety_executor
from sql_safety_executor.skills.mutation import ManagedMutationPlan,ManagedMutationValue,validate_managed_mutation_plan
assert Path(sql_safety_executor.__file__).resolve().is_relative_to(Path(sys.argv[1]).resolve())
out=[]
for sql in json.loads(sys.stdin.read()):
 p=ManagedMutationPlan(sql,(ManagedMutationValue.constant("n",7),),1)
 try:validate_managed_mutation_plan(p); error=None
 except TypeError as e:error=str(e)
 out.append({"sql":sql,"error":error})
print(json.dumps(out))'''
baselines = {}
for label in ('accepted_before_comments', 'HEAD_2c0a9e7'):
    with tempfile.TemporaryDirectory(prefix='colon-frozen-') as temporary:
        directory = Path(temporary)
        if label == 'accepted_before_comments':
            with tarfile.open(ROOT / 'local_archive/v382_review/20261020_dialect_comments_not/evidence/before_runtime.tar.gz') as archive:
                archive.extractall(directory, filter='data')
            package_root = directory
        else:
            source = subprocess.check_output(['git', 'archive', '--format=tar', 'HEAD', 'src/sql_safety_executor'], cwd=ROOT)
            with tarfile.open(fileobj=io.BytesIO(source)) as archive:
                archive.extractall(directory, filter='data')
            package_root = directory / 'src'
        environment = {**os.environ, 'PYTHONPATH': str(package_root)}
        response = subprocess.run([sys.executable, '-c', program, str(package_root)], input=json.dumps(statements),
                                  text=True, capture_output=True, check=True, cwd=directory, env=environment)
        baselines[label] = json.loads(response.stdout)
        assert all(item['error'] and 'exactly match SQL named binds' in item['error'] for item in baselines[label])


async def clients():
    observations = []
    for parser in ('sqlglot', 'sqlparse'):
        for mode in ('auto', 'legacy'):
            with tempfile.TemporaryDirectory(prefix='colon-skill-') as temporary:
                root = Path(temporary)
                with sqlite3.connect(root / 'fixture.sqlite') as db:
                    db.executescript('CREATE TABLE orders(n);INSERT INTO orders VALUES(7);')
                before = hashlib.sha256((root / 'fixture.sqlite').read_bytes()).hexdigest()
                for name, sql in [('colon-plan', statements[1]), ('plain-plan', 'UPDATE orders SET n=:n')]:
                    folder = root / 'skills' / name
                    folder.mkdir(parents=True)
                    (folder / 'skill_def.md').write_text('---\nname: '+name+'\ntype: mutation\nsource: mutation.py\nrisk: low\ndescription: Colon binding audit\ndatabases: [sqlite]\ntables: [orders]\nparams: {}\n---\n')
                    (folder / 'mutation.py').write_text(
                        'from sql_safety_executor.skills.mutation import ManagedMutationBase,ManagedMutationPlan,ManagedMutationValue\n'
                        'class Mutation(ManagedMutationBase):\n'
                        '    managed_plan=ManagedMutationPlan('+repr(sql)+',(ManagedMutationValue.constant("n",7),),1)\n'
                        '    def validate(self,params):return {"valid":True}\n'
                        '    def preview(self,params):return {"affected_rows_estimate":1}\n')
                (root / 'server.toml').write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="fixture"\n')
                (root / 'connections.toml').write_text('schema_version=1\n[connections.fixture]\ntype="sqlite"\nsqlite.path="fixture.sqlite"\nread.mode="allowlist"\nread.tables=["orders"]\nmutation.enabled=true\nmutation.skills=["colon-plan","plain-plan"]\n')
                (root / 'skills.toml').write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.mutation]\nenabled=true\nallowed_connections=["fixture"]\nmanaged_plan_parser="'+parser+'"\n[skills.mutation.mrtr]\nenabled=false\n[skills.audit]\npath="audit.jsonl"\n')
                server = create_server(load_config(root / 'server.toml'))
                assert sorted(server.gateway_runtime.catalog.get_skills_cache()) == ['plain-plan']
                rows = []
                async with Client(server, mode=mode) as client:
                    calls = [('list_skills', {'detail_level': 'full', 'available_only': False}),
                             ('get_skill_detail', {'skill_name': 'colon-plan'}),
                             ('execute_mutation_skill', {'skill_name': 'colon-plan', 'params': {}, 'confirm': False})]
                    for tool, arguments in calls:
                        result = await client.call_tool(tool, arguments, raise_on_error=False)
                        rows.append({'tool': tool, 'arguments': arguments, 'isError': result.is_error,
                                     'structured': result.structured_content,
                                     'content': [block.model_dump(mode='json', exclude_none=True) for block in result.content]})
                    assert [item['name'] for item in rows[0]['structured']['skills']] == ['plain-plan']
                    assert rows[1]['isError'] and rows[2]['isError']
                    observations.append({'mode': mode, 'parser': parser, 'protocol': client.protocol_version, 'calls': rows})
                server.gateway_runtime.close()
                assert hashlib.sha256((root / 'fixture.sqlite').read_bytes()).hexdigest() == before
    return observations


result = {'static': static, 'baselines': baselines, 'clients': asyncio.run(clients()),
          'business_writes': False, 'scope': 'Twelve shape/binding/transport comparisons; native SQLite non-executing plans; complete old package imports; twelve real in-process Client calls with two protocols/parsers. Defect intentionally retained; no runtime/config/dependency change, confirmation or generated preview handle.'}
OUT.write_bytes(gzip.compress(json.dumps(result, ensure_ascii=False, indent=2).encode(), mtime=0))
print(json.dumps({'static_comparisons': len(static), 'client_calls': 12, 'baselines_reproduce': True}))
