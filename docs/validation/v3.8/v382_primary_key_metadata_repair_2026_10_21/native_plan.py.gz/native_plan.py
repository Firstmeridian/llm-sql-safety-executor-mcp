"""Freeze read-only configured-alias truth before requesting one owner restart."""
import hashlib
import json
from pathlib import Path
import sqlite3

from sql_safety_executor import load_config
from sql_safety_executor.database.registry import create_adapter

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parents[1]
config = load_config(ROOT / 'config/server.toml')
truth = {}
sqlite_config = config.connections['sqlite_features_sqlite']
sqlite_path = Path(sqlite_config.sqlite_database_path)
before = hashlib.sha256(sqlite_path.read_bytes()).hexdigest()
with sqlite3.connect(f'file:{sqlite_path}?mode=ro', uri=True) as db:
    for (name,) in db.execute("SELECT name FROM main.sqlite_schema WHERE type='table' ORDER BY name"):
        if not sqlite_config.policy.allows_metadata_table(name, 'main'):
            continue
        columns = [list(r) for r in db.execute('PRAGMA main.table_xinfo(' + "'" + name.replace("'", "''") + "')")]
        truth[name] = {'columns': columns, 'positions': {r[1]: r[5] for r in columns if r[5]},
                      'primary_key': [r[1] for r in sorted(columns, key=lambda r: r[5]) if r[5]]}
assert hashlib.sha256(sqlite_path.read_bytes()).hexdigest() == before
sqlite_truth = truth
mysql_config = config.connections['sakila_mysql']
adapter = create_adapter(config=mysql_config)
truth = {}
try:
    assert adapter.connect()
    for (name,) in adapter.execute('SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=:schema_name '
                                 "AND TABLE_TYPE='BASE TABLE' ORDER BY TABLE_NAME", params={'schema_name': mysql_config.mysql_database}):
        if not mysql_config.policy.allows_metadata_table(name, mysql_config.mysql_database):
            continue
        columns = [list(r) for r in adapter.execute('SELECT COLUMN_NAME,DATA_TYPE,IS_NULLABLE,COLUMN_KEY,COLUMN_DEFAULT '
            'FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=:schema_name AND TABLE_NAME=:table_name ORDER BY ORDINAL_POSITION',
            params={'schema_name': mysql_config.mysql_database, 'table_name': name})]
        indexes = [list(r) for r in adapter.execute('SHOW INDEX FROM `' + mysql_config.mysql_database.replace('`', '``') + '`.`' + name.replace('`', '``') + '`')]
        primary = sorted((r for r in indexes if r[2] == 'PRIMARY'), key=lambda r: r[3])
        truth[name] = {'columns': columns, 'primary_key': [r[4] for r in primary],
                       'positions': {r[4]: r[3] for r in primary}}
finally:
    adapter.close()
mysql_truth = truth
assert len(sqlite_truth) == 6 and len(mysql_truth) == 16

calls = []
def add(case, tool, arguments, expected):
    calls.append(dict(case=case, tool=tool, arguments=arguments, expected=expected))
for alias, catalog in [('sqlite_features_sqlite', sqlite_truth), ('sakila_mysql', mysql_truth)]:
    names = ['pages', 'pages_fts'] if alias == 'sqlite_features_sqlite' else ['film_actor', 'film_category']
    for name in names:
        add(alias + ':' + name, 'describe_table', {'connection_id': alias, 'table_name': name},
            {'positions': catalog[name]['positions'], 'primary_key': catalog[name]['primary_key']})
    for level in ['compact', 'full']:
        add(alias + ':' + level, 'get_full_schema', {'connection_id': alias, 'detail_level': level},
            {'tables': {name: {'primary_key': v['primary_key'], 'positions': v['positions']} for name,v in catalog.items()}})
add('sqlite-values', 'query', {'connection_id': 'sqlite_features_sqlite', 'sql': "SELECT 7 AS n, 7='7' AS equals_text"},
    {'data': [{'n': 7, 'equals_text': 0}]})
add('mysql-values', 'query', {'connection_id': 'sakila_mysql', 'sql': 'SELECT 7 AS n'}, {'data': [{'n': 7}]})
add('shadow-denial', 'query', {'connection_id': 'sqlite_features_sqlite', 'sql': 'SELECT * FROM pages_fts_data LIMIT 1'},
    {'error_code': 'table_access_denied'})
add('function-denial', 'query', {'connection_id': 'sqlite_features_sqlite', 'sql': 'SELECT SLEEP(0) AS n'},
    {'error_code': 'expensive_function_denied'})
resources = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
             for p in (ROOT / 'src/sql_safety_executor').rglob('*') if p.is_file() and p.suffix in {'.py', '.md'}}
record = dict(status='Frozen before owner restart; not resident acceptance', calls=calls,
              sqlite_truth=sqlite_truth, mysql_truth=mysql_truth, resources=resources,
              sqlite_file_sha256=before,
              limits='Existing aliases only. Special reversed/unique-only/physical-repeat fixtures retain source/wheel coverage. No model trial.')
output = HERE / 'evidence/native_plan.json'
assert not output.exists()
output.write_text(json.dumps(record, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'frozen_calls': len(calls), 'sqlite_tables': len(sqlite_truth), 'mysql_tables': len(mysql_truth)}))
