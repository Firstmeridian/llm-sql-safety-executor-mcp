"""Validate both backends against independent native metadata, not old output."""
import gzip
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(path.read_text()) if path.exists() else json.loads(gzip.decompress(path.with_suffix(path.suffix + '.gz').read_bytes()))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def expected_columns(backend, truth, current):
    columns = []
    for r in truth['columns']:
        c = dict(column_name=r[1] if backend == 'sqlite' else r[0], data_type=r[2] if backend == 'sqlite' else r[1],
            nullable=('NO' if r[3] else 'YES') if backend == 'sqlite' else r[2],
            key_type=('PRI' if r[5] else '') if backend == 'sqlite' else r[3], default_value=r[4])
        if current and c['column_name'] in truth['positions']:
            c['primary_key_position'] = truth['positions'][c['column_name']]
        columns.append(c)
    return columns


def validate(data, current):
    truth, calls, backend = data['truth'], data['calls'], data['backend']
    assert len(truth) == 13 and len(calls) == 96 and data['fixture_cleaned']
    groups, baseline_mismatches, chars = {}, set(), {}
    for name, native in truth.items():
        if backend == 'mysql':
            # SHOW INDEX is a second native source, independent from KCU.
            key_parts = sorted((r for r in native['indexes'] if r['Key_name'] == 'PRIMARY'), key=lambda r:r['Seq_in_index'])
            assert [r['Column_name'] for r in key_parts] == native['primary_key']
    for call in calls:
        value = call['structured']
        assert not call['isError'] and json.loads(call['content'][0]['text']) == value
        group = call['transport'] + ':' + call['mode']
        groups[group] = groups.get(group, 0) + 1
        name = call['case']
        if call['tool'] in {'describe_table', 'get_table_summary'}:
            assert value['columns'] == expected_columns(backend, truth[name], current)
            if call['tool'] == 'get_table_summary':
                assert value['row_count'] == 1 and value['row_count_approximate'] is False
            if call['tool'] == 'describe_table':
                assert value['indexes_status'] == 'complete'
                primary = next((i['columns'] for i in value['indexes'] if i['primary']), [])
                assert primary == (['b', 'a', 'b'] if name == 'repeated_pk' else truth[name]['primary_key'])
        if name in {'compact', 'ungrouped'}:
            lookup = {t['name']: g for g in value['schema_groups'] for t in g['tables']}
            assert len(lookup) == 12 and value['total_columns'] == 24
            if current:
                assert lookup['key_ab'] is not lookup['key_ba']
            for table, metadata in lookup.items():
                assert metadata['columns'] == [[c['column_name'], c['data_type']] for c in expected_columns(backend, truth[table], current)]
                if metadata['primary_key'] != truth[table]['primary_key']:
                    baseline_mismatches.add(table)
                    assert not current
            chars[name] = len(call['content'][0]['text'])
        if name == 'full':
            for table, metadata in value['schema'].items():
                expected = [dict(name=c['column_name'], type=c['data_type'], nullable=c['nullable'],
                    key=c['key_type'], default=c['default_value'],
                    **({'primary_key_position': c['primary_key_position']} if 'primary_key_position' in c else {}))
                    for c in expected_columns(backend, truth[table], current)]
                assert metadata['columns'] == expected
            chars[name] = len(call['content'][0]['text'])
        if name in {'raw_key', 'sample_key'}:
            assert value['data'] == [{'a': 7, 'b': 99}]
        if name.endswith('_denied'):
            assert not value['success']
            assert value['error_code'] == ('table_access_denied' if name == 'secret_denied' else 'expensive_function_denied')
    assert groups == {t + ':' + m: 24 for t in ['inprocess', 'stdio'] for m in ['auto', 'legacy']}
    return {'calls': len(calls), 'objects': len(truth), 'groups': groups,
        'mismatches': sorted(baseline_mismatches), 'schema_text_chars': chars,
        'compact_groups': next(r['structured']['schema_group_count'] for r in calls if r['case'] == 'compact')}


def normalized(calls):
    result = json.loads(json.dumps(calls))
    databases = {(c['transport'], c['mode']): c['structured']['database_name']
                 for c in result if c['tool'] == 'list_tables'}
    for c in result:
        if c['tool'] == 'list_tables':
            # Random owned schema name differs per isolated MySQL fixture.
            c['structured']['database_name'] = '<fixture-database>'
            text = json.loads(c['content'][0]['text'])
            text['database_name'] = '<fixture-database>'
            c['content'][0]['text'] = json.dumps(text, sort_keys=True)
        if c['tool'] == 'sample' and c['structured']['db_type'] == 'mysql':
            database = databases[c['transport'], c['mode']]
            assert re.fullmatch(r'mcp_drr141_[0-9a-f]{16}', database)
            expected = f'SELECT * FROM `{database}`.`key_ba` LIMIT 1'
            text = json.loads(c['content'][0]['text'])
            assert c['structured']['query'] == text['query'] == expected
            c['structured']['query'] = text['query'] = 'SELECT * FROM `<fixture-database>`.`key_ba` LIMIT 1'
            c['content'][0]['text'] = json.dumps(text, sort_keys=True)
        if c['case'] == 'secret_denied' and c['structured']['db_type'] == 'mysql':
            database = databases[c['transport'], c['mode']]
            assert re.fullmatch(r'mcp_drr141_[0-9a-f]{16}', database)
            names = sorted(v['case'] for v in calls if v['tool'] == 'describe_table'
                           and (v['transport'], v['mode']) == (c['transport'], c['mode']))
            expected = 'Access denied to table(s): secret. Only allowed tables: ' + ', '.join(
                database + '.' + ('"dot.表 x"' if n == 'dot.表 x' else n) for n in names)
            text = json.loads(c['content'][0]['text'])
            assert text['error'] == c['structured']['error'] == expected
            c['structured']['error'] = text['error'] = expected.replace(database + '.', '<fixture-database>.')
            c['content'][0]['text'] = json.dumps(text, sort_keys=True)
    return result


summary = {}
for backend in ['sqlite', 'mysql']:
    base = read(HERE / f'evidence/baseline_{backend}.json')
    source = read(HERE / f'evidence/source_{backend}.json')
    summary[backend] = {'baseline': validate(base, False), 'source': validate(source, True)}
    installed = HERE / f'evidence/installed_{backend}.json'
    if installed.exists() or installed.with_suffix('.json.gz').exists():
        wheel = read(installed)
        summary[backend]['installed'] = validate(wheel, True)
        assert normalized(source['calls']) == normalized(wheel['calls'])
        summary[backend]['source_wheel_equal_except_verified_fixture_schema_fields'] = True
    assert summary[backend]['baseline']['mismatches']
    assert not summary[backend]['source']['mismatches']
before = read(HERE / 'baseline/current.json')
changed = {name for name, digest in before['resources'].items() if sha(ROOT / name) != digest}
assert changed == {'src/sql_safety_executor/' + name for name in ['database/base.py', 'database/sqlite.py', 'database/mysql.py', 'core/schema.py']}
for name, digest in before['private_toml_sha256'].items():
    assert sha(ROOT / name) == digest
count = 0
for spec in before['prior_seals']:
    manifest = ROOT / spec['manifest']
    assert sha(manifest) == spec['sha256']
    data = read(manifest)
    items = data['files'].items() if isinstance(data['files'], dict) else ((v['path'], v) for v in data['files'])
    paths = {}
    size = 0
    for name, meta in items:
        p = next(p for p in [manifest.parent / name, manifest.parent.parent / name, ROOT / name] if p.is_file())
        paths[name] = p
        assert sha(p) == (meta['sha256'] if isinstance(meta, dict) else meta)
        if isinstance(meta, dict):
            if 'bytes' in meta:
                assert p.stat().st_size == meta['bytes']
            if 'decoded_sha256' in meta:
                raw = gzip.decompress(p.read_bytes())
                assert hashlib.sha256(raw).hexdigest() == meta['decoded_sha256'] and len(raw) == meta['decoded_bytes']
        size += 1
    for name, meta in data.get('compressed_decoded_records', {}).items():
        raw = gzip.decompress(paths[name].read_bytes())
        assert hashlib.sha256(raw).hexdigest() == meta.get('decoded_sha256', meta.get('sha256'))
        assert len(raw) == meta.get('decoded_bytes', meta.get('bytes'))
    assert size == spec['files']
    count += size
assert len(before['prior_seals']) == 71 and count == 2180
summary.update(runtime_files_changed=sorted(changed), private_tomls_unchanged=3,
    prior_manifests_unchanged=71, prior_records_unchanged=2180,
    native_host='pending owner restart', model_trials=0, version='3.8.2')
(HERE / 'evidence/validation-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
