"""Serial A/B/A metadata costs against one disposable fixture per backend."""
import argparse
import asyncio
import importlib.util
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import tempfile
import time

from fastmcp import Client
from sql_safety_executor import create_server, load_config
from sql_safety_executor.database.registry import create_adapter

HERE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('matrix', HERE / 'scripts/matrix.py')
matrix = importlib.util.module_from_spec(spec)
spec.loader.exec_module(matrix)


async def worker(config, output, rounds):
    config = load_config(config)
    server = create_server(config)
    adapter = server.gateway_runtime.registry.get_adapter('matrix')
    policy = adapter._config.policy
    names = [r['table_name'] for r in adapter.get_table_directory()
             if policy.allows_metadata_table(r['table_name'], adapter.metadata_schema)]
    assert len(names) == 64
    operations = {
        'columns_one': lambda: adapter.get_columns('key_ba'),
        'columns_batch_one': lambda: adapter.get_columns_batch(['key_ba']),
        'columns_batch_13': lambda: adapter.get_columns_batch(names[:13]),
        'columns_batch_64': lambda: adapter.get_columns_batch(names),
    }
    result = {}
    try:
        async with Client(server, mode='auto') as client:
            for name in [*operations, 'schema_compact_64', 'schema_full_64']:
                async def invoke():
                    if name in operations:
                        return operations[name]()
                    return (await client.call_tool('get_full_schema', {'detail_level': 'compact' if 'compact' in name else 'full'})).structured_content
                for _ in range(5):
                    await invoke()
                samples = []
                for _ in range(rounds):
                    start = time.perf_counter()
                    value = await invoke()
                    samples.append((time.perf_counter() - start) * 1000)
                encoded = json.dumps(value, ensure_ascii=False, separators=(',', ':'))
                result[name] = {'samples_ms': samples, 'median_ms': statistics.median(samples),
                    'p95_ms': sorted(samples)[max(0, int(.95 * len(samples)) - 1)],
                    'payload_chars': len(encoded), 'objects': len(names)}
    finally:
        server.gateway_runtime.close()
    output.write_text(json.dumps(result, indent=2) + '\n')


def control(output, old_python, rounds):
    record = {}
    with tempfile.TemporaryDirectory(prefix='v382-key-cost-') as temporary:
        root = Path(temporary)
        for backend in ['sqlite', 'mysql']:
            folder = root / backend
            folder.mkdir()
            with matrix.fixture(backend, folder, table_count=64) as (connection, schema, names, truth, optional):
                connection['read'] = {'mode': 'allowlist', 'relations': [{'schema': schema, 'name': n} for n in names]}
                matrix.write_toml(folder / 'server.toml', {'schema_version': 1, 'server': {'default_connection': 'matrix'},
                    'files': {'connections': 'connections.toml'}, 'limits': {'schema_tables': 0}})
                matrix.write_toml(folder / 'connections.toml', {'schema_version': 1, 'connections': {'matrix': connection}})
                record[backend] = {}
                for phase, python in [('A1', old_python), ('B', sys.executable), ('A2', old_python)]:
                    target = folder / (phase + '.json')
                    subprocess.run([python, str(Path(__file__).resolve()), '--worker', str(folder / 'server.toml'),
                        '--output', str(target), '--rounds', str(rounds)], check=True, env=os.environ.copy(), timeout=240)
                    record[backend][phase] = json.loads(target.read_text())
    output.write_text(json.dumps({'rounds': rounds, 'warmups': 5, 'order': ['A1', 'B', 'A2'],
        'records': record, 'scope': 'Serial same-fixture warm adapter and inprocess Client costs; no model/provider token measurements'}, indent=2) + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--worker', type=Path)
    parser.add_argument('--old-python')
    parser.add_argument('--rounds', type=int, default=30)
    args = parser.parse_args()
    assert not args.output.exists()
    if args.worker:
        asyncio.run(worker(args.worker, args.output, args.rounds))
    else:
        control(args.output, args.old_python, args.rounds)
