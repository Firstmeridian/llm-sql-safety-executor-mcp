"""Compare primary-key metadata with independent SQLite/MySQL catalogs.

The live MySQL fixture owns a new, random schema and drops only that schema.
Private deployment files and pre-existing business objects are never changed.
"""
import argparse
import asyncio
from contextlib import contextmanager
from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
import uuid

from fastmcp import Client
from fastmcp.client.transports import StdioTransport
from sql_safety_executor import create_server, load_config
from sql_safety_executor.database.registry import create_adapter


ROOT = Path(__file__).resolve().parents[4]
COMMON = {
    'key_ab': 'a INTEGER NOT NULL,b INTEGER NOT NULL,PRIMARY KEY(a,b)',
    'key_ba': 'a INTEGER NOT NULL,b INTEGER NOT NULL,PRIMARY KEY(b,a)',
    'unique_only': 'a INTEGER NOT NULL,b INTEGER NOT NULL,UNIQUE(a)',
    'unique_composite': 'a INTEGER NOT NULL,b INTEGER NOT NULL,UNIQUE(b,a)',
    'nullable_unique': 'a INTEGER,b INTEGER,UNIQUE(a)',
    'no_key': 'a INTEGER,b INTEGER',
    'key_and_unique': 'a INTEGER NOT NULL UNIQUE,b INTEGER PRIMARY KEY',
    'key_desc': 'a INTEGER NOT NULL,b INTEGER NOT NULL,PRIMARY KEY(b DESC,a ASC)',
    'mixed_case': '`Camel` INTEGER NOT NULL,b INTEGER NOT NULL,PRIMARY KEY(b,`cAmEl`)',
    'dot.表 x': '`a b` INTEGER NOT NULL,`K` INTEGER NOT NULL,PRIMARY KEY(`K`,`a b`)',
}


def identifier(value, dialect):
    q = '`' if dialect == 'mysql' else '"'
    return q + value.replace(q, q + q) + q


def write_toml(path, data):
    def value(v):
        if isinstance(v, dict):
            return '{' + ','.join(json.dumps(k) + '=' + value(x) for k, x in v.items()) + '}'
        if isinstance(v, (list, tuple)):
            return '[' + ','.join(value(x) for x in v) + ']'
        return json.dumps(v, ensure_ascii=False)
    path.write_text('\n'.join(json.dumps(k) + '=' + value(v) for k, v in data.items()) + '\n')


@contextmanager
def fixture(backend, folder, *, table_count=None):
    if backend == 'sqlite':
        path = folder / 'fixture.sqlite'
        with sqlite3.connect(path) as db:
            for name, definition in COMMON.items():
                db.execute(f'CREATE TABLE {identifier(name, backend)}({definition})')
                db.execute(f'INSERT INTO {identifier(name, backend)} VALUES(7,99)')
            db.executescript('''
                CREATE TABLE without_rowid(a INTEGER NOT NULL,b INTEGER NOT NULL,PRIMARY KEY(b,a)) WITHOUT ROWID;
                INSERT INTO without_rowid VALUES(7,99);
                CREATE TABLE repeated_pk(a INTEGER,b INTEGER,PRIMARY KEY(b,a,b));
                INSERT INTO repeated_pk VALUES(7,99);
                CREATE VIEW key_view AS SELECT a,b FROM key_ba;
                CREATE TABLE secret(n INTEGER); INSERT INTO secret VALUES(123);
            ''')
            names = [*COMMON, 'without_rowid', 'repeated_pk', 'key_view']
            if table_count is not None:
                for i in range(table_count - (len(names) - 1)):
                    name = 'perf_' + str(i).zfill(3)
                    db.execute(f'CREATE TABLE {name}(a INTEGER NOT NULL,b INTEGER NOT NULL,PRIMARY KEY(b,a))')
                    names.append(name)
            truth = {}
            for name in names:
                columns = [list(r) for r in db.execute(f'PRAGMA main.table_xinfo({identifier(name, backend)})')]
                indexes = []
                for row in db.execute(f'PRAGMA main.index_list({identifier(name, backend)})'):
                    indexes.append({'catalog': list(row), 'parts': [list(r) for r in db.execute(f'PRAGMA main.index_xinfo({identifier(row[1], backend)})')]})
                truth[name] = {'columns': columns, 'indexes': indexes,
                    'primary_key': [r[1] for r in sorted(columns, key=lambda r: r[5]) if r[5]],
                    'positions': {r[1]: r[5] for r in columns if r[5]}}
        before = hashlib.sha256(path.read_bytes()).hexdigest()
        yield {'type': 'sqlite', 'sqlite': {'path': str(path)}}, 'main', names, truth, []
        assert hashlib.sha256(path.read_bytes()).hexdigest() == before
        return

    # Explicit owner-approved test-fixture work; no mutation Skill is exercised.
    config = load_config(ROOT / 'config/server.toml').connections['trade_analysis_mysql']
    admin = create_adapter(config=config)
    schema = 'mcp_drr141_' + uuid.uuid4().hex[:16]
    created = False
    try:
        assert admin.connect() and admin._engine is not None
        with admin._engine.connect() as db:
            db.exec_driver_sql(f'CREATE DATABASE `{schema}` CHARACTER SET utf8mb4')
            created = True
            engines = {r[0].upper(): r[1] for r in db.exec_driver_sql('SHOW ENGINES')}
            names, optional = [], []
            for name, definition in COMMON.items():
                db.exec_driver_sql(f'CREATE TABLE `{schema}`.{identifier(name, backend)}({definition}) ENGINE=InnoDB')
                db.exec_driver_sql(f'INSERT INTO `{schema}`.{identifier(name, backend)} VALUES(7,99)')
                names.append(name)
            for engine in ['MyISAM', 'MEMORY']:
                if engines.get(engine.upper()) not in {'YES', 'DEFAULT'}:
                    optional.append({'engine': engine, 'state': 'not_available'})
                    continue
                name = 'unique_' + engine.lower()
                db.exec_driver_sql(f'CREATE TABLE `{schema}`.`{name}`(a INTEGER NOT NULL,b INTEGER NOT NULL,UNIQUE(a)) ENGINE={engine}')
                db.exec_driver_sql(f'INSERT INTO `{schema}`.`{name}` VALUES(7,99)')
                names.append(name)
                optional.append({'engine': engine, 'state': 'tested'})
            db.exec_driver_sql(f'CREATE VIEW `{schema}`.key_view AS SELECT a,b FROM `{schema}`.key_ba')
            db.exec_driver_sql(f'CREATE TABLE `{schema}`.secret(n INTEGER)')
            db.exec_driver_sql(f'INSERT INTO `{schema}`.secret VALUES(123)')
            names.append('key_view')
            if table_count is not None:
                for i in range(table_count - (len(names) - 1)):
                    name = 'perf_' + str(i).zfill(3)
                    db.exec_driver_sql(f'CREATE TABLE `{schema}`.`{name}`(a INTEGER NOT NULL,b INTEGER NOT NULL,PRIMARY KEY(b,a))')
                    names.append(name)
            db.commit()
            truth = {}
            for name in names:
                columns = [list(r) for r in db.exec_driver_sql(
                    'SELECT COLUMN_NAME,DATA_TYPE,IS_NULLABLE,COLUMN_KEY,COLUMN_DEFAULT FROM INFORMATION_SCHEMA.COLUMNS WHERE BINARY TABLE_SCHEMA=BINARY %s AND BINARY TABLE_NAME=BINARY %s ORDER BY ORDINAL_POSITION', (schema, name))]
                constraints = [list(r) for r in db.exec_driver_sql(
                    "SELECT COLUMN_NAME,ORDINAL_POSITION FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE BINARY TABLE_SCHEMA=BINARY %s AND BINARY TABLE_NAME=BINARY %s AND CONSTRAINT_NAME='PRIMARY' ORDER BY ORDINAL_POSITION", (schema, name))]
                indexes = [dict(r._mapping) for r in db.exec_driver_sql(f'SHOW INDEX FROM `{schema}`.{identifier(name, backend)}')]
                truth[name] = {'columns': columns, 'primary_key': [r[0] for r in constraints],
                    'positions': dict(constraints), 'indexes': indexes}
        # Password only crosses an ephemeral environment variable, never reports or files.
        os.environ['V382_MATRIX_MYSQL_PASSWORD'] = config.mysql_password.get_secret_value()
        yield {'type': 'mysql', 'mysql': {'host': config.mysql_host, 'user': config.mysql_user,
            'password': {'env': 'V382_MATRIX_MYSQL_PASSWORD'}, 'database': schema,
            **({'sql_mode': list(config.mysql_sql_mode)} if config.mysql_sql_mode is not None else {})}}, schema, names, truth, optional
    finally:
        os.environ.pop('V382_MATRIX_MYSQL_PASSWORD', None)
        if created:
            # Only the schema successfully created by this invocation can be dropped.
            with admin._engine.connect() as db:
                db.exec_driver_sql(f'DROP DATABASE `{schema}`')
                db.commit()
                assert not db.exec_driver_sql('SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME=%s', (schema,)).fetchall()
        admin.close()


async def run(output, backend, stage):
    calls = []
    with tempfile.TemporaryDirectory(prefix='v382-key-matrix-') as temporary:
        folder = Path(temporary)
        with fixture(backend, folder) as (connection, schema, names, truth, optional):
            connection['read'] = {'mode': 'allowlist', 'relations': [{'schema': schema, 'name': n} for n in names]}
            write_toml(folder / 'server.toml', {'schema_version': 1, 'server': {'default_connection': 'matrix'},
                'files': {'connections': 'connections.toml'}, 'limits': {'schema_tables': 0}, 'tools': {'table_summary': True}})
            write_toml(folder / 'connections.toml', {'schema_version': 1, 'connections': {'matrix': connection}})
            for transport in ['inprocess', 'stdio']:
                for mode in ['auto', 'legacy']:
                    server = create_server(load_config(folder / 'server.toml')) if transport == 'inprocess' else None
                    target = server or StdioTransport(command=sys.executable,
                        args=[str(Path(__file__).resolve()), '--child', str(folder / 'server.toml')],
                        env={k: v for k, v in os.environ.items() if k == 'V382_MATRIX_MYSQL_PASSWORD'})
                    try:
                        async with asyncio.timeout(90), Client(target, mode=mode) as client:
                            cases = [(n, 'describe_table', {'table_name': n}) for n in names]
                            cases += [(n, 'get_table_summary', {'table_name': n, 'exact_count': True}) for n in ['key_ab', 'key_ba', 'unique_only']]
                            cases += [('compact', 'get_full_schema', {'detail_level': 'compact'}),
                                      ('ungrouped', 'get_full_schema', {'detail_level': 'compact', 'group_identical': False}),
                                      ('full', 'get_full_schema', {'detail_level': 'full'}),
                                      ('directory', 'list_tables', {}),
                                      ('raw_key', 'query', {'sql': 'SELECT a,b FROM key_ba'}),
                                      ('sample_key', 'sample', {'table_name': 'key_ba', 'limit': 1}),
                                      ('secret_denied', 'query', {'sql': 'SELECT n FROM secret'}),
                                      ('sleep_denied', 'query', {'sql': 'SELECT SLEEP(0)'})]
                            for name, tool, arguments in cases:
                                result = await client.call_tool(tool, arguments, raise_on_error=False)
                                payload = result.structured_content
                                record = {'backend': backend, 'transport': transport, 'mode': mode,
                                    'case': name, 'tool': tool, 'isError': result.is_error, 'structured': payload,
                                    'content': [c.model_dump(mode='json', exclude_none=True) for c in result.content]}
                                calls.append(record)
                                assert not result.is_error and payload is not None, record
                                assert json.loads(record['content'][0]['text']) == payload
                                assert payload['success'] == (not name.endswith('_denied')), record
                    finally:
                        if server:
                            server.gateway_runtime.close()
    # SHOW INDEX includes the disposable schema's table name but no deployment credentials.
    output.write_text(json.dumps({'stage': stage, 'backend': backend, 'truth': truth, 'calls': calls,
        'optional': optional, 'fixture_cleaned': True, 'configured_files_changed': False}, default=str, indent=2) + '\n')
    print(json.dumps({'backend': backend, 'stage': stage, 'objects': len(truth), 'calls': len(calls), 'fixture_cleaned': True}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--backend', choices=['sqlite', 'mysql'])
    parser.add_argument('--output', type=Path)
    parser.add_argument('--stage', default='current')
    parser.add_argument('--child', type=Path)
    args = parser.parse_args()
    if args.child:
        create_server(load_config(args.child)).run(transport='stdio', show_banner=False)
    else:
        assert args.output and not args.output.exists()
        asyncio.run(run(args.output, args.backend, args.stage))
