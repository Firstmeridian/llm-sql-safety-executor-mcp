"""Same configured aliases via a fresh CLI; not resident Host acceptance."""
import asyncio
import gzip
import json
from pathlib import Path

from fastmcp import Client
from fastmcp.client.transports import StdioTransport

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[3]

async def main():
    target = HERE / 'evidence/fresh_cli_results.json'
    assert not target.exists()
    plan = json.loads(gzip.decompress((HERE.parent / 'evidence/native_plan.json.gz').read_bytes()))
    transport = StdioTransport(command=str(ROOT / '.venv-v38/bin/sql-safety-executor'),
                               args=['serve', '--config', str(ROOT / 'config/server.toml')])
    records = []
    async with asyncio.timeout(90), Client(transport, mode='auto') as client:
        for call in plan['calls']:
            result = await client.call_tool(call['tool'], call['arguments'], raise_on_error=False)
            records.append({**call, 'result': {'isError': result.is_error,
                'structuredContent': result.structured_content,
                'content': [c.model_dump(mode='json', exclude_none=True) for c in result.content]}})
    target.write_text(json.dumps({'scope': 'Fresh configured-source CLI/stdin-stdout auto, separate from resident Host',
                                 'calls': records}, indent=2) + '\n')
    print(json.dumps({'fresh_cli_calls': len(records), 'resident_acceptance': False}))

if __name__ == '__main__':
    asyncio.run(main())
