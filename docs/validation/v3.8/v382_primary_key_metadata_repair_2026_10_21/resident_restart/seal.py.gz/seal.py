"""Seal the real mismatch and deferred reconnect without rewriting parent seals."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
from urllib.parse import unquote

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[3]
PUBLIC = ROOT / 'docs/validation/v3.8/v382_primary_key_metadata_repair_2026_10_21/resident_restart'
assert not (HERE / 'manifest.json').exists() and not (PUBLIC / 'manifest.json').exists()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text()) if path.exists() else json.loads(gzip.decompress(path.with_suffix(path.suffix + '.gz').read_bytes()))

def files(folder):
    return sorted(p for p in folder.rglob('*') if p.is_file() and p.name != 'manifest.json' and '__pycache__' not in p.parts)

verification = read(HERE / 'evidence/verification.json')
assert verification['native_host']['passed'] == 7 and verification['native_host']['failed'] == 5
assert verification['fresh_configured_cli']['passed'] == 12 and verification['resident_acceptance_complete'] is False
before = read(HERE / 'evidence/before.json')
for name, digest in before['resources'].items():
    assert sha((ROOT / name).read_bytes()) == digest
for name, digest in before['private_toml_sha256'].items():
    assert sha((ROOT / name).read_bytes()) == digest
for record in before['prior_seals']:
    manifest = ROOT / record['manifest']
    assert sha(manifest.read_bytes()) == record['sha256']
    data = read(manifest)
    items = data['files'].items() if isinstance(data['files'], dict) else ((x['path'], x) for x in data['files'])
    paths = {}
    for name, meta in items:
        path = next(p for p in [manifest.parent / name, manifest.parent.parent / name, ROOT / name] if p.is_file())
        paths[name] = path
        content = path.read_bytes()
        assert sha(content) == (meta['sha256'] if isinstance(meta, dict) else meta)
        if isinstance(meta, dict):
            if 'bytes' in meta:
                assert len(content) == meta['bytes']
            if 'decoded_sha256' in meta:
                decoded = gzip.decompress(content)
                assert sha(decoded) == meta['decoded_sha256'] and len(decoded) == meta['decoded_bytes']
    for name, meta in data.get('compressed_decoded_records', {}).items():
        raw = gzip.decompress(paths[name].read_bytes())
        assert sha(raw) == meta.get('decoded_sha256', meta.get('sha256'))
        assert len(raw) == meta.get('decoded_bytes', meta.get('bytes'))

for path in list((HERE / 'evidence').iterdir()):
    if path.suffix == '.log' or path.suffix == '.json' and path.stat().st_size > 10000:
        target = path.with_suffix(path.suffix + '.gz')
        assert not target.exists()
        target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
        path.unlink()
for path in (HERE / 'evidence').iterdir():
    if path.is_file():
        shutil.copyfile(path, PUBLIC / path.name)
for path in (HERE / 'scripts').glob('*.py'):
    (PUBLIC / (path.name + '.gz')).write_bytes(gzip.compress(path.read_bytes(), mtime=0))

private_count, public_count = len(files(HERE)) + 1, len(files(PUBLIC)) + 1
total = 2279 + private_count + public_count
handoff = ROOT / 'local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md'
text = handoff.read_text()
anchor = '## 此前检查点：DRR-141源码／安装完成（2026-10-21，当时待重启）'
assert anchor in text
text = text.replace(anchor, f'本次差异检查点封存private{private_count}／public{public_count}记录，累计**75份manifest／{total}条文件记录**。核验由本次before.json的73旧manifest加本次两份完成；后续重连另建补充，保留当前失败及父pending。\n\n' + anchor, 1)
handoff.write_text(text)

names = ['AI_COLLABORATION_GUIDE.md', 'README.md', 'README_ZH.md', 'REFACTORING_LOG.md', 'REFACTORING_LOG_ZH.md',
         'docs/README.md', 'docs/README_ZH.md', 'docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md',
         'docs/releases/RELEASE_NOTES_v3_8.md', 'docs/guides/TEST_MCP_CLIENT_GUIDE.md',
         'docs/security/DESIGN_RISK_REGISTER.md', 'docs/security/DESIGN_RISK_REGISTER_ZH.md', 'docs/security/V3_8_SECURITY.md',
         'docs/validation/v3.8/V3_8_2_PRIMARY_KEY_METADATA_REPAIR_2026_10_21_ZH.md',
         str((PUBLIC / 'README.md').relative_to(ROOT)), 'local_archive/v382_review/README.md',
         str(handoff.relative_to(ROOT)), str((HERE / 'reports/README_ZH.md').relative_to(ROOT))]
checked, broken = 0, []
for name in names:
    path = ROOT / name
    for link in re.findall(r'\[[^\]\n]+\]\(([^)\s]+)\)', path.read_text()):
        if re.match(r'^[a-zA-Z]+:', link) or link.startswith('#'):
            continue
        link = unquote(link.split('#', 1)[0].strip('<>'))
        if not link:
            continue
        target = Path(link) if link.startswith('/') else path.parent / link
        checked += 1
        if not target.exists() and not target.with_suffix(target.suffix + '.gz').exists():
            broken.append({'document': name, 'link': link})
assert not broken, broken
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
checks = dict(documents={name: sha((ROOT / name).read_bytes()) for name in names}, local_links_checked=checked,
    broken_links=broken, git_diff_check='passed', prior_manifests=73, prior_file_records=2279,
    new_private_records=private_count, new_public_records=public_count,
    cumulative_manifests=75, cumulative_file_records=total,
    scope='MySQL server acceptance; no MariaDB requirement. Native7/12 vs fresh CLI12/12, channel consistency pending and cause unconfirmed. Owner deferred reconnect.')
(HERE / 'evidence/documentation_checks.json').write_text(json.dumps(checks, indent=2) + '\n')
shutil.copyfile(HERE / 'evidence/documentation_checks.json', PUBLIC / 'documentation_checks.json')

for folder, count in [(HERE, private_count), (PUBLIC, public_count)]:
    entries = {}
    for path in files(folder):
        content = path.read_bytes()
        meta = dict(bytes=len(content), sha256=sha(content))
        if path.suffix == '.gz':
            decoded = gzip.decompress(content)
            meta.update(decoded_bytes=len(decoded), decoded_sha256=sha(decoded))
        entries[str(path.relative_to(folder))] = meta
    assert len(entries) == count
    manifest = dict(date='2026-10-21', checkpoint='DRR141 reported restart: native7/12, fresh CLI12/12, owner deferred channel reconnect',
        scope='Actual native mismatch retained; no source/configuration/database mutation or new model/regression/cost claim. MySQL server target; MariaDB not required.',
        append_rule='Preserve parent pending and this failure checkpoint; append reconnection results separately', files=entries)
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    for name, meta in entries.items():
        assert sha((folder / name).read_bytes()) == meta['sha256']
print(json.dumps(dict(private_records=private_count, public_records=public_count, cumulative_manifests=75,
    cumulative_file_records=total, local_links_checked=checked, resident_acceptance_complete=False)))
