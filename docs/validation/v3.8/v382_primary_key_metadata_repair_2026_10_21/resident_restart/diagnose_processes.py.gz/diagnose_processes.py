"""Read-only launch/timing evidence; do not infer the Host binding from PIDs."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[3]
boot = next(int(r.split()[1]) for r in Path('/proc/stat').read_text().splitlines() if r.startswith('btime '))
ticks = os.sysconf('SC_CLK_TCK')

def process(path):
    stat = (path / 'stat').read_text().rsplit(')', 1)[1].split()
    return dict(pid=int(path.name), ppid=int(stat[1]), name=(path / 'comm').read_text().strip(),
                start_utc=datetime.fromtimestamp(boot + int(stat[19]) / ticks, timezone.utc).isoformat())

result = []
for path in Path('/proc').iterdir():
    if not path.name.isdigit():
        continue
    try:
        argv = (path / 'cmdline').read_bytes().decode(errors='replace').split('\0')
        if not argv or any('\n' in arg for arg in argv):
            continue
        if not any('sql-safety-executor' in arg for arg in argv):
            continue
        row = process(path)
        row.update(executable=os.readlink(path / 'exe'), cwd=os.readlink(path / 'cwd'),
                   launch_arguments=[a for a in argv if len(a) < 250 and ('sql-safety-executor' in a or a.endswith('.toml'))])
        ancestors = []
        parent = row['ppid']
        for _ in range(5):
            if parent <= 0:
                break
            node = process(Path('/proc') / str(parent))
            ancestors.append(node)
            parent = node['ppid']
        row['ancestors'] = ancestors
        result.append(row)
    except OSError:
        continue
sources = {str(p.relative_to(ROOT)): datetime.fromtimestamp(p.stat().st_mtime, timezone.utc).isoformat()
           for p in [ROOT / 'src/sql_safety_executor/database/sqlite.py', ROOT / 'src/sql_safety_executor/database/mysql.py']}
output = dict(observed_utc=datetime.now(timezone.utc).isoformat(), processes=result,
              source_mtime_utc=sources,
              limit='Multiple launches and their ancestor names do not identify which process serves the current MCP tool channel. No process stopped, attached or modified; no environment/credentials read.')
target = HERE / 'evidence/process_diagnostics.json'
assert not target.exists()
target.write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps(output))
