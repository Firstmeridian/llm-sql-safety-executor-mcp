"""Check actual Host/fresh-CLI records without turning a mismatch into a pass."""
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3

from sql_safety_executor import load_config
from sql_safety_executor.database.registry import create_adapter

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[3]

def read(path):
    return json.loads(path.read_text()) if path.exists() else json.loads(gzip.decompress(path.with_suffix(path.suffix + '.gz').read_bytes()))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def columns(raw, backend, positions):
    result = []
    for r in raw:
        if backend == 'sqlite' and r[6] == 1:
            continue
        c = dict(column_name=r[1] if backend == 'sqlite' else r[0],
                 data_type=r[2] if backend == 'sqlite' else r[1],
                 nullable=('NO' if r[3] else 'YES') if backend == 'sqlite' else r[2],
                 key_type=('PRI' if r[5] else '') if backend == 'sqlite' else r[3], default_value=r[4])
        if c['column_name'] in positions:
            c['primary_key_position'] = positions[c['column_name']]
        if backend == 'sqlite' and r[6] in {2, 3}:
            c['generation_type'] = {2: 'virtual', 3: 'stored'}[r[6]]
        result.append(c)
    return result

def full_columns(cols):
    return [dict(name=c['column_name'], type=c['data_type'], nullable=c['nullable'],
                 key=c['key_type'], default=c['default_value'],
                 **{k: c[k] for k in ['primary_key_position', 'generation_type'] if k in c}) for c in cols]

def check_calls(data, plan):
    checked = []
    for expected, actual in zip(plan['calls'], data['calls'], strict=True):
        assert all(actual[k] == expected[k] for k in ['case', 'tool', 'arguments', 'expected'])
        failures = []
        result = actual.get('result', {})
        value = result.get('structuredContent', {})
        if result.get('isError') is not False:
            failures.append('MCP error or transport failure')
        if not result.get('content') or json.loads(result['content'][0]['text']) != value:
            failures.append('application text/structured mismatch')
        e = expected['expected']
        if value.get('success') is not ('error_code' not in e):
            failures.append('unexpected business success')
        if value.get('connection_id') != expected['arguments']['connection_id']:
            failures.append('connection identity')
        for key in ['data', 'error_code']:
            if key in e and value.get(key) != e[key]:
                failures.append(key)
        backend = 'sqlite' if expected['arguments']['connection_id'] == 'sqlite_features_sqlite' else 'mysql'
        truth = plan[backend + '_truth']
        if expected['tool'] == 'describe_table':
            name = expected['arguments']['table_name']
            native = truth[name]
            if value.get('columns') != columns(native['columns'], backend, native['positions']):
                failures.append('complete columns including actual PRIMARY positions')
            primary = next((i['columns'] for i in value.get('indexes', []) if i['primary']), [])
            if primary != native['primary_key'] or value.get('indexes_status') != 'complete':
                failures.append('complete primary index')
        if expected['tool'] == 'get_full_schema':
            cols = {name: columns(t['columns'], backend, t['positions']) for name,t in truth.items()}
            if value.get('truncated') or value.get('total_tables') != len(cols) or value.get('total_columns') != sum(map(len, cols.values())):
                failures.append('schema totals/completeness')
            if expected['arguments']['detail_level'] == 'compact':
                groups = {t['name']: g for g in value.get('schema_groups', []) for t in g['tables']}
                if set(groups) != set(truth):
                    failures.append('table set')
                for name, t in truth.items():
                    group = groups.get(name, {})
                    if group.get('primary_key') != t['primary_key']:
                        failures.append(name + ': ordered PRIMARY members')
                    if group.get('columns') != [[c['column_name'], c['data_type']] for c in cols[name]]:
                        failures.append(name + ': visible columns')
            else:
                tables = value.get('schema', {})
                if set(tables) != set(truth):
                    failures.append('table set')
                for name, native in cols.items():
                    if tables.get(name, {}).get('columns') != full_columns(native):
                        failures.append(name + ': complete columns including actual PRIMARY positions')
        checked.append(dict(case=expected['case'], passed=not failures, failures=failures))
    return dict(calls=len(checked), passed=sum(c['passed'] for c in checked),
                failed=sum(not c['passed'] for c in checked), checks=checked)

def main():
    output = HERE / 'evidence/verification.json'
    assert not output.exists()
    before = read(HERE / 'evidence/before.json')
    plan = read(HERE.parent / 'evidence/native_plan.json')
    resources = {str(p.relative_to(ROOT)): sha(p) for p in (ROOT / 'src/sql_safety_executor').rglob('*')
                 if p.is_file() and p.suffix in {'.py', '.md'}}
    assert resources == before['resources'] == plan['resources'] and len(resources) == 77
    installed = read(HERE.parent / 'evidence/installed_resources.json')
    assert {k.removeprefix('src/sql_safety_executor/'): v for k,v in resources.items()} == installed['installed']['resources']
    for name, digest in before['private_toml_sha256'].items():
        assert sha(ROOT / name) == digest
    config = load_config(ROOT / 'config/server.toml')
    path = Path(config.connections['sqlite_features_sqlite'].sqlite_database_path)
    assert sha(path) == before['sqlite_file_sha256'] == plan['sqlite_file_sha256']
    truth = {'sqlite': {}, 'mysql': {}}
    with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as db:
        for name, t in plan['sqlite_truth'].items():
            raw = [list(r) for r in db.execute("PRAGMA main.table_xinfo('" + name.replace("'", "''") + "')")]
            assert raw == t['columns']
            truth['sqlite'][name] = raw
    cfg = config.connections['sakila_mysql']
    adapter = create_adapter(config=cfg)
    try:
        for name, t in plan['mysql_truth'].items():
            rows = [list(r) for r in adapter.execute('SELECT COLUMN_NAME,DATA_TYPE,IS_NULLABLE,COLUMN_KEY,COLUMN_DEFAULT '
                'FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=:schema_name AND TABLE_NAME=:table_name ORDER BY ORDINAL_POSITION',
                params={'schema_name': cfg.mysql_database, 'table_name': name})]
            indexes = [list(r) for r in adapter.execute('SHOW INDEX FROM `' + cfg.mysql_database.replace('`', '``') + '`.`' + name.replace('`', '``') + '`')]
            primary = sorted((r for r in indexes if r[2] == 'PRIMARY'), key=lambda r:r[3])
            assert rows == t['columns'] and {r[4]: r[3] for r in primary} == t['positions']
            truth['mysql'][name] = dict(columns=rows, indexes=indexes)
    finally:
        adapter.close()
    (HERE / 'evidence/current_native_catalogs.json').write_text(json.dumps(truth, indent=2) + '\n')
    assert sha(path) == before['sqlite_file_sha256']
    count = 0
    for spec in before['prior_seals']:
        manifest = ROOT / spec['manifest']
        assert sha(manifest) == spec['sha256']
        data = read(manifest)
        items = data['files'].items() if isinstance(data['files'], dict) else ((v['path'],v) for v in data['files'])
        paths, size = {}, 0
        for name, meta in items:
            p = next(p for p in [manifest.parent / name, manifest.parent.parent / name, ROOT / name] if p.is_file())
            paths[name] = p
            assert sha(p) == (meta['sha256'] if isinstance(meta, dict) else meta)
            if isinstance(meta, dict):
                if 'bytes' in meta:
                    assert p.stat().st_size == meta['bytes']
                if 'decoded_sha256' in meta:
                    raw = gzip.decompress(p.read_bytes())
                    assert hashlib.sha256(raw).hexdigest() == meta['decoded_sha256'] and len(raw) == meta['decoded_bytes']
            size += 1
        for name, meta in data.get('compressed_decoded_records', {}).items():
            raw = gzip.decompress(paths[name].read_bytes())
            assert hashlib.sha256(raw).hexdigest() == meta.get('decoded_sha256', meta.get('sha256'))
            assert len(raw) == meta.get('decoded_bytes', meta.get('bytes'))
        assert size == spec['files']
        count += size
    assert len(before['prior_seals']) == 73 and count == 2279
    native = check_calls(read(HERE / 'evidence/native_results.json'), plan)
    fresh = check_calls(read(HERE / 'evidence/fresh_cli_results.json'), plan)
    assert fresh['passed'] == fresh['calls'] == native['calls'] == 12
    summary = dict(native_host=native, fresh_configured_cli=fresh,
        resident_acceptance_complete=native['failed'] == 0, resources_unchanged=77,
        private_tomls_unchanged=3, sqlite_file_unchanged=True,
        independent_catalogs_unchanged=dict(sqlite_tables=6,mysql_tables=16,mysql_columns=89),
        prior_seals=dict(manifests=73,records=2279),
        decision='Owner chose to reconnect later; keep native failure evidence and pending status. MySQL is the server validation target; MariaDB is not an acceptance requirement.',
        scope='No production/configuration/prompt/dependency change, new build/full regression/model/token/latency claim. Host binding/cache root cause is unconfirmed.')
    output.write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary))

if __name__ == '__main__':
    main()
