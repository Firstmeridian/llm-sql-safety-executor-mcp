"""Seal the source/package checkpoint; append post-owner-restart evidence later."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / 'docs/validation/v3.8/v382_primary_key_metadata_repair_2026_10_21'
assert not (HERE / 'manifest.json').exists() and not (PUBLIC / 'manifest.json').exists()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def files(folder):
    return sorted(p for p in folder.rglob('*') if p.is_file()
                  and p.name != 'manifest.json' and '__pycache__' not in p.parts)

# Revalidate all previous seals, private configuration and source/package matrix.
subprocess.run([str(ROOT / '.venv-v38/bin/python'), str(HERE / 'scripts/verify.py')],
               cwd=ROOT, check=True, stdout=subprocess.DEVNULL)
record = json.loads((HERE / 'evidence/installed_resources.json').read_text())
current = {str(p.relative_to(ROOT / 'src/sql_safety_executor')): digest(p.read_bytes())
           for p in (ROOT / 'src/sql_safety_executor').rglob('*')
           if p.is_file() and p.suffix in {'.py', '.md'}}
assert len(current) == 77 and current == record['installed']['resources']

for path in list((HERE / 'evidence').glob('*')):
    if path.is_file() and (path.suffix == '.log' or path.suffix == '.json' and path.stat().st_size > 10000):
        target = path.with_suffix(path.suffix + '.gz')
        assert not target.exists()
        target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
        path.unlink()
for path in (HERE / 'baseline').rglob('*.py'):
    path.with_suffix(path.suffix + '.gz').write_bytes(gzip.compress(path.read_bytes(), mtime=0))
    path.unlink()
for path in (HERE / 'evidence').iterdir():
    if path.is_file():
        shutil.copyfile(path, PUBLIC / path.name)
for path in [*(HERE / 'scripts').glob('*.py'), ROOT / 'tests/test_primary_key_metadata_v382.py']:
    (PUBLIC / (path.name + '.gz')).write_bytes(gzip.compress(path.read_bytes(), mtime=0))

private_count, public_count = len(files(HERE)) + 1, len(files(PUBLIC)) + 1
total = 2180 + private_count + public_count
handoff = ROOT / 'local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md'
text = handoff.read_text()
anchor = '## 最新扩大补查：无新独立缺陷（2026-10-21，仅评估）'
assert anchor in text
text = text.replace(anchor, f'本批独立封存private{private_count}／public{public_count}条记录，累计**73份manifest／{total}条文件记录**。核验由本批baseline/current.json记录的71份旧manifest加本批两份完成；原生补充另增，保留父pending。\n\n' + anchor, 1)
handoff.write_text(text)

names = ['README.md', 'README_ZH.md', 'REFACTORING_LOG.md', 'REFACTORING_LOG_ZH.md',
         'docs/README.md', 'docs/README_ZH.md', 'docs/releases/RELEASE_NOTES_v3_8.md',
         'docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md', 'docs/guides/TEST_MCP_CLIENT_GUIDE.md',
         'docs/security/DESIGN_RISK_REGISTER.md', 'docs/security/DESIGN_RISK_REGISTER_ZH.md',
         'docs/security/V3_8_SECURITY.md',
         'docs/validation/v3.8/V3_8_2_PRIMARY_KEY_METADATA_REPAIR_2026_10_21_ZH.md',
         str((PUBLIC / 'README.md').relative_to(ROOT)), 'local_archive/v382_review/README.md',
         str(handoff.relative_to(ROOT)), str((HERE / 'reports/README_ZH.md').relative_to(ROOT))]
broken, checked = [], 0
for name in names:
    path = ROOT / name
    for link in re.findall(r'\[[^\]\n]+\]\(([^)\s]+)\)', path.read_text()):
        if re.match(r'^[a-zA-Z]+:', link) or link.startswith('#'):
            continue
        link = unquote(link.split('#', 1)[0].strip('<>'))
        if not link:
            continue
        target = Path(link) if link.startswith('/') else path.parent / link
        checked += 1
        if not target.exists() and not target.with_suffix(target.suffix + '.gz').exists():
            broken.append({'document': name, 'link': link})
assert not broken, broken
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
checks = dict(documents={name: digest((ROOT / name).read_bytes()) for name in names},
    local_links_checked=checked, broken_links=broken, git_diff_check='passed',
    current_status='DRR141 source/package passed; 12 native checks pending owner restart',
    prior_manifests=71, prior_file_records=2180, new_private_records=private_count,
    new_public_records=public_count, cumulative_manifests=73, cumulative_file_records=total,
    note='Historical seals, failure records, assessment uncertainty and earlier scoped model/native acceptance retained.')
(HERE / 'evidence/documentation_checks.json').write_text(json.dumps(checks, indent=2) + '\n')
shutil.copyfile(HERE / 'evidence/documentation_checks.json', PUBLIC / 'documentation_checks.json')

for folder, count in [(HERE, private_count), (PUBLIC, public_count)]:
    entries = {}
    for path in files(folder):
        content = path.read_bytes()
        meta = dict(bytes=len(content), sha256=digest(content))
        if path.suffix == '.gz':
            decoded = gzip.decompress(content)
            meta.update(decoded_bytes=len(decoded), decoded_sha256=digest(decoded))
        entries[str(path.relative_to(folder))] = meta
    assert len(entries) == count
    manifest = dict(date='2026-10-21', checkpoint='DRR141 source/package passed; owner restart pending',
        scope='3373 passes/4 skips; source/normal-wheel192 application calls each over both backends; serial A/B/A costs; no model/token claim',
        append_rule='Keep this pending checkpoint; append resident_restart separately', files=entries)
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    for name, meta in entries.items():
        assert digest((folder / name).read_bytes()) == meta['sha256']
print(json.dumps(dict(private_records=private_count, public_records=public_count,
    cumulative_manifests=73, cumulative_file_records=total, local_links_checked=checked,
    status='Source/package sealed; owner restart pending')))
