"""Seal final-source evidence; preserve prior manifests and resident pending scope."""
import difflib
import gzip
import hashlib
import json
import re
import subprocess
from pathlib import Path
from urllib.parse import unquote

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/cte_analysis_2026_10_15"
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(name):
    p=OUT/name
    if not p.exists():p=OUT/(name+".gz")
    b=p.read_bytes();return json.loads(gzip.decompress(b) if p.suffix==".gz" else b)
def log(name):
    p=Path('/tmp')/name
    return p.read_text() if p.exists() else gzip.decompress((OUT/(name+'.gz')).read_bytes()).decode()

source={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted((ROOT/'src/sql_safety_executor').rglob('*')) if p.is_file() and p.suffix in ('.py','.md')}
tests={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted((ROOT/'tests').rglob('*.py'))}
baseline=read('baseline_source.json')
changed=[p for p,v in source.items() if baseline.get(p)!=v]
assert changed==['src/sql_safety_executor/core/policy.py','src/sql_safety_executor/core/sql.py','src/sql_safety_executor/core/structure.py']
assert len(source)==70 and len(tests)==46
previous=ROOT/'docs/validation/v3.8/cte_classification_2026_10_15'
prior=json.loads((previous/'manifest.json').read_text())
for row in prior['artifacts']:assert sha((previous/row['path']).read_bytes())==row['sha256']
assert baseline==json.loads((previous/'automation.json').read_text())['source_sha256']

matrix=read('impact_matrix.json.gz');old_matrix=read('baseline_impact_matrix.json.gz')
assert matrix['source_sha256']==source and old_matrix['source_sha256']==baseline
assert (matrix['candidates'],matrix['native_valid'])==(314,304)
assert [r['sql'] for r in matrix['records']]==[r['sql'] for r in old_matrix['records']]
recovered={}
for scope,count in [('all',36),('allowlist',116)]:
    functional=[r for r in matrix['records'] if r['native_valid'] and r['group']!='authorization_control']
    assert len(functional)==300 and all(r['policy'][scope]['allowed'] for r in functional)
    recovered[scope]=sum(r['native_valid'] and r['group']!='authorization_control' and not old['policy'][scope]['allowed'] and r['policy'][scope]['allowed'] for old,r in zip(old_matrix['records'],matrix['records']))
    assert recovered[scope]==count
assert all(not r['policy']['allowlist']['allowed'] for r in matrix['records'] if r['group']=='authorization_control')

skills=read('impact_skills.json.gz');old_skills=read('baseline_impact_skills.json.gz')
assert skills['source_sha256']==source and old_skills['source_sha256']==baseline
assert skills['checks']=={'passed':56,'failed':0}
assert sum(c['isError'] for p in old_skills['profiles'] for c in p['calls'])==10
for old,new in zip(old_skills['profiles'],skills['profiles']):
    assert (old['mode'],old['read_scope'])==(new['mode'],new['read_scope'])
    assert [(c['tool'],c['arguments']) for c in old['calls']]==[(c['tool'],c['arguments']) for c in new['calls']]
    assert len(new['calls'])==14 and all(not c['isError'] for c in new['calls'])

wheel=read('installed_wheel.json');mysql=read('live_mysql.json.gz')
assert wheel['total_calls']==96 and wheel['source_files_verified']==70
assert source=={'src/'+p:v for p,v in wheel['installed_source_sha256'].items()}
assert mysql['source_sha256']==source and mysql['checks']=={'passed':24,'failed':0}
assert len(mysql['native_truth'])==10 and sum(r['native_rows'] is not None for r in mysql['native_truth'])==8
relations=read('adjacent_audit.json');contexts=read('boundary_context_audit.json.gz');functions=read('header_scan_matrix.json.gz');cost=read('cost_probe.json.gz')
for data in (relations,contexts,functions,cost):assert data['source_sha256']==source
assert (relations['native_valid_cases'],relations['unapproved_scope_misses'],relations['approved_conservative_refusals'])==(542,0,0)
assert (contexts['native_valid_cases'],contexts['scope_misses'],contexts['approved_refusals'])==(1000,0,0)
assert (functions['native_cases'],functions['after_denied'],functions['positive_controls'])==(576,576,12)
assert all(r['after_code']==r['expected_code'] for r in functions['records'])
assert all(s['calls']==360 for s in cost['summary'].values())
full=log('v381-cte-analysis-full.log')
m=re.search(r'(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s',full)
assert m and m.group(1,2,3)==('1750','4','77')
assert '0 errors, 0 warnings' in log('v381-cte-analysis-pyright.log')
assert 'Installed prompt resources and routing guidance valid' in log('v381-cte-analysis-prompt.log')

native_before=read('native_before.json');assert len(native_before['records'])==10
resident={'status':'Pending maintainer restart and identical-input verification for this implementation',
          'scope':'Previous diagnostic restart is closed for its earlier source; source/package/private Client success is not resident acceptance'}
if (OUT/'native_after_restart.json').exists():
    native=read('native_after_restart.json')
    assert native['checks']['failed']==0
    assert native['checks']['total']==len(native['records'])==20
    assert native['checks']['same_input_baseline']==native['checks']['supplemental']==10
    for row in native['records']:
        raw=row['raw'];data=raw['structuredContent']
        assert not raw['isError']
        assert json.loads(next(c['text'] for c in raw['content'] if c['type']=='text'))==data
        if row['expected']=='seven':assert data['success'] and data['data']==[{'n':7}]
        elif row['expected']=='report':
            assert data['success'] and len(data['data'])==5
            assert sum(r['order_count'] for r in data['data'])==5
            assert abs(sum(r['revenue'] for r in data['data'])-1709.93)<0.001
        else:assert not data['success'] and data['error_code']==row['expected']
    assert [r['args'] for r in native['records'][:10]]==[r['args'] for r in native_before['records']]
    for r in native['records'][:8]:assert r['raw']['structuredContent']['data']==[{'n':7}]
    assert native['records'][8]['raw']['structuredContent']['error_code']=='expensive_function_denied'
    assert native['records'][9]['raw']['structuredContent']['error_code']=='read_only_required'
    resident={'status':'Verified after maintainer restart','checks':native['checks']}

patch=''
for path in changed:
    old=gzip.decompress((OUT/('baseline_'+Path(path).name+'.gz')).read_bytes()).decode() if path in baseline else ''
    patch+=''.join(difflib.unified_diff(old.splitlines(keepends=True),(ROOT/path).read_text().splitlines(keepends=True),fromfile='before/'+path,tofile='after/'+path))
(OUT/'change_from_prior.patch').write_text(patch)
for p in Path('/tmp').glob('v381-cte-analysis-*.log'):(OUT/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in Path(__file__).parent.glob('*.py'):(OUT/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for name in ('installed_wheel.json','adjacent_audit.json'):
    p=OUT/name
    if p.exists():(OUT/(name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0));p.unlink()

automation={'version':'3.8.1','source_sha256':source,'test_source_sha256':tests,'changed_production_files':changed,
    'dedicated_new_regressions':188,'additional_write_controls':2,'full_suite':{'passed':1750,'skipped':4,'warnings':77,'seconds':float(m[4]),'mysql_optin':False},
    'pyright':{'errors':0,'warnings':0},'prompt_contract':'passed',
    'same_input_client_checks':56,'installed_cli_stdio_checks':96,'installed_resource_hashes':70,'real_mysql_client_checks':24,
    'mysql_native_valid_reads':8,'mysql_native_syntax_errors':2,
    'functional_matrix':{'candidates':314,'native_valid_reads':304,'functional_cases':300,'unauthorized_controls':4,'recovered':recovered},
    'adjacent':{'physical_names':542,'relation_contexts':1000,'scope_misses':0,'approved_refusals':0,'reserved_calls_denied':576,'function_positive_controls':12},
    'cost_probe':cost['summary'],'resident':resident,'prior_manifest_artifacts_verified':len(prior['artifacts']),
    'configured_database_writes':False,'production_config_changes':False,'new_model_cost_claim':False,
    'scope':'Shared bounded CTE structure and relation-role analysis, not complete production dialect AST/authorizer; no SQL execution rewriting or policy-result cache'}
(OUT/'automation.json').write_text(json.dumps(automation,ensure_ascii=False,indent=2)+'\n')
links=0
for line in subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).splitlines():
    p=ROOT/line[3:]
    if not p.is_file() or p.suffix!='.md':continue
    for target in re.findall(r'\]\(([^)\n]+)\)',p.read_text()):
        target=target.strip().strip('<>')
        if '://' in target or target.startswith(('#','mailto:','data:')):continue
        filename=target.split('#',1)[0]
        if filename:
            resolved=(p.parent/unquote(filename)).resolve()
            assert resolved==OUT/'manifest.json' or resolved.exists(),(p,filename)
            links+=1
for name in ('DESIGN_RISK_REGISTER.md','DESIGN_RISK_REGISTER_ZH.md'):
    rows=(ROOT/'docs/security'/name).read_text().splitlines()
    ids=[m[1] for row in rows if (m:=re.match(r'^\| DRR-2026-(\d{3}) \|',row))]
    assert sorted(ids)==[f'{i:03}' for i in range(1,100)]
    i=next(i for i,row in enumerate(rows) if row.startswith('| DRR-2026-099 |'))
    assert rows[i-1].startswith('| DRR-2026-098 |')
draft=(ROOT/'local_archive/v381_review/commit-message-complete-v381.txt').read_text()
assert len(draft)<850 and sum(line.startswith('- ') for line in draft.splitlines())==7 and 'through 099' in draft
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
assert not subprocess.check_output(['git','diff','--','pyproject.toml','uv.lock'],cwd=ROOT)
(OUT/'document_checks.json').write_text(json.dumps({'local_file_links':links,'bilingual_drr_ids':99,'latest_drr_contiguous':True,'draft_characters':len(draft),'draft_bullets':7,'diff_check':'passed','scope':'Changed local Markdown file targets, not all external URLs/anchors'},indent=2)+'\n')
manifest={'version':'3.8.1','source_reference':'automation.json#source_sha256',
    'recording_profile':'Compressed application content/structuredContent/isError/meta and native-private-read truth; source/test hashes and scripts/logs',
    'omitted':['Full JSON-RPC frames/notifications','No new model token or billed-cost trial','No configured database write or complete dialect/authorizer claim'],
    'cleanup':'Private SQLite/install/CLI fixtures cleaned; resident server/configured databases/configuration untouched',
    'prior_evidence':'Previous 42-artifact manifest byte-verified; old diagnostics/native/model evidence not relabeled',
    'artifacts':[]}
for p in sorted(OUT.iterdir()):
    if not p.is_file() or p.name=='manifest.json':continue
    b=p.read_bytes();row={'path':p.name,'bytes':len(b),'sha256':sha(b)}
    if p.suffix=='.gz':
        raw=gzip.decompress(b);row.update(uncompressed_bytes=len(raw),uncompressed_sha256=sha(raw))
    manifest['artifacts'].append(row)
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'full_passed':1750,'source_files':len(source),'test_files':len(tests),'changes':changed,'installed_checks':96,'client_checks':56,'mysql_checks':24,'links':links,'drr_ids':99,'draft_characters':len(draft),'artifacts':len(manifest['artifacts']),'resident':resident},ensure_ascii=False))
