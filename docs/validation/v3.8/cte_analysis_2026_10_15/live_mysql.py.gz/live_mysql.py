"""Independent real MySQL constant-read truth and both current-source Client modes."""
import asyncio
import gzip
import hashlib
import json
from pathlib import Path
from fastmcp import Client
from sql_safety_executor import create_server, load_config
from sql_safety_executor.database.errors import DatabaseQueryError

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/cte_analysis_2026_10_15"
CASES=[
    "WITH data AS (SELECT 7 AS n) SELECT n FROM data",
    "WITH summary AS (SELECT 7 AS n) SELECT n FROM summary",
    "WITH result AS (SELECT 7 AS n) SELECT n FROM result",
    "WITH rollup AS (SELECT 7 AS n) SELECT n FROM rollup",
    "WITH `window`(n) AS (SELECT 7) SELECT n FROM `window`",
    "WITH `unıon`(n) AS (SELECT 7) SELECT n FROM `unıon`",
    "WITH `SLEEP`(n) AS (SELECT 7) SELECT n FROM `SLEEP`",
    "WITH base AS /* body */ (SELECT 7 AS n) SELECT n FROM base",
    "WITH `data`(n) AS (SELECT 7), later AS (SELECT n FROM `data`) SELECT n FROM later",
    "WITH replace(n) AS (SELECT 7) SELECT n FROM replace",
]

async def main():
    records=[];truth=[]
    source={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in (".py",".md")}
    for mode in ("legacy","auto"):
        server=create_server(load_config(ROOT/"config/server.toml"))
        try:
            adapter=server.gateway_runtime.registry.get_adapter("trade_analysis_mysql")
            if mode=="legacy":
                for sql in CASES:
                    try:
                        rows=[list(r) for r in adapter.execute(sql)]
                        assert rows==[[7]]
                        truth.append({"sql":sql,"native_rows":rows,"error_code":None})
                    except DatabaseQueryError as exc:
                        assert exc.error_code=="sql_syntax_error"
                        truth.append({"sql":sql,"native_rows":None,"error_code":exc.error_code})
            async with Client(server,mode=mode) as client:
                cases=[(r["sql"],r["error_code"]) for r in truth]+[
                    ('WITH `data`(n) AS (SELECT SLEEP(0)) SELECT n FROM `data`',"expensive_function_denied"),
                    ('WITH data AS (SELECT 7 AS n) UPDATE orders SET status=status',"read_only_required"),
                ]
                for sql,code in cases:
                    args={"connection_id":"trade_analysis_mysql","sql":sql}
                    r=await client.call_tool("query",args,raise_on_error=False)
                    d=r.structured_content
                    assert not r.is_error
                    if code:assert d["error_code"]==code
                    else:assert d["data"]==[{"n":7}]
                    records.append({"mode":mode,"arguments":args,"isError":r.is_error,"structuredContent":d,"content":[c.model_dump(mode="json",exclude_none=True) for c in r.content]})
        finally:server.gateway_runtime.close()
    assert source=={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in (".py",".md")}
    data={"source_sha256":source,"native_truth":truth,"records":records,"checks":{"passed":len(records),"failed":0},
        "configured_database_writes":False,"scope":"Only real configured MySQL constant reads; no direct execution of write/function-denial controls. Compare backend validity/errors instead of assuming SQLite keyword semantics. Current-source Client, not resident Host."}
    (OUT/"live_mysql.json.gz").write_bytes(gzip.compress((json.dumps(data,ensure_ascii=False,indent=2)+"\n").encode(),mtime=0))
    print(json.dumps({"client_checks":data["checks"],"native_valid":sum(r["native_rows"] is not None for r in truth),"native_invalid":sum(r["error_code"] is not None for r in truth)}))

asyncio.run(main())
