"""Private SQLite aliases/index hints and subsequent relation contexts."""
import gzip,hashlib,json,sqlite3
from pathlib import Path
from sql_safety_executor.core.policy import _validate_sql_query_policy,_extract_relation_references
from sql_safety_executor.database.models import ConnectionPolicy
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/cte_analysis_2026_10_15"
names=["window","offset","lock","filter","over","for","key","index","returning","lımıt","offſet","wındow","unıon","ınsert","f","main.orders"," f ","[f]"]
suffixes=[]
for name in names:
    for quote in ["{}",'"{}"']:
        target=quote.format(name)
        suffixes.extend([target,"AS "+target,"INDEXED BY "+target])
suffixes+=["NOT INDEXED"]
records=[];misses=[];refusals=[]
with sqlite3.connect(":memory:") as db:
    db.executescript("CREATE TABLE orders(n);INSERT INTO orders VALUES(7);CREATE TABLE other(n);INSERT INTO other VALUES(99);")
    for name in names:
        q='"'+name.replace('"','""')+'"'
        db.execute(f"CREATE INDEX {q} ON orders(n)")
    for tail in suffixes:
        shapes=[
            f"SELECT b.n FROM orders {tail}, other AS b",
            f"SELECT b.n FROM orders {tail} LEFT JOIN other AS b ON 1=1",
            f"SELECT b.n FROM orders {tail}, other AS b WHERE b.n=99",
            f"SELECT b.n FROM orders {tail} JOIN orders AS c ON 1=1, other AS b",
            f"SELECT (SELECT n FROM other) AS n FROM orders {tail}",
            f"SELECT 99 AS n FROM orders {tail} WHERE EXISTS(SELECT 1 FROM other)",
            f"WITH a AS (SELECT n FROM orders {tail}), b AS (SELECT n FROM other) SELECT n FROM b",
            f"WITH a AS (SELECT n FROM orders {tail}) SELECT b.n FROM a, other AS b",
            f"SELECT 99 AS n FROM orders {tail} WHERE 99 IN other",
            f"SELECT b.n FROM orders {tail}, other AS b ORDER BY b.n LIMIT 1",
        ]
        for sql in shapes:
            try:truth=[list(r) for r in db.execute(sql).fetchall()]
            except sqlite3.Error:continue
            assert truth==[[99]]
            no=_validate_sql_query_policy(None,sql,ConnectionPolicy(allowed_tables=frozenset({"orders"})))
            yes=_validate_sql_query_policy(None,sql,ConnectionPolicy(allowed_tables=frozenset({"orders","other"})))
            row={"sql":sql,"native_rows":truth,"unapproved_allowed":no.allowed,"unapproved_code":no.error_code,"approved_allowed":yes.allowed,"approved_code":yes.error_code}
            records.append(row)
            if no.allowed:misses.append(row)
            if not yes.allowed:refusals.append(row)
source={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in (".py",".md")}
data={"source_sha256":source,"candidate_suffixes":len(suffixes),"native_valid_cases":len(records),"scope_misses":len(misses),"approved_refusals":len(refusals),"records":records,"configured_database_writes":False,"scope":"Direct native private SQLite truth and policy predicates; not MCP calls"}
(OUT/"boundary_context_audit.json.gz").write_bytes(gzip.compress((json.dumps(data,ensure_ascii=False,indent=2)+"\n").encode(),mtime=0))
print(json.dumps({k:data[k] for k in ("candidate_suffixes","native_valid_cases","scope_misses","approved_refusals")}))
for r in misses+refusals:print(json.dumps(r,ensure_ascii=False))
assert not misses
