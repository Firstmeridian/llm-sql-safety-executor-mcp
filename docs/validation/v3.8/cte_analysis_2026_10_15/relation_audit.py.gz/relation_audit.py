"""Bounded native-name audit, no configured database access."""
import gzip,hashlib,json,sqlite3
from types import ModuleType
from pathlib import Path
from sql_safety_executor.core.policy import _validate_sql_query_policy
from sql_safety_executor.database.models import ConnectionPolicy
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/cte_analysis_2026_10_15"
names=("abort action after analyze asc attach before begin by cascade cast column conflict current_date current_time current_timestamp database deferred desc detach each end escape exclusive explain fail filter first following for generated glob groups ignore immediate indexed initially instead key last like match materialized natural no nothing nulls of offset others over partition plan pragma preceding query raise range recursive regexp reindex release rename replace restrict returning rollback row rows savepoint temp temporary ties trigger unbounded vacuum view virtual window with without lock").split()
names+=["lımıt","offſet","wındow","unıon","ınsert","deſcribe","ſhow","ſelect","pragma_locKing_mode","f"," f ","  f  ","main.orders","[f]",'"f"']
# Reconstruct only the two archived baseline modules. Other production
# resources must still match that snapshot; do not modify imported modules.
baseline=json.loads((OUT/"baseline_source.json").read_text())
for name,value in baseline.items():
    if name not in {"src/sql_safety_executor/core/policy.py","src/sql_safety_executor/core/sql.py"}:
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==value
old_modules={}
for name in ("sql","policy"):
    module=ModuleType("sql_safety_executor.core._baseline_"+name)
    module.__package__="sql_safety_executor.core"
    raw=gzip.decompress((OUT/f"baseline_{name}.py.gz").read_bytes())
    assert hashlib.sha256(raw).hexdigest()==baseline[f"src/sql_safety_executor/core/{name}.py"]
    exec(compile(raw,f"archived_baseline_{name}.py","exec"),module.__dict__)
    old_modules[name]=module
old_modules["policy"].classify_sql_statement=old_modules["sql"].classify_sql_statement
old_modules["policy"].has_unsafe_mysql_comment_semantics=old_modules["sql"].has_unsafe_mysql_comment_semantics
before_decision=old_modules["policy"]._validate_sql_query_policy
records=[];unsupported=[];violations=[];function_records=[]
with sqlite3.connect(":memory:") as db:
    db.executescript("CREATE TABLE orders(n);INSERT INTO orders VALUES(7);")
    for i,name in enumerate(names):
        quoted='"'+name.replace('"','""')+'"'
        db.execute(f"CREATE TABLE {quoted}(n)")
        db.execute(f"INSERT INTO {quoted} VALUES(99)")
        shapes={
            "from":f"SELECT n FROM {name}",
            "join":f"SELECT t.n FROM orders JOIN {name} AS t ON 1=1",
            "comma":f"SELECT t.n FROM orders, {name} AS t",
            "in":f"SELECT 99 AS n WHERE 99 IN {name}",
            "qualified_quoted":f"SELECT n FROM main.{quoted}",
            "cte_body":f"WITH business AS (SELECT n FROM {name}) SELECT n FROM business",
        }
        for shape,sql in shapes.items():
            try:truth=db.execute(sql).fetchall()
            except sqlite3.Error:continue
            # Some unquoted special names are expressions; record only a
            # statement that reads this fixture's distinguished table value.
            if truth!=[(99,)]:continue
            denied=_validate_sql_query_policy(None,sql,ConnectionPolicy(allowed_tables=frozenset({"orders"})))
            allowed=_validate_sql_query_policy(None,sql,ConnectionPolicy(allowed_tables=frozenset({"orders",name,"main."+name})))
            row={"name":name,"shape":shape,"sql":sql,"native_rows":[[99]],"unapproved_allowed":denied.allowed,"unapproved_code":denied.error_code,"approved_allowed":allowed.allowed,"approved_code":allowed.error_code}
            records.append(row)
            if denied.allowed:violations.append(row)
            if not allowed.allowed:
                old=before_decision(None,sql,ConnectionPolicy(allowed_tables=frozenset({"orders",name,"main."+name})))
                assert not old.allowed
                row["archived_baseline_approved_code"]=old.error_code
                recovery={
                    "from":f"SELECT n FROM {quoted}",
                    "join":f"SELECT t.n FROM orders JOIN {quoted} AS t ON 1=1",
                    "comma":f"SELECT t.n FROM orders, {quoted} AS t",
                    "in":f"SELECT 99 AS n WHERE 99 IN {quoted}",
                    "qualified_quoted":f"SELECT n FROM main.{quoted}",
                    "cte_body":f"WITH business AS (SELECT n FROM {quoted}) SELECT n FROM business",
                }[shape]
                recovery_policy=ConnectionPolicy(allowed_tables=frozenset({"orders",name,"main."+name}))
                row["quoted_recovery_sql"]=recovery
                row["quoted_recovery_native_rows"]=[list(r) for r in db.execute(recovery).fetchall()]
                row["quoted_recovery_allowed"]=_validate_sql_query_policy(None,recovery,recovery_policy).allowed
                assert row["quoted_recovery_native_rows"]==[[99]] and row["quoted_recovery_allowed"]
                unsupported.append(row)
        db.execute(f"DROP TABLE {quoted}")
    for name in ("load_fıle","load_file","user"):
        db.create_function(name,1,lambda _:7)
        for quote in ("{}",'"{}"',"`{}`","[{}]"):
            sql=f"SELECT {quote.format(name)}(1)"
            truth=[list(r) for r in db.execute(sql).fetchall()]
            assert truth==[[7]]
            p=ConnectionPolicy(allowed_tables=frozenset({"orders"}))
            old=before_decision(None,sql,p);current=_validate_sql_query_policy(None,sql,p)
            function_records.append({"sql":sql,"native_rows":truth,"before_allowed":old.allowed,"before_code":old.error_code,"after_allowed":current.allowed,"after_code":current.error_code})
source={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in (".py",".md")}
data={"source_sha256":source,"candidate_names":len(names),"native_valid_cases":len(records),"unapproved_scope_misses":len(violations),"approved_conservative_refusals":len(unsupported),"recording_profile":"Native private SQLite truth and source policy decisions, not MCP calls","configured_database_writes":False,"records":records,"function_records":function_records,"baseline_reconstruction":"Two hash-verified archived modules, unchanged other resources; isolated predicate reconstruction, not a historical native Host observation"}
(OUT/"adjacent_audit.json").write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({k:data[k] for k in ("candidate_names","native_valid_cases","unapproved_scope_misses","approved_conservative_refusals")}))
for row in violations+unsupported:print(json.dumps(row,ensure_ascii=False))
assert not violations
