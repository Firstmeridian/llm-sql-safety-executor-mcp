"""Identical baseline/current/installed requests for ambiguous CTE classification."""
from fastmcp import Client
from fastmcp.client.transports import StdioTransport
import sqlite3
NAMES=("unıon","offſet","wındow","window")
def statement(name,quoted):
    target='"'+name+'"' if quoted else name
    return f"WITH {target} AS (SELECT 7 AS n)\nSELECT n FROM {target};"
def populate_fixture(directory,admitted=False):
    directory.mkdir(exist_ok=True)
    with sqlite3.connect(directory/"fixture.sqlite") as db:
        db.executescript("CREATE TABLE orders(n);INSERT INTO orders VALUES(7);")
        for name in NAMES:
            assert db.execute(statement(name,False)).fetchall()==db.execute(statement(name,True)).fetchall()==[(7,)]
    (directory/"server.toml").write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="demo"\n')
    read='mode="all"' if admitted else 'mode="allowlist"\ntables=["orders"]'
    (directory/"connections.toml").write_text('schema_version=1\n[connections.demo]\ntype="sqlite"\n[connections.demo.sqlite]\npath="fixture.sqlite"\n[connections.demo.read]\n'+read+'\n')
    (directory/"skills.toml").write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=true\n[skills.audit]\npath="audit.jsonl"\n')
    for i,name in enumerate(NAMES):
        for quoted in (False,True):
            label=f"cte-{i}-"+("quoted" if quoted else "bare")
            skill=directory/"skills"/label;skill.mkdir(parents=True)
            (skill/"skill_def.md").write_text(f"---\nname: {label}\ntype: query\nsource: query.sql\nrisk: low\ndescription: CTE classification\nparams: {{}}\n---\n")
            (skill/"query.sql").write_text(statement(name,quoted))
async def check_client(client,mode,*,admitted,expect_fixed):
    requests=[("query",{"sql":statement(name,False)}) for name in NAMES]
    requests += [("query",{"sql":statement(name,True)}) for name in NAMES]
    requests += [("list_skills",{"detail_level":"full","available_only":False})]
    requests += [("get_skill_detail",{"skill_name":f"cte-{i}-quoted","detail_level":"full"}) for i in range(4)]
    requests += [("execute_query_skill",{"skill_name":f"cte-{i}-quoted","params":{}}) for i in range(4)]
    requests += [("query",{"sql":"UPDATE orders SET n=99"}),("query",{"sql":"WITH window AS (SELECT 7 AS n) UPDATE orders SET n=99"})]
    records=[]
    for tool,args in requests:
        r=await client.call_tool(tool,args,raise_on_error=False)
        records.append({"tool":tool,"arguments":args,"isError":r.is_error,"structuredContent":r.structured_content,"content":[c.model_dump(mode="json",exclude_none=True) for c in r.content],"meta":r.meta})
    for r in records[:4]+records[18:]:
        assert not r["isError"] and r["structuredContent"]["error_code"]==("sql_parse_failed" if expect_fixed else "read_only_required"),r
        hint=r["structuredContent"].get("hint","")
        assert ("mutation" not in hint.lower()) is expect_fixed,hint
    for r in records[4:8]+records[13:17]:
        assert not r["isError"] and r["structuredContent"]["data"]==[{"n":7}]
    assert {s["name"] for s in records[8]["structuredContent"]["skills"]}=={f"cte-{i}-quoted" for i in range(4)}
    assert all(r["structuredContent"]["skill"]["executable"] for r in records[9:13])
    assert records[17]["structuredContent"]["error_code"]=="read_only_required"
    assert "mutation" in records[17]["structuredContent"]["hint"].lower()
    return {"mode":mode,"admitted":admitted,"requests":requests,"calls":records}
async def check_installed(target,fixture,logs):
    import sys
    records=[]
    for mode in ("legacy","auto"):
        for admitted in (False,True):
            stage=fixture/f"{mode}-{admitted}";populate_fixture(stage,admitted)
            transport=StdioTransport(command=sys.executable,args=["-m","sql_safety_executor","serve","--config",str(stage/"server.toml")],env={"PYTHONPATH":str(target)},cwd=str(stage),keep_alive=False,log_file=logs/f"installed-{mode}-{admitted}.log")
            async with Client(transport,mode=mode) as client:
                records.append(await check_client(client,mode,admitted=admitted,expect_fixed=True))
            with sqlite3.connect(stage/"fixture.sqlite") as db:assert db.execute("SELECT n FROM orders").fetchall()==[(7,)]
    return records
