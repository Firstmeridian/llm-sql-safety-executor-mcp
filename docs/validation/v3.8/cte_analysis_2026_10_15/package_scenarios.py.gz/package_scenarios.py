"""Final installed-wheel CTE workflow and guards, private SQLite only."""
import sqlite3
import sys
from fastmcp import Client
from fastmcp.client.transports import StdioTransport

SQL = [
    "WITH data AS (SELECT n FROM orders) SELECT n FROM data",
    'WITH "monthly_sales"(n) AS (SELECT n FROM orders) SELECT n FROM "monthly_sales"',
    "WITH base AS /* body */ (SELECT n FROM orders) SELECT n FROM base",
    "WITH replace(n) AS (SELECT n FROM orders) SELECT r.n FROM orders, replace AS r",
    "WITH data(n) AS MATERIALIZED (SELECT n FROM orders) SELECT n FROM data",
    "WITH unıon(n) AS (SELECT n FROM orders) SELECT n FROM orders WHERE n IN unıon",
]

def populate_fixture(stage, admitted=False):
    stage.mkdir(exist_ok=True)
    with sqlite3.connect(stage/"fixture.sqlite") as db:
        db.executescript("CREATE TABLE orders(n);INSERT INTO orders VALUES(7);CREATE TABLE blocked(n);INSERT INTO blocked VALUES(99);")
        for sql in SQL:assert db.execute(sql).fetchall()==[(7,)]
    (stage/"server.toml").write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="demo"\n')
    read='mode="all"' if admitted else 'mode="allowlist"\ntables=["orders"]'
    (stage/"connections.toml").write_text('schema_version=1\n[connections.demo]\ntype="sqlite"\n[connections.demo.sqlite]\npath="fixture.sqlite"\n[connections.demo.read]\n'+read+'\n')
    (stage/"skills.toml").write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=true\n[skills.audit]\npath="audit.jsonl"\n')
    for i,sql in enumerate(SQL):
        skill=stage/"skills"/f"cte-{i}";skill.mkdir(parents=True)
        (skill/"skill_def.md").write_text(f"---\nname: cte-{i}\ntype: query\nsource: query.sql\nrisk: low\ndescription: CTE production workflow\nparams: {{}}\n---\n")
        (skill/"query.sql").write_text(sql)

async def check_installed(target,fixture,logs):
    profiles=[]
    for mode in ("legacy","auto"):
        for admitted in (False,True):
            stage=fixture/f"{mode}-{admitted}";populate_fixture(stage,admitted)
            requests=[("query",{"sql":sql}) for sql in SQL]
            requests += [("list_skills",{"detail_level":"full","available_only":v}) for v in (False,True)]
            requests += [("get_skill_detail",{"skill_name":f"cte-{i}","detail_level":"full"}) for i in range(len(SQL))]
            requests += [("execute_query_skill",{"skill_name":f"cte-{i}","params":{}}) for i in range(len(SQL))]
            controls=[
                ('WITH data(n) AS MATERIALIZED (SELECT SLEEP(0)) SELECT n FROM data',"expensive_function_denied"),
                ('WITH "data"(n) AS (SELECT LOAD_FILE(NULL)) SELECT n FROM "data"',"file_operation_denied"),
                ('WITH data AS (SELECT n FROM orders) UPDATE orders SET n=99',"read_only_required"),
                ('WITH "data"(n) AS (SELECT n FROM blocked) SELECT n FROM "data"',None if admitted else "table_access_denied"),
            ]
            requests += [("query",{"sql":sql}) for sql,_ in controls]
            calls=[]
            transport=StdioTransport(command=sys.executable,args=["-m","sql_safety_executor","serve","--config",str(stage/"server.toml")],env={"PYTHONPATH":str(target)},cwd=str(stage),keep_alive=False,log_file=logs/f"installed-{mode}-{admitted}.log")
            async with Client(transport,mode=mode) as client:
                for tool,args in requests:
                    r=await client.call_tool(tool,args,raise_on_error=False)
                    calls.append({"tool":tool,"arguments":args,"isError":r.is_error,"structuredContent":r.structured_content,"content":[c.model_dump(mode="json",exclude_none=True) for c in r.content],"meta":r.meta})
            assert len(calls)==24 and all(not r["isError"] for r in calls)
            for r in calls[:6]+calls[14:20]:assert r["structuredContent"]["data"]==[{"n":7}]
            for r in calls[6:8]:
                assert len(r["structuredContent"]["skills"])==6
                assert all(s["executable"] and s["inferred_tables"]==["orders"] and not s["missing_tables"] for s in r["structuredContent"]["skills"])
            assert all(r["structuredContent"]["skill"]["executable"] for r in calls[8:14])
            for (_,code),r in zip(controls,calls[20:]):
                if code:assert r["structuredContent"]["error_code"]==code
                else:assert r["structuredContent"]["data"]==[{"n":99}]
            with sqlite3.connect(stage/"fixture.sqlite") as db:assert db.execute("SELECT n FROM orders").fetchall()==[(7,)]
            profiles.append({"mode":mode,"admitted":admitted,"requests":requests,"calls":calls})
    return profiles
