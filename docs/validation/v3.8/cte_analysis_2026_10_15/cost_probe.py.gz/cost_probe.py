"""Serial A/B/A policy timings for inputs accepted by both snapshots."""
import gzip
import hashlib
import json
import math
import statistics
import time
from pathlib import Path
from types import ModuleType
from sql_safety_executor.core.policy import _validate_sql_query_policy
from sql_safety_executor.database.models import ConnectionPolicy

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/cte_analysis_2026_10_15"
baseline=json.loads((OUT/"baseline_source.json").read_text())
old_modules={}
for name in ("sql","policy"):
    raw=gzip.decompress((OUT/f"baseline_{name}.py.gz").read_bytes())
    assert hashlib.sha256(raw).hexdigest()==baseline[f"src/sql_safety_executor/core/{name}.py"]
    module=ModuleType("sql_safety_executor.core._cost_before_"+name);module.__package__="sql_safety_executor.core"
    exec(compile(raw,"archived_before_"+name+".py","exec"),module.__dict__);old_modules[name]=module
old_modules["policy"].classify_sql_statement=old_modules["sql"].classify_sql_statement
old_modules["policy"].has_unsafe_mysql_comment_semantics=old_modules["sql"].has_unsafe_mysql_comment_semantics
before=old_modules["policy"]._validate_sql_query_policy
SQL=[
    "SELECT n FROM orders WHERE n=7",
    "WITH monthly_sales AS (SELECT n FROM orders) SELECT n FROM monthly_sales",
    "WITH monthly_sales(n) AS (SELECT n FROM orders) SELECT n FROM monthly_sales",
    "WITH a AS (SELECT n FROM orders), b AS (SELECT n FROM a) SELECT n FROM b",
    "WITH a AS (WITH b AS (SELECT n FROM orders) SELECT n FROM b) SELECT n FROM a",
    'WITH "monthly_sales" AS (SELECT n FROM orders) SELECT n FROM "monthly_sales"',
]
POLICIES={"allowlist":ConnectionPolicy(allowed_tables=frozenset({"orders"})), "all":ConnectionPolicy(read_mode="all",allowed_tables=frozenset({"*"}))}
records=[]
for label,validator in (("A1",before),("B",_validate_sql_query_policy),("A2",before)):
    for scope,policy in POLICIES.items():
        for sql in SQL:
            for _ in range(3):assert validator(None,sql,policy).allowed
            timings=[]
            for _ in range(30):
                started=time.perf_counter_ns();d=validator(None,sql,policy)
                timings.append((time.perf_counter_ns()-started)/1e6);assert d.allowed
            records.append({"stage":label,"scope":scope,"sql":sql,"milliseconds":timings,
                "median_ms":statistics.median(timings),"p95_ms":sorted(timings)[math.ceil(.95*len(timings))-1]})
summary={}
for label in ("A1","B","A2"):
    values=[t for r in records if r["stage"]==label for t in r["milliseconds"]]
    summary[label]={"calls":len(values),"median_ms":statistics.median(values),"p95_ms":sorted(values)[math.ceil(.95*len(values))-1]}
source={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in (".py",".md")}
data={"source_sha256":source,"baseline_source_ref":"baseline_source.json","records":records,"summary":summary,
    "scope":"Local serial pure-policy A/B/A, same accepted inputs, 360 measured calls per stage, fixed warmups. No database/Host/model/token/end-to-end measurement; timings are observations without production performance guarantee.",
    "configured_database_writes":False}
(OUT/"cost_probe.json.gz").write_bytes(gzip.compress((json.dumps(data,ensure_ascii=False,indent=2)+"\n").encode(),mtime=0))
print(json.dumps(summary))
