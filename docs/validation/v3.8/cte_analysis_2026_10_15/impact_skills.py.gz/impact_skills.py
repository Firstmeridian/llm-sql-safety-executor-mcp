"""Observe CTE false refusals through discovery/readiness/execution, private DB."""
import asyncio
import gzip
import hashlib
import json
import shutil
import sqlite3
import tempfile
from pathlib import Path
from fastmcp import Client
from sql_safety_executor import create_server, load_config
from scenarios import populate_fixture

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "docs/validation/v3.8/cte_analysis_2026_10_15"
cases = {
    "business-bare": "WITH data AS (SELECT n FROM orders) SELECT n FROM data",
    "business-quoted": 'WITH "data" AS (SELECT n FROM orders) SELECT n FROM "data"',
    "column-list-bare": "WITH monthly_sales(n) AS (SELECT n FROM orders) SELECT n FROM monthly_sales",
    "column-list-quoted": 'WITH "monthly_sales"(n) AS (SELECT n FROM orders) SELECT n FROM "monthly_sales"',
}

def source_hashes():
    return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in (".py", ".md")}

async def main():
    initial_source = source_hashes()
    profiles = []
    for mode in ("legacy", "auto"):
        for admitted in (False, True):
            with tempfile.TemporaryDirectory(prefix="v381-cte-impact-") as directory:
                stage = Path(directory)
                populate_fixture(stage, admitted)
                shutil.rmtree(stage / "skills")
                for name, sql in cases.items():
                    skill = stage / "skills" / name
                    skill.mkdir(parents=True)
                    (skill / "skill_def.md").write_text(f"---\nname: {name}\ntype: query\nsource: query.sql\nrisk: low\ndescription: Business CTE impact\nparams: {{}}\n---\n")
                    (skill / "query.sql").write_text(sql)
                server = create_server(load_config(stage / "server.toml"))
                calls = []
                try:
                    async with Client(server, mode=mode) as client:
                        requests = [("query", {"sql": sql}) for sql in cases.values()]
                        requests += [("list_skills", {"detail_level": "full", "available_only": flag}) for flag in (False, True)]
                        requests += [("get_skill_detail", {"skill_name": name, "detail_level": "full"}) for name in cases]
                        requests += [("execute_query_skill", {"skill_name": name, "params": {}}) for name in cases]
                        for tool, args in requests:
                            result = await client.call_tool(tool, args, raise_on_error=False)
                            calls.append(dict(tool=tool, arguments=args, isError=result.is_error,
                                structuredContent=result.structured_content,
                                content=[c.model_dump(mode="json", exclude_none=True) for c in result.content], meta=result.meta))
                        loaded = sorted(server.gateway_runtime.catalog.get_skills_cache())
                finally:
                    server.gateway_runtime.close()
                with sqlite3.connect(stage / "fixture.sqlite") as db:
                    assert db.execute("SELECT n FROM orders").fetchall() == [(7,)]
                profile = dict(mode=mode, read_scope="all" if admitted else "allowlist", loaded=loaded, calls=calls)
                profiles.append(profile)
                print(json.dumps({"mode":mode,"scope":profile["read_scope"],"loaded":loaded,
                    "raw_results":[c["structuredContent"] for c in calls[:4]],
                    "all_discovery":calls[4]["structuredContent"],"default_discovery":calls[5]["structuredContent"],
                    "execution_results":[c["structuredContent"] for c in calls[-4:]]},ensure_ascii=False))
    source = {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in (".py", ".md")}
    assert source == initial_source
    for profile in profiles:
        assert profile["loaded"] == sorted(cases)
        assert all(not c["isError"] for c in profile["calls"])
        for c in profile["calls"][:4] + profile["calls"][-4:]:
            assert c["structuredContent"]["data"] == [{"n": 7}]
        for c in profile["calls"][4:6]:
            assert len(c["structuredContent"]["skills"]) == 4
            assert all(s["executable"] and s["inferred_tables"] == ["orders"] and s["missing_tables"] == [] for s in c["structuredContent"]["skills"])
    data = dict(source_sha256=source, checks={"passed":56,"failed":0}, total_calls=sum(len(p["calls"]) for p in profiles), profiles=profiles,
        scope="Current-source in-process private Client, two modes/two read scopes with readiness enabled; all observed results retained. Application objects, not full wire frames or resident configured Skill changes.",
        configured_database_writes=False, probe_mutated_production=False)
    (OUT / "impact_skills.json.gz").write_bytes(gzip.compress((json.dumps(data,ensure_ascii=False,indent=2)+"\n").encode(),mtime=0))
    print(json.dumps({"total_calls":data["total_calls"],"transport_errors":sum(c["isError"] for p in profiles for c in p["calls"])}))

asyncio.run(main())
