"""Harmless native UDFs and archived-source predicate comparison."""
import gzip,hashlib,json,sqlite3
from pathlib import Path
from types import ModuleType
from sql_safety_executor.core.policy import _validate_sql_query_policy
from sql_safety_executor.database.models import ConnectionPolicy
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/cte_analysis_2026_10_15"
baseline=json.loads((OUT/"baseline_source.json").read_text())
for path,digest in baseline.items():
    if path not in {"src/sql_safety_executor/core/policy.py","src/sql_safety_executor/core/sql.py"}:assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest
raw=gzip.decompress((OUT/"baseline_policy.py.gz").read_bytes())
assert hashlib.sha256(raw).hexdigest()==baseline["src/sql_safety_executor/core/policy.py"]
old=ModuleType("sql_safety_executor.core._archived_cte_policy");old.__package__="sql_safety_executor.core"
exec(compile(raw,"archived_policy.py","exec"),old.__dict__)
raw_sql=gzip.decompress((OUT/"baseline_sql.py.gz").read_bytes())
assert hashlib.sha256(raw_sql).hexdigest()==baseline["src/sql_safety_executor/core/sql.py"]
old_sql=ModuleType("sql_safety_executor.core._archived_cte_sql");old_sql.__package__="sql_safety_executor.core"
exec(compile(raw_sql,"archived_sql.py","exec"),old_sql.__dict__)
old.classify_sql_statement=old_sql.classify_sql_statement
old.has_unsafe_mysql_comment_semantics=old_sql.has_unsafe_mysql_comment_semantics
policy=ConnectionPolicy(read_mode="all",allowed_tables=frozenset({"*"}))
calls=[("SLEEP","expensive_function_denied"),("BENCHMARK","expensive_function_denied"),("GET_LOCK","lock_function_denied"),("LOAD_FILE","file_operation_denied"),("USER","server_state_denied"),("CURRENT_ROLE","server_state_denied")]
quotes=["{}",'"{}"',"\x60{}\x60","[{}]"]
records=[];controls=[]
with sqlite3.connect(":memory:") as db:
    for name,code in calls:
        db.create_function(name,-1,lambda *args:7)
        for declaration_quote in quotes:
            target=declaration_quote.format("x")
            for function_quote in quotes:
                call=function_quote.format(name)+"(0)"
                shapes={
                    "single":f"WITH {target}(n) AS (SELECT {call}) SELECT n FROM {target}",
                    "multi":f"WITH first_cte AS (SELECT 1), {target}(n) AS (SELECT {call}) SELECT n FROM {target}",
                    "nested":f"WITH outer_cte AS (WITH {target}(n) AS (SELECT {call}) SELECT n FROM {target}) SELECT n FROM outer_cte",
                    "materialized":f"WITH {target}(n) AS MATERIALIZED (SELECT {call}) SELECT n FROM {target}",
                    "not_materialized":f"WITH {target}(n) AS NOT MATERIALIZED (SELECT {call}) SELECT n FROM {target}",
                    "as_column":f'WITH {target}("AS",n) AS (SELECT 1,{call}) SELECT n FROM {target}',
                }
                for shape,sql in shapes.items():
                    truth=[list(r) for r in db.execute(sql).fetchall()];assert truth==[[7]]
                    before=old._validate_sql_query_policy(None,sql,policy)
                    after=_validate_sql_query_policy(None,sql,policy)
                    row={"shape":shape,"declaration_quote":declaration_quote,"function_quote":function_quote,"sql":sql,"native_rows":truth,"before_allowed":before.allowed,"before_code":before.error_code,"after_allowed":after.allowed,"after_code":after.error_code,"expected_code":code}
                    records.append(row)
                    assert not after.allowed and (after.error_code==code or before.error_code==after.error_code=="read_only_required"),row
    for quote in quotes:
        target=quote.format("SLEEP")
        for body in ["7","ABS(-7)","'AS ( SLEEP(0)'"]:
            sql=f"WITH {target}(n) AS (SELECT {body}) SELECT n FROM {target}"
            truth=[list(r) for r in db.execute(sql).fetchall()]
            decision=_validate_sql_query_policy(None,sql,policy)
            controls.append({"sql":sql,"native_rows":truth,"allowed":decision.allowed})
            assert decision.allowed
source={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in (".py",".md")}
data={"source_sha256":source,"native_cases":len(records),"previously_allowed":sum(r["before_allowed"] for r in records),"after_denied":sum(not r["after_allowed"] for r in records),"positive_controls":len(controls),"earlier_shape_denials":sum(r["after_code"]=="read_only_required" for r in records),"records":records,"controls":controls,"baseline_reconstruction":"Hash-verified archived policy and unchanged other production resources, not historical Host","configured_database_writes":False,"native_functions":"Private sqlite3 UDFs return 7 only, no real locks/delay/file/account access"}
(OUT/"header_scan_matrix.json.gz").write_bytes(gzip.compress((json.dumps(data,ensure_ascii=False,indent=2)+"\n").encode(),mtime=0))
print(json.dumps({k:data[k] for k in ("native_cases","previously_allowed","after_denied","positive_controls","earlier_shape_denials")}))
