"""Capture native object truth and real preceding/current policy projections."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "docs/validation/v3.8/precommit_2026_10_14"
PROBE = r'''
import hashlib,json,sqlite3,sys
from dataclasses import asdict
from pathlib import Path
sys.path.insert(0,sys.argv[1])
import sql_safety_executor.core.policy as policy
from sql_safety_executor.database.models import ConnectionPolicy
assert Path(policy.__file__).is_relative_to(Path(sys.argv[1]))
cases=[('  f  ',' f '),('[f]','f'),('a"b','a""b'),('a`b','a``b'),('\tf\t',' f '),('f\nx','f x')]
rows=[]
for name,shadow in cases:
    quote=lambda s:'"'+s.replace('"','""')+'"'
    conn=sqlite3.connect(':memory:')
    conn.execute('CREATE TABLE '+quote(name)+'(id INTEGER)')
    conn.execute('INSERT INTO '+quote(name)+' VALUES(999)')
    sql='WITH '+quote(shadow)+' AS (SELECT 7 AS id) SELECT id FROM '+quote(name)
    native=conn.execute(sql).fetchall()
    decision=policy._validate_sql_query_policy(None,sql,ConnectionPolicy(allowed_tables=frozenset({shadow})))
    authorized=policy._validate_sql_query_policy(None,sql,ConnectionPolicy(allowed_tables=frozenset({name})))
    rows.append({'physical_name':name,'other_name':shadow,'sql':sql,'native_rows':native,
        'normalized_sql':policy._normalize_sql_for_policy(sql),
        'dependencies':policy._extract_tables_from_sql(sql,case_sensitive=True,cte_case_sensitive=False),
        'other_grant':asdict(decision),'exact_grant':asdict(authorized)})
    conn.close()
print(json.dumps({'sqlite_version':sqlite3.sqlite_version,'policy_sha256':hashlib.sha256(Path(policy.__file__).read_bytes()).hexdigest(),'cases':rows}))
'''
records = {}
for stage, source in [("before", Path("/tmp/v381-precommit-before-src")), ("after", ROOT / "src")]:
    records[stage] = json.loads(subprocess.check_output(
        [sys.executable, "-c", PROBE, str(source)], text=True, cwd=ROOT))
for row in records["after"]["cases"]:
    assert row["native_rows"] == [[999]]
    assert row["dependencies"] == [row["physical_name"]]
    assert row["other_grant"]["error_code"] == "table_access_denied"
    assert row["exact_grant"]["allowed"] is True
assert any(r["other_grant"]["allowed"] for r in records["before"]["cases"])
records["scope"] = "Private in-memory SQLite only; no existing database writes. Preceding source hashes verified in baseline_source.json."
(OUT / "identity_comparison.json").write_text(json.dumps(records, ensure_ascii=False, indent=2) + "\n")
print("Six native identity cases verified before/after; all exact grants retained and differing grants refused.")
