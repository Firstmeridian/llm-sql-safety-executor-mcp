"""Index final checks without rewriting preceding source/model snapshots."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "docs/validation/v3.8/precommit_2026_10_14"
sha = lambda data: hashlib.sha256(data).hexdigest()
full = Path('/tmp/v381-precommit-full.log').read_text()
match = re.search(r'(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s', full)
assert match and match.group(1, 2, 3) == ('1114', '4', '17')
assert '0 errors, 0 warnings' in Path('/tmp/v381-precommit-pyright.log').read_text()
assert 'Installed prompt resources and routing guidance valid' in Path('/tmp/v381-precommit-prompt.log').read_text()
installed = json.loads((OUT / 'installed_wheel.json').read_text())
assert installed['import_outside_repository'] and sum(len(c['requests']) for c in installed['calls']) == 22
source = {p.relative_to(ROOT).as_posix(): sha(p.read_bytes()) for p in sorted((ROOT / 'src/sql_safety_executor').rglob('*')) if p.is_file() and p.suffix in {'.py', '.md'}}
previous = OUT / 'automation.json'
if previous.exists():
    assert source == json.loads(previous.read_text())['source_sha256'], 'Production source changed since final regression'
automation = {'version': '3.8.1', 'source_sha256': source,
    'full_suite': {'passed': 1114, 'skipped': 4, 'warnings': 17, 'seconds': float(match.group(4)), 'mysql_optin': False},
    'pyright': {'errors': 0, 'warnings': 0}, 'prompt_contract': 'passed',
    'installed_stdio_calls': 22, 'new_identity_regressions': 25,
    'matrix_policy_results_unchanged': 52,
    'sqlglot_runtime_dependency': False, 'authorizer_installed': False,
    'model_cost': 'Not remeasured for final identity patch; previous dated Luna evidence remains distinct',
    'resident_host': 'Awaiting maintainer restart; current primary still returns preceding unknown_table decision',
    'limitations': ['Conservative SQLite forward/implicit recursion', 'MySQL 0/2 and MariaDB not independently tested', 'No full function cost control or complete semantic parser']}
native = OUT / 'native_after_restart.json'
if (OUT / 'maintainer_checkpoint.json').exists():
    automation['resident_host_deferred_by_maintainer'] = True
if native.exists():
    result = json.loads(native.read_text())
    assert result['checks']['failed'] == 0
    automation['resident_host_deferred_by_maintainer'] = False
    automation['earlier_maintainer_checkpoint'] = 'maintainer_checkpoint.json'
    automation['resident_host'] = 'Maintainer restart confirmed; final primary Host native checks passed'
    automation['resident_host_checks'] = {**result['checks'], 'reference': 'native_after_restart.json'}
(OUT / 'automation.json').write_text(json.dumps(automation, ensure_ascii=False, indent=2) + '\n')
for path in Path('/tmp').glob('v381-precommit-*.log'):
    (OUT / (path.name + '.gz')).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for path in Path(__file__).parent.glob('*.py'):
    (OUT / (path.name + '.gz')).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for name in ('pyproject.toml', 'uv.lock'):
    assert not subprocess.check_output(['git', 'diff', '--', name], cwd=ROOT)
assert 'version = "3.8.1"' in (ROOT / 'pyproject.toml').read_text()
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
paths = []
for line in subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).splitlines():
    path = ROOT / line[3:]
    if path.suffix == '.md': paths.append(path)
from urllib.parse import unquote
links = 0
for path in paths:
    for link in re.findall(r'\]\(([^)\n]+)\)', path.read_text()):
        link = link.strip().strip('<>')
        if '://' in link or link.startswith(('#', 'mailto:', 'data:')): continue
        target = link.split('#', 1)[0]
        if target:
            # The manifest is generated below in this same finalization.
            candidate = path.parent / unquote(target)
            assert candidate.resolve() == (OUT / 'manifest.json').resolve() or candidate.exists(), (path, target)
            links += 1
for name in ('DESIGN_RISK_REGISTER.md', 'DESIGN_RISK_REGISTER_ZH.md'):
    ids = re.findall(r'^\| DRR-2026-(\d{3}) \|', (ROOT / 'docs/security' / name).read_text(), re.M)
    assert sorted(ids) == [f'{n:03}' for n in range(1, 88)]
(OUT / 'document_checks.json').write_text(json.dumps({'relative_document_links': links,
    'bilingual_drr_ids': 87, 'tested_source_files': len(source), 'source_sha256_matches': True,
    'version_and_runtime_dependencies_unchanged': True, 'diff_check': 'passed',
    'scope': 'File targets; remote URLs and heading anchors not automatically validated'}, indent=2) + '\n')
manifest = {'version': '3.8.1', 'source_reference': 'automation.json#source_sha256',
    'recording_profile': 'Decoded public tool results and compressed logs/source references; not complete transport frames',
    'history': 'Earlier batches and Luna provider usage remain unchanged',
    'omitted': ['Internal model reasoning/credentials', 'Complete raw JSON-RPC notifications/IDs and omitted-vs-null distinction', 'No new end-to-end model cost measurement for final patch'], 'artifacts': []}
for path in sorted(OUT.iterdir()):
    if path.name == 'manifest.json': continue
    data = path.read_bytes()
    row = {'path': path.name, 'bytes': len(data), 'sha256': sha(data)}
    if path.suffix == '.gz':
        raw = gzip.decompress(data)
        row.update(uncompressed_bytes=len(raw), uncompressed_sha256=sha(raw))
    manifest['artifacts'].append(row)
(OUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'full_passed': 1114, 'installed_calls': 22, 'document_links': links,
    'indexed_artifacts': len(manifest['artifacts']), 'resident_host': automation['resident_host']}))
