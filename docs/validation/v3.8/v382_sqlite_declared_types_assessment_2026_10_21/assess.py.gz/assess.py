"""Reproduce declared-type loss using disposable SQLite/MCP fixtures only."""
from __future__ import annotations

import argparse
import asyncio
from collections import Counter
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import traceback

ROOT = Path(__file__).resolve().parents[4]
parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path)
parser.add_argument('--output', type=Path)
parser.add_argument('--baseline', action='store_true')
parser.add_argument('--child', type=Path)
args = parser.parse_args()
if args.source:
    sys.path.insert(0, str(args.source.resolve()))

from fastmcp import Client
from fastmcp.client.transports import StdioTransport
from sql_safety_executor import create_server, load_config
import sql_safety_executor


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def quote(value):
    return '"' + value.replace('"', '""') + '"'


def toml_value(value):
    if isinstance(value, dict):
        return '{' + ', '.join(json.dumps(k) + '=' + toml_value(v) for k, v in value.items()) + '}'
    if isinstance(value, list):
        return '[' + ','.join(toml_value(v) for v in value) + ']'
    return json.dumps(value, ensure_ascii=False)


def save(path, data):
    path.write_text('\n'.join(json.dumps(k) + '=' + toml_value(v) for k, v in data.items()) + '\n')


def fixture(folder):
    database = folder / 'fixture.sqlite'
    definitions = [
        ('untyped', 'CREATE TABLE untyped(n)', 'INSERT INTO untyped VALUES(7)'),
        ('typed_text', 'CREATE TABLE typed_text(n TEXT)', 'INSERT INTO typed_text VALUES(7)'),
        ('typed_blob', 'CREATE TABLE typed_blob(n BLOB)', 'INSERT INTO typed_blob VALUES(7)'),
        ('typed_integer', 'CREATE TABLE typed_integer(n INTEGER)', 'INSERT INTO typed_integer VALUES(7)'),
        ('typed_numeric', 'CREATE TABLE typed_numeric(n NUMERIC)', 'INSERT INTO typed_numeric VALUES(7)'),
        ('quoted_empty', 'CREATE TABLE quoted_empty(n "")', 'INSERT INTO quoted_empty VALUES(7)'),
        ('quoted_space', 'CREATE TABLE quoted_space(n " ")', 'INSERT INTO quoted_space VALUES(7)'),
        ('custom_string', 'CREATE TABLE custom_string(n STRING)', 'INSERT INTO custom_string VALUES(7)'),
        ('strict_any', 'CREATE TABLE strict_any(n ANY) STRICT', 'INSERT INTO strict_any VALUES(7)'),
        ('as_const', 'CREATE TABLE as_const AS SELECT 7 AS n', None),
        ('generated', 'CREATE TABLE generated(base INTEGER,n AS(base) VIRTUAL)', 'INSERT INTO generated(base) VALUES(7)'),
        ('generated_text', 'CREATE TABLE generated_text(base INTEGER,n TEXT AS(base) VIRTUAL)', 'INSERT INTO generated_text(base) VALUES(7)'),
        ('generated_stored', 'CREATE TABLE generated_stored(base INTEGER,n AS(base) STORED)', 'INSERT INTO generated_stored(base) VALUES(7)'),
        ('searchable', 'CREATE VIRTUAL TABLE searchable USING fts5(n)', 'INSERT INTO searchable VALUES(7)'),
        ('v_untyped', 'CREATE VIEW v_untyped AS SELECT n FROM untyped', None),
        ('v_text', 'CREATE VIEW v_text AS SELECT n FROM typed_text', None),
        ('v_expr', 'CREATE VIEW v_expr AS SELECT 7 AS n', None),
        ('v_unary', 'CREATE VIEW v_unary AS SELECT +n AS n FROM typed_text', None),
    ]
    if args.baseline:
        definitions = [d for d in definitions if d[0] in {'untyped', 'typed_text', 'v_untyped', 'v_text'}]
    truth = {}
    with sqlite3.connect(database) as db:
        for name, ddl, insert in definitions:
            db.execute(ddl)
            if insert:
                db.execute(insert)
        for name, _, _ in definitions:
            columns = [list(row) for row in db.execute('PRAGMA main.table_xinfo(' + quote(name) + ')')]
            sql = 'SELECT n, typeof(n) AS storage_type, n=\'7\' AS equals_text FROM main.' + quote(name)
            rows = [list(row) for row in db.execute(sql)]
            truth[name] = {'columns': columns, 'sql': sql, 'rows': rows}
    save(folder / 'server.toml', {'schema_version': 1, 'files': {'connections': 'connections.toml', 'skills': 'skills.toml'},
         'server': {'default_connection': 'scoped'}, 'tools': {'table_summary': True},
         'limits': {'schema_tables': 50, 'overview_tables': 50}})
    save(folder / 'connections.toml', {'schema_version': 1, 'connections': {'scoped': {
        'type': 'sqlite', 'sqlite': {'path': str(database)},
        'read': {'mode': 'allowlist', 'tables': [*truth, *('main.' + name for name in truth)]}}}})
    skill = folder / 'skills/probe'
    skill.mkdir(parents=True)
    (skill / 'skill_def.md').write_text('---\nname: probe\ntype: query\nsource: query.sql\nrisk: low\ndescription: Declared-type assessment\nparams: {}\n---\n')
    (skill / 'query.sql').write_text(truth['untyped']['sql'])
    save(folder / 'skills.toml', {'schema_version': 1, 'skills': {
        'enabled': True, 'directory': str(folder / 'skills'), 'readiness': {'check_schema': True},
        'audit': {'path': str(folder / 'audit.jsonl')}}})
    return database, truth


async def main():
    assert args.output and not args.output.exists() and not args.output.with_suffix(args.output.suffix + '.gz').exists()
    records, components, errors = [], [], []
    with tempfile.TemporaryDirectory(prefix='v382-declared-type-') as temporary:
        folder = Path(temporary)
        database, truth = fixture(folder)
        initial = sha(database)
        transports = ['inprocess'] if args.baseline else ['inprocess', 'stdio']
        for transport in transports:
            for mode in ['auto', 'legacy']:
                server = None
                try:
                    if transport == 'inprocess':
                        server = create_server(load_config(folder / 'server.toml'))
                        target = server
                        adapter = server.gateway_runtime.registry.get_adapter('scoped')
                        for name in truth:
                            components.append({'mode': mode, 'table': name, 'columns': adapter.get_columns(name)})
                    else:
                        command = [str(Path(__file__).resolve())]
                        if args.source:
                            command += ['--source', str(args.source.resolve())]
                        command += ['--child', str(folder / 'server.toml')]
                        target = StdioTransport(command=sys.executable, args=command, cwd=str(ROOT))
                    async with Client(target, mode=mode, timeout=20, init_timeout=20) as client:
                        calls = []
                        for name, oracle in truth.items():
                            calls += [(name, 'describe_table', {'table_name': name}), (name, 'query', {'sql': oracle['sql']})]
                        for name in ['untyped', 'typed_text', *([] if args.baseline else ['generated', 'searchable'])]:
                            calls.append((name, 'get_table_summary', {'table_name': name}))
                        calls += [('compact', 'get_full_schema', {'detail_level': 'compact'}),
                                  ('ungrouped', 'get_full_schema', {'detail_level': 'compact', 'group_identical': False}),
                                  ('full', 'get_full_schema', {'detail_level': 'full'}),
                                  ('skill', 'execute_query_skill', {'skill_name': 'probe', 'params': {}}),
                                  ('detail', 'get_skill_detail', {'skill_name': 'probe'}),
                                  ('directory', 'list_tables', {})]
                        for case, tool, arguments in calls:
                            arguments = {'connection_id': 'scoped', **arguments}
                            result = await client.call_tool(tool, arguments, raise_on_error=False)
                            records.append({'transport': transport, 'mode': mode, 'case': case, 'tool': tool,
                                'arguments': arguments, 'isError': result.is_error,
                                'structured': result.structured_content,
                                'content': [c.model_dump(mode='json', exclude_none=True) for c in result.content]})
                except Exception as error:
                    errors.append({'transport': transport, 'mode': mode, 'type': type(error).__name__, 'message': str(error),
                                   'traceback': traceback.format_exc()})
                finally:
                    if server is not None:
                        server.gateway_runtime.close()
        assert sha(database) == initial
    data = {'scope': 'Baseline2c0a9e7' if args.baseline else 'Current source', 'package': str(Path(sql_safety_executor.__file__).parent),
            'sqlite_version': sqlite3.sqlite_version, 'truth': truth, 'components': components,
            'calls': records, 'errors': errors, 'fixtures_cleaned': not Path(temporary).exists(),
            'database_unchanged_after_setup': True,
            'summary': {'objects': len(truth), 'calls': len(records), 'groups': dict(Counter(r['transport'] + ':' + r['mode'] for r in records)),
                        'tool_errors': sum(r['isError'] for r in records)}}
    args.output.write_text(json.dumps(data, indent=2) + '\n')
    print(json.dumps(data['summary']))
    print(json.dumps(errors))


if __name__ == '__main__':
    if args.child:
        create_server(load_config(args.child)).run(transport='stdio', show_banner=False)
    else:
        asyncio.run(main())
