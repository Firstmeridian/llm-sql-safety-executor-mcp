"""Verify type-only assessment results without modifying runtime code."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import tomllib

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(path.read_text()) if path.exists() else json.loads(gzip.decompress(path.with_suffix(path.suffix + '.gz').read_bytes()))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    current = read(HERE / 'evidence/source-final.json')
    baseline = read(HERE / 'evidence/baseline-2c0a9e7-final.json')
    before = read(HERE / 'baseline/current.json')
    for data, expected_calls in [(current, 184), (baseline, 32)]:
        assert not data['errors'] and data['summary']['calls'] == expected_calls
        assert data['fixtures_cleaned'] and data['database_unchanged_after_setup']
        for row in data['calls']:
            result = row['structured']
            assert not row['isError'] and result['success'], (row['case'], row['tool'], result)
            text = [c['text'] for c in row['content'] if c['type'] == 'text']
            assert len(text) == 1 and json.loads(text[0]) == result
            if row['tool'] == 'query':
                expected = [dict(zip(['n', 'storage_type', 'equals_text'], values)) for values in data['truth'][row['case']]['rows']]
                assert result['data'] == expected, row['case']
            if row['tool'] in {'describe_table', 'get_table_summary'}:
                expected = [r for r in data['truth'][row['case']]['columns'] if r[6] != 1]
                assert [c['column_name'] for c in result['columns']] == [r[1] for r in expected]
                assert [c['data_type'] for c in result['columns']] == [r[2] or 'TEXT' for r in expected]
            if row['tool'] == 'get_skill_detail':
                assert result['skill']['executable'] and result['skill']['schema_ready']
            if row['tool'] == 'execute_query_skill':
                assert result['data'] == [{'n': 7, 'storage_type': 'integer', 'equals_text': 0}]
        assert data['truth']['untyped']['columns'][0][2] == ''
        assert data['truth']['untyped']['rows'] == [[7, 'integer', 0]]
        assert data['truth']['typed_text']['rows'] == [['7', 'text', 1]]
    mismatch_names = []
    corrected = {}
    for comp in current['components']:
        if comp['mode'] != 'auto':
            continue
        native = [r for r in current['truth'][comp['table']]['columns'] if r[6] != 1]
        if any(c['data_type'] != r[2] for c, r in zip(comp['columns'], native, strict=True)):
            mismatch_names.append(comp['table'])
        fixed = [dict(c, data_type=r[2]) for c, r in zip(comp['columns'], native, strict=True)]
        corrected[comp['table']] = fixed
    assert set(mismatch_names) == {'untyped', 'quoted_empty', 'as_const', 'generated', 'generated_stored', 'searchable', 'v_expr', 'v_unary'}
    compact_rows = [r for r in current['calls'] if r['case'] == 'compact']
    for row in compact_rows:
        groups = row['structured']['schema_groups']
        lookup = {t['name']: i for i, g in enumerate(groups) for t in g['tables']}
        assert lookup['untyped'] == lookup['typed_text']
        assert lookup['generated'] == lookup['generated_text']
        assert row['structured']['schema_group_count'] == 9
        assert row['structured']['total_tables'] == 14 and row['structured']['total_columns'] == 17
        selected = sorted(lookup)
        proposed = {json.dumps(corrected[name], sort_keys=True, ensure_ascii=False) for name in selected}
        assert len(proposed) == 11
    native = read(HERE / 'evidence/native.json')
    assert len(native['calls']) == 2
    for row in native['calls']:
        result = row['result']
        assert not result['isError'] and result['structuredContent']['success']
        assert json.loads(result['content'][0]['text']) == result['structuredContent']
    assert native['calls'][0]['result']['structuredContent']['data'] == [{'n': 7, 'storage_type': 'integer', 'equals_text': 0}]
    assert [c['data_type'] for c in native['calls'][1]['result']['structuredContent']['columns']] == ['TEXT', 'TEXT']
    old = ROOT / 'local_archive/v382_review/20261021_fts_catalog_statistics_repair/resident_restart/evidence'
    truth = read(old / 'metadata_truth.json')
    assert [r[2] for r in truth['columns']['pages_fts'] if r[6] != 1] == ['', '']
    cfg = tomllib.loads((ROOT / 'config/connections.toml').read_text())
    path = Path(cfg['connections']['sqlite_features_sqlite']['sqlite']['path'])
    database = path if path.is_absolute() else ROOT / 'config' / path
    assert sha(database) == read(old / 'before.json')['configured_sqlite_sha256']
    for name, digest in before['resources'].items():
        assert sha(ROOT / name) == digest, name
    for name, digest in before['private_toml_sha256'].items():
        assert sha(ROOT / name) == digest, name
    stored = ROOT / 'local_archive/v382_review/20261021_fts_catalog_statistics_assessment/baseline/2c0a9e7/src/sql_safety_executor/database/sqlite.py'
    commit_data = subprocess.check_output(['git', 'show', '2c0a9e78252849f127a5dc8367f5c42d5209c609:src/sql_safety_executor/database/sqlite.py'], cwd=ROOT)
    assert stored.read_bytes() == commit_data
    records = 0
    for spec in before['prior_seals']:
        manifest = ROOT / spec['manifest']
        assert sha(manifest) == spec['sha256']
        data = read(manifest)
        items = data['files'].items() if isinstance(data['files'], dict) else ((r['path'], r) for r in data['files'])
        paths = {}
        count = 0
        for name, file in items:
            path = next(p for p in [manifest.parent / name, manifest.parent.parent / name, ROOT / name] if p.is_file())
            paths[name] = path
            assert sha(path) == (file['sha256'] if isinstance(file, dict) else file)
            if isinstance(file, dict):
                if 'bytes' in file:
                    assert path.stat().st_size == file['bytes']
                if 'decoded_sha256' in file:
                    decoded = gzip.decompress(path.read_bytes())
                    assert hashlib.sha256(decoded).hexdigest() == file['decoded_sha256'] and len(decoded) == file['decoded_bytes']
            count += 1
        for name, file in data.get('compressed_decoded_records', {}).items():
            decoded = gzip.decompress(paths[name].read_bytes())
            assert hashlib.sha256(decoded).hexdigest() == file.get('decoded_sha256', file.get('sha256'))
            assert len(decoded) == file.get('decoded_bytes', file.get('bytes'))
        assert count == spec['files']
        records += count
    assert len(before['prior_seals']) == 61 and records == 2020
    summary = {'finding': 'DRR-2026-140', 'severity': 'P3', 'status': 'Confirmed old metadata defect; assessment only, not repaired',
        'source_calls': 184, 'source_component_observations': 36, 'baseline_calls': 32, 'native_calls': 2,
        'current_groups': current['summary']['groups'], 'text_structured_equal': True,
        'current_empty_type_objects': mismatch_names, 'old_compact_groups': 9,
        'proposed_declared_type_preservation_groups': 11, 'proposal_scope': 'Pure signature calculation, not patched production/tool results',
        'raw_and_query_skill_storage_semantics_preserved': True,
        'schema_tables': 14, 'schema_columns': 17, 'view_schema_overview': 'Views excluded by existing directory contract, but describe_table is checked',
        'native_fts_columns_reported': ['TEXT', 'TEXT'], 'native_fts_raw_declared_types': ['', ''],
        'native_oracle': 'Prior sealed independent metadata, with configured SQLite file SHA unchanged',
        'runtime_resources_unchanged': 77, 'private_configs_unchanged': 3, 'configured_sqlite_unchanged': True,
        'baseline_sqlite_py_matches_commit': True, 'prior_manifests_unchanged': 61, 'prior_file_records_unchanged': records,
        'new_confirmed_P1_P2': 0, 'new_independent_production_roots': 1,
        'new_model_trials': 0, 'new_builds': 0, 'new_full_regression_runs': 0, 'configured_database_writes': False,
        'limits': 'Only selected type/metadata neighbors; not all SQL or whole database semantics; previous37 external rowid variants not independently replayed here'}
    (HERE / 'evidence/assessment.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
