"""Recheck frozen resident catalogs using independent native directory statements."""
import gzip
import json
from pathlib import Path
import sqlite3

from sql_safety_executor import load_config
from sql_safety_executor.database.mysql import MySQLAdapter

ROOT=Path(__file__).resolve().parents[4]
E=Path(__file__).resolve().parents[1]/'evidence'
plan=json.loads(gzip.decompress((ROOT/'local_archive/v382_review/20261021_primary_key_metadata_repair/evidence/native_plan.json.gz').read_bytes()))
config=load_config(ROOT/'config/server.toml');truth={'sqlite':{},'mysql':{}}
out=E/'native_catalogs.json';assert not out.exists()
with sqlite3.connect(Path(config.connections['sqlite_features_sqlite'].sqlite_database_path).resolve().as_uri()+'?mode=ro',uri=True) as db:
    for name,t in plan['sqlite_truth'].items():
        raw=[list(r) for r in db.execute("PRAGMA main.table_xinfo('"+name.replace("'","''")+"')")]
        assert raw==t['columns'];truth['sqlite'][name]=raw
adapter=MySQLAdapter(config.connections['sakila_mysql'])
try:
    assert adapter.connect()
    with adapter._engine.connect() as db:
        for name,t in plan['mysql_truth'].items():
            rows=[list(r) for r in db.exec_driver_sql('SELECT COLUMN_NAME,DATA_TYPE,IS_NULLABLE,COLUMN_KEY,COLUMN_DEFAULT FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=%s AND TABLE_NAME=%s ORDER BY ORDINAL_POSITION',(adapter._config.mysql_database,name))]
            indexes=[list(r) for r in db.exec_driver_sql('SHOW INDEX FROM `'+adapter._config.mysql_database.replace('`','``')+'`.`'+name.replace('`','``')+'`')]
            primary=sorted((r for r in indexes if r[2]=='PRIMARY'),key=lambda r:r[3])
            assert rows==t['columns'] and {r[4]:r[3] for r in primary}==t['positions']
            truth['mysql'][name]={'columns':rows,'primary_key_positions':{r[4]:r[3] for r in primary}}
finally:adapter.close()
out.write_text(json.dumps({'matches_frozen_truth':True,'catalogs':truth},indent=2)+'\n')
print('Independent current catalogs agree: SQLite6 tables / MySQL16 tables89 columns.')
