"""Serial identical read workflows: immediate pre-DRR141 wheel A/current B/A."""
import argparse
import asyncio
from datetime import date, datetime, time
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time as clock

from fastmcp import Client
from sql_safety_executor import create_server, load_config

ROOT = Path(__file__).resolve().parents[4]
E = Path(__file__).resolve().parents[1] / 'evidence'

async def worker(output):
    frozen = json.loads((E / 'frozen.json').read_text())
    config = load_config(ROOT / 'config/server.toml')
    server = create_server(config)
    records = {}
    try:
        async with Client(server, mode='auto') as client:
            for task in frozen['tasks']:
                if not task.get('queries'):
                    continue
                async def invoke():
                    responses = []
                    schema = (await client.call_tool('get_full_schema', {'connection_id': task['connection_id'], 'detail_level': 'compact'})).structured_content
                    assert schema['success'] and not schema['truncated']
                    responses.append(schema)
                    for name, sql in task['queries'].items():
                        value = (await client.call_tool('query', {'connection_id': task['connection_id'], 'sql': sql})).structured_content
                        assert value['success'] and not value['truncated'], (task['id'], name, value)
                        expected = task['truth'][name]
                        if task['id'] == 'finance' and name == 'asof_examples':
                            expected = [{**r, 'return_date': r['return_date'].replace(' ', 'T', 1) if r['return_date'] else None} for r in expected]
                        assert json.loads(json.dumps(value['data'], default=str)) == expected, (task['id'], name)
                        responses.append(value)
                    return responses
                for _ in range(3):
                    await invoke()
                samples = []
                for _ in range(12):
                    start = clock.perf_counter()
                    values = await invoke()
                    samples.append((clock.perf_counter() - start) * 1000)
                records[task['id']] = {'samples_ms': samples, 'median_ms': statistics.median(samples),
                    'p95_ms': sorted(samples)[int(.95*len(samples))-1], 'tool_calls': len(values),
                    'schema_json_chars': len(json.dumps(values[0],ensure_ascii=False,separators=(',',':'))),
                    'rows_sha256': hashlib.sha256(json.dumps([v['data'] for v in values[1:]],ensure_ascii=False,sort_keys=True).encode()).hexdigest(),
                    'query_data_matches_frozen_native_truth': True}
    finally:
        server.gateway_runtime.close()
    output.write_text(json.dumps(records,indent=2)+'\n')

def control(old_python):
    output = E / 'workflow_cost.json'
    assert not output.exists()
    phases = {}
    for phase, executable in [('A1', old_python), ('B', sys.executable), ('A2', old_python)]:
        path = E / ('workflow_cost_'+phase+'.json')
        assert not path.exists()
        subprocess.run([executable, str(Path(__file__).resolve()), '--worker', str(path)],
                       cwd=ROOT, check=True, env=os.environ.copy(), timeout=300)
        phases[phase] = json.loads(path.read_text())
    summaries=[]
    for name, current in phases['B'].items():
        reference=statistics.mean(phases[p][name]['median_ms'] for p in ['A1','A2'])
        assert len({phases[p][name]['rows_sha256'] for p in phases})==1
        summaries.append({'task':name,'baseline_median_reference_ms':reference,
            'current_median_ms':current['median_ms'],'delta_ms':current['median_ms']-reference,
            'delta_percent':(current['median_ms']/reference-1)*100,'tool_calls':current['tool_calls'],
            'all_truth_matches':True})
    output.write_text(json.dumps({'warmups':3,'samples_per_phase':12,'order':['A1','B','A2'],
        'phases':phases,'summary':summaries,
        'limits':'No concurrent model trials or tests. Warm inprocess Client, fixed business SQL and one compact call; not model planning, remote Host latency or provider tokens. Immediate pre-DRR141 wheel baseline differs from October20 full-model baseline. Natural drift retained; correctness payloads may differ.'},indent=2)+'\n')
    print(json.dumps(summaries))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--worker',type=Path);parser.add_argument('--old-python')
    args=parser.parse_args()
    if args.worker:asyncio.run(worker(args.worker))
    else:control(args.old_python)
