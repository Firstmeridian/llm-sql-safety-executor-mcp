"""Verify earlier sealed bytes without mutating earlier checkpoints."""
import gzip
import hashlib
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4]
E=Path(__file__).resolve().parents[1]/'evidence'
sha=lambda b:hashlib.sha256(b).hexdigest()
frozen=json.loads((E/'frozen.json').read_text())
count=0
for spec in frozen['prior_seals']:
    manifest=ROOT/spec['manifest'];assert sha(manifest.read_bytes())==spec['sha256']
    data=json.loads(manifest.read_bytes());paths={}
    items=data['files'].items() if isinstance(data['files'],dict) else ((x['path'],x) for x in data['files'])
    for name,meta in items:
        path=next(p for p in [manifest.parent/name,manifest.parent.parent/name,ROOT/name] if p.is_file())
        paths[name]=path;raw=path.read_bytes();assert sha(raw)==(meta['sha256'] if isinstance(meta,dict) else meta)
        if isinstance(meta,dict):
            if 'bytes' in meta:assert len(raw)==meta['bytes']
            if 'decoded_sha256' in meta:
                decoded=gzip.decompress(raw);assert sha(decoded)==meta['decoded_sha256'] and len(decoded)==meta['decoded_bytes']
        count+=1
    for name,meta in data.get('compressed_decoded_records',{}).items():
        raw=gzip.decompress(paths[name].read_bytes());assert sha(raw)==meta.get('decoded_sha256',meta.get('sha256'))
        assert len(raw)==meta.get('decoded_bytes',meta.get('bytes'))
assert len(frozen['prior_seals'])==75 and count==2316,(len(frozen['prior_seals']),count)
out=Path(sys.argv[1]) if len(sys.argv)>1 else E/'prior_seals_verified.json';assert not out.exists()
out.write_text(json.dumps({'manifests':75,'records':count,'stored_and_declared_decoded_hashes_valid':True},indent=2)+'\n')
print('75 prior manifests / 2316 records verified unchanged')
