"""Freeze identical historical tasks and independent native truth before dispatch."""
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sqlite3

from sql_safety_executor import load_config
from sql_safety_executor.database.mysql import MySQLAdapter

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
E = BATCH / 'evidence'
OLD = ROOT / 'local_archive/v382_review/20261020_complete_agent_eval'
PARENT = ROOT / 'local_archive/v382_review/20261021_primary_key_metadata_repair'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(gzip.decompress(p.read_bytes()) if p.suffix == '.gz' else p.read_bytes())
assert not (E / 'frozen.json').exists()
old = read(OLD / 'evidence/frozen.json')
config = load_config(ROOT / 'config/server.toml')
resources = {str(p.relative_to(ROOT / 'src/sql_safety_executor')): sha(p)
             for p in (ROOT / 'src/sql_safety_executor').rglob('*')
             if p.is_file() and p.suffix in {'.py', '.md'}}
sqlite_files = {alias: {'file_sha256': sha(Path(c.sqlite_database_path))}
                for alias, c in config.connections.items() if c.db_type == 'sqlite'}
assert sqlite_files == old['sqlite_files'], 'Historical business data changed'
cfg_hashes = {name: sha(ROOT / 'config' / name) for name in old['private_config_hashes']}
assert cfg_hashes == old['private_config_hashes'], 'Historical private config changed'
native_truth = {}
mysql = MySQLAdapter(config.connections['sakila_mysql'])
try:
    assert mysql.connect()
    for task in old['tasks']:
        alias = task['connection_id']
        if task['id'] == 'mutation':
            with sqlite3.connect(Path(config.connections[alias].sqlite_database_path).resolve().as_uri() + '?mode=ro', uri=True) as db:
                assert db.execute('SELECT status FROM main.orders WHERE id=1').fetchone()[0] == task['truth']['last_observed_status']
            native_truth[task['id']] = task['truth']
            continue
        if config.connections[alias].db_type == 'sqlite':
            with sqlite3.connect(Path(config.connections[alias].sqlite_database_path).resolve().as_uri() + '?mode=ro', uri=True) as db:
                db.row_factory = sqlite3.Row
                actual = {name: [dict(r) for r in db.execute(sql)] for name, sql in task['queries'].items()}
        else:
            with mysql._engine.connect() as db:
                actual = {name: [dict(r._mapping) for r in db.exec_driver_sql(sql)] for name, sql in task['queries'].items()}
        actual = json.loads(json.dumps(actual, default=str))
        assert actual == task['truth'], task['id']
        native_truth[task['id']] = actual
    with mysql._engine.connect() as db:
        sakila = {}
        for name in old['sakila_before']:
            rows = [tuple(r) for r in db.exec_driver_sql('SELECT * FROM ' + name + ' ORDER BY 1')]
            sakila[name] = {'rows': len(rows), 'sha256': hashlib.sha256(json.dumps(rows, default=str, ensure_ascii=False).encode()).hexdigest()}
    assert sakila == old['sakila_before']
finally:
    mysql.close()
spec = importlib.util.spec_from_file_location('native_verify', PARENT / 'resident_restart/scripts/verify.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
native = mod.check_calls(read(E / 'native_reconnect.json'), read(PARENT / 'evidence/native_plan.json.gz'))
assert native['calls'] == native['passed'] == 12 and native['failed'] == 0
(E / 'native_verification.json').write_text(json.dumps(native, indent=2) + '\n')
manifests = sorted([p for parent in (ROOT / 'local_archive/v382_review', ROOT / 'docs/validation/v3.8')
                    for p in parent.rglob('*manifest*.json') if '20261021_complete_agent_eval' not in str(p)])
# Match the previously accepted set; only sealed manifests are included by explicit ancestry.
previous = read(PARENT / 'resident_restart/evidence/before.json.gz')['prior_seals']
previous += [{'manifest': str(p.relative_to(ROOT)), 'sha256': sha(p)} for p in (
    PARENT / 'resident_restart/manifest.json',
    ROOT / 'docs/validation/v3.8/v382_primary_key_metadata_repair_2026_10_21/resident_restart/manifest.json') if p.exists()]
data = {**old, 'frozen_utc': datetime.now(timezone.utc).isoformat(),
        'runtime_resources': resources, 'sqlite_files': sqlite_files,
        'private_config_hashes': cfg_hashes, 'sakila_before': sakila,
        'native_truth_rechecked': native_truth, 'prior_seals': previous,
        'historical_baseline': {'batch': str(OLD.relative_to(ROOT)), 'prompt_identical_trials': 15,
                               'same_data_config_model_effort_required': True,
                               'not_randomized_source_ab': True},
        'scope': '15 fresh Luna medium sessions, each own canary and two identical historical business turns. No confirmed writes. Compare provider token usage, tool calls and public wall time descriptively; not causal MCP/model performance. Preserve all initial failures. No hidden reasoning or bearer handles exported.'}
(E / 'frozen.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
snapshot = ROOT / 'docs/validation/v3.8/V3_8_2_PRIMARY_KEY_METADATA_REPAIR_2026_10_21_ZH.md'
(E / 'primary_report_before.md').write_bytes(snapshot.read_bytes())
print(json.dumps({'native_passed': native['passed'], 'frozen_trials': 15, 'resources': len(resources),
                  'sqlite_files': len(sqlite_files), 'historical_truth_equal': True, 'prior_manifests': len(previous)}))
