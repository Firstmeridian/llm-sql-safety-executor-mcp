"""Read only public final messages for these exact trial threads."""
import json
from pathlib import Path
import sys

E=Path(__file__).resolve().parents[1]/'evidence'
for filename in sys.argv[1:]:
    for agent in json.loads(Path(filename).read_text()):
        paths=list(Path('/home/andy/.codex/sessions/2026/10/21').glob('*'+agent['agent_id']+'.jsonl'))
        if not paths:
            print(json.dumps({'task':agent['task'],'trial':agent['trial'],'not_found':True}));continue
        phase='preflight';finals={};usage=[]
        for line in paths[0].open():
            event=json.loads(line);p=event.get('payload',{})
            if event.get('type')=='token_usage_record':usage.append(p.get('thread_token_usage'))
            if event.get('type')!='response_item' or p.get('type')!='message':continue
            text='\n'.join(x.get('text','') for x in p.get('content',[]))
            if p.get('role')=='user':
                for label in ('turn1','turn2'):
                    if '.'+label.upper()+'\n' in text:phase=label
            if p.get('role')=='assistant' and p.get('phase',p.get('channel')) in ('final','final_answer'):
                finals[phase]=text
        print(json.dumps({'task':agent['task'],'trial':agent['trial'],'agent_id':agent['agent_id'],
                         'finals':finals,'latest_usage':usage[-1] if usage else {}},ensure_ascii=False))
