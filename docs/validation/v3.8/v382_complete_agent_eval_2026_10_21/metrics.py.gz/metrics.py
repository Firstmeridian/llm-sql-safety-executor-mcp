"""Separate task usage/public latency from local fixed-workflow costs."""
from datetime import datetime
import gzip
import json
from pathlib import Path
import statistics

ROOT=Path(__file__).resolve().parents[4]
E=Path(__file__).resolve().parents[1]/'evidence'
OLD=ROOT/'local_archive/v382_review/20261020_complete_agent_eval/evidence'
read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
new=read(E/'summary.json');old=read(OLD/'summary.json');audit=read(E/'model_context_check.json')
delta=lambda a,b:{'old':a,'new':b,'delta_percent':(b/a-1)*100 if a else None}
counts={k:delta(old[k],new[k]) for k in ('business_mcp_returns','all_canonical_mcp_returns')}
counts['business_model_responses']=delta(sum(t['business_model_responses'] for t in old['trials']),sum(t['business_model_responses'] for t in new['trials']))
usage={field:{k:delta(old[field][k],new[field][k]) for k in new[field]} for field in ('business_usage','all_usage')}
groups=[];public=[]
seconds=lambda s:datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()
def tool_spans(record):
    calls={};total=0;spans=[]
    for e in record['events']:
        if e['phase'] not in ('turn1','turn2'):continue
        kind=e['type'];cid=e.get('call_id')
        if kind in ('custom_tool_call','function_call'):calls[cid]=e
        elif kind in ('custom_tool_call_output','function_call_output') and cid in calls:
            a=seconds(calls.pop(cid)['timestamp']);b=seconds(e['timestamp']);spans.append((a,b))
    # Union overlapping public call windows, including tool discovery and batching.
    merged=[]
    for a,b in sorted(spans):
        if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(b,merged[-1][1]))
        else:merged.append((a,b))
    return sum(b-a for a,b in merged)
for task in ('telemetry','knowledge','search','finance','mutation'):
    a=[t for t in old['trials'] if t['task']==task];b=[t for t in new['trials'] if t['task']==task]
    groups.append({'task':task,'calls':delta(sum(t['business_mcp_returns'] for t in a),sum(t['business_mcp_returns'] for t in b)),
        'business_total_tokens':delta(sum(t['business_usage']['total_tokens'] for t in a),sum(t['business_usage']['total_tokens'] for t in b))})
for pair in audit['historical_comparison']:
    name=pair['trial'];a=read(OLD/(name+'_complete.json.gz'));b=read(E/(name+'_complete.json.gz'))
    wall_a=sum(pair['old_public_business_wall_seconds'].values());wall_b=sum(pair['new_public_business_wall_seconds'].values())
    public.append({'trial':name,'business_wall_seconds':delta(wall_a,wall_b),
        'public_tool_windows_seconds':delta(tool_spans(a),tool_spans(b)),
        'first_response_input_tokens':delta(pair['old_first_response_input_tokens'],pair['new_first_response_input_tokens'])})
wall=delta(sum(r['business_wall_seconds']['old'] for r in public),sum(r['business_wall_seconds']['new'] for r in public))
tool=delta(sum(r['public_tool_windows_seconds']['old'] for r in public),sum(r['public_tool_windows_seconds']['new'] for r in public))
out=E/'metrics.json';assert not out.exists()
value={'counts':counts,'usage':usage,'groups':groups,'public_trial_windows':public,
    'summed_business_wall_seconds':wall,'mean_complete_task_seconds':delta(wall['old']/15,wall['new']/15),
    'summed_public_tool_windows_seconds':tool,
    'business_refusals':[{'task':t['task'],'trial':t['trial'],**r} for t in new['trials'] for r in t['business_refusals']],
    'limits':'Historical comparison is descriptive, all15 exact prompts/data/model/effort pairs.15 concurrent-task windows are summed, not actual batch elapsed. Public tool windows include exec discovery/batching/Host/transport and are not database latency; residual includes provider/model/Host queue/scheduling, cannot isolate root cause. Different dates/backend sampling; no causal MCP or universal token conclusion. Guidance probes excluded.'}
out.write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({'calls':counts['business_mcp_returns'],'business_total_tokens':usage['business_usage']['total_tokens'],'task_mean_seconds':value['mean_complete_task_seconds'],'summed_tool_windows':tool}))
