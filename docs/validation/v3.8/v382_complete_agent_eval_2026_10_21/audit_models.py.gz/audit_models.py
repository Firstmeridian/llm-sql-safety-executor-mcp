"""Audit actual per-turn context and preserve identical business prompts."""
from datetime import datetime
import gzip
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4]
E=Path(__file__).resolve().parents[1]/'evidence'
OLD=ROOT/'local_archive/v382_review/20261020_complete_agent_eval/evidence'
read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
out=E/'model_context_check.json';assert not out.exists()
selected=[];comparison=[]
for agent in read(E/'agents_selected_final.json'):
    name=agent['task']+'_'+str(agent['trial'])
    new=read(E/(name+'_complete.json.gz'));old=read(OLD/(name+'_complete.json.gz'))
    contexts=new['actual_model_contexts']
    historical_audit=read(OLD/'model_context_check.json')
    old_contexts=next(x['contexts'] for x in historical_audit['selected_trials'] if x['agent_id']==old['agent']['agent_id'])
    valid=bool(contexts) and all(c['model']=='gpt-6-luna' and c['effort']=='medium' for c in contexts)
    old_valid=bool(old_contexts) and all(c['model']=='gpt-6-luna' and c['effort']=='medium' for c in old_contexts)
    def prompts(record):
        return {e['phase']:'\n'.join(c.get('text','') for c in e.get('content',[]))
                for e in record['events'] if e.get('role')=='user' and e['phase'] in ('turn1','turn2')}
    assert prompts(new)==prompts(old) and set(prompts(new))=={'turn1','turn2'},name
    selected.append({'task':agent['task'],'trial':agent['trial'],'agent_id':agent['agent_id'],
                     'contexts':contexts,'valid_luna_medium':valid,'historical_model_valid':old_valid})
    def times(record):
        values={}
        for phase in ('turn1','turn2'):
            events=[e for e in record['events'] if e['phase']==phase]
            start=next(e['timestamp'] for e in events if e.get('role')=='user')
            end=[e['timestamp'] for e in events if e.get('role')=='assistant' and e.get('message_phase') in ('final','final_answer')][-1]
            values[phase]=(datetime.fromisoformat(end.replace('Z','+00:00'))-datetime.fromisoformat(start.replace('Z','+00:00'))).total_seconds()
        return values
    comparison.append({'trial':name,'identical_business_prompts':True,
        'old_public_business_wall_seconds':times(old),'new_public_business_wall_seconds':times(new),
        'old_first_response_input_tokens':old['per_response_usage'][0]['usage']['input_tokens'],
        'new_first_response_input_tokens':new['per_response_usage'][0]['usage']['input_tokens']})
assert len(selected)==15 and all(x['valid_luna_medium'] and x['historical_model_valid'] for x in selected)
out.write_text(json.dumps({'verified':True,'selected_trials':selected,'historical_comparison':comparison,
    'limits':'Per-context actual model/effort, not requested spawn label. No hidden reasoning. Public task windows include model, Host, transport, queueing and SQL time, exclude parent wait between turns; not isolated MCP latency or randomized source A/B.'},indent=2)+'\n')
print('Actual Luna medium and exact prompts verified for all fifteen current/historical pairs.')
