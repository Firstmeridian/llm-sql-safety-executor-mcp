"""Append this restart/model/cost checkpoint, retaining all previous sealed failures."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
from urllib.parse import unquote

HERE=Path(__file__).resolve().parents[1]
ROOT=HERE.parents[2]
PUBLIC=ROOT/'docs/validation/v3.8/v382_complete_agent_eval_2026_10_21'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not (HERE/'manifest.json').exists() and not (PUBLIC/'manifest.json').exists()
summary=json.loads((HERE/'evidence/summary.json').read_text())
assert summary['business_passed']==summary['planned_trials']==15
assert json.loads((HERE/'evidence/native_verification.json').read_text())['passed']==12
assert json.loads((HERE/'evidence/after_data.json').read_text())['all_checks_passed']
assert json.loads((HERE/'evidence/after_all_checks.json').read_text())['all_checks_passed']
assert json.loads((HERE/'evidence/guidance_verification.json').read_text())['trials']==3
PUBLIC.mkdir(exist_ok=True)
for p in list((HERE/'evidence').iterdir()):
    if p.is_file() and (p.suffix=='.log' or p.suffix=='.json' and p.stat().st_size>10000):
        out=p.with_suffix(p.suffix+'.gz');assert not out.exists()
        out.write_bytes(gzip.compress(p.read_bytes(),mtime=0));p.unlink()
for p in (HERE/'evidence').iterdir():
    if p.is_file():shutil.copyfile(p,PUBLIC/p.name)
for p in (HERE/'scripts').glob('*.py'):
    (PUBLIC/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))

names=['README.md','README_ZH.md','REFACTORING_LOG.md','REFACTORING_LOG_ZH.md',
       'docs/README.md','docs/README_ZH.md','docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md',
       'docs/guides/TEST_MCP_CLIENT_GUIDE.md','docs/releases/RELEASE_NOTES_v3_8.md',
       'docs/security/DESIGN_RISK_REGISTER.md','docs/security/DESIGN_RISK_REGISTER_ZH.md','docs/security/V3_8_SECURITY.md',
       'docs/validation/v3.8/V3_8_2_PRIMARY_KEY_METADATA_REPAIR_2026_10_21_ZH.md',
       'docs/validation/v3.8/V3_8_2_COMPLETE_AGENT_EVAL_2026_10_21_ZH.md',
       'local_archive/v382_review/README.md','local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md',
       'local_archive/v382_review/handoff/commit-message-v382.txt',
       str((HERE/'reports/README_ZH.md').relative_to(ROOT)),str((PUBLIC/'README.md').relative_to(ROOT))]
checked=0;broken=[]
for name in names:
    p=ROOT/name
    for link in re.findall(r'\[[^\]\n]+\]\(([^)\s]+)\)',p.read_text()):
        if re.match(r'^[a-zA-Z]+:',link) or link.startswith('#'):continue
        link=unquote(link.split('#',1)[0].strip('<>'))
        if not link:continue
        target=Path(link) if link.startswith('/') else p.parent/link
        checked+=1
        if not target.exists() and not target.with_suffix(target.suffix+'.gz').exists():broken.append({'document':name,'link':link})
assert not broken,broken
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)

def files(folder):
    return sorted(p for p in folder.rglob('*') if p.is_file() and p.name!='manifest.json' and '__pycache__' not in p.parts)

private_count=len(files(HERE))+1;public_count=len(files(PUBLIC))+1
handoff=ROOT/'local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md'
text=handoff.read_text()
anchor='## 历史检查点：DRR-141原生通道差异与MySQL范围'
assert anchor in text
text=text.replace(anchor,f'本批封存private{private_count}／public{public_count}条记录，累计**77份manifest／{2316+private_count+public_count}条文件记录**。由frozen中的75旧清单加本批private/public两份核验；旧失败和pending不改。\n\n'+anchor,1)
handoff.write_text(text)
checks={'documents':{name:sha((ROOT/name).read_bytes()) for name in names},
        'local_links_checked':checked,'broken_links':broken,'git_diff_check':'passed',
        'prior_manifests':75,'prior_file_records':2316,'new_private_records':private_count,'new_public_records':public_count,
        'cumulative_manifests':77,'cumulative_file_records':2316+private_count+public_count,
        'scope':'Native12/12, actual verified Luna fifteen same-task trials plus three separate natural-guidance probes, serial fixed-workflow costs. No runtime/config/database mutation or new full-suite/build/install claim.'}
(HERE/'evidence/documentation_checks.json').write_text(json.dumps(checks,indent=2)+'\n')
shutil.copyfile(HERE/'evidence/documentation_checks.json',PUBLIC/'documentation_checks.json')
for folder,count in [(HERE,private_count),(PUBLIC,public_count)]:
    entries={}
    for p in files(folder):
        raw=p.read_bytes();meta={'bytes':len(raw),'sha256':sha(raw)}
        if p.suffix=='.gz':
            decoded=gzip.decompress(raw);meta.update(decoded_bytes=len(decoded),decoded_sha256=sha(decoded))
        entries[str(p.relative_to(folder))]=meta
    assert len(entries)==count
    (folder/'manifest.json').write_text(json.dumps({'date':'2026-10-21','checkpoint':'DRR141 latest resident closure and complete Agent evaluation',
        'append_rule':'Previous native7/12 mismatch, source/package pending seals, failed attempts and model trials remain unchanged.',
        'files':entries},indent=2)+'\n')
    for name,meta in entries.items():assert sha((folder/name).read_bytes())==meta['sha256']
print(json.dumps({k:v for k,v in checks.items() if k!='documents'}))
