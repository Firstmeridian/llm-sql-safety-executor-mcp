"""Describe the implemented COLLATE repair without claiming resident closure."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
REPORT = 'V3_8_2_COLLATE_REPAIR_2026_10_18_ZH.md'


def add_after_line(name, marker, text):
    path = ROOT / name
    lines = path.read_text().splitlines()
    matches = [i for i, row in enumerate(lines) if marker in row]
    assert len(matches) == 1, (name, marker)
    lines[matches[0] + 1:matches[0] + 1] = text.splitlines()
    path.write_text('\n'.join(lines) + '\n')


for name, row in [
    ('docs/security/DESIGN_RISK_REGISTER.md',
     '| DRR-2026-109 | Implemented; scoped resident verification pending | Low (functional compatibility) | 2026-10-18 | SQLite IS/ESCAPE operand COLLATE parsing | Pinned SQLGlot shortcuts omitted COLLATE after NULL/placeholder IS operands and string/NULL/parameter ESCAPE operands; e49cd0e falsely refused valid reads. | Yes | Parse these SQLite operands at expression precedence; retain original SQL/bindings, independent project policy and authorizer. Other IS branches and MySQL delegation remain scoped. | 100 new regressions, 2375 full passes/four skips, clean type/prompt; 40 matched Client calls restore 26 prior refusals; 96 source stdio and 490 installed calls pass with 75 matching resources. [Evidence](../validation/v3.8/' + REPORT + '). | Await maintainer restart: four resident probes still report old refusal. Keep DRR-108 closed; preserve earlier P3 findings, intermediate failures and source attribution. No blanket parenthesis rewrite, new grant, dependency or zero-cost claim. |'),
    ('docs/security/DESIGN_RISK_REGISTER_ZH.md',
     '| DRR-2026-109 | 已补修；限定驻留复验待完成 | 低（功能兼容） | 2026-10-18 | SQLite IS／ESCAPE 操作数 COLLATE 解析 | 固定 SQLGlot 的 NULL／placeholder IS 右值及字符串／NULL／参数 ESCAPE 右值快捷分支遗漏 COLLATE，e49cd0e 误拒合法读取。 | 是 | SQLite 按表达式优先级解析这些右值；原 SQL／参数、独立读取策略及 authorizer 保留，其他 IS 及 MySQL 分支继续按原方言处理。 | 新增 100 项，全量 2375 passed／四项跳过，类型／提示通过；同输入 40 次恢复原 26 次拒绝，源码 stdio 96 次及安装包 490 次通过，75 项资源一致。[证据](../validation/v3.8/' + REPORT + ')。 | 待维护者重启：四次驻留请求仍为旧拒绝。DRR-108 保持限定关闭，保留原 P3 发现、中间失败和源码归属；不通用补括号、不新增 grant／依赖或零成本承诺。 |'),
]:
    path = ROOT / name
    lines = path.read_text().splitlines()
    matches = [i for i, line in enumerate(lines) if line.startswith('| DRR-2026-109 |')]
    assert len(matches) == 1
    lines[matches[0]] = row
    path.write_text('\n'.join(lines) + '\n')

for name, entry in [
    ('REFACTORING_LOG.md',
     '## v3.8.2 Repair SQLite operand COLLATE binding (October 18, 2026; resident checks pending)\n\n'
     '- Adapt only SQLite IS/IS NOT NULL/parameter and LIKE ESCAPE right operands to expression precedence; preserve raw SQL/parameters, all dependencies, grants and authorizer checks. Retain SQLGlot 30.22.0 and v3.8.2.\n'
     '- Add 100 regressions: final 2375 passed/four skipped, clean type/prompt checks; matched 40-call comparison restores 26 false refusals. Source stdio 96 and independently installed 490 calls pass with 75 matching resources; no new required Agent call or model-cost A/B claim.\n'
     '- Preserve the IS-only checkpoint, two corrected error-layer test expectations, ESCAPE red tests and package-tool failures. Offline final build reuses the previously verified PyPA installer with RECORD checks; fresh wheel interpreter explicitly reuses frozen dependencies.\n'
     '- Four current resident probes still refuse, so DRR-109 awaits maintainer restart; DRR-108 stays closed. [Repair, evidence and limits](docs/validation/v3.8/' + REPORT + ').\n\n'),
    ('REFACTORING_LOG_ZH.md',
     '## v3.8.2 修复 SQLite 操作数 COLLATE 结合（2026-10-18；待驻留复验）\n\n'
     '- SQLite 的 IS／IS NOT NULL／参数及 LIKE ESCAPE 右值按表达式优先级解析，保留原 SQL／绑定和所有依赖、grant、authorizer 检查。SQLGlot 30.22.0、版本 v3.8.2 不变。\n'
     '- 新增 100 项，最终全量 2375 passed／四项跳过，类型／提示通过；同输入 40 次恢复原 26 次误拒。源码真实 stdio 96 次、独立 wheel 490 次通过，75 项资源一致；没有新增 Agent 必需调用或模型成本 A/B 结论。\n'
     '- 保留 IS 单独阶段、两项错误层次断言校正、ESCAPE 首轮失败及安装工具失败。最终离线构建复用已验证的 PyPA installer 并核验 RECORD；新 wheel 解释器显式复用锁定依赖。\n'
     '- 当前四次驻留定点请求仍拒绝，DRR-109 待维护者手动重启后限定核验；DRR-108 不重开。[修复、证据与限制](docs/validation/v3.8/' + REPORT + ')。\n\n'),
]:
    path = ROOT / name
    text = path.read_text()
    index = text.index('## v3.8.2 ')
    path.write_text(text[:index] + entry + text[index:])

add_after_line('README.md', "The adjacent audit's trigger-WHEN boundary is now repaired:",
    '\nSQLite IS/IS NOT and LIKE ESCAPE operands now preserve COLLATE precedence, including parameter bindings. Source/package validation passes; resident checks await the maintainer restart. See the [operand repair](docs/validation/v3.8/' + REPORT + ').')
add_after_line('README_ZH.md', '相邻复查的触发器 WHEN 边界已补修：',
    '\nSQLite IS／IS NOT 与 LIKE ESCAPE 操作数现保留 COLLATE 结合位置及参数绑定；源码／安装验证通过，待维护者重启限定复验。见[操作数补修](docs/validation/v3.8/' + REPORT + ')。')
for name, label in [('docs/README.md', 'v3.8.2 SQLite operand COLLATE repair'),
                    ('docs/README_ZH.md', 'v3.8.2 SQLite 操作数 COLLATE 补修')]:
    add_after_line(name, 'V3_8_2_FINAL_REVIEW_2026_10_18_ZH.md',
                   '- [' + label + '](validation/v3.8/' + REPORT + ').')

path = ROOT / 'docs/validation/v3.8/V3_8_2_FINAL_REVIEW_2026_10_18_ZH.md'
lines = path.read_text().splitlines()
lines[2:2] = ['> 后续已获准[补修 IS／ESCAPE 操作数](' + REPORT + ')，源码／安装通过，待维护者重启限定复验。下文保留 e49cd0e 首次复核时的 P3 发现、开放状态和原始证据。', '']
path.write_text('\n'.join(lines) + '\n')

path = ROOT / 'docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md'
text = path.read_text().replace('e49cd0e 再次通过 2275 项回归', '首次复核时，e49cd0e 再次通过 2275 项回归')
text = text.replace('当前不改原 SQL 或完整性策略。', '该阶段未改原 SQL 或完整性策略。')
text += ('\n## 2026-10-18 操作数补修（DRR-109，待驻留复验）\n\n'
    '维护者批准修复后，SQLite Parser 对 IS／IS NOT 的 NULL／参数右值及 LIKE ESCAPE 右值改用既有表达式优先级入口，保留 COLLATE 作用位置、真实依赖和函数；原始 SQL／参数继续执行。其余 IS 形态及 MySQL 不扩大改动。新增 100 项、全量 2375 项及源码／wheel 两协议验证通过；不新增数据库探测或 Agent 必需步骤，未做新的成本 A/B。当前驻留四例仍拒绝，需维护者重启；DRR-108 保持限定关闭。[最新实现与证据](../validation/v3.8/' + REPORT + ')。\n')
path.write_text(text)

path = ROOT / 'docs/releases/RELEASE_NOTES_v3_8.md'
text = path.read_text()
index = text.index('\n---\n')
text = text[:index] + ('\n### October 18 SQLite operand COLLATE compatibility\n\n'
    'Repair the SQLite IS/IS NOT NULL/parameter and LIKE ESCAPE operand shortcuts that rejected valid COLLATE expressions. Parse at expression precedence, preserving original SQL/bindings, physical dependencies and function restrictions. No new dependency, grant or required Agent call. Add 100 regressions: final 2375 passed/four skipped, clean type/prompt, 96 source stdio and 490 installed targeted calls. DRR-109 awaits scoped resident verification after the maintainer restart; DRR-108 stays closed. Preserve prior review findings and intermediate failures in the [repair evidence](../validation/v3.8/' + REPORT + ').\n') + text[index:]
path.write_text(text)

path = ROOT / 'docs/guides/TEST_MCP_CLIENT_GUIDE.md'
text = path.read_text()
old = '`installed_semantics.py --output <new>.json.gz` requires an outside-repository wheel interpreter and uses only private temporary databases, both stdio protocols, scoped metadata and real temp/view fixtures.'
new = ('`installed_semantics.py --source <src> --output <new>.json.gz` checks explicit source; omit --source with an outside-repository wheel interpreter. It uses private temporary databases, both stdio protocols, scoped metadata and real temp/view fixtures, including IS/ESCAPE COLLATE operands and bound Query Skills.')
assert text.count(old) == 1
path.write_text(text.replace(old, new))
print('Updated documentation for the implemented repair; resident status remains pending.')
