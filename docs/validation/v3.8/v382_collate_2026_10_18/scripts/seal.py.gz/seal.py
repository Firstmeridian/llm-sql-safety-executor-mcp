"""Seal the final COLLATE repair with explicit pending resident scope."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
LOCAL = BATCH / 'evidence'
PUBLIC = ROOT / 'docs/validation/v3.8/v382_collate_2026_10_18'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)


def main():
    assert not PUBLIC.exists(), 'Append evidence; never overwrite a seal'
    before = read(LOCAL / 'source_before.json')['source_sha256']
    package = ROOT / 'src/sql_safety_executor'
    current = {p.relative_to(package).as_posix(): sha(p) for p in sorted(package.rglob('*'))
               if p.is_file() and p.suffix in ('.py', '.md')}
    changed = [name for name in before if before[name] != current[name]]
    assert len(current) == 75 and changed == ['core/analysis.py']
    a, b = read(LOCAL / 'same_input_before.json.gz'), read(LOCAL / 'same_input_after.json.gz')
    assert a['source_sha256'] == before and b['source_sha256'] == current
    assert len(a['records']) == len(b['records']) == 40 and a['independent'] == b['independent']
    assert sum(r['structured']['success'] for r in a['records']) == 14
    assert all(r['structured']['success'] for r in b['records'])
    for row in b['records']:
        truth = next(r['sqlite_rows'] for r in b['independent'] if r['name'] == row['name'])
        assert row['structured']['data'] == truth
    full = (LOCAL / 'full_regression.log').read_text()
    assert '2375 passed, 4 skipped, 284 warnings in 157.85s' in full
    assert '100 passed, 44 warnings' in (LOCAL / 'tests_final.log').read_text()
    assert '0 errors, 0 warnings' in (LOCAL / 'pyright.log').read_text()
    assert 'Installed prompt resources and routing guidance valid.' in (LOCAL / 'prompt_contract.log').read_text()
    assert 'outside_repository' in (LOCAL / 'installed_generic.log').read_text()
    installed = read(LOCAL / 'installed_resources.json')
    assert installed['installed']['resources'] == current
    total, protocols = 0, set()
    for name, count, field in [('source_stdio', 96, 'installed_source_sha256'),
                                ('installed_semantics', 96, 'installed_source_sha256'),
                                ('installed_trigger_ctes', 254, 'source_sha256'),
                                ('installed_plans', 140, 'source_sha256')]:
        record = read(LOCAL / (name + '.json.gz'))
        assert record['calls'] == len(record['records']) == count
        assert record[field] == current
        for row in record['records']:
            assert not row['isError']
            assert json.loads(next(c['text'] for c in row['content'] if c['type'] == 'text')) == row['structured']
            protocols.add(row['protocol'])
        if name != 'source_stdio':
            total += count
    assert total == 490 and protocols == {'2026-07-28', '2025-11-25'}
    resident = read(LOCAL / 'native_before_restart.json')
    assert len(resident['records']) == 4
    assert all(r['raw']['structuredContent'].get('error_code') == 'sql_parse_failed' for r in resident['records'])
    assert len(read(LOCAL / 'native_plan.json')['records']) == 25
    parent = ROOT / 'docs/validation/v3.8/v382_when_2026_10_17'
    accepted = read(parent / 'verification.json')
    preserved, prior = 0, {}
    manifests = list(accepted['preserved_manifests']) + [
        str((parent / 'manifest.json').relative_to(ROOT)),
        str((parent / 'resident_restart/manifest.json').relative_to(ROOT)),
        'docs/validation/v3.8/v382_final_review_2026_10_18/manifest.json']
    for name in manifests:
        path = ROOT / name
        base = path.parent.parent if name.startswith('local_archive/') else path.parent
        files = read(path)['files']
        for relative, info in files.items():
            file = base / relative
            assert sha(file) == info['sha256'] and file.stat().st_size == info['bytes'], file
        prior[name] = {'sha256': sha(path), 'files': len(files)}
        preserved += len(files)
    assert preserved == 498
    location = read(LOCAL / 'before_source_location.json')
    owned = Path(location['path']).resolve()
    assert owned.parent == Path('/tmp') and owned.name.startswith('v382-collate-before-')
    for name, digest in before.items():
        assert sha(owned / 'src/sql_safety_executor' / name) == digest
    shutil.rmtree(owned)
    script_names = ['scripts/validation/installed_semantics.py', 'tests/test_sqlite_collate_v382.py',
                    'local_archive/v382_review/20261018_final_review/scripts/probe_collate.py']
    script_names += [str(p.relative_to(ROOT)) for p in sorted((BATCH / 'scripts').glob('*.py'))]
    verification = {
        'version': '3.8.2', 'base_commit': 'e49cd0eebb9bdf56ac6c114522af5b8743ba3bbf',
        'closed_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'source_package_passed_resident_restart_pending', 'risk': 'DRR-2026-109',
        'changed_runtime_resources': changed, 'runtime_resources': current,
        'scripts_tests': {name: sha(ROOT / name) for name in script_names},
        'tests': {'new': 100, 'full_passed': 2375, 'skipped': 4, 'warnings': 284, 'seconds': 157.85},
        'same_input': {'cases': 20, 'calls_per_version': 40, 'before_success': 14, 'before_refused': 26,
                       'after_success': 40, 'actual_old_package_path_asserted': True},
        'source_stdio_calls': 96, 'installed_targeted_calls': 490, 'protocols': sorted(protocols),
        'wheel': {k: installed[k] for k in ('wheel_sha256', 'dependency_scope', 'installer', 'installer_sha256', 'installer_provenance')},
        'resident': {'four_initial_refusals_preserved': True, 'planned_readonly_checks': 25,
                     'state': 'Await manual maintainer restart; no code-object or native-protocol attestation.'},
        'preserved_sealed_files': preserved, 'preserved_manifests': prior,
        'limits': [
            'No version/dependency/config/grant/approval or MySQL parser change; original SQL and bindings remain.',
            'Private data/functions and source/package evidence do not imply configured trigger/Skill native coverage.',
            'No new Luna task, MySQL live matrix or model/server cost A/B; previous results retain source attribution.',
            'Fresh interpreter uses a normal wheel install with explicitly reused frozen dependencies, not fresh dependency resolution.',
            'IS-only checkpoint is intermediate, not final source evidence. Initial assertion/tool failures remain recorded.',
            'Application content/structured records omit full transport frames; complete analysis is not native syntax certification.',
        ],
    }
    PUBLIC.mkdir()
    # All intermediate records remain distinct. Derive only a minimal input
    # plan here; the seed's old native responses already have their own seal.
    for path in sorted(LOCAL.rglob('*')):
        if not path.is_file() or path.name == 'cases_input.json':
            continue
        relative = path.relative_to(LOCAL)
        target = PUBLIC / 'evidence' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        if path.suffix in ('.log', '.py') or path.name == 'native_before_restart.json':
            target = target.with_name(target.name + '.gz')
            target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
        else:
            shutil.copy2(path, target)
    seed = read(LOCAL / 'cases_input.json')
    plan = {'scope': 'SQL/name projection only; original old native results remain in the final-review batch.',
            'records': [{k: r[k] for k in ('name', 'sql')} for r in seed['records']]}
    (PUBLIC / 'input_plan.json').write_text(json.dumps(plan, ensure_ascii=False, indent=2) + '\n')
    for name in script_names:
        target = PUBLIC / 'scripts' / (Path(name).name + '.gz')
        target.parent.mkdir(exist_ok=True)
        target.write_bytes(gzip.compress((ROOT / name).read_bytes(), mtime=0))
    (PUBLIC / 'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
    manifest = {'closed_utc': verification['closed_utc'], 'scope': 'Final source/package repair with pending manual resident restart; prior seals unchanged.',
        'files': {p.relative_to(PUBLIC).as_posix(): {'sha256': sha(p), 'bytes': p.stat().st_size}
                  for p in sorted(PUBLIC.rglob('*')) if p.is_file()}}
    (PUBLIC / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'full_passed': 2375, 'installed_calls': 490, 'source_calls': 96,
                      'old_sealed_files': 498, 'new_sealed_files': len(manifest['files']), 'resident': 'pending'}))


if __name__ == '__main__':
    main()
