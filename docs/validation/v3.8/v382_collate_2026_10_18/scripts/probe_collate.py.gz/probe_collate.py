"""Read-only COLLATE comparison, with actual package-path/source attestation."""
import argparse
import asyncio
import gzip
import hashlib
import inspect
import json
from pathlib import Path
import sqlite3
import sys
import tempfile


async def main(args):
    sys.path.insert(0, str(args.source))
    import sql_safety_executor as package
    import sqlglot
    from sqlglot.parser import Parser
    from fastmcp import Client
    from sql_safety_executor import create_server, load_config
    directory = Path(package.__file__).resolve().parent
    assert directory == args.source / 'sql_safety_executor', directory
    specs = [{k: r[k] for k in ('name', 'sql')} for r in json.loads(args.native.read_text())['records']]
    specs += [
        {'name': f'{op}_{collation}_{context}', 'sql':
            (f'SELECT NULL {op} NULL COLLATE {collation} AS n;' if context == 'projection'
             else f'SELECT 7 AS n WHERE NULL {op} NULL COLLATE {collation};')}
        for op in ('IS', 'IS NOT') for collation in ('BINARY', 'RTRIM')
        for context in ('where', 'projection')
    ]
    independent, records = [], []
    with sqlite3.connect(':memory:') as native:
        for spec in specs:
            native.row_factory = sqlite3.Row
            rows = [dict(r) for r in native.execute(spec['sql'])]
            try:
                sqlglot.parse_one(spec['sql'], read='sqlite')
                parser = {'success': True}
            except Exception as error:
                parser = {'success': False, 'type': type(error).__name__, 'message': str(error)}
            independent.append({**spec, 'sqlite_rows': rows, 'sqlglot': parser})
    with tempfile.TemporaryDirectory(prefix='v382-collate-') as temporary:
        folder = Path(temporary)
        (folder / 'server.toml').write_text('schema_version=1\n[files]\nconnections="connections.toml"\n[server]\ndefault_connection="demo"\n')
        (folder / 'connections.toml').write_text('schema_version=1\n[connections.demo]\ntype="sqlite"\nsqlite.path="fixture.sqlite"\nread.mode="all"\n')
        server = create_server(load_config(folder / 'server.toml'))
        try:
            for mode in ('auto', 'legacy'):
                async with Client(server, mode=mode) as client:
                    for spec, truth in zip(specs, independent):
                        response = await client.call_tool('query', {'connection_id': 'demo', 'sql': spec['sql']}, raise_on_error=False)
                        body = response.structured_content
                        assert not response.is_error
                        assert json.loads(next(c.text for c in response.content if c.type == 'text')) == body
                        if body['success']:
                            assert body['data'] == truth['sqlite_rows'], (spec, body)
                        records.append({'name': spec['name'], 'mode': mode,
                            'protocol': client.protocol_version, 'structured': body,
                            'content': [c.model_dump(mode='json', exclude_none=True) for c in response.content],
                            'isError': response.is_error})
        finally:
            server.gateway_runtime.close()
    output = {'stage': args.stage, 'version': package.__version__, 'package': str(directory),
        'source': str(args.source), 'source_sha256': {str(p.relative_to(directory)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(directory.rglob('*')) if p.is_file() and p.suffix in ('.py', '.md')},
        'sqlite_version': sqlite3.sqlite_version, 'sqlglot_version': sqlglot.__version__,
        'sqlglot_parse_is': inspect.getsource(Parser._parse_is),
        'independent': independent, 'records': records,
        'scope': 'Private in-process Client comparison with current installed dependencies; no configured DB writes, no historical dependency-environment or fresh stdio/Host claim.'}
    assert not args.output.exists()
    args.output.write_bytes(gzip.compress((json.dumps(output, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
    print(json.dumps({'stage': args.stage, 'cases': len(specs), 'client_calls': len(records),
        'success': sum(r['structured']['success'] for r in records),
        'refusals': sum(not r['structured']['success'] for r in records)}))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--source', type=lambda s: Path(s).resolve(), required=True)
    p.add_argument('--native', type=lambda s: Path(s).resolve(), required=True)
    p.add_argument('--output', type=lambda s: Path(s).resolve(), required=True)
    p.add_argument('--stage', required=True)
    asyncio.run(main(p.parse_args()))
