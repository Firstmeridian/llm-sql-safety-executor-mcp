"""Offline cached-backend build; normal wheel install with frozen dependency reuse."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import venv

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parents[1] / 'evidence'
cache = Path.home() / '.cache/uv/archive-v0'
backend_paths = []
for name in ('hatchling', 'pathspec', 'trove_classifiers', 'tomlkit'):
    matches = [p for p in cache.iterdir() if (p / name).is_dir()]
    assert len(matches) == 1, (name, matches)
    backend_paths.append(str(matches[0]))
build_env = os.environ.copy()
build_env['PYTHONPATH'] = os.pathsep.join(backend_paths)
build_env['PYTHONDONTWRITEBYTECODE'] = '1'
folder = Path(tempfile.mkdtemp(prefix='v382-collate-wheel-'))
dist = folder / 'dist'
print(json.dumps({'build_directory': str(folder), 'offline_cached_backend': True}), flush=True)
code = 'import importlib.metadata as m,json;print(json.dumps({n:m.version(n) for n in ["build","hatchling","pathspec","tomlkit","trove-classifiers"]}))'
backends = json.loads(subprocess.check_output([sys.executable, '-c', code], env=build_env))
subprocess.run([sys.executable, '-m', 'build', '--no-isolation', '--outdir', str(dist)],
               cwd=ROOT, env=build_env, check=True)
wheel = dist / 'llm_sql_safety_executor_mcp-3.8.2-py3-none-any.whl'
assert wheel.is_file()
target = folder / 'wheel_env'
venv.EnvBuilder(with_pip=True).create(target)
site = next((target / 'lib').glob('python*/site-packages'))
dependencies = ROOT / '.venv-v38/lib/python3.12/site-packages'
(site / 'frozen_dependencies.pth').write_text(str(dependencies) + '\n')
python = target / 'bin/python'
install_env = os.environ.copy()
install_env.pop('PYTHONPATH', None)
install_env['PIP_DISABLE_PIP_VERSION_CHECK'] = '1'
subprocess.run([str(python), '-m', 'pip', 'install', '--no-deps', '--no-index', str(wheel)],
               cwd='/tmp', env=install_env, check=True)
inspect_code = '''import importlib.metadata as m,hashlib,json,pathlib,sys,sql_safety_executor
p=pathlib.Path(sql_safety_executor.__file__).parent
assert p.is_relative_to(pathlib.Path(sys.prefix))
assert not any('__editable__' in str(x) for x in sys.meta_path)
print(json.dumps(dict(package=str(p),version=m.version('llm-sql-safety-executor-mcp'),resources={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file() and f.suffix in {'.py','.md'}})))'''
installed = json.loads(subprocess.check_output([str(python), '-c', inspect_code], cwd='/tmp', env=install_env))
package = ROOT / 'src/sql_safety_executor'
current = {str(p.relative_to(package)): hashlib.sha256(p.read_bytes()).hexdigest()
           for p in package.rglob('*') if p.is_file() and p.suffix in {'.py', '.md'}}
assert current == installed['resources'] and len(current) == 75
record = {'version': '3.8.2', 'wheel': str(wheel), 'python': str(python),
          'wheel_sha256': hashlib.sha256(wheel.read_bytes()).hexdigest(), 'installed': installed,
          'backend_versions': backends, 'build_directory': str(folder),
          'dependency_scope': 'Offline cached-backend sdist/wheel build. Fresh venv uses bundled pip for a normal no-deps/no-index wheel install, explicitly reusing existing frozen dependency directory. No editable import or fresh dependency resolution.'}
(OUT / 'installed_resources.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'installed_resources': 75, 'python': str(python), 'wheel_sha256': record['wheel_sha256']}), flush=True)
