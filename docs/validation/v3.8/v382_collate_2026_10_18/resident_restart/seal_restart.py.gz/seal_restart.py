"""Append native restart evidence without changing prior sealed checkpoints."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
PARENT = ROOT / "docs/validation/v3.8/v382_collate_2026_10_18"
TARGET = PARENT / "resident_restart"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def check_manifest(path):
    base = path.parent.parent if "local_archive" in path.parts else path.parent
    items = read(path)["files"]
    for name, info in items.items():
        entry = base / name
        assert sha(entry) == info["sha256"], entry
        assert entry.stat().st_size == info["bytes"], entry
    return len(items)


def main():
    assert not TARGET.exists(), "Use a new supplement; never overwrite sealed evidence"
    parent = read(PARENT / "verification.json")
    preserved = {}
    for name, info in parent["preserved_manifests"].items():
        path = ROOT / name
        assert sha(path) == info["sha256"], path
        assert check_manifest(path) == info["files"]
        preserved[name] = info
    path = PARENT / "manifest.json"
    preserved[str(path.relative_to(ROOT))] = {"sha256": sha(path), "files": check_manifest(path)}
    assert sum(v["files"] for v in preserved.values()) == 556
    for name, expected in parent["runtime_resources"].items():
        assert sha(ROOT / "src/sql_safety_executor" / name) == expected, name
    for name, expected in parent["scripts_tests"].items():
        assert sha(ROOT / name) == expected, name
    plan = read(PARENT / "evidence/native_plan.json")
    raw_path = BATCH / "evidence/native_after_restart.json"
    raw = read(raw_path)
    checks, independent = [], []
    assert len(raw["records"]) == len(plan["records"]) == 25
    with sqlite3.connect(":memory:") as db:
        db.row_factory = sqlite3.Row
        for record, expected in zip(raw["records"], plan["records"], strict=True):
            assert {k: record[k] for k in ("name", "tool", "arguments", "expected")} == expected
            result = record["result"]
            assert result["isError"] is False
            assert len(result["content"]) == 1 and result["content"][0]["type"] == "text"
            data = result["structuredContent"]
            assert json.loads(result["content"][0]["text"]) == data
            assert data["connection_id"] == "analytics_demo_sqlite" and data["db_type"] == "sqlite"
            assert data["query"] == expected["arguments"]["sql"]
            for key, value in expected["expected"].items():
                assert data[key] == value, (record["name"], key)
            if data["success"]:
                assert data["truncated"] is False
                assert data["row_count"] == data["total_rows"] == len(data["data"])
                if not record["name"].startswith("snapshot_"):
                    sql = expected["arguments"]["sql"]
                    truth = [dict(row) for row in db.execute(sql)]
                    assert truth == data["data"], record["name"]
                    independent.append({"name": record["name"], "sql": sql, "sqlite_rows": truth})
            checks.append({"name": record["name"], "passed": True})
    assert len(independent) == 20
    by_name = {r["name"]: r["result"]["structuredContent"] for r in raw["records"]}
    before, after = by_name["snapshot_before"], by_name["snapshot_after"]
    assert before == after and len(before["data"]) == 5 and len(before["data"][0]) == 5
    verification = {
        "version": "3.8.2", "base_commit": parent["base_commit"],
        "sealed_utc": datetime.now(timezone.utc).isoformat(),
        "status": "scoped_native_verification_passed", "risk": "DRR-2026-109",
        "calls": 25, "passed": 25, "valid_constant_cases": 20,
        "refusal_controls": 3, "full_snapshots": 2, "checks": checks,
        "connection_id": "analytics_demo_sqlite", "snapshot_rows": 5, "snapshot_columns": 5,
        "snapshot_equal": True, "application_content_matches_structured": True,
        "native_started_utc": raw["started_utc"], "native_completed_utc": raw["completed_utc"],
        "plan_sha256": sha(PARENT / "evidence/native_plan.json"),
        "runtime_resources": parent["runtime_resources"],
        "parent_verification_sha256": sha(PARENT / "verification.json"),
        "preserved_sealed_files": 556, "preserved_manifests": preserved,
        "scope": [
            "Actual current native Host query tools after maintainer-confirmed manual restart; exact frozen plan.",
            "No configured writes, fixtures, grant, dependency or version change.",
            "20 constant outputs independently rechecked using local SQLite; three policy refusals retained.",
            "Runtime hashes match the previously tested 2375-regression / 490-installed-call checkpoint; this continuation does not rerun or relabel them.",
            "Configured trigger/parameter Skill native fixtures, new Luna tasks, live MySQL and new cost A/B were not run.",
            "Application content/structured tool records do not capture full protocol frames, attest negotiated native protocol or resident code objects.",
            "DRR-109 closes within the documented regression/package and 25-check native scope; DRR-108 remains scoped closed.",
            "Four pre-restart parse refusals remain sealed in the unchanged parent; their old-process cause is not classified as confirmed caching."
        ]
    }
    TARGET.mkdir()
    (TARGET / "native_after_restart.json.gz").write_bytes(gzip.compress(raw_path.read_bytes(), mtime=0))
    write(TARGET / "independent_sqlite.json", {
        "sqlite_version": sqlite3.sqlite_version, "database": ":memory:",
        "scope": "Recompute only the 20 constant statements; no configured database opened",
        "records": independent})
    write(TARGET / "verification.json", verification)
    (TARGET / "seal_restart.py.gz").write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
    write(TARGET / "manifest.json", {
        "sealed_utc": verification["sealed_utc"],
        "scope": "Separate resident restart supplement; parent and all historical checkpoints unchanged.",
        "files": {p.relative_to(TARGET).as_posix(): {"sha256": sha(p), "bytes": p.stat().st_size}
                  for p in sorted(TARGET.rglob("*")) if p.is_file()}})
    assert check_manifest(TARGET / "manifest.json") == 4
    print(json.dumps({"native": "25/25", "independent_constants": len(independent),
                      "snapshot": "5 rows/5 columns identical", "prior_files_verified": 556,
                      "new_sealed_files": 4, "status": verification["status"]}))


if __name__ == "__main__":
    main()
