"""Follow up five UPDATE OR forms and isolate plan source/grant boundaries."""
import argparse
import asyncio
from pathlib import Path
import assess_adjacent as harness

original={case['name']:case for case in harness.CASES}
harness.CASES=[]
for conflict in ['ROLLBACK','ABORT','FAIL','IGNORE','REPLACE']:
    for with_prefix in [False,True]:
        body='UPDATE OR '+conflict+' orders SET n=99'
        if with_prefix:
            body='WITH chosen(n) AS (SELECT 99) '+body
        harness.add('update_or_'+conflict.lower()+('_with' if with_prefix else ''),body)
        # Both scopes distinguish a parsing limit from baseline allowlist errors.
        unrestricted=dict(harness.CASES[-1])
        unrestricted['name']+='_read_all'
        unrestricted['read_mode']='all'
        harness.CASES.append(unrestricted)

for name in ['temp_trigger','trigger_quoted_names']:
    case=dict(original[name])
    case['name']+='_explicit_grant'
    case['grants']=['main.orders','audit_log','lookup_values']
    harness.CASES.append(case)

harness.add('trigger_view_grant_without_base', 'INSERT INTO orders VALUES(99)',
    ddl='CREATE VIEW lookup_view AS SELECT n FROM lookup_values; CREATE TRIGGER log_orders AFTER INSERT ON orders BEGIN INSERT INTO audit_log SELECT n FROM lookup_view; END;',
    grants=['orders','audit_log','lookup_view'])
harness.add('trigger_count_ambiguous_main_temp', 'INSERT INTO main.orders VALUES(99)',
    session='CREATE TEMP TABLE lookup_values(n); INSERT INTO temp.lookup_values VALUES(17); CREATE TEMP TRIGGER log_orders AFTER INSERT ON main.orders BEGIN INSERT INTO audit_log SELECT COUNT(*) FROM main.lookup_values; END;',
    grants=['main.orders','audit_log','main.lookup_values'])
harness.add('trigger_same_name_cte', 'WITH log_orders(n) AS (SELECT 99) INSERT INTO orders SELECT n FROM log_orders',
    ddl='CREATE TRIGGER log_orders AFTER INSERT ON orders BEGIN INSERT INTO audit_log SELECT n FROM lookup_values; END;')
harness.add('trigger_same_name_cte_ungranted', 'WITH log_orders(n) AS (SELECT 99) INSERT INTO orders SELECT n FROM log_orders',
    ddl='CREATE TRIGGER log_orders AFTER INSERT ON orders BEGIN INSERT INTO audit_log SELECT n FROM hidden; END;', expected='deny')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    args.source=args.source.resolve();args.output=args.output.resolve()
    if args.output.exists():
        parser.error('Output already exists; choose a fresh filename')
    asyncio.run(harness.assess(args))
