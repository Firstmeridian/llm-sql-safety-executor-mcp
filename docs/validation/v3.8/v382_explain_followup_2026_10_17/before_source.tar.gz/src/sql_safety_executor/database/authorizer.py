"""SQLite compile-time checks scoped to one exclusively owned read operation."""
from __future__ import annotations

import sqlite3
import time
from collections import Counter
from dataclasses import dataclass, field

from .errors import DatabaseQueryError
from .identifiers import ascii_identifier_lower as fold
from .models import ConnectionPolicy
from .relations import RelationReference
from .semantics import DialectContext


@dataclass
class SQLiteReadGuard:
    policy: ConnectionPolicy
    default_schema: str
    cte_names: frozenset[str] = frozenset()
    view_edges: set[tuple[str, RelationReference]] = field(default_factory=set)
    resolved_bindings: dict[str, set[RelationReference]] = field(default_factory=dict)
    ephemeral_ctes: frozenset[str] = frozenset()
    explain_dml: bool = False
    denial: str | None = None

    def deny(self, code: str) -> int:
        if self.denial is None:
            self.denial = code
        return sqlite3.SQLITE_DENY

    def authorize(self, action: int, first: str | None, second: str | None,
                  database: str | None, source: str | None) -> int:
        from sql_safety_executor.core.read_rules import (
            _ACCOUNT_FUNCTIONS, _LOCK_FUNCTIONS, _EXPENSIVE_FUNCTIONS,
            _SQLITE_PRAGMA_OBJECTS,
        )
        if action == sqlite3.SQLITE_READ:
            if first is None:
                return self.deny("table_access_denied")
            unscoped_count = database is None and second == "" and (
                source is None or fold(source) in self.cte_names
            )
            if database is None:
                # Materialized/constant CTE counts can emit an empty-column
                # READ of the CTE itself. This is not a physical relation grant:
                # bootstrap verified a unique declaration and no catalog object
                # with that spelling; all actual base READs remain checked.
                if second == "" and fold(first) in self.ephemeral_ctes:
                    return sqlite3.SQLITE_OK
                # SQLite emits extra empty-column READ events without a DB
                # for some rowid/count/order plans. Bind only to a unique
                # catalog-resolved object from this analysis, never guess main.
                candidates = self.resolved_bindings.get(fold(first), set())
                if len(candidates) != 1:
                    return self.deny("view_scope_unresolved")
                database = next(iter(candidates)).schema
                if database is None:
                    return self.deny("view_scope_unresolved")
            reference = RelationReference(first, database)
            if fold(first) in _SQLITE_PRAGMA_OBJECTS:
                return self.deny("server_state_denied")
            if source is None:
                allowed = self.policy.allows_resolved_relation(reference, self.default_schema)
            else:
                allowed = (fold(source), reference.key(case_sensitive=False)) in self.view_edges or (
                    fold(source) in self.cte_names and self.policy.allows_resolved_relation(reference, self.default_schema)
                )
            if not allowed and unscoped_count:
                # SQLite can drop the view source from an additional
                # COUNT READ of its base. All physical roots were checked
                # before activation; accept only a unique resolved base
                # already in the authorized view dependency graph.
                allowed = any(target == reference.key(case_sensitive=False)
                              for _, target in self.view_edges)
            return sqlite3.SQLITE_OK if allowed else self.deny("table_access_denied")
        if action == sqlite3.SQLITE_FUNCTION:
            name = fold(second or "")
            if name == "load_file":
                return self.deny("file_operation_denied")
            if name in _ACCOUNT_FUNCTIONS or name in _SQLITE_PRAGMA_OBJECTS:
                return self.deny("server_state_denied")
            if name in _LOCK_FUNCTIONS:
                return self.deny("lock_function_denied")
            if name in _EXPENSIVE_FUNCTIONS:
                return self.deny("expensive_function_denied")
            return sqlite3.SQLITE_OK
        if action in {sqlite3.SQLITE_SELECT, sqlite3.SQLITE_RECURSIVE}:
            return sqlite3.SQLITE_OK
        if action == sqlite3.SQLITE_PRAGMA:
            return self.deny("server_state_denied")
        if self.explain_dml and action in {sqlite3.SQLITE_INSERT, sqlite3.SQLITE_UPDATE, sqlite3.SQLITE_DELETE}:
            # These are compilation events for a verified, non-executing DML
            # plan. Still authorize every target, including trigger targets.
            if first is None or database is None:
                return self.deny("table_access_denied")
            reference = RelationReference(first, database)
            allowed = self.policy.allows_resolved_relation(reference, self.default_schema)
            return sqlite3.SQLITE_OK if allowed else self.deny("table_access_denied")
        return self.deny("read_only_required")


def build_read_guard(connection: sqlite3.Connection, policy: ConnectionPolicy,
                     context: DialectContext, analysis, *, deadline: float | None = None) -> SQLiteReadGuard:
    """Resolve authorized view edges before activating the read callback.

    Catalog SQL is fixed trusted bootstrap, never an untrusted query or callback
    re-entry. Actual READ events must still match these edges and root grants.
    Views cannot turn their sources into directly authorized base tables.
    """
    from sql_safety_executor.core.analysis import analyze_sql
    from sql_safety_executor.core.read_rules import _SQLITE_PRAGMA_OBJECTS

    guard = SQLiteReadGuard(policy, context.default_schema or "main", frozenset(fold(name.name) for name in analysis.names if name.role == "cte"))
    guard.explain_dml = (
        analysis.statement_kind == "explain"
        and analysis.explain_payload in {"insert", "update", "delete"}
        and not analysis.has_nested_write
    )
    cte_counts = Counter(fold(cte.name) for cte in analysis.ctes)
    candidate_ctes = {name for name, count in cte_counts.items() if count == 1}
    if not analysis.relations and not candidate_ctes:
        return guard
    schemas = [row[1] for row in connection.execute("PRAGMA database_list")]
    schemas.sort(key=lambda name: 0 if name == "temp" else 1 if name == "main" else 2)
    catalog: dict[RelationReference, tuple[str, str | None]] = {}
    observed: set[RelationReference] = set()

    def lookup(key: RelationReference):
        if deadline is not None and time.monotonic() > deadline:
            raise DatabaseQueryError("query_timeout")
        if key not in observed:
            if len(observed) >= 2048:
                raise DatabaseQueryError("view_scope_unresolved")
            observed.add(key)
            schema = key.schema
            assert schema is not None
            quoted = '"' + schema.replace('"', '""') + '"'
            rows = list(connection.execute(
                f"SELECT name, type, sql FROM {quoted}.sqlite_master "
                "WHERE name = ? COLLATE NOCASE AND type IN ('table','view') LIMIT 2", (key.name,)
            ))
            if len(rows) > 1:
                raise DatabaseQueryError("view_scope_unresolved")
            if rows:
                name, kind, definition = rows[0]
                catalog[RelationReference(name, schema).key(case_sensitive=False)] = (kind, definition)
        return catalog.get(key)

    def resolve(reference: RelationReference, owner: str | None = None):
        search = [reference.schema] if reference.schema is not None else (
            [owner] if owner is not None and owner != "temp" else schemas
        )
        for schema in search:
            key = RelationReference(reference.name, schema).key(case_sensitive=False)
            if lookup(key) is not None:
                guard.resolved_bindings.setdefault(key.name, set()).add(key)
                return key
        return None

    visited: set[RelationReference] = set()
    source_schemas: dict[str, str | None] = {}
    source_owners: dict[str, RelationReference | None] = {name: None for name in guard.cte_names}

    def source_owner(name: str, owner: RelationReference):
        key = fold(name)
        if key in source_owners and source_owners[key] != owner:
            raise DatabaseQueryError("view_scope_unresolved")
        source_owners[key] = owner

    def visit(reference: RelationReference):
        if reference in visited or catalog[reference][0] != "view":
            return
        visited.add(reference)
        if len(visited) > 128:
            raise DatabaseQueryError("view_scope_unresolved")
        # Callback source has no schema component. Ambiguous reachable source
        # spellings are unsupported rather than merged into a larger grant.
        previous = source_schemas.setdefault(reference.name, reference.schema)
        if previous != reference.schema:
            raise DatabaseQueryError("view_scope_unresolved")
        source_owner(reference.name, reference)
        definition = catalog[reference][1]
        if not definition:
            raise DatabaseQueryError("view_scope_unresolved")
        result = analyze_sql(definition, context, view_definition=True)
        if not result.complete or result.has_nested_write:
            raise DatabaseQueryError("view_scope_unresolved")
        labels = [fold(cte.name) for cte in result.ctes]
        if len(labels) != len(set(labels)):
            raise DatabaseQueryError("view_scope_unresolved")
        for label in labels:
            source_owner(label, reference)
            candidate_ctes.add(label)
        for use in result.relation_uses:
            if fold(use.reference.name) in _SQLITE_PRAGMA_OBJECTS:
                raise DatabaseQueryError("server_state_denied")
            target = resolve(use.reference, reference.schema)
            if target is None:
                raise DatabaseQueryError("unknown_table")
            guard.view_edges.add((fold(use.source) if use.source is not None else reference.name, target))
            if len(guard.view_edges) > 1024:
                raise DatabaseQueryError("view_scope_unresolved")
            visit(target)

    for reference in analysis.relations:
        target = resolve(reference)
        if target is not None:
            if not policy.allows_resolved_relation(target, guard.default_schema):
                raise DatabaseQueryError("table_access_denied")
            visit(target)
    # Callback READ labels have no scope/schema for these CTE events. Never
    # infer an ephemeral identity if a real main/temp/attached object could share
    # it. Catalog work stays outside the callback and within the existing budget.
    guard.ephemeral_ctes = frozenset(
        name for name in sorted(candidate_ctes)
        if not any(lookup(RelationReference(name, schema).key(case_sensitive=False))
                   is not None for schema in schemas)
    )
    return guard
