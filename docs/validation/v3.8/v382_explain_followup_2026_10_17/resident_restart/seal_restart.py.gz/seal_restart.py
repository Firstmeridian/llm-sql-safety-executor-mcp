"""Append native restart acceptance; preserve the pre-restart checkpoint."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parents[2]
LOCAL=ROOT/'evidence/resident_restart'
PARENT=REPO/'docs/validation/v3.8/v382_explain_followup_2026_10_17'
PUBLIC=PARENT/'resident_restart'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    assert not PUBLIC.exists(),'Do not overwrite native evidence'
    data=json.loads((LOCAL/'native.json').read_text())
    assert data['summary']['calls']==42 and data['summary']['passed']==42
    records=data['records']
    assert len(records)==42 and all(item['passed'] for item in data['checks'])
    for row in records:
        raw=row['raw'];payload=raw['structuredContent']
        assert not raw.get('isError',False)
        content=[item['text'] for item in raw['content'] if item['type']=='text']
        assert len(content)==1 and json.loads(content[0])==payload
        assert all(payload.get(key)==value for key,value in row['expected'].items()),row['name']
    before=next(row['raw']['structuredContent']['data'] for row in records if row['name']=='snapshot_before')
    after=next(row['raw']['structuredContent']['data'] for row in records if row['name']=='snapshot_after')
    assert before==after and len(before)==5 and all(len(row)==5 for row in before)
    assert sum(row['expected'].get('success') is False for row in records)==12
    assert sum(row['arguments'].get('sql','').startswith('EXPLAIN') and row['expected']['success'] for row in records)==26
    closure=json.loads((PARENT/'source_closure.json').read_text())
    for group in ['resources','tests','scripts']:
        for path,expected in closure[group].items():
            assert sha(REPO/path)==expected,path
    historical=[
        REPO/'docs/validation/v3.8/v382_2026_10_16/manifest.json',
        REPO/'docs/validation/v3.8/v382_read_boundaries_2026_10_17/manifest.json',
        REPO/'docs/validation/v3.8/v382_read_boundaries_2026_10_17/resident_restart/manifest.json',
        ROOT.parent/'20261017_explain_followup/evidence/manifest.json',
        ROOT.parent/'20261017_explain_adjacency/evidence/manifest.json',
        PARENT/'manifest.json',
    ]
    preserved={}
    for manifest in historical:
        old=json.loads(manifest.read_text())
        base=manifest.parent.parent if manifest.is_relative_to(REPO/'local_archive') else manifest.parent
        for relative,info in old['files'].items():
            path=base/relative
            assert sha(path)==info['sha256'] and path.stat().st_size==info['bytes'],path
        preserved[str(manifest.relative_to(REPO))]=len(old['files'])
    snapshot_hash=hashlib.sha256(json.dumps(before,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
    verification={
        'version':'3.8.2','status':'accepted_with_explicit_native_coverage_limits',
        'observed_utc':data['observed_utc'],'maintainer_restart':data['maintainer_restart'],
        'native':{**data['summary'],'text_structured_results_matching':42,'protocol':'Not exposed by this native facade.'},
        'data_integrity':{'connection_id':data['connection_id'],'relation':'orders','rows':5,'columns':5,
                          'before_sha256':snapshot_hash,'after_sha256':snapshot_hash,'unchanged':True,
                          'write_control_scope':'Actual-DML refusal probes use WHERE 0 or empty SELECT input; only EXPLAIN probes contain value-changing payloads. No configured mutation was executed.'},
        'source':{'current_resources_match_parent_closure':len(closure['resources']),
                  'loaded_code_object_hashes':'Not introspected; disk/installed identity and native behavior are separate evidence.'},
        'parent_checkpoint':{'manifest':'../manifest.json','sha256':sha(PARENT/'manifest.json'),
                             'verification':'../verification.json','files_verified_unchanged':50,
                             'scope':'The parent still records its then-pending restart status. Current status is this supplement.'},
        'preserved_sealed_files_verified':preserved,
        'coverage_limits':[
            'No trigger/view/UDF/plan-Skill fixture or new connection configuration was created in configured databases. Trigger-specific/count-source/plan-Skill cases retain same-source regression and 140 new installed-stdio coverage within 272 total installed calls.',
            'The Host exposes neither sample nor get_table_summary; their cross-entry coverage remains installed/regression evidence.',
            'No fresh full Luna task or model-token/latency measurement was run after restart; retain prior trial attribution and serial adapter costs.',
            'Tool catalog is Codex available-tool metadata, not a protocol tools/list frame. Application records do not include complete wire frames or notifications.',
        ],
    }
    PUBLIC.mkdir()
    for name in ['native','tool_catalog']:
        (PUBLIC/(name+'.json.gz')).write_bytes(gzip.compress((LOCAL/(name+'.json')).read_bytes(),mtime=0))
    (PUBLIC/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')
    (PUBLIC/'seal_restart.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
    manifest={'closed_utc':datetime.now(timezone.utc).isoformat(),
              'scope':'Native post-maintainer-restart acceptance supplement. Parent checkpoint, failures and raw history remain unchanged.',
              'files':{path.name:{'sha256':sha(path),'bytes':path.stat().st_size} for path in sorted(PUBLIC.iterdir())}}
    (PUBLIC/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'native_passed':42,'runtime_resources':75,'preserved_files':sum(preserved.values()),'sealed_files':len(manifest['files']),'status':verification['status']}))

if __name__=='__main__':
    main()
