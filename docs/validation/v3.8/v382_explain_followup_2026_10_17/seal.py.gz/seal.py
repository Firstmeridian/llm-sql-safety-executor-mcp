"""Seal this pre-restart checkpoint without altering historical evidence."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT=Path(__file__).resolve().parents[1]
REPO=ROOT.parents[2]
LOCAL=ROOT/'evidence'
PUBLIC=REPO/'docs/validation/v3.8/v382_explain_followup_2026_10_17'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def unpack(path):
    return json.loads(gzip.decompress(path.read_bytes()))

def main():
    assert not PUBLIC.exists(),'Never overwrite a sealed batch'
    runtime={str(p.relative_to(REPO/'src/sql_safety_executor')):sha(p)
             for p in sorted((REPO/'src/sql_safety_executor').rglob('*')) if p.is_file() and p.suffix in {'.py','.md'}}
    before=json.loads((LOCAL/'before_source.json').read_text())['resources']
    changed=[name for name in runtime if runtime[name]!=before[name]]
    assert set(changed)=={'core/analysis.py','database/sqlite.py','database/authorizer.py'}
    for name,count in [('installed_plans',140),('installed_read_boundaries',74),('installed_semantics',58),('stdio_source_final',140),('adjacent_after',238),('focused_after',104)]:
        data=unpack(LOCAL/(name+'.json.gz'))
        assert data['calls']==count,name
        assert data.get('source_sha256',data.get('installed_source_sha256'))==runtime,name
    assert unpack(LOCAL/'stdio_before.json.gz')['source_sha256']==before
    assert unpack(LOCAL/'stdio_before.json.gz')['calls']==132
    assert '2067 passed, 4 skipped, 144 warnings' in (LOCAL/'full_regression.txt').read_text()
    assert '0 errors, 0 warnings' in (LOCAL/'pyright_final.txt').read_text()
    assert 'valid' in (LOCAL/'prompt_contract.txt').read_text()
    for stage in ['A1','B','A2']:
        cost=unpack(LOCAL/('cost_'+stage+'.json.gz'))
        assert cost['source_sha256']==(runtime if stage=='B' else before)
        assert cost['data_unchanged'] and all(len(values)==41 for values in cost['samples'].values())
    preserved={}
    paths=[
        REPO/'docs/validation/v3.8/v382_2026_10_16/manifest.json',
        REPO/'docs/validation/v3.8/v382_read_boundaries_2026_10_17/manifest.json',
        REPO/'docs/validation/v3.8/v382_read_boundaries_2026_10_17/resident_restart/manifest.json',
        ROOT.parent/'20261017_explain_followup/evidence/manifest.json',
        ROOT.parent/'20261017_explain_adjacency/evidence/manifest.json',
    ]
    for manifest in paths:
        data=json.loads(manifest.read_text())
        base=manifest.parent.parent if manifest.is_relative_to(REPO/'local_archive') else manifest.parent
        for name,info in data['files'].items():
            path=base/name
            assert sha(path)==info['sha256'] and path.stat().st_size==info['bytes'],path
        preserved[str(manifest.relative_to(REPO))]=len(data['files'])
    PUBLIC.mkdir()
    for path in sorted(LOCAL.iterdir()):
        if path.suffix=='.txt':
            (PUBLIC/(path.name+'.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
        elif path.suffix in {'.json','.gz'}:
            shutil.copyfile(path,PUBLIC/path.name)
    review=ROOT.parent/'20261017_explain_adjacency/evidence'
    for old,new in [('current','before_adjacent'),('focused_current','before_focused'),('focused_baseline_3323f9c','owner_baseline_focused'),('native','native_before')]:
        path=review/(old+'.json.gz')
        shutil.copyfile(path,PUBLIC/(new+'.json.gz'))
        if old in {'current','focused_current'}:
            assert unpack(path)['source_sha256']==before
    frozen=Path(json.loads((LOCAL/'before_source.json').read_text())['frozen_source'])
    with tarfile.open(PUBLIC/'before_source.tar.gz','w:gz') as archive:
        archive.add(frozen/'sql_safety_executor',arcname='src/sql_safety_executor')
    scripts=[REPO/'scripts/validation/sqlite_plans.py',REPO/'scripts/validation/sqlite_plan_cost.py',
             review/'assess_adjacent_main_matrix.py',review.parent/'scripts/assess_adjacent.py',
             review.parent/'scripts/assess_focused.py',Path(__file__)]
    for path in scripts:
        (PUBLIC/(path.name+'.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
    (PUBLIC/'regression_before.txt.gz').write_bytes(gzip.compress(Path('/tmp/v382-explain-before.txt').read_bytes(),mtime=0))
    wheel=Path('/tmp/v382-explain-wheel/llm_sql_safety_executor_mcp-3.8.2-py3-none-any.whl')
    code="import json,importlib.metadata,sql_safety_executor;print(json.dumps({'package':sql_safety_executor.__file__,'dependencies':{n:importlib.metadata.version(n) for n in ['fastmcp','mcp','sqlglot','SQLAlchemy','pydantic']}}))"
    installed=json.loads(subprocess.check_output(['/tmp/v382-tools/wheel-env/bin/python','-c',code],cwd='/tmp'))
    assert 'site-packages' in installed['package']
    verification=dict(status='source-and-installed-accepted-resident-pending',version='3.8.2',
        regression={'passed':2067,'skipped':4,'warnings':144,'new_tests':101},
        installed_calls={'new_plans':140,'existing_reads':74,'existing_semantics':58,'total':272},
        source_stdio_before=132,source_stdio_after=140,same_input_client_observations_before_and_after=342,
        matrix_after={'successful_plans':292,'protective_refusals':42,'scope_controls':8},
        runtime_resources=len(runtime),runtime_changes=changed,prior_sealed_files_verified=preserved,
        wheel={'name':wheel.name,'sha256':sha(wheel),'bytes':wheel.stat().st_size,'installed':installed},
        scope='No configured database writes. Full private persistent rows unchanged; serving temp/attached total_changes unchanged; harmless restricted UDF calls zero. No new full Luna task or model token claim. Native restart verification still requires maintainer; old native records retain their source attribution. Application records are not full protocol frames.')
    (PUBLIC/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')
    closure={'resources':{'src/sql_safety_executor/'+name:value for name,value in runtime.items()},
        'tests':{'tests/test_explain_followup_v382.py':sha(REPO/'tests/test_explain_followup_v382.py')},
        'scripts':{str(path.relative_to(REPO)):sha(path) for path in scripts},
        'before_resources':before,'scope':'Final runtime resource closure; resident code objects are not introspected.'}
    (PUBLIC/'source_closure.json').write_text(json.dumps(closure,ensure_ascii=False,indent=2)+'\n')
    manifest={'closed_utc':datetime.now(timezone.utc).isoformat(),
        'scope':'Pre-maintainer-restart checkpoint. Append later resident evidence separately; do not replace this status or prior logs.',
        'files':{str(p.relative_to(PUBLIC)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(PUBLIC.iterdir()) if p.is_file()}}
    (PUBLIC/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'files':len(manifest['files']),'runtime_resources':len(runtime),'preserved_files':sum(preserved.values()),'installed_calls':272,'resident':'pending'}))

if __name__=='__main__':
    main()
