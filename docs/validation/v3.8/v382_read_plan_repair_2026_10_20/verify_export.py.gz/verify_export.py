"""Verify this repair against frozen resources, publish once, preserve old seals."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
from urllib.parse import unquote
import zipfile

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
E = BATCH / 'evidence'
PUBLIC = ROOT / 'docs/validation/v3.8/v382_read_plan_repair_2026_10_20'
PACKAGE = ROOT / 'src/sql_safety_executor'
assert not (E / 'summary.json').exists()
assert not (BATCH / 'manifest.json').exists()
assert not (PUBLIC / 'manifest.json').exists()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name):
    path = E / name
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)


before = read('before.json')
after = read('after_resources.json')
current = {str(p.relative_to(PACKAGE)): digest(p) for p in PACKAGE.rglob('*')
           if p.is_file() and p.suffix in {'.py', '.md'}}
assert current == after and len(current) == 77
changed = sorted(k for k in current if before['resources'][k] != current[k])
assert changed == sorted(['core/analysis.py', 'core/managed_sql.py', 'core/policy.py',
                         'core/runtime.py', 'core/schema.py', 'database/base.py',
                         'database/mysql.py', 'database/transport.py',
                         'skills/access.py', 'skills/mutation.py'])
for name in ('pyproject.toml', 'uv.lock',
             'skills/sample-update-order-status/mutation.py',
             'skills/sample-reset-order-to-pending/mutation.py'):
    assert digest(ROOT / name) == before['files'][name], name

old_files = 0
for record in before['previous_seals']:
    manifest = ROOT / record['manifest']
    assert digest(manifest) == record['sha256'], str(manifest)
    files = json.loads(manifest.read_text())['files']
    entries = files.items() if isinstance(files, dict) else ((x['path'], x) for x in files)
    count = 0
    for name, expected in entries:
        path = manifest.parent / name
        assert digest(path) == expected['sha256'], str(path)
        assert path.stat().st_size == expected['bytes'], str(path)
        count += 1
    assert count == record['files_verified']
    old_files += count
assert len(before['previous_seals']) == 31 and old_files == 739

installed = read('installed_resources.json')
assert installed['installed']['resources'] == current
wheel = Path(installed['wheel'])
assert digest(wheel) == installed['wheel_sha256']
with zipfile.ZipFile(wheel) as archive:
    for name, expected in current.items():
        assert hashlib.sha256(archive.read('sql_safety_executor/' + name)).hexdigest() == expected
    metadata = archive.read('llm_sql_safety_executor_mcp-3.8.2.dist-info/METADATA').decode()
    assert (ROOT / 'README.md').read_text().strip() in metadata
assert '3003 passed, 4 skipped' in (E / 'full_pytest.log').read_text()
assert '2 passed, 71 deselected' in (E / 'session_binding_extra.log').read_text()
assert '0 errors, 0 warnings' in (E / 'typecheck_initial.log').read_text()
for name in ('prompt_contract.log', 'installed_prompt.log'):
    assert 'prompt resources and routing guidance valid.' in (E / name).read_text(), name

for name in ('source_stdio.json.gz', 'installed_stdio.json.gz'):
    result = read(name)
    assert result['passed'] and len(result['records']) == 84
    assert len(result['inventories']) == 4 and result['redacted_preview_handles'] == 12
    assert result['resource_sha256'] == current
    refusals = [x for x in result['records'] if x['isError']]
    assert len(refusals) == 4
    assert all(x['tool'] == 'execute_mutation_skill' and
               'rejected before execution' in str(x['content']) for x in refusals)
mysql_wheel = read('installed_mysql_stdio.json.gz')
assert mysql_wheel['passed'] and mysql_wheel['calls'] == 6
assert mysql_wheel['wheel_sha256'] == installed['wheel_sha256']
assert mysql_wheel['installed_runtime_resources'] == current
mysql = read('mysql_functional.json.gz')
assert len(mysql['metadata']) == 5
assert all(x['exact_projection_equal'] for x in mysql['metadata'])
assert len(mysql['physical_sessions']) == 16
assert len(mysql['literal_semantics']) == len(mysql['nonexecuting_plans']) == 32
assert all(x['matches_native_original'] for x in mysql['literal_semantics'])
assert all(x['nonexecuting_plan_succeeds'] for x in mysql['nonexecuting_plans'])
assert mysql['order_rows_sha256_unchanged'] and not mysql['configured_business_or_global_writes']

matrix = read('comment_matrix.json.gz')
previous_matrix = json.loads(gzip.decompress((ROOT / 'local_archive/v382_review/20261020_dialect_comments_not/evidence/after_matrix.json.gz').read_bytes()))
assert matrix['runtime_resources'] == current
assert previous_matrix['runtime_resources'] == before['resources']
assert matrix['records'] == previous_matrix['records'] and len(matrix['records']) == 1513
assert matrix['sqlite_unchanged']
columns = read('metadata_cost.json.gz')
assert columns['all_checks_passed'] and columns['timed_calls'] == 400 and columns['warmup_calls'] == 60
assert columns['runtime_resources'] == {'A': before['resources'], 'B': current}
cycles = read('paired_cost.json.gz')
assert cycles['all_checks_passed'] and cycles['measured_calls'] == 720
assert cycles['warmup_calls'] == 120 and cycles['complete_restored_cycles'] == 140
startup = read('startup_cost.json')
assert len(startup['records']) == 3
for row, expected in zip(startup['records'], (before['resources'], current, before['resources'])):
    assert row['resources'] == expected and not row['database_created']
    assert len(row['durations_ms']) == 80 and row['warmups'] == 8
studies = [read(n) for n in ('read_analysis_study.json.gz', 'read_analysis_complex.json.gz')]
assert sum(len(s['observations']) for s in studies) == 16
for study in studies:
    assert not study['production_reuse_implemented'] and study['runtime_resources'] == current
    for row in study['observations']:
        assert len(row['records']) == 23
        assert sum(x['phase'] == 'timed' for x in row['records']) == 20
        if not row['dependency_inference_cold']:
            assert row['counted_B']['reuse_hits'] == 0

names = subprocess.check_output(['git', 'diff', '--name-only', '--', '*.md'], cwd=ROOT, text=True).splitlines()
names += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', '*.md'], cwd=ROOT, text=True).splitlines()
names += [str(p.relative_to(ROOT)) for p in BATCH.rglob('*.md')]
names += ['local_archive/v382_review/README.md', 'AI_COLLABORATION_GUIDE.md',
          'local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md']
checked = 0
for name in sorted(set(names)):
    path = ROOT / name
    if not path.is_file():
        continue
    for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^\n)]*)\)', path.read_text()):
        target = target.strip().split(' "', 1)[0].strip('<>')
        if not target or re.match(r'[a-zA-Z][a-zA-Z0-9+.-]*:', target):
            continue
        relative = unquote(target.split('#', 1)[0])
        if relative:
            assert (path.parent / relative).exists(), (name, relative)
            checked += 1
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)

# Mutations begin only after all checks; this export refuses to overwrite seals.
(E / 'dist').mkdir(exist_ok=True)
shutil.copy2(wheel, E / 'dist' / wheel.name)
with tarfile.open(E / 'after_runtime.tar.gz', 'w:gz') as archive:
    for name in sorted(current):
        archive.add(PACKAGE / name, arcname='sql_safety_executor/' + name)
references = {}
for path in sorted(E.iterdir()):
    if not path.is_file() or path.suffix not in {'.json', '.gz', '.log'}:
        continue
    name = path.name if path.suffix == '.gz' else path.name + '.gz'
    destination = PUBLIC / name
    assert not destination.exists(), str(destination)
    destination.write_bytes(path.read_bytes() if path.suffix == '.gz' else gzip.compress(path.read_bytes(), mtime=0))
    references[path.name] = {'file': name, 'sha256': digest(destination), 'bytes': destination.stat().st_size}
for path in [*sorted((BATCH / 'scripts').glob('*.py')), ROOT / 'scripts/validation/read_plan_followups.py']:
    destination = PUBLIC / (path.name + '.gz')
    assert not destination.exists(), str(destination)
    destination.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
summary = {
    'verified_utc': datetime.now(timezone.utc).isoformat(),
    'version': '3.8.2', 'status': 'source_package_passed_resident_pending',
    'findings_repaired': ['DRR-2026-124', 'DRR-2026-125'],
    'optimizations_implemented': ['query_startup_first_allow', 'bounded_selected_mysql_columns'],
    'pure_read_request_cache': 'studied_only_not_in_production',
    'changed_runtime_resources': changed, 'matching_source_and_wheel_resources': len(current),
    'full_suite': {'passed': 3003, 'optional_skipped': 4},
    'subsequent_session_binding_tests': 2, 'source_stdio_calls': 84,
    'installed_stdio_calls': 84, 'additional_installed_mysql_calls': 6,
    'mysql': {'catalogs': 5, 'physical_sessions': 16, 'literal_comparisons': 32,
              'nonexecuting_plans': 32, 'orders_unchanged': True},
    'old_matrix_groups_unchanged': 1513,
    'metadata_cost': {'timed_calls': 400, 'warmup_calls': 60,
                      'samples': 'metadata_cost.json.gz'},
    'managed_cost': {'timed_calls': 720, 'warmup_calls': 120, 'restored_cycles': 140,
                     'samples': 'paired_cost.json.gz'},
    'startup_cost': {k: startup[k] for k in ('baseline_median_ms', 'optimized_median_ms', 'delta_percent')},
    'pure_read_study_scenarios': 16, 'new_complete_model_trials': 0,
    'prior_manifests_verified': 31, 'prior_file_records_verified': old_files,
    'frozen_dependency_and_builtin_files_unchanged': True,
    'configured_business_writes': False, 'private_configuration_or_grant_changes': False,
    'wheel_sha256': installed['wheel_sha256'], 'durable_wheel': 'evidence/dist/' + wheel.name,
    'markdown_local_links_verified': checked, 'diff_check_passed': True,
    'evidence': references,
    'limits': 'Source/package evidence, not resident/model/wire acceptance. Positive syntax freedom is paired with restricted-operation refusals. Costs are scoped warm measurements with control/mixed groups retained; direct-handler cache prototype is not deployed. Prior seals/failed attempts remain unchanged; append resident_restart after owner manual restart.'}
for path in (E / 'summary.json', PUBLIC / 'summary.json'):
    path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
for root in (BATCH, PUBLIC):
    files = {}
    for path in sorted(root.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.name == 'manifest.json':
            continue
        files[str(path.relative_to(root))] = {'bytes': path.stat().st_size, 'sha256': digest(path)}
    (root / 'manifest.json').write_text(json.dumps({
        'date': '2026-10-20', 'checkpoint': summary['status'], 'files': files,
        'append_rule': 'Keep this pending checkpoint immutable; add resident_restart after owner restart.'},
        ensure_ascii=False, indent=2) + '\n')
    print(str(root.relative_to(ROOT)), len(files), 'files sealed')
print(json.dumps({k: summary[k] for k in ('status', 'matching_source_and_wheel_resources',
                                        'prior_manifests_verified', 'prior_file_records_verified',
                                        'markdown_local_links_verified')}))
