"""Publish and seal the independent resident supplement once."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote
import zipfile

ROOT = Path(__file__).resolve().parents[5]
LOCAL = Path(__file__).resolve().parents[1]
BATCH = LOCAL.parent
E = LOCAL / 'evidence'
PUBLIC = ROOT / 'docs/validation/v3.8/v382_read_plan_repair_2026_10_20/resident_restart'
assert not (LOCAL / 'manifest.json').exists() and not (PUBLIC / 'manifest.json').exists()
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
summary = json.loads((E / 'summary.json').read_text())
assert summary['all_checks_passed'] and summary['passed'] == summary['total'] == 34
plan = json.loads((E / 'native_plan.json').read_text())
for record in plan['previous_seals']:
    manifest = ROOT / record['manifest']
    assert digest(manifest) == record['sha256']
    files = json.loads(manifest.read_text())['files']
    entries = files.items() if isinstance(files, dict) else ((x['path'], x) for x in files)
    for name, entry in entries:
        path = manifest.parent / name
        assert path.stat().st_size == entry['bytes'] and digest(path) == entry['sha256']
package = ROOT / 'src/sql_safety_executor'
resources = {str(p.relative_to(package)): digest(p) for p in package.rglob('*')
             if p.is_file() and p.suffix in {'.py', '.md'}}
assert resources == plan['runtime_resources'] and len(resources) == 77
parent_summary = json.loads((BATCH / 'evidence/summary.json').read_text())
wheel = BATCH / parent_summary['durable_wheel']
assert digest(wheel) == parent_summary['wheel_sha256']
with zipfile.ZipFile(wheel) as archive:
    assert (ROOT / 'README.md').read_text().strip() in archive.read('llm_sql_safety_executor_mcp-3.8.2.dist-info/METADATA').decode()
names = subprocess.check_output(['git', 'diff', '--name-only', '--', '*.md'], cwd=ROOT, text=True).splitlines()
names += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', '*.md'], cwd=ROOT, text=True).splitlines()
names += [str(p.relative_to(ROOT)) for p in LOCAL.rglob('*.md')]
names += ['AI_COLLABORATION_GUIDE.md', 'local_archive/v382_review/README.md',
          'local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md']
checked = 0
for name in sorted(set(names)):
    path = ROOT / name
    if not path.is_file():
        continue
    for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^\n)]*)\)', path.read_text()):
        target = target.strip().split(' "', 1)[0].strip('<>')
        if not target or re.match(r'[a-zA-Z][a-zA-Z0-9+.-]*:', target):
            continue
        relative = unquote(target.split('#', 1)[0])
        if relative:
            assert (path.parent / relative).exists(), (name, relative)
            checked += 1
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
for path in sorted(E.glob('*.json')):
    if path.name == 'summary.json':
        destination = PUBLIC / path.name
        assert not destination.exists()
        destination.write_bytes(path.read_bytes())
    else:
        destination = PUBLIC / (path.name + '.gz')
        assert not destination.exists()
        destination.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for path in sorted((LOCAL / 'scripts').glob('*.py')):
    destination = PUBLIC / (path.name + '.gz')
    assert not destination.exists()
    destination.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for root in (LOCAL, PUBLIC):
    files = {}
    for path in sorted(root.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path.name == 'manifest.json':
            continue
        files[str(path.relative_to(root))] = {'bytes': path.stat().st_size, 'sha256': digest(path)}
    (root / 'manifest.json').write_text(json.dumps({
        'date': '2026-10-20', 'checkpoint': summary['status'], 'files': files,
        'scope': 'Scoped native restart acceptance only; preserve pending parents and source/package/model attribution.',
        'append_rule': 'Do not overwrite; append a separate dated supplement for subsequent work.'},
        ensure_ascii=False, indent=2) + '\n')
    print(str(root.relative_to(ROOT)), len(files), 'files sealed')
print(json.dumps({'native': '34/34', 'previous_manifests': 33, 'previous_file_records': 840,
                  'matching_runtime_resources': 77, 'markdown_local_links_verified': checked,
                  'diff_check_passed': True}))
