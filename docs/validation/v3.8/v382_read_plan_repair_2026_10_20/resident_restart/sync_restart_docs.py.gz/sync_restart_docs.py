"""One-time synchronization of unsealed entry documents; never edit old seals."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[5]


def replace(name, old, new):
    path = ROOT / name
    value = path.read_text()
    assert value.count(old) == 1, (name, old, value.count(old))
    path.write_text(value.replace(old, new))


replace('docs/validation/v3.8/V3_8_2_READ_PLAN_REPAIR_2026_10_20_ZH.md',
    '本批新代码的原生Host核验待维护者手动重启后单独追加，旧验收与模型任务保持各自归属。',
    '维护者手动重启后，当前Host另完成**34/34限定原生核验**，MySQL完整列投影、月报真值、预览及拒绝符合预期，数据库摘要不变；旧验收与模型任务保持各自归属。')
replace('docs/validation/v3.8/V3_8_2_READ_PLAN_REPAIR_2026_10_20_ZH.md',
    '## 文档、失败与来源',
    '## 重启后的限定原生验收\n\n'
    '维护者重启／重连后，冻结并完成34项：1目录、16读取／非执行计划、3 schema投影、4 Skill发现／详情、1 Query Skill执行、2未确认预览及7预期拒绝，全部符合预期。MySQL compact／full完整16表89列payload与已验证样本相同；月报20行与独立原SQL真值相同。SQLite文件／完整80行订单、MySQL完整60行订单摘要及前后状态快照相同。77项磁盘资源与父检查点／wheel一致，33份先前manifest／840文件记录不变。\n\n'
    '原生未确认写入、未更改模式／配置／grant；两枚句柄落盘前一致脱敏，按300秒自然TTL，不声称撤销或观察到过期。当前普通Skill的发现／预览不冒称临时注释／字面绑定模板的同条件重放；16模式、自定义生命周期及批次边界仍保留源码／安装覆盖。没有新完整模型任务或原生性能A/B，行为不证明内存摘要／cache命中。新验收脚本冻结前的一次样本引用键断言已修正并保留；34个原生检查无失败／重试。\n\n'
    '[独立resident_restart补充](v382_read_plan_repair_2026_10_20/resident_restart/README.md)追加封存，父pending保持原字节。维护者要求后续完成项附“（功能修复）／（速度优化）／（研究验证）”等描述标签，已写入协作指南和交接。\n\n'
    '## 文档、失败与来源')
replace('docs/validation/v3.8/V3_8_2_READ_PLAN_REPAIR_2026_10_20_ZH.md',
    '维护者手动重启后追加resident_restart补充，父检查点保留当时pending。',
    '维护者手动重启后已追加resident_restart补充，父检查点保留当时pending。')
for old, new in [
    ('| DRR-124：读取尾注释 |', '| （功能修复）DRR-124：读取尾注释 |'),
    ('| DRR-125：真实绑定 |', '| （功能修复）DRR-125：真实绑定 |'),
    ('| 受管纯缓存 |', '| （一致性修复）受管纯缓存 |'),
    ('| DRR-126：启动候选短路 |', '| （速度优化）DRR-126：启动候选短路 |'),
    ('| DRR-126：有界列批读 |', '| （速度优化）DRR-126：有界列批读 |'),
    ('| DRR-127：请求内分析复用研究 |', '| （研究验证）DRR-127：请求内分析复用研究 |'),
]:
    replace('docs/validation/v3.8/V3_8_2_READ_PLAN_REPAIR_2026_10_20_ZH.md', old, new)
replace('REFACTORING_LOG.md',
    "Resident acceptance awaits the owner's restart; earlier native/model evidence is not reassigned.",
    'After the owner restart, 34/34 scoped native checks pass: complete MySQL column payloads and a 20-row monthly report match independent truth, two previews remain unconfirmed, and seven refusals hold. SQLite file/full 80-order and MySQL full 60-order digests stay unchanged. Earlier model/native evidence is not reassigned; parent pending seals remain immutable.')
replace('REFACTORING_LOG_ZH.md',
    '原生驻留验收待维护者重启，旧模型／原生范围不挪用。',
    '维护者重启后原生34/34通过：完整MySQL列payload及20行月报符合独立真值，两次预览未确认，7项拒绝保持；SQLite文件／完整80行及MySQL完整60行订单摘要不变。父pending封存不改写，旧模型／原生范围不挪用。')
replace('docs/releases/RELEASE_NOTES_v3_8.md',
    'Resident verification pending owner restart.',
    'After owner restart, 34/34 scoped native checks pass with exact MySQL metadata/monthly-report truth, two unconfirmed previews, seven refusals and unchanged data digests; no new model or native timing claim.')
replace('docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md',
    '源码／安装通过，当前驻留待维护者重启；',
    '源码／安装通过，维护者重启后当前驻留34/34限定检查通过；')
replace('docs/guides/CONFIGURATION_ZH.md',
    'DRR-124／125已完成源码／安装补修，当前驻留核验待维护者重启：',
    'DRR-124／125已完成源码／安装补修，维护者重启后另通过34/34限定原生核验：')
replace('docs/guides/TEST_MCP_CLIENT_GUIDE.md',
    "This batch's resident verification remains pending owner restart;\nthen append separate native evidence instead of rewriting sealed checkpoints.",
    'After the owner restart, 34/34 scoped native checks pass, with exact MySQL\nmetadata/report truth, unconfirmed previews and unchanged data. The separate\n[resident supplement](../validation/v3.8/v382_read_plan_repair_2026_10_20/resident_restart/README.md)\nretains fixture/mode limits and preserves the parent pending seals.')
replace('docs/security/V3_8_SECURITY.md',
    "Source/package checks pass; this batch's resident check awaits owner restart.",
    'Source/package checks pass; after owner restart, 34/34 scoped native checks pass with unchanged data and no confirmed writes. Exact temporary-template/mode cases retain source/package coverage; no new model/native performance claim.')
replace('docs/validation/v3.8/V3_8_2_FINAL_AUDIT_2026_10_20_ZH.md',
    '源码／安装验证通过，原生核验待手动重启。',
    '源码／安装验证通过，随后手动重启的34/34限定原生核验也已完成。')
for filename, zh in [('docs/security/DESIGN_RISK_REGISTER.md', False),
                     ('docs/security/DESIGN_RISK_REGISTER_ZH.md', True)]:
    path = ROOT / filename
    lines = path.read_text().splitlines(keepends=True)
    for index, line in enumerate(lines):
        if any(line.startswith('| DRR-2026-' + str(n) + ' |') for n in (124, 125, 126)):
            if zh:
                line = line.replace('已实现；源码／安装通过，驻留待验', '已实现；限定驻留验收通过')
                line = line.replace('维护者重启后另验驻留。', '维护者重启后34/34限定检查通过，数据摘要不变。')
                line = line.replace('驻留待验。[补修]', '当前已有Skill／预览原生通过，自定义模板保持源码／安装覆盖。[补修]')
            else:
                line = line.replace('Implemented; source/package passed, resident pending', 'Implemented; scoped resident acceptance passed')
                line = line.replace('Owner restart required for resident evidence.', 'Owner restart: 34/34 scoped checks pass with unchanged data.')
                line = line.replace('Resident pending. [Repair]', 'Existing native Skills/previews pass; custom templates keep source/package coverage. [Repair]')
            lines[index] = line
    path.write_text(''.join(lines))
replace('local_archive/v382_review/README.md',
    '[当前尾注释／绑定补修、启动／列批读及请求复用研究](20261020_read_plan_repair/reports/README_ZH.md)（124／125源码／安装修复；两项优化落地；通用请求缓存暂缓，驻留待重启核验）',
    '[当前尾注释／绑定补修、启动／列批读及请求复用研究](20261020_read_plan_repair/resident_restart/reports/README_ZH.md)（124／125与两项优化源码／安装通过，重启后原生34/34；通用请求缓存仅研究，未生产接入）')
replace('local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md',
    '**源码／安装通过，当前驻留待维护者手动重启后核验**',
    '**源码／安装通过，维护者重启后当前驻留34/34限定核验通过**')
replace('local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md',
    '下一步：待维护者重启／重连后，先核验轻量常量与尾注释canary，再核对查询／Skill、MySQL schema及必要预览／拒绝；**未经单独批准不确认配置库写入**。追加独立resident_restart记录，父检查点保留pending。此前31份封存／739文件记录保留原摘要与范围，勿重跑旧seal或依赖失效/tmp路径。',
    '重启后已完成34/34：尾注释／CTE／非执行计划、MySQL完整16表89列payload、20行月报真值、发现／详情、两次未确认预览及7项拒绝均通过；SQLite文件／完整80行订单和MySQL完整60行订单摘要不变。当前无需再重启／安装／导入；**未经单独批准不确认配置库写入**。独立resident_restart已追加，父pending原字节保持；33份先前封存／840文件记录不变。新会话按下一项明确需求继续，不把限定验收扩成全语法／完整模型通过，也勿重跑旧seal或依赖失效/tmp路径。')
replace('local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md',
    '[当前本地批次](../20261020_read_plan_repair/reports/README_ZH.md)、[完整未提交范围commit草案](../20261020_read_plan_repair/drafts/commit-message-complete.txt)。',
    '[当前原生补充](../20261020_read_plan_repair/resident_restart/reports/README_ZH.md)、[完整未提交范围commit草案](../20261020_read_plan_repair/resident_restart/drafts/commit-message-complete.txt)。完成项名称按维护者要求加“（功能修复）／（速度优化）／（研究验证）”等短标签；未生产接入的研究明确标注。')
print('Unsealed current documentation synchronized; old checkpoint files untouched.')
