"""Verify scoped native outcomes, unchanged independent truth and prior seals."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3

from sql_safety_executor import load_config
from sql_safety_executor.database.mysql import MySQLAdapter

ROOT = Path(__file__).resolve().parents[5]
LOCAL = Path(__file__).resolve().parents[1]
BATCH = LOCAL.parent
E = LOCAL / 'evidence'
OUT = E / 'summary.json'
assert not OUT.exists()
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
config = load_config(ROOT / 'config/server.toml')
plan = json.loads((E / 'native_plan.json').read_text())
raw = json.loads((E / 'native_application.json').read_text())
catalog = json.loads((E / 'native_catalog.json').read_text())
samples = json.loads(gzip.decompress((BATCH / 'evidence/metadata_cost.json.gz').read_bytes()))['payload_samples']
checks = []
for index, (record, frozen) in enumerate(zip(raw['records'], plan['checks'], strict=True)):
    assert record['index'] == index and record['id'] == frozen['id']
    assert record['tool'] == frozen['tool'] and record['arguments'] == frozen['arguments']
    response, expected = record['result'], frozen['expected']
    assert not response.get('isError', False), frozen['id']
    payload = response['structuredContent']
    texts = [x['text'] for x in response['content'] if x['type'] == 'text']
    assert len(texts) == 1 and json.loads(texts[0]) == payload, frozen['id']
    if 'connection_id' in frozen['arguments']:
        assert payload['connection_id'] == frozen['arguments']['connection_id']
    if 'error_code' in expected:
        assert payload['success'] is False and payload['error_code'] == expected['error_code'], frozen['id']
    else:
        assert payload['success'] is True, frozen['id']
    if 'connection_ids' in expected:
        assert sorted(x['connection_id'] for x in payload['connections']) == expected['connection_ids']
        assert payload['connection_count'] == len(expected['connection_ids'])
    if 'data' in expected or 'sales_data' in expected:
        assert payload['data'] == expected.get('data', expected.get('sales_data')), frozen['id']
        assert payload['truncated'] is False
    if frozen['tool'] == 'query' and payload['success']:
        assert payload['query'] == frozen['arguments']['sql']
    if expected.get('nonempty_plan'):
        assert payload['data'] and payload['truncated'] is False
    if 'schema_reference' in expected:
        assert payload == samples[expected['schema_reference']], frozen['id']
        assert payload['returned_table_count'] == 16 and payload['total_columns'] == 89
    if 'schema_tables' in expected:
        names = sorted(t['name'] for group in payload['schema_groups'] for t in group['tables'])
        assert names == expected['schema_tables'] and payload['total_columns'] == 14
    if 'skill_names' in expected:
        assert sorted(x['name'] for x in payload['skills']) == expected['skill_names']
        assert all(x['executable'] and x['schema_ready'] and not x['missing_tables']
                   and not x['unverified_tables'] for x in payload['skills'])
    if 'executable' in expected:
        assert payload['skill']['executable'] is expected['executable']
    if 'preview_status' in expected:
        assert frozen['arguments']['confirm'] is False
        assert payload['mode'] == 'preview' and payload['execution_outcome'] == 'not_executed'
        assert payload['preview_token'] == '[REDACTED_PREVIEW_HANDLE]'
        assert isinstance(payload['preview_token_expires_at'], str)
        assert payload['preview']['preview_sql'] == 'UPDATE orders SET status = :new_status WHERE id = :order_id AND status = :expected_status'
        assert payload['preview']['bound_params'] == {'order_id': 1, 'expected_status': 'confirmed', 'new_status': expected['preview_status']}
        assert payload['preview']['affected_rows_estimate'] == 1
    checks.append({'index': index, 'id': frozen['id'], 'passed': True})
assert len(checks) == 34 and raw['redacted_preview_handle_count'] == 2
assert all(not x['arguments'].get('confirm', False) for x in raw['records'])
rich, mysql = 'rich_mutation_sqlite', 'orders_demo_mysql'
state = plan['databases'][rich]
path = Path(config.connections[rich].sqlite_database_path)
assert digest(path) == state['file_sha256']
with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as db:
    db.row_factory = sqlite3.Row
    assert [dict(r) for r in db.execute('SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')] == state['snapshot']
    rows = [tuple(r) for r in db.execute('SELECT * FROM main.orders ORDER BY id')]
    assert len(rows) == state['row_count']
    assert hashlib.sha256(json.dumps(rows, ensure_ascii=False, default=str).encode()).hexdigest() == state['all_order_rows_sha256']
assert digest(path) == state['file_sha256']
adapter = MySQLAdapter(config.connections[mysql])
try:
    assert adapter.connect()
    with adapter._engine.connect() as db:
        rows = [tuple(r) for r in db.exec_driver_sql('SELECT * FROM orders ORDER BY id')]
    state = plan['databases'][mysql]
    assert len(rows) == state['row_count']
    assert hashlib.sha256(json.dumps(rows, ensure_ascii=False, default=str).encode()).hexdigest() == state['all_order_rows_sha256']
finally:
    adapter.close()
verified = 0
for record in plan['previous_seals']:
    manifest = ROOT / record['manifest']
    assert digest(manifest) == record['sha256']
    files = json.loads(manifest.read_text())['files']
    entries = files.items() if isinstance(files, dict) else ((x['path'], x) for x in files)
    for name, entry in entries:
        p = manifest.parent / name
        assert digest(p) == entry['sha256'] and p.stat().st_size == entry['bytes']
        verified += 1
assert verified == 840 and len(plan['previous_seals']) == 33
resources = {str(p.relative_to(ROOT / 'src/sql_safety_executor')): digest(p)
             for p in (ROOT / 'src/sql_safety_executor').rglob('*')
             if p.is_file() and p.suffix in {'.py', '.md'}}
assert resources == plan['runtime_resources'] == json.loads((BATCH / 'evidence/after_resources.json').read_text())
description_hashes = []
for tool in catalog['tools']:
    description = catalog['shared_description_prefix'] + tool['description_suffix']
    assert len(description.encode('utf-16-le')) // 2 == tool['description_characters']
    description_hashes.append({'name': tool['name'], 'sha256': hashlib.sha256(description.encode()).hexdigest()})
summary = {'owner_restart_confirmed': True, 'verified_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'scoped_resident_acceptance_passed', 'passed': 34, 'total': 34,
    'routing_catalog_checks': 1, 'successful_raw_reads_or_plans': 16,
    'schema_projections': 3, 'discovery_detail_checks': 4,
    'query_skill_executions': 1, 'successful_unconfirmed_previews': 2,
    'expected_refusals': 7, 'checks': checks,
    'independent_truth_unchanged': plan['databases'],
    'source_resources_matching_parent_and_wheel': len(resources),
    'source_dependency_private_config_grant_changes': False, 'configured_business_writes': False,
    'prior_manifests_verified': 33, 'prior_file_records_verified': verified,
    'model_visible_tool_description_digests': description_hashes,
    'preview_ttl_seconds': plan['preview_ttl_seconds'],
    'preview_handling': 'Two previews; handles consistently redacted before disk, no confirm. Natural TTL applies, with no active revocation or observed-expiry claim.',
    'limits': [plan['scope'], 'Application results/model-visible metadata are not complete wire frames/notifications or original field-omission evidence.',
               'The plan setup reference-key assertion failed before freezing; corrected verifier key without changing old samples or product. No native check failure/retry.',
               'Current Host uses existing config only; alternate modes, custom commented/binding Skill templates, 199-table boundaries and full disposable write lifecycles retain source/package coverage. No new model/provider-token/native performance comparison.'],
    'all_checks_passed': True}
OUT.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: summary[k] for k in ('status', 'passed', 'total', 'source_resources_matching_parent_and_wheel', 'prior_file_records_verified')}))
