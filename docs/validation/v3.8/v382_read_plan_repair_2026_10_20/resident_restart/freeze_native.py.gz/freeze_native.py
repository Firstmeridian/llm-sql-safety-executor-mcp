"""Freeze scoped Host checks and independent read-only truth after owner restart."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3

from sql_safety_executor import load_config
from sql_safety_executor.database.mysql import MySQLAdapter

ROOT = Path(__file__).resolve().parents[5]
LOCAL = Path(__file__).resolve().parents[1]
BATCH = LOCAL.parent
OUT = LOCAL / 'evidence/native_plan.json'
assert not OUT.exists()
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
config = load_config(ROOT / 'config/server.toml')
assert config.skills.mutation.managed_plan_parser == 'sqlglot'
resources = {str(p.relative_to(ROOT / 'src/sql_safety_executor')): digest(p)
             for p in (ROOT / 'src/sql_safety_executor').rglob('*')
             if p.is_file() and p.suffix in {'.py', '.md'}}
assert resources == json.loads((BATCH / 'evidence/after_resources.json').read_text())
before = json.loads((BATCH / 'evidence/before.json').read_text())
manifests = [ROOT / x['manifest'] for x in before['previous_seals']]
manifests += [BATCH / 'manifest.json', ROOT / 'docs/validation/v3.8/v382_read_plan_repair_2026_10_20/manifest.json']
seals = []
for manifest in manifests:
    files = json.loads(manifest.read_text())['files']
    entries = files.items() if isinstance(files, dict) else ((x['path'], x) for x in files)
    for name, entry in entries:
        p = manifest.parent / name
        assert digest(p) == entry['sha256'] and p.stat().st_size == entry['bytes']
    seals.append({'manifest': str(manifest.relative_to(ROOT)), 'sha256': digest(manifest), 'file_count': len(files)})
assert len(seals) == 33 and sum(x['file_count'] for x in seals) == 840
rich, mysql = 'rich_mutation_sqlite', 'orders_demo_mysql'
update, reset = 'sample-update-order-status', 'sample-reset-order-to-pending'
query_skill = 'sample-monthly-sales-report'
path = Path(config.connections[rich].sqlite_database_path)
sqlite_state = {'file_sha256': digest(path)}
with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as db:
    db.row_factory = sqlite3.Row
    sqlite_state['snapshot'] = [dict(r) for r in db.execute('SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')]
    assert sqlite_state['snapshot'][0] == {'id': 1, 'status': 'confirmed'}
    rows = [tuple(r) for r in db.execute('SELECT * FROM main.orders ORDER BY id')]
    sqlite_state['row_count'] = len(rows)
    sqlite_state['all_order_rows_sha256'] = hashlib.sha256(json.dumps(rows, ensure_ascii=False, default=str).encode()).hexdigest()
assert digest(path) == sqlite_state['file_sha256']
adapter = MySQLAdapter(config.connections[mysql])
try:
    assert adapter.connect()
    context = adapter.resolve_analysis_context()
    with adapter._engine.connect() as db:
        rows = [tuple(r) for r in db.exec_driver_sql('SELECT * FROM orders ORDER BY id')]
        snapshot = [dict(r._mapping) for r in db.exec_driver_sql('SELECT id,status FROM orders ORDER BY id')]
        mysql_state = {'row_count': len(rows), 'snapshot': snapshot,
            'all_order_rows_sha256': hashlib.sha256(json.dumps(rows, ensure_ascii=False, default=str).encode()).hexdigest(),
            'separate_truth_adapter_sql_modes': sorted(context.sql_modes)}
        year, month = tuple(db.exec_driver_sql('SELECT YEAR(order_date), MONTH(order_date) FROM orders ORDER BY id LIMIT 1').one())
        sales = [dict(r._mapping) for r in db.exec_driver_sql(
            'SELECT DATE(order_date) AS date, COUNT(*) AS order_count, SUM(amount) AS revenue, '
            'ROUND(AVG(amount),2) AS avg_order_value FROM orders '
            'WHERE YEAR(order_date)=%s AND MONTH(order_date)=%s '
            'GROUP BY DATE(order_date) ORDER BY date ASC', (year, month))]
finally:
    adapter.close()
sales = json.loads(json.dumps(sales, default=str))
assert sales
checks = [{'id': 'routing_catalog', 'tool': 'list_connections', 'arguments': {},
           'expected': {'connection_ids': sorted(config.connections)}}]


def add(label, tool, alias, expected, **arguments):
    checks.append({'id': label, 'tool': tool, 'arguments': {'connection_id': alias, **arguments}, 'expected': expected})


for alias, label in [(rich, 'sqlite'), (mysql, 'mysql')]:
    add(label + '_canary', 'query', alias, {'data': [{'n': 7}]}, sql='SELECT 7 AS n')
add('sqlite_snapshot_before', 'query', rich, {'data': sqlite_state['snapshot']}, sql='SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')
add('mysql_snapshot_before', 'query', mysql, {'data': snapshot}, sql='SELECT id,status FROM orders ORDER BY id')
for label, sql, data in [
    ('sqlite_tail', 'SELECT 7 AS n; /* tail */', [{'n': 7}]),
    ('sqlite_dash_tail', 'SELECT 7 AS n; -- tail\n', [{'n': 7}]),
    ('sqlite_literal_colon', "SELECT ':business' AS marker; /* :comment */", [{'marker': ':business'}]),
    ('sqlite_cte_tail', 'WITH chosen(n) AS (SELECT 7) SELECT n FROM chosen; /* tail */', [{'n': 7}]),
]:
    add(label, 'query', rich, {'data': data}, sql=sql)
add('sqlite_plan_tail', 'query', rich, {'nonempty_plan': True}, sql="EXPLAIN UPDATE main.orders SET status='pending' WHERE id=1; /* tail */")
for label, sql, data in [
    ('mysql_tail', 'SELECT 7 AS n; /* tail */', [{'n': 7}]),
    ('mysql_cte_tail', 'WITH chosen AS (SELECT 7 AS n) SELECT n FROM chosen; /* tail */', [{'n': 7}]),
    ('mysql_hint_tail', 'SELECT /*+ NO_ICP(orders) */ COUNT(*) AS n FROM orders; /* tail */', [{'n': mysql_state['row_count']}]),
    ('mysql_trailing_hint', 'SELECT 7 AS n; /*+ QB_NAME(qb) */', [{'n': 7}]),
    ('mysql_literal_colon', "SELECT ':business' AS marker; /* :comment */", [{'marker': ':business'}]),
]:
    add(label, 'query', mysql, {'data': data}, sql=sql)
samples = json.loads(gzip.decompress((BATCH / 'evidence/metadata_cost.json.gz').read_bytes()))['payload_samples']
for level in ('compact', 'full'):
    add('mysql_schema_' + level, 'get_full_schema', 'sakila_mysql', {'schema_reference': 'auto/mysql_' + level}, detail_level=level)
    assert 'auto/mysql_' + level in samples
add('sqlite_schema', 'get_full_schema', rich, {'schema_tables': ['customers', 'order_items', 'orders']}, detail_level='compact')
add('managed_discovery', 'list_skills', rich, {'skill_names': sorted((update, reset))}, search=update, detail_level='full')
add('managed_detail', 'get_skill_detail', rich, {'executable': True}, skill_name=update, detail_level='execution')
add('update_preview', 'execute_mutation_skill', rich, {'preview_status': 'shipped'}, skill_name=update, params={'order_id': 1, 'new_status': 'shipped'}, confirm=False)
add('reset_preview', 'execute_mutation_skill', rich, {'preview_status': 'pending'}, skill_name=reset, params={'order_id': 1, 'expected_status': 'confirmed'}, confirm=False)
add('query_discovery', 'list_skills', mysql, {'skill_names': [query_skill]}, search=query_skill, detail_level='full')
add('query_detail', 'get_skill_detail', mysql, {'executable': True}, skill_name=query_skill, detail_level='execution')
add('query_execution', 'execute_query_skill', mysql, {'sales_data': sales}, skill_name=query_skill, params={'year': year, 'month': month})
for label, alias, sql, code in [
    ('mysql_function_denied', mysql, 'SELECT /*+ NO_ICP(orders) */ SLEEP(0) AS n; /* tail */', 'expensive_function_denied'),
    ('mysql_state_hint_denied', mysql, "SELECT /*+ SET_VAR(sql_mode='ANSI_QUOTES') */ 7 AS n; /* tail */", 'unsafe_comment'),
    ('mysql_multiple_denied', mysql, 'SELECT 7 AS n; SELECT 8 AS n; /* tail */', 'multiple_statements'),
    ('sqlite_multiple_denied', rich, 'SELECT 7 AS n; SELECT 8 AS n; /* tail */', 'multiple_statements'),
    ('sqlite_relation_denied', rich, 'SELECT * FROM secret LIMIT 1; /* tail */', 'table_access_denied'),
    ('sqlite_function_denied', rich, 'SELECT SLEEP(0) AS n; /* tail */', 'expensive_function_denied'),
    ('sqlite_write_denied', rich, "UPDATE main.orders SET status='pending' WHERE id=1; /* tail */", 'read_only_required'),
]:
    add(label, 'query', alias, {'error_code': code}, sql=sql)
add('mysql_snapshot_after', 'query', mysql, {'data': snapshot}, sql='SELECT id,status FROM orders ORDER BY id')
add('sqlite_snapshot_after', 'query', rich, {'data': sqlite_state['snapshot']}, sql='SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')
assert len(checks) == 34 and all(not c['arguments'].get('confirm', False) for c in checks)
plan = {'owner_restart_confirmed': True, 'frozen_utc': datetime.now(timezone.utc).isoformat(),
    'checks': checks, 'databases': {rich: sqlite_state, mysql: mysql_state},
    'runtime_resources': resources, 'previous_seals': seals,
    'preview_ttl_seconds': config.skills.mutation.preview.ttl_seconds,
    'scope': 'Current Codex Host; fixed inputs after owner restart. No configured business write, confirmation, new grant/config or mode edits. Standard existing Query Skill/previews are smoke tests, not native replay of temporary literal-bind/commented templates; exact lifecycle cases retain source/package coverage. No new model/usage/native speed or in-memory source/cache-hit claim. Catalog call precedes freeze and does not inspect DB.'}
OUT.write_text(json.dumps(plan, ensure_ascii=False, indent=2, default=str) + '\n')
print(json.dumps({'planned_native_calls': len(checks), 'previous_manifests': len(seals),
                  'previous_file_records': 840, 'runtime_resources': len(resources)}))
