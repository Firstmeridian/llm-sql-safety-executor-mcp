"""Final-wheel MySQL metadata projection and trailing read, both Client modes."""
import asyncio
import gzip
import json
import os
from pathlib import Path
import tempfile

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
OUT = BATCH / 'evidence/installed_mysql_stdio.json.gz'


async def run():
    from sql_safety_executor.mcp.bootstrap import prepare_framework
    prepare_framework()
    from fastmcp import Client
    from fastmcp.client.transports import StdioTransport
    assert not OUT.exists()
    installed = json.loads((BATCH / 'evidence/installed_resources.json').read_text())
    cost = json.loads(gzip.decompress((BATCH / 'evidence/metadata_cost.json.gz').read_bytes()))
    records = []
    for mode in ('auto', 'legacy'):
        with tempfile.TemporaryDirectory(prefix='installed-mysql-stdio-') as temporary:
            environment = os.environ.copy()
            environment.pop('PYTHONPATH', None)
            transport = StdioTransport(command=installed['python'],
                args=['-m', 'sql_safety_executor', 'serve', '--config', str(ROOT / 'config/server.toml')],
                cwd=temporary, env=environment)
            async with Client(transport, mode=mode) as client:
                for level in ('compact', 'full'):
                    arguments = {'connection_id': 'sakila_mysql', 'detail_level': level}
                    response = await client.call_tool('get_full_schema', arguments)
                    payload = response.structured_content
                    assert not response.is_error and payload == cost['payload_samples'][mode + '/mysql_' + level]
                    records.append({'mode': mode, 'protocol': client.protocol_version, 'tool': 'get_full_schema',
                                    'arguments': arguments, 'isError': response.is_error, 'structured': payload})
                arguments = {'connection_id': 'orders_demo_mysql', 'sql': 'SELECT 7 AS n; /* tail */'}
                response = await client.call_tool('query', arguments)
                payload = response.structured_content
                assert not response.is_error and payload['success'] and payload['data'] == [{'n': 7}]
                records.append({'mode': mode, 'protocol': client.protocol_version, 'tool': 'query',
                                'arguments': arguments, 'isError': response.is_error, 'structured': payload})
    return {'records': records, 'calls': len(records), 'passed': True,
            'wheel_sha256': installed['wheel_sha256'], 'installed_runtime_resources': installed['installed']['resources'],
            'scope': 'Six final-wheel real child-stdio MySQL calls, two Client modes. Full metadata payload equals matched source/baseline samples. No configured business writes or new native-Host/complete-model acceptance; application observations only.'}


result = asyncio.run(run())
OUT.write_bytes(gzip.compress(json.dumps(result, ensure_ascii=False, indent=2).encode(), mtime=0))
print(json.dumps({'calls': result['calls'], 'passed': True}))
