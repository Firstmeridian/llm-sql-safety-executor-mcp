"""Actual MySQL metadata batches and mode-bound literal/placeholder semantics."""
from dataclasses import replace
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path

from sqlalchemy import event
from sql_safety_executor import load_config
from sql_safety_executor.core.managed_sql import check_managed_sql
from sql_safety_executor.database.mysql import MySQLAdapter
from sql_safety_executor.database.relations import RelationReference
from sql_safety_executor.database.semantics import DialectContext
from sql_safety_executor.database.transport import named_parameters, statement_text

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parents[1] / 'evidence/mysql_functional.json.gz'
assert not OUT.exists()
config = load_config(ROOT / 'config/server.toml')
metadata = []
for alias in ('orders_demo_mysql', 'sakila_mysql', 'world_demo_mysql', 'us_equities_mysql', 'exoplanets_mysql'):
    adapter = MySQLAdapter(config.connections[alias])
    events = []
    try:
        assert adapter.connect()
        adapter.resolve_analysis_context()
        tables = [row['table_name'] for row in adapter.get_table_directory() if config.connections[alias].policy.allows_metadata_relation(RelationReference(row['table_name'], adapter.metadata_schema))]
        def observe(conn, cursor, sql, params, context, many):
            events.append('columns' if 'INFORMATION_SCHEMA.COLUMNS' in sql else 'timeout' if sql.startswith('SET SESSION MAX_EXECUTION_TIME') else 'other')
        event.listen(adapter._engine, 'before_cursor_execute', observe)
        expected = {name: adapter.get_columns(name) for name in tables}
        before = {key: events.count(key) for key in set(events)}
        events.clear()
        actual = adapter.get_columns_batch(tables)
        after = {key: events.count(key) for key in set(events)}
        assert actual == expected
        assert after.get('columns', 0) == (len(tables) + 198) // 199
        metadata.append({'connection_id': alias, 'tables': len(tables), 'columns': sum(len(columns) for columns in actual.values()),
                         'counted_scalar': before, 'counted_batch': after, 'exact_projection_equal': True,
                         'projection_sha256': hashlib.sha256(json.dumps(actual, ensure_ascii=False, default=str, sort_keys=True).encode()).hexdigest()})
    finally:
        adapter.close()

names = ('ANSI_QUOTES', 'NO_BACKSLASH_ESCAPES', 'PIPES_AS_CONCAT', 'HIGH_NOT_PRECEDENCE')
semantics, plans, modes_checked = [], [], []
order_digest = None
for bits in product((False, True), repeat=4):
    modes = ('STRICT_TRANS_TABLES', 'NO_ENGINE_SUBSTITUTION', *(name for name, enabled in zip(names, bits) if enabled))
    adapter = MySQLAdapter(replace(config.connections['orders_demo_mysql'], mysql_sql_mode=modes))
    try:
        assert adapter.connect()
        context = adapter.resolve_analysis_context()
        with adapter._engine.connect() as db:
            assert frozenset(db.exec_driver_sql('SELECT @@SESSION.sql_mode').scalar_one().split(',')) == frozenset(modes)
            modes_checked.append(sorted(context.sql_modes))
            rows = [tuple(row) for row in db.exec_driver_sql('SELECT * FROM orders ORDER BY id').fetchall()]
            digest = hashlib.sha256(json.dumps(rows, ensure_ascii=False, default=str).encode()).hexdigest()
            if order_digest is None:
                order_digest = digest
            assert digest == order_digest
            expressions = [
                ("SELECT ':business' AS marker, :n AS n /* :comment */; /* tail */", "SELECT ':business' AS marker, 7 AS n /* :comment */; /* tail */"),
                ("SELECT '\\:business' AS `:column`, :n AS n /* :comment */", "SELECT '\\:business' AS `:column`, 7 AS n /* :comment */"),
            ]
            for sql, reference in expressions:
                assert named_parameters(sql, context) == frozenset({'n'})
                actual = list(db.execute(statement_text(sql, context), {'n': 7}).fetchall())
                expected = list(db.exec_driver_sql(reference).fetchall())
                assert actual == expected
                semantics.append({'modes': sorted(context.sql_modes), 'sql': sql, 'reference': reference,
                                  'rows': [tuple(row) for row in actual], 'matches_native_original': True})
            statements = [
                ("UPDATE /* :comment */ orders SET status=':business' WHERE id=:order_id; /* tail */", {'order_id': 1}),
                ("UPDATE orders SET status='\\' OR :ghost -- '", {'ghost': 7} if bits[1] else {}),
            ]
            for sql, params in statements:
                assert check_managed_sql(sql, context, 'sqlglot', frozenset(params)).allowed
                assert named_parameters(sql, context) == frozenset(params)
                assert db.execute(statement_text('EXPLAIN ' + sql, context), params).fetchall()
                plans.append({'modes': sorted(context.sql_modes), 'sql': sql, 'actual_bind_names': sorted(params), 'nonexecuting_plan_succeeds': True})
            after = [tuple(row) for row in db.exec_driver_sql('SELECT * FROM orders ORDER BY id').fetchall()]
            assert rows == after
    finally:
        adapter.close()
result = {'metadata': metadata, 'physical_sessions': modes_checked, 'literal_semantics': semantics,
          'nonexecuting_plans': plans, 'order_rows_sha256_unchanged': order_digest,
          'configured_business_or_global_writes': False,
          'scope': 'Five actual configured databases, exact scalar/batch column projection and counted SQL. Sixteen independent test-adapter physical mode sets, 32 original literal/placeholder comparisons and 32 non-executing managed plans. Only private session initialization changes modes, never globals/private config/business data. Generated AST SQL is not executed; only original SQL under EXPLAIN for DML.'}
OUT.write_bytes(gzip.compress(json.dumps(result, ensure_ascii=False, default=str, indent=2).encode(), mtime=0))
print(json.dumps({'metadata_connections': len(metadata), 'actual_mode_sessions': len(modes_checked),
                  'literal_semantics': len(semantics), 'nonexecuting_plans': len(plans), 'orders_unchanged': True}))
