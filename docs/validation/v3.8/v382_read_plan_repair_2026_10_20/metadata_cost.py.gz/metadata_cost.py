"""Matched current/baseline child-stdio metadata calls; no business writes."""
import asyncio
from contextlib import AsyncExitStack
import gzip
import hashlib
import json
import os
from pathlib import Path
from statistics import median
import sys
import tarfile
import tempfile
from time import perf_counter_ns

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
OUT = BATCH / 'evidence/metadata_cost.json.gz'
CASES = [('mysql_compact', 'get_full_schema', {'connection_id': 'sakila_mysql', 'detail_level': 'compact'}),
         ('mysql_full', 'get_full_schema', {'connection_id': 'sakila_mysql', 'detail_level': 'full'}),
         ('sqlite_compact', 'get_full_schema', {'connection_id': 'rich_mutation_sqlite', 'detail_level': 'compact'}),
         ('sqlite_full', 'get_full_schema', {'connection_id': 'rich_mutation_sqlite', 'detail_level': 'full'}),
         ('mysql_directory_control', 'list_tables', {'connection_id': 'sakila_mysql'})]


async def run():
    from sql_safety_executor.mcp.bootstrap import prepare_framework
    prepare_framework()
    from fastmcp import Client
    from fastmcp.client.transports import StdioTransport
    assert not OUT.exists()
    snapshots = {'A': json.loads((BATCH / 'evidence/before.json').read_text())['resources'],
                 'B': json.loads((BATCH / 'evidence/after_resources.json').read_text())}
    runs = []
    samples = {}
    with tempfile.TemporaryDirectory(prefix='read-plan-baseline-') as temporary:
        baseline = Path(temporary)
        with tarfile.open(BATCH / 'evidence/before_runtime.tar.gz') as archive:
            archive.extractall(baseline, filter='data')
        for mode in ('auto', 'legacy'):
            with tempfile.TemporaryDirectory(prefix='read-plan-launchers-') as launchers:
                async with AsyncExitStack() as sessions:
                    clients = {}
                    protocols = {}
                    for variant, source in [('A', baseline), ('B', ROOT / 'src')]:
                        folder = Path(launchers) / variant
                        folder.mkdir()
                        launcher = folder / 'launch.py'
                        launcher.write_text('import sys,json,hashlib\nfrom pathlib import Path\nsys.path.insert(0,'+repr(str(source))+')\n'
                            'import sql_safety_executor\np=Path(sql_safety_executor.__file__).resolve().parent\n'
                            'assert p==Path('+repr(str(source))+')/"sql_safety_executor"\n'
                            'Path("runtime.json").write_text(json.dumps({str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob("*") if f.is_file() and f.suffix in {".py",".md"}}))\n'
                            'from sql_safety_executor import create_server,load_config\ncreate_server(load_config('+repr(str(ROOT / 'config/server.toml'))+')).run(transport="stdio",show_banner=False)\n')
                        environment = {**os.environ, 'PYTHONPATH': str(source)}
                        transport = StdioTransport(command=sys.executable, args=[str(launcher)], cwd=str(folder), env=environment)
                        clients[variant] = await sessions.enter_async_context(Client(transport, mode=mode))
                        protocols[variant] = clients[variant].protocol_version
                        assert json.loads((folder / 'runtime.json').read_text()) == snapshots[variant]
                    for label, tool, arguments in CASES:
                        records = []
                        reference = None
                        for index in range(23):
                            order = ('A', 'B') if index % 2 == 0 else ('B', 'A')
                            pair = {'phase': 'warmup' if index < 3 else 'timed', 'order': order}
                            for variant in order:
                                start = perf_counter_ns()
                                response = await clients[variant].call_tool(tool, arguments, raise_on_error=False)
                                elapsed = (perf_counter_ns() - start) / 1e6
                                payload = response.structured_content
                                assert not response.is_error and payload['success'], (label, variant, payload)
                                if reference is None:
                                    reference = payload
                                    samples[mode + '/' + label] = payload
                                assert payload == reference, (label, variant, 'payload changed')
                                pair[variant + '_ms'] = elapsed
                            records.append(pair)
                        timed = [pair for pair in records if pair['phase'] == 'timed']
                        runs.append({'mode': mode, 'protocols': protocols, 'case': label,
                            'tool': tool, 'arguments': arguments, 'records': records,
                            'payload_sha256': hashlib.sha256(json.dumps(reference, ensure_ascii=False, sort_keys=True).encode()).hexdigest(),
                            'A_median_ms': median(pair['A_ms'] for pair in timed),
                            'B_median_ms': median(pair['B_ms'] for pair in timed),
                            'paired_relative_median_percent': median((pair['B_ms']/pair['A_ms']-1)*100 for pair in timed),
                            'pairs_faster': sum(pair['B_ms'] < pair['A_ms'] for pair in timed)})
    return {'runtime_resources': snapshots, 'runs': runs, 'payload_samples': samples,
            'timed_calls': 400, 'warmup_calls': 60, 'all_checks_passed': True,
            'scope': 'Alternating A/B and B/A serial calls to two persistent source-verified child servers per protocol, same current config/test fixtures. Twenty timed/three warmup pairs per case. End-to-end call_tool metadata costs only; not cold startup, complete-model/provider cost or configured business writes. Payloads compared in full; source versions are actual pre-repair archive/current code, not HEAD.'}


result = asyncio.run(run())
OUT.write_bytes(gzip.compress(json.dumps(result, ensure_ascii=False, indent=2).encode(), mtime=0))
print(json.dumps({'runs': [{key: value for key, value in row.items() if key not in {'records','arguments','payload_sha256'}} for row in result['runs']], 'timed_calls': result['timed_calls']}, ensure_ascii=False))
