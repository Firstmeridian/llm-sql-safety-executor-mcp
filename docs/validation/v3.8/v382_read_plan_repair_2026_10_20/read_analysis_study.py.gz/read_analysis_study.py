"""Measure operation-local pure analysis reuse; no production cache is added."""
import asyncio
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
from statistics import median
import sqlite3
import sys
import tempfile
from time import perf_counter_ns

from sql_safety_executor import create_server, load_config
from sql_safety_executor.core import analysis as analysis_module
from sql_safety_executor.core.policy import _prepare_sql_read
from sql_safety_executor.core.queries import query
from sql_safety_executor.core.types import NullContext
from sql_safety_executor.database.models import ConnectionPolicy
from sql_safety_executor.database.semantics import DialectContext
from sql_safety_executor.skills.tools import execute_query_skill, get_skill_detail, list_skills

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parents[1] / 'evidence/read_analysis_study.json.gz'
assert not OUT.exists()
original = analysis_module.analyze_sql
scope = None


def observe(sql, context, *, view_definition=False):
    if scope is None:
        return original(sql, context, view_definition=view_definition)
    key = (sql, context, view_definition)
    scope['calls'] += 1
    scope['keys'][key] += 1
    if scope['reuse'] and key in scope['cache']:
        scope['hits'] += 1
        return scope['cache'][key]
    result = original(sql, context, view_definition=view_definition)
    scope['underlying'] += 1
    if scope['reuse']:
        scope['cache'][key] = result
    return result


def new_scope(reuse):
    return {'reuse': reuse, 'calls': 0, 'underlying': 0, 'hits': 0, 'keys': Counter(), 'cache': {}}


async def run():
    global scope
    patched = []
    for module_name, module in list(sys.modules.items()):
        if module_name.startswith('sql_safety_executor.') and getattr(module, 'analyze_sql', None) is original:
            patched.append(module)
            module.analyze_sql = observe
    observations = []
    try:
        for number in (1, 20):
            with tempfile.TemporaryDirectory(prefix='read-analysis-study-') as temporary:
                root = Path(temporary)
                with sqlite3.connect(root / 'fixture.sqlite') as db:
                    db.executescript('CREATE TABLE orders(n);INSERT INTO orders VALUES(7);')
                before = hashlib.sha256((root / 'fixture.sqlite').read_bytes()).hexdigest()
                for index in range(number):
                    name = f'query-{index:02}'
                    directory = root / 'skills' / name
                    directory.mkdir(parents=True)
                    (directory / 'skill_def.md').write_text('---\nname: '+name+'\ntype: query\nsource: query.sql\nrisk: low\ndescription: Analysis reuse study\ndatabases: [sqlite]\ntables: [main.orders]\nparams: {}\n---\n')
                    (directory / 'query.sql').write_text(f'SELECT n FROM main.orders WHERE n>=0 /* skill_{index:02} */')
                (root / 'server.toml').write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="fixture"\n')
                (root / 'connections.toml').write_text('schema_version=1\n[connections.fixture]\ntype="sqlite"\nsqlite.path="fixture.sqlite"\nread.mode="allowlist"\nread.tables=["orders"]\n')
                (root / 'skills.toml').write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=true\n[skills.audit]\npath="audit.jsonl"\nqueries=false\n')
                server = create_server(load_config(root / 'server.toml'))
                runtime = server.gateway_runtime
                context = NullContext()
                try:
                    for stage, cold in [('discovery', True), ('discovery', False), ('detail', True),
                                        ('detail', False), ('execute', True), ('execute', False), ('raw', False)]:
                        async def call():
                            if stage == 'discovery':
                                return await list_skills(runtime, context, detail_level='full', connection_id='fixture')
                            if stage == 'detail':
                                return await get_skill_detail(runtime, 'query-00', context, connection_id='fixture')
                            if stage == 'execute':
                                return await execute_query_skill(runtime, 'query-00', {}, context, connection_id='fixture')
                            return await query(runtime, 'SELECT n FROM main.orders', context, 'fixture')

                        # Prime DB/session/inference outside timing. Cold here
                        # means empty dependency inference, not a cold process.
                        await call()
                        records = []
                        frozen_payload = None
                        for pair in range(23):
                            labels = ('A', 'B') if pair % 2 == 0 else ('B', 'A')
                            row = {'phase': 'warmup' if pair < 3 else 'timed', 'order': labels}
                            for label in labels:
                                if cold:
                                    for meta in runtime.catalog.get_skills_cache().values():
                                        meta._inferred_tables.clear()
                                scope = new_scope(label == 'B')
                                try:
                                    start = perf_counter_ns()
                                    result = await call()
                                    elapsed = (perf_counter_ns() - start) / 1e6
                                    payload = result.structured_content
                                    if frozen_payload is None:
                                        frozen_payload = payload
                                    assert payload == frozen_payload
                                    row[label] = {'ms': elapsed, 'analysis_calls': scope['calls'],
                                                  'underlying_analyses': scope['underlying'],
                                                  'reuse_hits': scope['hits'], 'distinct_keys': len(scope['keys'])}
                                finally:
                                    scope = None
                            records.append(row)
                        timed = [row for row in records if row['phase'] == 'timed']
                        observations.append({'query_skills': number, 'stage': stage, 'dependency_inference_cold': cold,
                            'records': records, 'A_median_ms': median(row['A']['ms'] for row in timed),
                            'B_median_ms': median(row['B']['ms'] for row in timed),
                            'paired_relative_median_percent': median((row['B']['ms'] / row['A']['ms'] - 1) * 100 for row in timed),
                            'pairs_faster': sum(row['B']['ms'] < row['A']['ms'] for row in timed),
                            'counted_A': {key: timed[0]['A'][key] for key in ('analysis_calls','underlying_analyses','reuse_hits','distinct_keys')},
                            'counted_B': {key: timed[0]['B'][key] for key in ('analysis_calls','underlying_analyses','reuse_hits','distinct_keys')}})
                    # A reused pure result never reuses grant decisions; mode
                    # and view-definition role are separate immutable keys.
                    scope = new_scope(True)
                    allowed = ConnectionPolicy(allowed_tables=frozenset({'orders'}))
                    denied = ConnectionPolicy(allowed_tables=frozenset({'secret'}))
                    assert _prepare_sql_read(None, 'SELECT n FROM orders', allowed).decision.allowed
                    assert _prepare_sql_read(None, 'SELECT n FROM orders', denied).decision.error_code == 'table_access_denied'
                    assert scope['hits'] == 1
                    observe('SELECT 7', DialectContext('mysql'))
                    observe('SELECT 7', DialectContext('mysql', frozenset({'ANSI_QUOTES'})))
                    assert scope['hits'] == 1
                    scope = None
                finally:
                    runtime.close()
                assert hashlib.sha256((root / 'fixture.sqlite').read_bytes()).hexdigest() == before
    finally:
        scope = None
        for module in patched:
            module.analyze_sql = original
    package = ROOT / 'src/sql_safety_executor'
    return {'production_reuse_implemented': False, 'observations': observations,
            'patched_instrumentation_modules': [module.__name__ for module in patched],
            'runtime_resources': {str(path.relative_to(package)): hashlib.sha256(path.read_bytes()).hexdigest()
                                  for path in package.rglob('*') if path.is_file() and path.suffix in {'.py','.md'}},
            'scope': 'Operation-local prototype dictionary, pure immutable SQLAnalysis only; no file/runtime implementation change. Serial direct tool handlers with real temporary SQLite, not Client/stdio/Host/model timings. Twenty balanced timed pairs and three warmup pairs per stage; inference-cold and warm separated, no cold-process claim. Clear the prototype every operation and retain live grants/catalog/authorizer. No production concurrency/lifecycle guarantee is inferred.'}


result = asyncio.run(run())
OUT.write_bytes(gzip.compress(json.dumps(result, ensure_ascii=False, indent=2).encode(), mtime=0))
print(json.dumps({'scenarios': len(result['observations']), 'production_reuse_implemented': False,
                  'results': [{key: value for key, value in row.items() if key != 'records'} for row in result['observations']]}, ensure_ascii=False))
