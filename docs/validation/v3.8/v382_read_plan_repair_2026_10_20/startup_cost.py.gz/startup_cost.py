"""Warm GatewayRuntime initialization/close costs, distinct from cold CLI import."""
import gzip
import hashlib
import json
import logging
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import tarfile
import tempfile
import time

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
OUT = BATCH / 'evidence/startup_cost.json'

if len(sys.argv) > 1 and sys.argv[1] == '--child':
    sys.path.insert(0, sys.argv[2])
    from sql_safety_executor import load_config
    from sql_safety_executor.core.runtime import GatewayRuntime
    from sql_safety_executor.core.managed_sql import managed_plan_contexts
    import sql_safety_executor
    logging.disable(logging.CRITICAL)
    package = Path(sql_safety_executor.__file__).resolve().parent
    assert package == Path(sys.argv[2]) / 'sql_safety_executor'
    config = load_config(sys.argv[3])
    durations = []
    for index in range(-8, 80):
        start = time.perf_counter_ns()
        runtime = GatewayRuntime(config)
        assert len(runtime.catalog.get_skills_cache()) == 22
        runtime.close()
        duration = (time.perf_counter_ns() - start) / 1e6
        if index >= 0:
            durations.append(duration)
    assert not Path(config.connections['fixture'].sqlite_database_path).exists()
    print(json.dumps({'durations_ms': durations, 'median_ms': statistics.median(durations),
                      'warmups': 8, 'startup_contexts': len(managed_plan_contexts()),
                      'database_created': False,
                      'resources': {str(p.relative_to(package)): hashlib.sha256(p.read_bytes()).hexdigest()
                                    for p in package.rglob('*') if p.is_file() and p.suffix in {'.py', '.md'}}}))
else:
    assert not OUT.exists()
    snapshots = {'A': json.loads((BATCH / 'evidence/before.json').read_text())['resources'],
                 'B': json.loads((BATCH / 'evidence/after_resources.json').read_text())}
    records = []
    with tempfile.TemporaryDirectory(prefix='comment-startup-before-') as baseline:
        with tarfile.open(BATCH / 'evidence/before_runtime.tar.gz') as archive:
            archive.extractall(baseline, filter='data')
        for phase, source in [('A1', Path(baseline)), ('B', ROOT / 'src'), ('A2', Path(baseline))]:
            with tempfile.TemporaryDirectory(prefix='comment-startup-config-') as folder:
                root = Path(folder)
                names = ('sample-update-order-status', 'sample-reset-order-to-pending')
                for name in names:
                    shutil.copytree(ROOT / 'skills' / name, root / 'skills' / name)
                for index in range(20):
                    name = f'query-{index:02}'
                    directory = root / 'skills' / name
                    directory.mkdir()
                    (directory / 'skill_def.md').write_text('---\nname: '+name+'\ntype: query\nsource: query.sql\nrisk: low\ndescription: Startup acceptance workload\ndatabases: [sqlite]\ntables: [orders]\nparams: {}\n---\n')
                    (directory / 'query.sql').write_text(f'SELECT n FROM orders WHERE n>={index}')
                (root / 'server.toml').write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="fixture"\n')
                (root / 'connections.toml').write_text('schema_version=1\n[connections.fixture]\ntype="sqlite"\nsqlite.path="unused.sqlite"\n')
                (root / 'skills.toml').write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.mutation]\nenabled=true\nallowed_connections=["fixture"]\n[skills.audit]\npath="audit.jsonl"\n')
                env = os.environ.copy()
                env['PYTHONPATH'] = str(source)
                output = subprocess.check_output([sys.executable, str(Path(__file__).resolve()), '--child', str(source), str(root / 'server.toml')], env=env, text=True)
                result = json.loads(output)
                expected = snapshots['B' if phase == 'B' else 'A']
                assert result['resources'] == {name.removeprefix('sql_safety_executor/'): value for name, value in expected.items()}
                result['phase'] = phase
                records.append(result)
                print(json.dumps({key: value for key, value in result.items() if key not in {'durations_ms', 'resources'}}), flush=True)
    baseline = statistics.median(records[0]['durations_ms'] + records[2]['durations_ms'])
    after = records[1]['median_ms']
    result = {'scope': __doc__, 'records': records, 'baseline_median_ms': baseline, 'optimized_median_ms': after,
              'delta_ms': after - baseline, 'delta_percent': (after / baseline - 1) * 100,
              'notes': 'Two unchanged bundled managed plans plus 20 query templates, default parser; YAML/module discovery plus runtime initialization/close. No database connections, process import, FastMCP creation/stdio handshake, model inference or configured writes. Sequential A/B/A, not randomized. Query startup candidates stop at first allow; actual-target checks remain separate.'}
    OUT.write_text(json.dumps(result, indent=2) + '\n')
