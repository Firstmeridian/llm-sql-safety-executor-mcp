from scenarios import check_installed

def populate_fixture(fixture):
    fixture.mkdir()
