"""Private SQLite truth, both Client modes and unchanged installed CLI inputs."""
from contextlib import contextmanager
import json
from pathlib import Path
import sqlite3

from fastmcp import Client
from fastmcp.client.transports import StdioTransport

SKILLS = {
    'unicode-from': 'SELECT n FROM main."pragma_locKing_mode"',
    'unicode-in': 'SELECT 7 AS n WHERE 7 IN main."pragma_locKing_mode"',
    'unicode-account-column': 'SELECT current_uſer AS n FROM main.orders',
    'reserved-pragma': 'SELECT n FROM main.pragma_locking_mode',
    'reserved-account': 'SELECT current_user AS n FROM main.orders',
}
GOOD = list(SKILLS)[:3]


def populate_fixture(directory):
    directory.mkdir(exist_ok=True)
    with sqlite3.connect(directory / 'fixture.sqlite') as db:
        db.executescript('CREATE TABLE "pragma_locKing_mode"(n INTEGER);INSERT INTO "pragma_locKing_mode" VALUES(7);'
            'CREATE TABLE pragma_locking_mode(n INTEGER);INSERT INTO pragma_locking_mode VALUES(99);'
            'CREATE TABLE orders(current_uſer INTEGER,current_user INTEGER);INSERT INTO orders VALUES(7,99);')
        assert db.execute(SKILLS['unicode-from']).fetchall() == [(7,)]
        assert db.execute(SKILLS['unicode-in']).fetchall() == [(7,)]
        assert db.execute(SKILLS['unicode-account-column']).fetchall() == [(7,)]
        assert db.execute(SKILLS['reserved-pragma']).fetchall() == [(99,)]
        assert db.execute(SKILLS['reserved-account']).fetchall() == [(99,)]
    (directory/'server.toml').write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="demo"\n')
    (directory/'connections.toml').write_text('schema_version=1\n[connections.demo]\ntype="sqlite"\n[connections.demo.sqlite]\npath="fixture.sqlite"\n[connections.demo.read]\nmode="allowlist"\ntables=["main.pragma_locKing_mode","main.orders"]\n')
    (directory/'skills.toml').write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=true\n[skills.audit]\npath="audit.jsonl"\n')
    for name,sql in SKILLS.items():
        skill=directory/'skills'/name;skill.mkdir(parents=True)
        (skill/'skill_def.md').write_text(f'---\nname: {name}\ntype: query\nsource: query.sql\nrisk: low\ndescription: Unicode SQL name identity\nparams: {{}}\n---\n')
        (skill/'query.sql').write_text(sql)


async def check_client(client,mode,*,expect_fixed):
    requests=[('query',{'sql':SKILLS[name]}) for name in GOOD]
    requests += [('query',{'sql':SKILLS['reserved-pragma']}),
        ('query',{'sql':'SELECT 1 WHERE 1 IN main.pragma_locking_mode'}),
        ('query',{'sql':SKILLS['reserved-account']}),
        ('list_skills',{'detail_level':'full'})]
    requests += [('get_skill_detail',{'skill_name':name,'detail_level':'full'}) for name in GOOD]
    requests += [('execute_query_skill',{'skill_name':name,'params':{}}) for name in GOOD]
    records=[]
    for tool,arguments in requests:
        result=await client.call_tool(tool,arguments,raise_on_error=False)
        records.append({'tool':tool,'arguments':arguments,'isError':result.is_error,
            'structuredContent':result.structured_content,
            'content':[c.model_dump(mode='json',exclude_none=True) for c in result.content],'meta':result.meta})
    good_raw=all(not r['isError'] and r['structuredContent'].get('data')==[{'n':7}] for r in records[:3])
    reserved=all(not r['isError'] and r['structuredContent']['error_code']=='server_state_denied' for r in records[3:6])
    listed=records[6]['structuredContent']['skills']
    good_skills=all(not r['isError'] and r['structuredContent'].get('data')==[{'n':7}] for r in records[10:])
    if expect_fixed:
        assert good_raw and reserved and good_skills
        assert {s['name'] for s in listed}==set(GOOD)
        for record in records[7:10]:
            state=record['structuredContent']['skill']
            assert state['schema_ready'] and state['policy_allowed'] and state['executable']
            assert state['missing_tables']==state['unverified_tables']==[]
    else:
        assert not good_raw and reserved and not good_skills
        assert not listed
        assert all(r['structuredContent']['error_code']=='server_state_denied' for r in records[:3])
        assert all(r['isError'] for r in records[7:])
    return {'mode':mode,'native_truth':{'unicode_pragma_table':7,'ascii_pragma_table':99,'unicode_account_column':7,'ascii_account_column':99},
        'requests':requests,'calls':records,'outcome':{'unicode_raw_ok':good_raw,'reserved_still_denied':reserved,'unicode_skills_ok':good_skills,'default_skills':[s['name'] for s in listed]}}


async def check_installed(target,fixture,logs):
    import sys
    records=[]
    for mode in ('legacy','auto'):
        stage=fixture/mode
        populate_fixture(stage)
        transport=StdioTransport(command=sys.executable,args=['-m','sql_safety_executor','serve','--config',str(stage/'server.toml')],
            env={'PYTHONPATH':str(target)},cwd=str(stage),keep_alive=False,log_file=logs/f'installed-{mode}.log')
        async with Client(transport,mode=mode) as client:
            record=await check_client(client,mode,expect_fixed=True)
            result=client.initialize_result
            record['protocol']=result.protocol_version if result else None
            records.append(record)
    return records
