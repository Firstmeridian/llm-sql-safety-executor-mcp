"""Preserve before/after evidence without changing configured databases."""
import argparse
import asyncio
import gzip
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from fastmcp import Client
from sql_safety_executor import create_server,load_config
from scenarios import populate_fixture,check_client

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'docs/validation/v3.8/pragma_identity_2026_10_15'
parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['before','after'],required=True);args=parser.parse_args()
OUT.mkdir(parents=True,exist_ok=True)
source={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'src/sql_safety_executor').rglob('*')) if p.is_file() and p.suffix in ('.py','.md')}

async def main():
    records=[]
    for mode in ('legacy','auto'):
        with tempfile.TemporaryDirectory(prefix='v381-unicode-') as directory:
            stage=Path(directory);populate_fixture(stage)
            server=create_server(load_config(stage/'server.toml'))
            try:
                async with Client(server,mode=mode) as client:
                    record=await check_client(client,mode,expect_fixed=args.stage=='after')
                    records.append(record)
                    print(mode,json.dumps(record['outcome']),flush=True)
            finally:server.gateway_runtime.close()
    data={'version':'3.8.1','stage':args.stage,'source_sha256':source,'total_calls':26,'records':records,
          'scope':'Private in-process Client application results; not full transport frames','configured_database_writes':False,'production_config_changes':False,'private_fixtures_cleaned':True}
    (OUT/f'{args.stage}-calls.json.gz').write_bytes(gzip.compress((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
    if args.stage=='before':
        assert source==json.loads((ROOT/'docs/validation/v3.8/sqlite_prefix_2026_10_15/automation.json').read_text())['source_sha256']
        (OUT/'baseline_source.json').write_text(json.dumps(source,indent=2)+'\n')
        (OUT/'baseline_policy.py.gz').write_bytes(gzip.compress((ROOT/'src/sql_safety_executor/core/policy.py').read_bytes(),mtime=0))

asyncio.run(main())
