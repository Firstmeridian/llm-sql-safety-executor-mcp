"""Seal source-attributed Unicode-name repair evidence; keep prior batches intact."""
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'docs/validation/v3.8/pragma_identity_2026_10_15'
sha=lambda data:hashlib.sha256(data).hexdigest()
source={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted((ROOT/'src/sql_safety_executor').rglob('*')) if p.is_file() and p.suffix in ('.py','.md')}
baseline=json.loads((OUT/'baseline_source.json').read_text())
changed=[name for name in source if source[name]!=baseline[name]]
assert changed==['src/sql_safety_executor/core/policy.py']
old=gzip.decompress((OUT/'baseline_policy.py.gz').read_bytes()).decode()
current=(ROOT/changed[0]).read_text()
(OUT/'change_from_prior.patch').write_text(''.join(difflib.unified_diff(old.splitlines(keepends=True),current.splitlines(keepends=True),fromfile='before/'+changed[0],tofile='after/'+changed[0])))
before=json.loads(gzip.decompress((OUT/'before-calls.json.gz').read_bytes()))
after=json.loads(gzip.decompress((OUT/'after-calls.json.gz').read_bytes()))
assert before['source_sha256']==baseline and after['source_sha256']==source
assert before['total_calls']==after['total_calls']==26
for left,right in zip(before['records'],after['records']):
    assert left['mode']==right['mode'] and left['requests']==right['requests']
    assert not left['outcome']['unicode_raw_ok'] and not left['outcome']['unicode_skills_ok']
    assert right['outcome']['unicode_raw_ok'] and right['outcome']['unicode_skills_ok']
    assert left['outcome']['reserved_still_denied'] and right['outcome']['reserved_still_denied']
installed=json.loads((OUT/'installed_wheel.json').read_text())
assert installed['total_calls']==26 and installed['source_files_verified']==69
assert source=={'src/'+name:value for name,value in installed['installed_source_sha256'].items()}
for name in ('sqlite_prefix_2026_10_15','real_tasks_2026_10_15','schema_binding_2026_10_15'):
    base=ROOT/'docs/validation/v3.8'/name
    for record in json.loads((base/'manifest.json').read_text())['artifacts']:
        assert sha((base/record['path']).read_bytes())==record['sha256']
full=Path('/tmp/v381-unicode-full.log').read_text()
match=re.search(r'(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s',full)
assert match and match.group(1,2,3)==('1278','4','68')
assert '56 passed, 1 warning' in Path('/tmp/v381-unicode-focused.log').read_text()
assert '0 errors, 0 warnings' in Path('/tmp/v381-unicode-pyright.log').read_text()
assert 'Installed prompt resources and routing guidance valid' in Path('/tmp/v381-unicode-prompt.log').read_text()
probes=json.loads((OUT/'restart_probe_source_checks.json').read_text())
native_before=json.loads((OUT/'native_before_restart_corrected.json').read_text())
assert probes['checks']=={'passed':3,'failed':0}
assert all(c['structuredContent']['data']==[{'n':7}] for c in probes['calls'])
assert [r['args']['sql'] for r in probes['calls']]==[r['args']['sql'] for r in native_before['records']]
assert all(r['raw']['structuredContent']['error_code']=='server_state_denied' for r in native_before['records'])
automation={'version':'3.8.1','source_sha256':source,
    'test_source_sha256':{p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted((ROOT/'tests').rglob('*.py'))},
    'changed_production_files':changed,'new_regressions':56,
    'full_suite':{'passed':1278,'skipped':4,'warnings':68,'seconds':float(match[4]),'mysql_optin':False},
    'focused':{'passed':56,'warnings':1,'seconds':3.76},'pyright':{'errors':0,'warnings':0},'prompt_contract':'passed',
    'baseline_client_calls':26,'after_client_calls':26,'installed_cli_stdio_calls':26,
    'current_source_constant_probes':3,'resident_host':'Pending maintainer restart; corrected native constant probes still show old refusal',
    'new_model_or_mysql_unicode_cost_claim':False,'configured_database_writes':False,'production_config_modified':False,
    'retained_attempts':[
        'Initial type check had 49 missing-import errors and 1 warning; absolute-interpreter approved-environment check passed, no unique root-cause claim',
        'Initial default-environment private stdio result set incomplete; SIGINT insufficient, task parent/child terminated; approved-environment full 26-call retry passed',
        'Initial quoted-CTE-column-list refresh probe was unsuitable: current source conservatively refused relation_scope_unresolved and collector raised KeyError(data); preserve old native observations but compare only corrected same-input set'
    ]}
if (OUT/'native_after_restart.json').exists():
    native=json.loads((OUT/'native_after_restart.json').read_text())
    assert native['checks']['failed']==0
    automation['resident_host']='Corrected native probes and controls passed after maintainer restart'
    automation['resident_host_checks']=native['checks']
(OUT/'automation.json').write_text(json.dumps(automation,ensure_ascii=False,indent=2)+'\n')
for p in Path('/tmp').glob('v381-unicode-*.log'):
    (OUT/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in Path(__file__).parent.glob('*.py'):
    (OUT/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
links=0
for line in subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).splitlines():
    path=ROOT/line[3:]
    if not path.is_file() or path.suffix!='.md':continue
    for target in re.findall(r'\]\(([^)\n]+)\)',path.read_text()):
        target=target.strip().strip('<>')
        if '://' in target or target.startswith(('#','mailto:','data:')):continue
        filename=target.split('#',1)[0]
        if filename:
            resolved=(path.parent/unquote(filename)).resolve()
            assert resolved==OUT/'manifest.json' or resolved.exists(),(path,filename)
            links+=1
for name in ('DESIGN_RISK_REGISTER.md','DESIGN_RISK_REGISTER_ZH.md'):
    lines=(ROOT/'docs/security'/name).read_text().splitlines()
    ids=[m[1] for line in lines if (m:=re.match(r'^\| DRR-2026-(\d{3}) \|',line))]
    assert sorted(ids)==[f'{i:03}' for i in range(1,96)]
    index=next(i for i,line in enumerate(lines) if line.startswith('| DRR-2026-095 |'))
    assert lines[index-1].startswith('| DRR-2026-094 |')
for name in ('README.md','README_ZH.md'):
    top=(ROOT/name).read_text().split('## ',1)[0]
    assert 'V3_8_1_' not in top and '12 native Luna' not in top and '12 个原生 Luna' not in top
for name in ('docs/README.md','docs/README_ZH.md'):
    assert (ROOT/name).read_text().startswith('# ')
draft=(ROOT/'local_archive/v381_review/commit-message-complete-v381.txt').read_text()
assert sum(line.startswith('- ') for line in draft.splitlines())==7 and len(draft)<850
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
assert not subprocess.check_output(['git','diff','--','pyproject.toml','uv.lock'],cwd=ROOT)
(OUT/'document_checks.json').write_text(json.dumps({'local_file_links':links,'bilingual_drr_ids':95,'drr_table_contiguous':True,
    'root_readme_stage_notices_removed':True,'documentation_indexes_start_with_title':True,
    'commit_draft_bullets':7,'commit_draft_characters':len(draft),'diff_check':'passed',
    'scope':'Local file links and relevant navigation structure, not every remote URL/anchor'},indent=2)+'\n')
manifest={'version':'3.8.1','source_reference':'automation.json#source_sha256','recording_profile':'Source/test hashes, compressed application results and build/check logs; not full protocol frames',
    'omitted':['Full JSON-RPC frames/notifications','No new model usage/cost or MySQL Unicode matrix'],
    'cleanup':'Only task-private SQLite/build/install processes and directories; configured resident/database/TOML untouched',
    'prior_evidence':'Prior manifests byte-verified; prior dated source/model results not relabeled', 'artifacts':[]}
for p in sorted(OUT.iterdir()):
    if not p.is_file() or p.name=='manifest.json':continue
    data=p.read_bytes();row={'path':p.name,'bytes':len(data),'sha256':sha(data)}
    if p.suffix=='.gz':
        raw=gzip.decompress(data);row.update(uncompressed_bytes=len(raw),uncompressed_sha256=sha(raw))
    manifest['artifacts'].append(row)
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'full_passed':1278,'focused_passed':56,'installed_calls':26,'baseline_after_calls_each':26,
    'source_files':len(source),'test_files':len(automation['test_source_sha256']),'changed_files':changed,'document_links':links,
    'drr_ids':95,'draft_characters':len(draft),'resident_host':automation['resident_host'],'artifacts':len(manifest['artifacts'])}))
