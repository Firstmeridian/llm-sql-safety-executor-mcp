"""Verify scoped native restart and adjacent metadata without normalizing types."""
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import tomllib

ROOT = Path(__file__).resolve().parents[5]
HERE = Path(__file__).resolve().parents[1]
BATCH = HERE.parent


def read(path):
    return json.loads(path.read_text()) if path.exists() else json.loads(gzip.decompress(path.with_suffix(path.suffix + '.gz').read_bytes()))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def literal(name):
    return "'" + name.replace("'", "''") + "'"


def quote(name):
    return '"' + name.replace('"', '""') + '"'


def columns(rows):
    output = []
    for row in rows:
        if row[6] == 1:
            continue
        item = {'column_name': row[1], 'data_type': row[2], 'nullable': 'NO' if row[3] else 'YES',
                'key_type': 'PRI' if row[5] else '', 'default_value': row[4]}
        if row[6] in {2, 3}:
            item['generation_type'] = {2: 'virtual', 3: 'stored'}[row[6]]
        output.append(item)
    return output


def full_columns(cols):
    return [dict(name=c['column_name'], type=c['data_type'], nullable=c['nullable'],
                 key=c['key_type'], default=c['default_value'],
                 **({'generation_type': c['generation_type']} if 'generation_type' in c else {})) for c in cols]


def main():
    before = read(HERE / 'evidence/before.json')
    plan = read(BATCH / 'evidence/native_plan.json')
    installed = read(BATCH / 'evidence/installed_resources-final.json')
    resources = {str(p.relative_to(ROOT)): sha(p) for p in (ROOT / 'src/sql_safety_executor').rglob('*') if p.is_file() and p.suffix in {'.py', '.md'}}
    assert resources == before['resources'] == plan['resources'] and len(resources) == 77
    assert {k.removeprefix('src/sql_safety_executor/'): v for k, v in resources.items()} == installed['installed']['resources']
    for name, digest in before['private_toml_sha256'].items():
        assert sha(ROOT / name) == digest
    cfg = tomllib.loads((ROOT / 'config/connections.toml').read_text())
    database = Path(cfg['connections']['sqlite_features_sqlite']['sqlite']['path'])
    if not database.is_absolute():
        database = ROOT / 'config' / database
    assert sha(database) == before['configured_sqlite_sha256']
    total = 0
    for record in before['prior_seals']:
        manifest = ROOT / record['manifest']
        assert sha(manifest) == record['sha256']
        data = read(manifest)
        items = data['files'].items() if isinstance(data['files'], dict) else ((x['path'], x) for x in data['files'])
        paths = {}
        count = 0
        for name, spec in items:
            path = next(p for p in [manifest.parent / name, manifest.parent.parent / name, ROOT / name] if p.is_file())
            paths[name] = path
            assert sha(path) == (spec['sha256'] if isinstance(spec, dict) else spec)
            if isinstance(spec, dict):
                if 'bytes' in spec:
                    assert path.stat().st_size == spec['bytes']
                if 'decoded_sha256' in spec:
                    content = gzip.decompress(path.read_bytes())
                    assert hashlib.sha256(content).hexdigest() == spec['decoded_sha256'] and len(content) == spec['decoded_bytes']
            count += 1
        for name, spec in data.get('compressed_decoded_records', {}).items():
            content = gzip.decompress(paths[name].read_bytes())
            assert hashlib.sha256(content).hexdigest() == spec.get('decoded_sha256', spec.get('sha256'))
            assert len(content) == spec.get('decoded_bytes', spec.get('bytes'))
        assert count == record['files']
        total += count
    assert len(before['prior_seals']) == 65 and total == 2097

    native = read(HERE / 'evidence/native_results.json')
    assert len(native['calls']) == len(plan['calls']) == 9
    values = {}
    for expected, actual in zip(plan['calls'], native['calls'], strict=True):
        assert all(actual[k] == expected[k] for k in ['case', 'tool', 'arguments', 'expected'])
        assert 'transport_error' not in actual
        result = actual['result']
        value = result['structuredContent']
        assert result['isError'] is False
        assert json.loads(result['content'][0]['text']) == value
        assert value['success'] is (actual['case'] not in {'shadow-denial', 'function-denial'})
        assert value['connection_id'] == expected['arguments']['connection_id']
        if 'data' in expected['expected']:
            assert value['data'] == expected['expected']['data']
        if 'error_code' in expected['expected']:
            assert value['error_code'] == expected['expected']['error_code']
        values[actual['case']] = value
    assert [c['data_type'] for c in values['fts-native-types']['columns']] == ['', '']
    assert values['pages-generated']['column_count'] == 10
    assert next(c for c in values['pages-generated']['columns'] if c['column_name'] == 'status')['generation_type'] == 'virtual'
    compact, full = values['compact'], values['full']
    assert compact['total_tables'] == full['total_tables'] == 6
    assert compact['total_columns'] == full['total_columns'] == 34
    assert not compact['truncated'] and not full['truncated']
    groups = {t['name']: (g, t) for g in compact['schema_groups'] for t in g['tables']}
    assert set(groups) == set(full['schema'])
    truth = {'scope': 'Independent read-only SQLite columns, counts and indexes; direct native type strings', 'columns': {}, 'row_counts': {}, 'index_list': [], 'index_parts': {}}
    with sqlite3.connect(database.resolve().as_uri() + '?mode=ro', uri=True) as db:
        for name, table in full['schema'].items():
            raw = [list(r) for r in db.execute('PRAGMA main.table_xinfo(' + literal(name) + ')')]
            truth['columns'][name] = raw
            expected = columns(raw)
            assert table['columns'] == full_columns(expected)
            group, item = groups[name]
            assert group['columns'] == [[c['column_name'], c['data_type']] for c in expected]
            assert group.get('generated_columns', {}) == {c['column_name']: c['generation_type'] for c in expected if 'generation_type' in c}
            count = db.execute('SELECT COUNT(*) FROM main.' + quote(name)).fetchone()[0]
            truth['row_counts'][name] = count
            assert item['row_count'] == table['row_count'] == count
        for key, name in [('pages-generated', 'pages'), ('fts-native-types', 'pages_fts')]:
            assert values[key]['columns'] == columns(truth['columns'][name])
            assert values[key]['row_count'] == truth['row_counts'][name]
        assert db.execute("SELECT COUNT(*) FROM main.pages_fts WHERE pages_fts MATCH 'database'").fetchone()[0] == 1
        listed = [list(r) for r in db.execute("PRAGMA main.index_list('pages')")]
        truth['index_list'] = listed
        indexes = {}
        for _, name, unique, origin, partial in listed:
            raw = [list(r) for r in db.execute('PRAGMA main.index_xinfo(' + literal(name) + ')')]
            truth['index_parts'][name] = raw
            keys = [r for r in raw if r[5] == 1]
            index = {'name': name, 'primary': origin == 'pk', 'unique': bool(unique),
                     'columns': [None if r[1] == -2 else r[2] for r in keys],
                     'key_parts': [{'column': None if r[1] == -2 else r[2], 'sort_order': 'desc' if r[3] else 'asc', 'collation': r[4]} for r in keys],
                     'partial': bool(partial)}
            if any(r[1] == -2 for r in keys):
                index['has_expression'] = True
            indexes[name] = index
        primary = sorted([r for r in truth['columns']['pages'] if r[5] > 0], key=lambda r: r[5])
        if primary and not any(i['primary'] for i in indexes.values()):
            indexes[None] = {'name': None, 'primary': True, 'unique': True, 'columns': [r[1] for r in primary],
                             'key_parts': [{'column': r[1], 'sort_order': None, 'collation': None} for r in primary], 'partial': False}
        assert values['pages-generated']['indexes_status'] == 'complete'
        assert {i['name']: i for i in values['pages-generated']['indexes']} == indexes
    assert sha(database) == before['configured_sqlite_sha256']
    (HERE / 'evidence/metadata_truth.json').write_text(json.dumps(truth, indent=2) + '\n')

    source, wheel = [read(HERE / ('evidence/adjacent-' + side + '.json')) for side in ['source', 'installed']]
    assert source['calls'] == wheel['calls'] and source['truth'] == wheel['truth'] and source['components'] == wheel['components']
    assert Path(wheel['package']) == Path(installed['installed']['package'])
    for data in [source, wheel]:
        assert data['summary']['calls'] == 144 and data['summary']['objects'] == 10 and not data['errors']
        assert data['fixtures_cleaned'] and data['database_unchanged_after_setup']
        assert data['summary']['groups'] == {t + ':' + m: 36 for t in ['inprocess', 'stdio'] for m in ['auto', 'legacy']}
        for c in data['components']:
            assert c['columns'] == columns(data['truth'][c['table']]['columns'])
        for row in data['calls']:
            value = row['structured']
            assert not row['isError'] and value['success']
            assert json.loads(row['content'][0]['text']) == value
            if row['tool'] in {'describe_table', 'get_table_summary'}:
                assert value['columns'] == columns(data['truth'][row['case']]['columns'])
            if row['tool'] == 'query':
                assert value['data'] == [dict(zip(['n', 'storage_type', 'equals_text'], r)) for r in data['truth'][row['case']]['rows']]
            if row['case'] == 'detail':
                assert value['skill']['schema_ready'] and value['skill']['executable']
            if row['case'] == 'skill':
                assert value['data'] == [{'n': 0, 'storage_type': 'integer', 'equals_text': 0}]
            if row['tool'] == 'get_full_schema':
                assert value['total_tables'] == 8 and value['total_columns'] == 14
                if row['case'] == 'full':
                    for name, table in value['schema'].items():
                        assert table['columns'] == full_columns(columns(data['truth'][name]['columns']))
                else:
                    lookup = {t['name']: i for i, g in enumerate(value['schema_groups']) for t in g['tables']}
                    assert len({lookup[n] for n in ['defaults_none', 'defaults_null', 'defaults_zero', 'defaults_empty', 'defaults_text_zero']}) == 5
                    for name, i in lookup.items():
                        assert value['schema_groups'][i]['columns'] == [[c['column_name'], c['data_type']] for c in columns(data['truth'][name]['columns'])]
    report = {'finding': 'DRR-2026-140', 'status': 'Scoped source/package plus post-owner-restart native verification complete',
              'native': {'passed': 9, 'total': 9, 'text_structured_equal': True, 'metadata_independently_verified': True},
              'adjacent': {'source_calls': 144, 'installed_calls': 144, 'objects': 10, 'component_observations_per_side': 20,
                           'source_wheel_application_records_equal': True, 'text_structured_equal': True,
                           'new_confirmed_independent_findings': 0, 'scope': 'Absent/NULL/0/empty/text defaults; space/custom/sized declarations; quoted Unicode/dotted/spaced names; strict TEXT; inherited/CAST views; generated metadata'},
              'resources_unchanged': 77, 'private_tomls_unchanged': 3, 'configured_database_unchanged': True,
              'prior_manifests_unchanged': 65, 'prior_file_records_unchanged': 2097,
              'new_model_trials': 0, 'new_builds': 0, 'new_full_suite_runs': 0,
              'limits': 'Selected metadata neighbors only, no general SQL completeness, latency/provider-token or full-protocol guarantee. Disk identity alone is not resident-memory proof.'}
    (HERE / 'evidence/verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
