"""Verify native type preservation and existing seals; never normalize empty types."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tomllib

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(path.read_text()) if path.exists() else json.loads(gzip.decompress(path.with_suffix(path.suffix + '.gz').read_bytes()))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    source = read(HERE / 'evidence/source-final.json')
    installed = read(HERE / 'evidence/installed-final.json')
    old = read(ROOT / 'local_archive/v382_review/20261021_sqlite_declared_type_assessment/evidence/source-final.json')
    before = read(HERE / 'baseline/current.json')
    assert source['calls'] == installed['calls']
    assert source['truth'] == installed['truth'] == old['truth']
    assert source['components'] == installed['components']
    projection_sizes = {}
    for data in [source, installed]:
        assert not data['errors'] and data['summary']['calls'] == 184
        assert data['summary']['groups'] == {t + ':' + m: 46 for t in ['inprocess', 'stdio'] for m in ['auto', 'legacy']}
        assert data['fixtures_cleaned'] and data['database_unchanged_after_setup']
        for row in data['calls']:
            result = row['structured']
            assert not row['isError'] and result['success'], (row['case'], row['tool'], result)
            texts = [c['text'] for c in row['content'] if c['type'] == 'text']
            assert len(texts) == 1 and json.loads(texts[0]) == result
            if row['tool'] == 'query':
                expected = [dict(zip(['n', 'storage_type', 'equals_text'], values)) for values in data['truth'][row['case']]['rows']]
                assert result['data'] == expected
            if row['tool'] in {'describe_table', 'get_table_summary'}:
                native = [r for r in data['truth'][row['case']]['columns'] if r[6] != 1]
                assert result['column_count'] == len(native)
                assert [c['column_name'] for c in result['columns']] == [r[1] for r in native]
                assert [c['data_type'] for c in result['columns']] == [r[2] for r in native]
                assert [c.get('generation_type') for c in result['columns']] == [{2: 'virtual', 3: 'stored'}.get(r[6]) for r in native]
            if row['tool'] == 'get_full_schema':
                assert result['total_tables'] == 14 and result['total_columns'] == 17
                if row['case'] == 'full':
                    projected = {name: [c['type'] for c in table['columns']] for name, table in result['schema'].items()}
                else:
                    projected = {t['name']: [c[1] for c in g['columns']] for g in result['schema_groups'] for t in g['tables']}
                    assert result['schema_group_count'] == (11 if row['case'] == 'compact' else 14)
                for name, types in projected.items():
                    assert types == [r[2] for r in data['truth'][name]['columns'] if r[6] != 1]
            if row['tool'] == 'get_skill_detail':
                assert result['skill']['executable'] and result['skill']['schema_ready']
            if row['tool'] == 'execute_query_skill':
                assert result['data'] == [{'n': 7, 'storage_type': 'integer', 'equals_text': 0}]
        for component in data['components']:
            assert [c['data_type'] for c in component['columns']] == [r[2] for r in data['truth'][component['table']]['columns'] if r[6] != 1]
    for row, old_row in zip(source['calls'], old['calls'], strict=True):
        assert all(row[k] == old_row[k] for k in ['transport', 'mode', 'case', 'tool', 'arguments'])
        if row['tool'] in {'query', 'execute_query_skill', 'list_tables'}:
            assert row['structured'] == old_row['structured']
        if row['transport'] == 'inprocess' and row['mode'] == 'auto' and row['tool'] == 'get_full_schema':
            def size(record):
                return sum(len(c['text']) for c in record['content'] if c['type'] == 'text')
            projection_sizes[row['case']] = {'old_application_text_chars': size(old_row), 'new_application_text_chars': size(row)}
    current = {str(p.relative_to(ROOT)): sha(p) for p in (ROOT / 'src/sql_safety_executor').rglob('*') if p.is_file() and p.suffix in {'.py', '.md'}}
    changed = [name for name in current if current[name] != before['resources'].get(name)]
    assert set(current) == set(before['resources']) and changed == ['src/sql_safety_executor/database/sqlite.py']
    for name, digest in before['private_toml_sha256'].items():
        assert sha(ROOT / name) == digest
    wheel = read(HERE / 'evidence/installed_resources-final.json')
    assert {k.removeprefix('src/sql_safety_executor/'): v for k, v in current.items()} == wheel['installed']['resources']
    assert sha(Path(wheel['wheel'])) == wheel['wheel_sha256']
    assert Path(installed['package']) == Path(wheel['installed']['package'])
    dist = HERE / 'evidence/distributions'
    dist.mkdir(exist_ok=True)
    destination = dist / Path(wheel['wheel']).name
    if not destination.exists():
        shutil.copyfile(wheel['wheel'], destination)
    assert sha(destination) == wheel['wheel_sha256']
    cfg = tomllib.loads((ROOT / 'config/connections.toml').read_text())
    database = Path(cfg['connections']['sqlite_features_sqlite']['sqlite']['path'])
    if not database.is_absolute():
        database = ROOT / 'config' / database
    prior_native = ROOT / 'local_archive/v382_review/20261021_fts_catalog_statistics_repair/resident_restart/evidence'
    database_digest = sha(database)
    assert database_digest == read(prior_native / 'before.json')['configured_sqlite_sha256']
    records = 0
    for spec in before['prior_seals']:
        manifest = ROOT / spec['manifest']
        assert sha(manifest) == spec['sha256']
        data = read(manifest)
        items = data['files'].items() if isinstance(data['files'], dict) else ((r['path'], r) for r in data['files'])
        paths = {}
        count = 0
        for name, file in items:
            path = next(p for p in [manifest.parent / name, manifest.parent.parent / name, ROOT / name] if p.is_file())
            paths[name] = path
            assert sha(path) == (file['sha256'] if isinstance(file, dict) else file)
            if isinstance(file, dict):
                if 'bytes' in file:
                    assert path.stat().st_size == file['bytes']
                if 'decoded_sha256' in file:
                    decoded = gzip.decompress(path.read_bytes())
                    assert hashlib.sha256(decoded).hexdigest() == file['decoded_sha256'] and len(decoded) == file['decoded_bytes']
            count += 1
        for name, file in data.get('compressed_decoded_records', {}).items():
            decoded = gzip.decompress(paths[name].read_bytes())
            assert hashlib.sha256(decoded).hexdigest() == file.get('decoded_sha256', file.get('sha256'))
            assert len(decoded) == file.get('decoded_bytes', file.get('bytes'))
        assert count == spec['files']
        records += count
    assert len(before['prior_seals']) == 63 and records == 2047
    summary = {'finding': 'DRR-2026-140', 'status': 'Implemented; source/wheel verified; owner restart and native plan pending',
        'source_calls': 184, 'installed_calls': 184, 'component_observations_per_side': 36,
        'text_structured_equal': True, 'source_installed_application_records_equal': True,
        'native_type_comparison': 'Direct raw PRAGMA strings, with no TEXT fallback or affinity inference',
        'compact_groups_before': 9, 'compact_groups_after': 11, 'schema_tables': 14, 'schema_columns': 17,
        'application_projection_chars': projection_sizes, 'chars_are_provider_tokens': False,
        'runtime_resources': len(current), 'runtime_changes': changed, 'private_configs_unchanged': 3,
        'configured_sqlite_sha256': database_digest, 'configured_sqlite_unchanged': True,
        'prior_manifests_unchanged': 63, 'prior_file_records_unchanged': records,
        'wheel_sha256': wheel['wheel_sha256'], 'new_model_trials': 0,
        'limits': 'Selected native-type metadata neighbors; no whole-project, latency, model-token or full-protocol claim; historical normalized checks preserved'}
    (HERE / 'evidence/final-checks.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
