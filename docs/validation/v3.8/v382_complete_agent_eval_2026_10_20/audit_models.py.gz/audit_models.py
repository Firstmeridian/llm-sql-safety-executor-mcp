"""Verify actual public turn-context model/effort for selected and old trials."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
E = Path(__file__).resolve().parents[1] / 'evidence'
OUT = E / 'model_context_check.json'
assert not OUT.exists()


def audit(agents, day):
    result = []
    for a in agents:
        paths = list((Path('/home/andy/.codex/sessions') / day).glob('*' + a['agent_id'] + '.jsonl'))
        assert len(paths) == 1
        contexts = []
        for line in paths[0].open():
            event = json.loads(line)
            if event.get('type') == 'turn_context':
                payload = event['payload']
                contexts.append({'timestamp': event.get('timestamp'), 'model': payload.get('model'),
                                 'effort': payload.get('effort'), 'turn_id': payload.get('turn_id')})
        assert contexts
        result.append({'task': a['task'], 'trial': a['trial'], 'agent_id': a['agent_id'],
            'contexts': contexts, 'valid_luna_medium': all(c['model'] == 'gpt-6-luna' and c['effort'] == 'medium' for c in contexts)})
    return result


selected = audit(json.loads((E / 'agents_selected_final.json').read_text()), '2026/10/20')
older = []
for wave in range(1, 4):
    older += json.loads((ROOT / f'local_archive/v382_review/20261019_external_review_repair/resident_restart/evidence/agents_wave{wave}.json').read_text())
historical = audit(older, '2026/10/19')
assert len(selected) == 15 and all(x['valid_luna_medium'] for x in selected)
assert len(historical) == 9 and all(x['valid_luna_medium'] for x in historical)
OUT.write_text(json.dumps({'verified': True, 'selected_trials': selected, 'historical_trials': historical,
    'limits': 'Only selected public model/effort/turn-id context; no instructions or hidden reasoning. Three mixed-model recovered diagnostics remain separate and excluded.'}, indent=2) + '\n')
print('Actual model/effort verified: 15 selected and 9 historical trials are Luna medium.')
