"""Compare captured contracts; keep fixture differences and model costs explicit."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parents[1] / 'evidence/contract_and_cost_context.json'
assert not OUT.exists()


def read(relative):
    p = ROOT / relative
    return json.loads(gzip.decompress(p.read_bytes()) if p.suffix == '.gz' else p.read_bytes())


old_prefix = 'local_archive/v382_review/20261019_external_review_repair/evidence/'
new_prefix = 'local_archive/v382_review/20261020_read_plan_repair/evidence/'
old = read(old_prefix + 'source_capabilities_release.json.gz')
new = read(new_prefix + 'source_stdio.json.gz')
oldr = read(old_prefix + 'installed_resources_release.json')['installed']['resources']
newr = read(new_prefix + 'after_resources.json')
prompt_names = sorted(n for n in oldr if n.startswith('prompts/'))
assert all(oldr[n] == newr[n] for n in prompt_names)
contracts = []
for mode in ('auto', 'legacy'):
    a = {t['name']: t for t in next(i for i in old['inventories'] if i['mode'] == mode)['tools']}
    b = {t['name']: t for t in next(i for i in new['inventories'] if i['mode'] == mode and i['parser'] == 'sqlglot')['tools']}
    shared = sorted(set(a) & set(b))
    assert all(a[n] == b[n] for n in shared)
    contracts.append({'mode': mode, 'identical_common_tools': shared,
        'older_fixture_only': sorted(set(a) - set(b)), 'newer_fixture_only': sorted(set(b) - set(a)),
        'scope': 'Captured child-client fixture contracts; fixtures enable different optional tools, so not an assertion that both actual Host tool universes or first-turn token counts are equal.'})
metadata = read(new_prefix + 'metadata_cost.json.gz')
managed = read(new_prefix + 'paired_cost.json.gz')
startup = read(new_prefix + 'startup_cost.json')
value = {'matching_prompt_resources': len(prompt_names), 'prompt_files_sha256': {n: newr[n] for n in prompt_names},
         'contract_comparisons': contracts,
         'startup': {k: startup[k] for k in ('baseline_median_ms', 'optimized_median_ms', 'delta_percent', 'notes')},
         'metadata_summary': [{k: v for k, v in row.items() if k not in ('records', 'protocols')}
                              for row in metadata['runs']],
         'managed_summary': managed['runs'],
         'limits': 'No new performance rerun, universal tool-step/token claim or guidance ablation. Same contracts and prompts do not guarantee same Agent plan or provider usage. Measured actual task usage and correctness are separate.'}
OUT.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'unchanged_prompt_resources': len(prompt_names), 'identical_common_tools_each_mode': len(contracts[0]['identical_common_tools']), 'new_speed_claim': False}))
