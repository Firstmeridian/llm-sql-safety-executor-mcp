"""Publish final same-model figures; preserve mixed-model diagnostics separately."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
E = Path(__file__).resolve().parents[1] / 'evidence'
d = json.loads((E / 'summary.json').read_text())
assert d['business_passed'] == 15 and d['initial_canary_passed'] == 15
assert d['independently_replayed_sql'] == 60 and d['all_replayed_sql_matches']
old = json.loads((ROOT / 'local_archive/v382_review/20261019_external_review_repair/resident_restart/evidence/summary.json').read_text())
rows = d['historical_comparisons']
metrics = {}
for field in ('business_returns', 'business_model_responses'):
    a = sum(r['old_' + field] for r in rows); b = sum(r['new_' + field] for r in rows)
    metrics[field] = {'old': a, 'new': b, 'relative_percent': (b / a - 1) * 100}
for key in d['business_usage']:
    a = sum(r['old_business_usage'][key] for r in rows); b = sum(r['new_business_usage'][key] for r in rows)
    metrics[key] = {'old': a, 'new': b, 'relative_percent': (b / a - 1) * 100 if a else None}
same = [t for t in d['trials'] if t['task'] in ('telemetry', 'knowledge', 'search')]
all_comparison = {k: {'old': old['all_usage'][k], 'new': sum(t['all_usage'][k] for t in same)} for k in d['all_usage']}
mixed = json.loads((E / 'diagnostics/mixed_model_recovery/summary.json').read_text())
diagnostic_rows = [t for t in mixed['trials'] if t['task'] in ('telemetry', 'knowledge', 'search') and t['trial'] == 1]
mixed_usage = {k: sum(t['all_usage'][k] for t in diagnostic_rows) for k in d['all_usage']}
value = {'same_model_business': metrics, 'same_model_including_canaries': all_comparison,
         'operational_threads': 18, 'first_canary_success': 15, 'first_canary_failure': 3,
         'selected_fresh_luna_tasks': 15, 'mixed_model_recovery_diagnostics': 3,
         'selected_luna_all_usage': d['all_usage'], 'mixed_diagnostic_all_usage': mixed_usage,
         'all_18_threads_usage': {k: d['all_usage'][k] + mixed_usage[k] for k in d['all_usage']},
         'limits': 'Same-model selection checked actual per-turn model/effort; excludes three initially Luna then resumed Sol-ultra diagnostics by protocol, not outcome. Mixed-model operational token totals are counts, not homogeneous billing. Original mixed figures retained and withdrawn as same-model conclusions.'}
out = E / 'final_metrics.json'; assert not out.exists()
out.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def replace(name, before, after):
    p = ROOT / name; text = p.read_text()
    assert before in text, (name, before)
    p.write_text(text.replace(before, after))


report = 'docs/validation/v3.8/V3_8_2_COMPLETE_AGENT_EVAL_2026_10_20_ZH.md'
p = ROOT / report
text = p.read_text()
text = '\n'.join(line for line in text.split('\n') if not line.startswith('> 工作稿校正中：'))
text = text.replace('62条', '60条').replace('62/62', '60/60').replace('107次', '108次').replace('122次', '123次')
text = text.replace('初次子会话canary仅12/15通过；另3个原ID关闭／恢复后成功，失败保留。',
    '全程18个初始会话中15个canary首次通过，3个失败后原ID恢复可调用但实际模型变为Sol ultra，另列诊断；正式15个Luna任务均为fresh且逐轮核验model／effort。')
text = text.replace('但含前置／恢复总量增加，不能声称普遍更省', '同模型含前置总量也下降，但不能声称普遍更省')
text = text.replace('主会话独立真值不提供给子模型。', '主会话独立真值不提供给子模型。新15项及旧9项都从公开turn_context逐轮确认实际gpt-6-luna／medium；不只依据spawn请求。')
text = text.replace('首三个新会话没有SQL MCP工具，主通道正常；每个原ID仅尝试一次关闭／恢复，随后canary成功，其余12个fresh会话首次通过。没有无限重试／替换失败，具体底层原因未定位，不能确认由缓存导致。',
    '首三个新会话没有SQL MCP工具，主通道正常；每个原ID仅尝试一次关闭／恢复，随后canary成功，但实际model／effort变为GPT-6.1 Sol ultra，业务两轮也使用后者。三项业务结果和全部成本保留为混合模型诊断，不能并入Luna对照；按相同原提示另补三项fresh Luna并核实实际模型。连同其余12项，正式15项均Luna medium且canary首次成功；全程初始可用率仍是15/18，不抹除三次失败。没有无限重试，工具不可用的底层原因未定位，不能确认由缓存导致。')
text = text.replace('业务任务中另一次无必要的sqlite_master定义查询被白名单正确拒绝，Agent随后通过已授权业务对象完成；',
    '业务任务中一次无必要的sqlite_master定义查询、一次违反已公布FROM子查询限制的SQL均被正确拒绝；后者还先猜错温度指标名，随后按元数据和CTE恢复。两项最终均完成；')
text = text.replace('三项恢复后的上下文也会进入后续业务。', '三项混合模型恢复记录已排除，正式对照均为fresh Luna；仍不能控制别名背后的provider采样或服务端模型快照。')
replacements = {
    '| MCP返回次数 | 78 | 72 | -7.69% |': '| MCP返回次数 | 78 | 73 | -6.41% |',
    '| 模型响应次数 | 89 | 80 | -10.11% |': '| 模型响应次数 | 89 | 85 | -4.49% |',
    '| 输入token | 2,881,185 | 2,861,859 | -0.67% |': '| 输入token | 2,881,185 | 2,696,167 | -6.42% |',
    '| 其中缓存输入token | 2,792,704 | 2,783,744 | -0.32% |': '| 其中缓存输入token | 2,792,704 | 2,611,328 | -6.49% |',
    '| 输出token | 18,466 | 24,787 | +34.23% |': '| 输出token | 18,466 | 20,890 | +13.13% |',
    '| 总token | 2,899,651 | 2,886,646 | -0.45% |': '| 总token | 2,899,651 | 2,717,057 | -6.30% |',
    '业务阶段排除前置／恢复响应的用量，但恢复文字仍可影响后续上下文。若计入全部前置与恢复，九项总token **3,614,931→3,871,717，+7.10%**。':
    '业务阶段排除前置响应用量。计入正式九项Luna自身前置检查，总token **3,614,931→3,377,135，-6.58%**；不混入三项不同模型的恢复诊断。此前混合模型口径的+7.10%已撤回，原记录保留。',
    '设备巡检调用29→23，知识盘点31→32，FTS18→17；业务输入分别约+2.00%、-11.52%、+15.75%。仅看无需恢复的六项子集':
    '设备巡检调用29→25，知识盘点31→31，FTS18→17；业务输入分别约+8.30%、-22.36%、+1.27%。仅看先前已完成的六项同模型子集',
    '总体业务用量近持平、任务可完成': '本样本总体业务用量下降、任务可完成',
    '15个新任务全部输入5,957,369／输出40,478／总5,997,847；其中30轮业务输入4,534,444／输出36,645／总4,571,089。':
    '15个纯Luna任务全部输入5,467,612／输出35,653／总5,503,265；其中30轮业务输入4,368,752／输出32,748／总4,401,500。另三项混合诊断输入1,621,495／输出12,035／总1,633,530；18会话合计输入7,089,107／输出47,688／总7,136,795，均为实际计数，混合模型不能直接按同一价格推账单。',
    '所有15个子代理均已关闭。': '全部18个子代理均已关闭。另保留实际模型审计纠正：先前仅按spawn请求贴Luna标签不充分，已撤回混合口径，用三项fresh同模型补足；未来关闭／恢复后必须逐轮核验实际model／effort。',
}
for before, after in replacements.items():
    assert before in text, before
    text = text.replace(before, after)
p.write_text(text)
print(json.dumps({'same_model_business_total_token': metrics['total_tokens'],
                  'selected_luna_15': d['all_usage']['total_tokens'],
                  'operational_18_total': value['all_18_threads_usage']['total_tokens']}))
