"""Verify unchanged runtime/old seals, export public evidence and seal once."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote
import zipfile

from sql_safety_executor import load_config

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
E = BATCH / 'evidence'
PUBLIC = ROOT / 'docs/validation/v3.8/v382_complete_agent_eval_2026_10_20'
assert not (BATCH / 'manifest.json').exists() and not (PUBLIC / 'manifest.json').exists()
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
config = load_config(ROOT / 'config/server.toml')
frozen = json.loads((E / 'frozen.json').read_text())
summary = json.loads((E / 'summary.json').read_text())
assert summary['business_passed'] == 15 and summary['initial_canary_passed'] == 15
assert summary['all_replayed_sql_matches'] and summary['independently_replayed_sql'] == 60
models = json.loads((E / 'model_context_check.json').read_text())
assert models['verified'] and len(models['selected_trials']) == 15 and len(models['historical_trials']) == 9
assert all(r['valid_luna_medium'] for r in models['selected_trials'] + models['historical_trials'])
metrics = json.loads((E / 'final_metrics.json').read_text())
assert metrics['operational_threads'] == 18 and metrics['first_canary_failure'] == 3
assert metrics['same_model_business']['total_tokens']['new'] == 2717057
assert json.loads((E / 'config_connection_check.json').read_text())['all_new_present_in_toml_and_host']
assert json.loads((E / 'after_data.json').read_text())['all_checks_passed']
for alias, value in frozen['sqlite_files'].items():
    assert digest(Path(config.connections[alias].sqlite_database_path)) == value['file_sha256']
for name, value in frozen['private_config_hashes'].items():
    assert digest(ROOT / 'config' / name) == value
package = ROOT / 'src/sql_safety_executor'
resources = {str(p.relative_to(package)): digest(p) for p in package.rglob('*')
             if p.is_file() and p.suffix in {'.py', '.md'}}
assert resources == frozen['runtime_resources'] and len(resources) == 77
parent = ROOT / 'local_archive/v382_review/20261020_read_plan_repair'
parent_summary = json.loads((parent / 'evidence/summary.json').read_text())
wheel = parent / parent_summary['durable_wheel']
assert digest(wheel) == parent_summary['wheel_sha256']
with zipfile.ZipFile(wheel) as archive:
    assert (ROOT / 'README.md').read_text().strip() in archive.read('llm_sql_safety_executor_mcp-3.8.2.dist-info/METADATA').decode()
prior = json.loads((parent / 'resident_restart/evidence/native_plan.json').read_text())['previous_seals']
paths = [ROOT / x['manifest'] for x in prior] + [parent / 'resident_restart/manifest.json',
    ROOT / 'docs/validation/v3.8/v382_read_plan_repair_2026_10_20/resident_restart/manifest.json']
old_files = 0
for manifest in paths:
    files = json.loads(manifest.read_text())['files']
    entries = files.items() if isinstance(files, dict) else ((x['path'], x) for x in files)
    for name, entry in entries:
        p = manifest.parent / name
        assert p.stat().st_size == entry['bytes'] and digest(p) == entry['sha256'], str(p)
        old_files += 1
assert len(paths) == 35 and old_files == 861
for trial in summary['trials']:
    record = json.loads(gzip.decompress((E / f"{trial['task']}_{trial['trial']}_complete.json.gz").read_bytes()))
    for event in record['events']:
        assert event['type'] != 'reasoning'
        if event.get('role') == 'assistant':
            assert event['message_phase'] in ('final', 'final_answer', 'commentary')
    for observation in record['observations']:
        token = observation['body'].get('preview_token')
        assert token is None or token.startswith('[REDACTED_PREVIEW_HANDLE_')
        assert observation['body'].get('mode') != 'execute'
names = subprocess.check_output(['git', 'diff', '--name-only', '--', '*.md'], cwd=ROOT, text=True).splitlines()
names += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', '*.md'], cwd=ROOT, text=True).splitlines()
names += [str(p.relative_to(ROOT)) for p in BATCH.rglob('*.md')]
names += ['AI_COLLABORATION_GUIDE.md', 'local_archive/AGENT_WORKFLOW_PLAYBOOK_ZH.md',
    'local_archive/v382_review/README.md', 'local_archive/v382_review/handoff/codex-sql-mcp-readiness.md',
    'local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md']
checked = 0
for name in sorted(set(names)):
    p = ROOT / name
    if not p.is_file():
        continue
    for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^\n)]*)\)', p.read_text()):
        target = target.strip().split(' "', 1)[0].strip('<>')
        if not target or re.match(r'[a-zA-Z][a-zA-Z0-9+.-]*:', target):
            continue
        relative = unquote(target.split('#', 1)[0])
        if relative:
            assert (p.parent / relative).exists(), (name, relative)
            checked += 1
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
verification = {'verified_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'complete_model_verified_scoped_acceptance', 'selected_luna_tasks': 15,
    'operational_threads_including_diagnostics': 18, 'actual_contexts_verified': {'new': 15, 'historical': 9},
    'business_success': '15/15', 'sql_replay': '60/60', 'configured_connections': 16,
    'private_config_changed': False, 'configured_business_writes': False,
    'runtime_resources_unchanged_and_match_installed': 77,
    'prior_manifests_verified': 35, 'prior_file_records_verified': 861,
    'markdown_local_links_verified': checked, 'diff_check_passed': True,
    'limits': 'Model-verified same-prompt historical comparisons are descriptive, not causal source A/B, guidance ablation, billing or universal performance. Three initial failures and recovered mixed models remain visible diagnostics. No new runtime/full-suite/install/restart claim.'}
(E / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n')
selected = ['frozen.json', 'summary.json', 'final_metrics.json', 'verification.json',
    'config_connection_check.json', 'contract_and_cost_context.json', 'after_data.json',
    'model_context_check.json', 'manual_review.json', 'agents_selected_final.json',
    'agents_operational_all_final.json', 'initial_canary_failures.json', 'preparation_notes.json',
    'sql_replay.json.gz']
selected += [p.name for p in sorted(E.glob('*_complete.json.gz'))]
for name in selected:
    p = E / name
    filename = name if p.suffix == '.gz' else name + '.gz'
    out = PUBLIC / filename; assert not out.exists()
    out.write_bytes(p.read_bytes() if p.suffix == '.gz' else gzip.compress(p.read_bytes(), mtime=0))
for p in sorted((E / 'diagnostics').rglob('*')):
    if not p.is_file():
        continue
    filename = str(p.relative_to(E)) + ('' if p.suffix == '.gz' else '.gz')
    out = PUBLIC / filename;out.parent.mkdir(parents=True, exist_ok=True);assert not out.exists()
    out.write_bytes(p.read_bytes() if p.suffix == '.gz' else gzip.compress(p.read_bytes(), mtime=0))
for p in sorted((BATCH / 'scripts').glob('*.py')):
    out = PUBLIC / (p.name + '.gz');assert not out.exists()
    out.write_bytes(gzip.compress(p.read_bytes(), mtime=0))
for root in (BATCH, PUBLIC):
    files = {str(p.relative_to(root)): {'bytes': p.stat().st_size, 'sha256': digest(p)}
             for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts
             and p.name != 'manifest.json'}
    (root / 'manifest.json').write_text(json.dumps({'date': '2026-10-20',
        'checkpoint': verification['status'], 'files': files,
        'append_rule': 'Keep all selected/mixed/failure evidence and old manifests immutable; append later work.'}, indent=2) + '\n')
    print(str(root.relative_to(ROOT)), len(files), 'files sealed')
print(json.dumps(verification))
