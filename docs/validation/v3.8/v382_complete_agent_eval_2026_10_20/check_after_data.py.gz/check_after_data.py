"""Independently confirm configured data/config/source stayed unchanged."""
import hashlib
import json
from pathlib import Path

from sql_safety_executor import load_config
from sql_safety_executor.database.mysql import MySQLAdapter

ROOT = Path(__file__).resolve().parents[4]
E = Path(__file__).resolve().parents[1] / 'evidence'
OUT = E / 'after_data.json'
assert not OUT.exists()
frozen = json.loads((E / 'frozen.json').read_text())
config = load_config(ROOT / 'config/server.toml')
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sqlite = {alias: {'file_sha256': digest(Path(config.connections[alias].sqlite_database_path))}
          for alias in frozen['sqlite_files']}
assert sqlite == frozen['sqlite_files']
current_config = {name: digest(ROOT / 'config' / name) for name in frozen['private_config_hashes']}
assert current_config == frozen['private_config_hashes']
package = ROOT / 'src/sql_safety_executor'
resources = {str(p.relative_to(package)): digest(p) for p in package.rglob('*')
             if p.is_file() and p.suffix in {'.py', '.md'}}
assert resources == frozen['runtime_resources']
adapter = MySQLAdapter(config.connections['sakila_mysql'])
try:
    assert adapter.connect()
    sakila = {}
    with adapter._engine.connect() as db:
        for name in frozen['sakila_before']:
            rows = [tuple(r) for r in db.exec_driver_sql('SELECT * FROM ' + name + ' ORDER BY 1')]
            sakila[name] = {'rows': len(rows), 'sha256': hashlib.sha256(json.dumps(rows, default=str, ensure_ascii=False).encode()).hexdigest()}
    assert sakila == frozen['sakila_before']
finally:
    adapter.close()
OUT.write_text(json.dumps({'all_checks_passed': True, 'sqlite_files': sqlite,
    'sakila': sakila, 'private_config_hashes': current_config,
    'runtime_resources_match': len(resources), 'configured_connections': sorted(config.connections),
    'scope': 'Read-only independent after-check; no global/config changes or compensating write.'}, indent=2) + '\n')
print(json.dumps({'sqlite_files_unchanged': len(sqlite), 'sakila_tables_unchanged': len(sakila),
                  'private_toml_files_unchanged': len(current_config), 'runtime_resources_unchanged': len(resources)}))
