"""Read-only backend identity and fixture cleanup check; do not export secrets."""
import json
from pathlib import Path
import sys

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / 'scripts/validation'))
from mysql_writes import Fixture
from sql_safety_executor import load_config

fixture = Fixture(load_config(ROOT / 'config/server.toml').connections['sakila_mysql'])
with fixture.connect(schema=False, autocommit=True) as db:
    with db.cursor() as cur:
        cur.execute('SELECT VERSION(),@@lower_case_table_names,@@SESSION.sql_mode')
        version, case_rule, modes = cur.fetchone()
        cur.execute("SELECT COUNT(*) FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME REGEXP '^mcp_contract_[0-9a-f]{16}$'")
        remaining = cur.fetchone()[0]
assert version == '8.0.25' and remaining == 0
path = ROOT / 'local_archive/v382_review/20261022_stabilization/evidence/postflight.json'
assert not path.exists()
path.write_text(json.dumps({'passed':True,'version':version,'lower_case_table_names':case_rule,
    'sql_modes':sorted(modes.split(',')) if modes else [],'remaining_contract_fixture_schemas':remaining,
    'configured_business_writes':0,'scope':'read-only server/session identity and bounded fixture-prefix count; no host/account/session IDs exported'}, indent=2)+'\n')
print(json.dumps({'passed':True,'mysql':version,'remaining_fixture_schemas':remaining}))
