"""Freeze finite stabilization coverage before executing supplement cases."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd()
HERE = ROOT / 'local_archive/v382_review/20261022_stabilization'
E = HERE / 'evidence'
E.mkdir(parents=True, exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
last = ROOT / 'local_archive/v382_review/20261022_mysql_write_contracts/resident_restart'
before = json.loads((last / 'evidence/before.json').read_text())
resources = {str(p.relative_to(ROOT / 'src/sql_safety_executor')): sha(p)
             for p in (ROOT / 'src/sql_safety_executor').rglob('*') if p.is_file() and p.suffix in {'.py', '.md'}}
assert resources == before['resources']
prior = dict(before['prior_manifest_digests'])
certified = before['certified_manifests']
for path in [last / 'manifest.json', ROOT / 'docs/validation/v3.8/v382_mysql_write_contracts_2026_10_22/resident_restart/manifest.json']:
    name = str(path.relative_to(ROOT)); prior[name] = sha(path)
    certified.append({'manifest': name, 'sha256': sha(path)})
assert len(certified) == 85
for name, digest in before['configuration'].items(): assert sha(ROOT / name) == digest
for name, digest in prior.items(): assert sha(ROOT / name) == digest

# Inspect the actual assertions in these functions. Full-suite status alone
# is not an independent database oracle; the explicit categories below matter.
families = [
 ('C01', ['test_read_analysis_binding_v382'], ['test_mysql_mismatched_source_never_reaches_executor', 'test_mysql_matching_source_preserves_original_and_bindings', 'test_sqlite_mismatched_source_retains_preconnect_rejection'], 'zero-DB dispatch controls; live MySQL initial/reuse/reconnect reused'),
 ('C02', ['test_structured_grants_v382'], ['test_structured_name_is_not_reparsed_as_a_grant'], 'independent sqlite3 fixture; raw/Skill/metadata/sample'),
 ('C03', ['test_sqlite_authorizer_v382','test_sql_semantics_v382'], ['test_metadata_and_reads_share_exact_name_components','test_mysql_invalid_physical_names_are_not_trimmed','test_physical_trailing_space_rule_is_not_applied_to_other_roles'], 'actual SQLite names; MySQL role unit checks; live legal names supplemented'),
 ('C04', ['test_schema_binding_review'], ['test_internal_reads_remain_in_authorized_main'], 'independently seeded main/temp/aux and captured exact generated SQL'),
 ('C05', ['test_attached_json_readiness_v382'], ['test_attached_binding_shared_by_skill_discovery_detail_and_precheck','test_incomplete_json_observation_does_not_poison_known_default_scope'], 'real attached FTS, readiness details/discovery/precheck; injected partial observation labelled'),
 ('C06', ['test_sql_semantics_v382','test_sqlite_authorizer_v382'], ['test_scope_order_does_not_hide_physical_self_or_forward_reference','test_sqlite_forward_and_implicit_recursive_visibility_match_native','test_view_grant_cannot_be_reused_through_cte_or_direct_union'], 'native sqlite3 CTE values and distinct physical grant controls'),
 ('C07', ['test_relation_calls_columns_v382','test_fts_followups_v382','test_fts_catalog_statistics_v382'], ['test_relation_call_roles_names_and_skill_dependencies','test_fts_content_definition_changes_are_checked_on_each_read','test_fts_catalog_collision_across_raw_skill_and_metadata'], 'real FTS plus cold/warm definition/catalog changes; direct-shadow negatives retained'),
 ('C08', ['test_fts_followups_v382','test_read_boundaries_v382'], ['test_external_content_guard_is_shared_across_public_entries'], 'harmless UDF counter zero; existing read_boundaries stdio replay supplements normal views/plans'),
 ('C09', ['test_primary_key_metadata_v382','test_sqlite_declared_types_v382','test_fts_catalog_statistics_v382'], ['test_sqlite_positions_follow_native_constraint_not_column_order','test_types_all_projections_groups_and_read_semantics','test_table_estimates_use_table_or_full_index_sources'], 'native PRAGMA/catalog truth; real MySQL columns and PRIMARY supplemented'),
 ('C10', ['test_read_results_v382'], ['test_query_and_skill_result_contract'], 'literal/native labels; MySQL real raw/Skill duplicate-label supplement'),
 ('C11', ['test_read_results_v382'], ['test_sample_encodes_binary_and_keeps_empty_result'], 'known byte sequences; MySQL raw/Skill/sample binary supplement'),
 ('C12', ['test_read_results_v382'], ['test_all_read_entries_limit_wide_first_row','test_limit_uses_actual_protocol_number_and_escape_encoding'], 'Pydantic actual compact protocol data size; MySQL wide-row supplement'),
 ('C13', ['test_read_boundaries_v382','test_sqlite_predicate_collate_v382'], ['test_nonexecuting_dml_plan_preserves_data_and_scope','test_predicate_tail_precedence_and_right_operand_collation'], 'native plan/data checks; installed_semantics and read_boundaries real-stdio supplement'),
 ('C14', ['test_managed_classification_reuse_v382'], ['test_warm_classification_does_not_reuse_execution_permission','test_consumed_confirmation_resolves_target_even_when_warm'], 'warm pure classification with live permission/context/token controls; labelled injected failures'),
 ('C15', ['test_sqlite_authorizer_v382'], ['test_trusted_preparation_and_metadata_do_not_poison_reused_read','test_udf_exception_restores_context_and_progress_handler','test_physical_connection_is_owned_until_result_consumption'], 'actual physical SQLite callbacks/threads; live MySQL binding/lifecycle reused'),
 ('C16', ['test_sqlite_write_transactions_v382'], [], 'reuse sealed real private-file/real InnoDB lifecycle matrices and independent post-cleanup truth; no full repeat'),
]
rows = []
selected = []
for code, modules, names, oracle in families:
    found = {}
    for module in modules:
        path = ROOT / 'tests' / (module + '.py')
        tree = ast.parse(path.read_text())
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in names:
                selector = str(path.relative_to(ROOT)) + '::' + node.name
                found[node.name] = selector
    assert set(found) == set(names), (code, set(names) - set(found))
    selectors = [found[name] for name in names]
    selected.extend(s for s in selectors if s not in selected)
    rows.append({'id': code, 'selectors': selectors, 'test_files': {
        'tests/' + module + '.py': sha(ROOT / 'tests' / (module + '.py')) for module in modules},
        'oracle_review': oracle, 'status': 'frozen; not yet accepted'})
gaps = [
 {'id': 'G01', 'scope': 'current source and existing normal wheel SQLite child-stdio semantic/view/plan parity', 'scripts': ['scripts/validation/installed_semantics.py', 'scripts/validation/read_boundaries.py']},
 {'id': 'G02', 'scope': 'current live MySQL raw/Query Skill/sample results, bounded schema projection and legal literal names; both Client modes/transports', 'script': 'scripts/validation/stabilization_mysql_reads.py'},
 {'id': 'G03', 'scope': 'finite selected current-source hot-state cross-entry contract cases', 'selectors': selected},
 {'id': 'G04', 'scope': 'test effectiveness: reuse actual known-bad source sentinels and independent lifecycle faults; add two bounded result-boundary variants with positive controls', 'script': 'local_archive/v382_review/20261022_stabilization/scripts/result_sentinels.py'},
]
result = {'date': '2026-10-22', 'version': '3.8.2', 'resources': resources, 'configuration': before['configuration'],
          'prior_manifest_digests': prior, 'certified_manifests': certified, 'fully_verified_prior_seals': 85,
          'prior_sealed_records': 2809, 'families': rows, 'gaps': gaps,
          'reuse': {'latest_full_suite': 'local_archive/v382_review/20261022_mysql_write_contracts/evidence/full_tests_final.log',
                   'full_suite_scope': '3505 passed/four optional skipped; explicitly enabled MySQL four passed separately',
                   'mysql': 'local_archive/v382_review/20261022_mysql_write_contracts/evidence',
                   'sqlite': 'local_archive/v382_review/20261022_sqlite_write_repair',
                   'sqlite_resource_delta': 'only database/mysql.py differs from last real SQLite write evidence; verify before reuse'},
          'exclusions': ['new SQL capabilities/engines/modes', 'MariaDB', 'unapproved configured writes/grants/config edits',
                         'all-network-fault simulation', 'fresh model/token/performance claims', 'new generic cache/framework'],
          'recording': 'application results and independent database observations; not complete wire frames'}
path = E / 'frozen_plan.json'
assert not path.exists(), 'Do not rewrite a frozen plan'
path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(E / 'selectors.txt').write_text('\n'.join(selected) + '\n')
print(json.dumps({'passed': True, 'families': len(rows), 'function_selectors': len(selected), 'gaps': len(gaps), 'prior_seals': len(certified)}))
