"""Audit frozen scope, current supplement and independent reused evidence."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path.cwd()
HERE = ROOT/'local_archive/v382_review/20261022_stabilization'
E = HERE/'evidence'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def read(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)


def verify_manifest(path):
    manifest = read(path); count = 0; resolved = {}
    entries = manifest['files']
    entries = entries.items() if isinstance(entries,dict) else ((r['path'],r) for r in entries)
    for name, meta in entries:
        p = next(p for p in (path.parent/name,path.parent.parent/name,ROOT/name) if p.is_file())
        raw=p.read_bytes();resolved[name]=p
        assert sha(raw)==(meta['sha256'] if isinstance(meta,dict) else meta),(path,name)
        if isinstance(meta,dict):
            if 'bytes' in meta:assert len(raw)==meta['bytes']
            if 'decoded_sha256' in meta:
                decoded=gzip.decompress(raw);assert sha(decoded)==meta['decoded_sha256'] and len(decoded)==meta['decoded_bytes']
        count+=1
    for name,meta in manifest.get('compressed_decoded_records',{}).items():
        decoded=gzip.decompress(resolved[name].read_bytes())
        assert sha(decoded)==meta.get('decoded_sha256',meta.get('sha256')) and len(decoded)==meta.get('decoded_bytes',meta.get('bytes'))
    return count


def stable(value):
    if isinstance(value,dict):return {k:stable(v) for k,v in value.items() if k not in {'execution_ms','elapsed_ms'}}
    if isinstance(value,list):return [stable(v) for v in value]
    if isinstance(value,str):return re.sub(r'mcp_contract_[0-9a-f]{16}', '<owned-schema>', value)
    return value


plan=read(E/'frozen_plan.json')
current={str(p.relative_to(ROOT/'src/sql_safety_executor')):sha(p.read_bytes()) for p in (ROOT/'src/sql_safety_executor').rglob('*') if p.is_file() and p.suffix in {'.py','.md'}}
assert current==plan['resources'] and len(current)==77
for name,digest in plan['configuration'].items():assert sha((ROOT/name).read_bytes())==digest
for name,digest in plan['prior_manifest_digests'].items():assert sha((ROOT/name).read_bytes())==digest
records=0
for spec in plan['certified_manifests']:
    path=ROOT/spec['manifest'];assert sha(path.read_bytes())==spec['sha256'];records+=verify_manifest(path)
assert len(plan['certified_manifests'])==85 and records==2809

junit=ET.parse(E/'selected_tests.xml').getroot()
cases=junit.findall('.//testcase')
assert len(cases)==254 and not junit.findall('.//failure') and not junit.findall('.//error') and not junit.findall('.//skipped')
for family in plan['families']:
    for name,digest in family['test_files'].items():assert sha((ROOT/name).read_bytes())==digest
    for selector in family['selectors']:
        path,function=selector.split('::');module=path[:-3].replace('/','.')
        assert any(c.attrib['classname']==module and (c.attrib['name']==function or c.attrib['name'].startswith(function+'[')) for c in cases),selector

applications={}
for stage in ('source','installed'):
    data=[]
    for script,hash_key,expected in [('installed_semantics','installed_source_sha256',130),('read_boundaries','source_sha256',74)]:
        record=read(E/f'{stage}_{script}.json.gz')
        assert record[hash_key]==current and record['calls']==len(record['records'])==expected
        for call in record['records']:
            assert not call['isError']
        data.extend(record['records'])
    mysql=read(E/f'{stage}_mysql_reads_attempt1.json.gz')
    assert mysql['passed'] and mysql['disposable_schema_removed'] and mysql['transactional_business_truth_unchanged']
    assert mysql['resources']==current and len(mysql['calls'])==128
    assert {(r['transport'],r['mode']) for r in mysql['calls']}=={(t,m) for t in ('inprocess','stdio') for m in ('auto','legacy')}
    assert mysql['oracle']['primary_positions']=={'a':1,'b':2}
    assert all(r['text_structured_agree'] for r in mysql['calls'])
    applications[stage]={'sqlite':len(data),'mysql':len(mysql['calls']),'total':len(data)+len(mysql['calls'])}
assert applications['source']==applications['installed']=={'sqlite':204,'mysql':128,'total':332}
for script in ('installed_semantics','read_boundaries','mysql_reads_attempt1'):
    a=read(E/f'source_{script}.json.gz');b=read(E/f'installed_{script}.json.gz')
    key='calls' if script=='mysql_reads_attempt1' else 'records'
    assert stable(a[key])==stable(b[key]),('source/wheel semantics differ',script)

mysql_root=ROOT/'local_archive/v382_review/20261022_mysql_write_contracts/evidence'
sqlite_root=ROOT/'local_archive/v382_review/20261022_sqlite_write_repair/resident_restart/evidence'
reused={}
for stage,name in [('source','source_attempt3.json.gz'),('installed','installed_final.json.gz')]:
    mysql=read(mysql_root/name)
    assert mysql['passed'] and mysql['resources']==current
    assert len(mysql['matrix'])==14 and len(mysql['faults'])==19 and len(mysql['concurrency'])==3
    assert mysql['server']['version']=='8.0.25' and mysql['engines']==['InnoDB']
    for row in mysql['matrix']:
        committed,rolled=row['phases']
        assert committed['result']['outcome']=='committed' and committed['post_cleanup_truth']==row['native_after']
        assert rolled['result']['outcome']=='rolled_back' and rolled['post_cleanup_truth']==row['native_before']
    fault={r['case']:r for r in mysql['faults']}
    for label,errno in [('duplicate',1062),('trigger',1644),('foreign-key',1452),('lock-wait-timeout',1205),('deadlock-victim',1213)]:
        assert fault[label]['result']['mysql_errno']==errno and fault[label]['kind']=='real-server-error'
    for row in mysql['faults']:
        if row['kind']=='labelled-client-injection':assert row['injection_hits']
    assert fault['commit-before']['result']['outcome']==fault['commit-after']['result']['outcome']=='unknown'
    assert fault['commit-before']['post_cleanup_truth']['orders'][0][1]==7 and fault['commit-after']['post_cleanup_truth']['orders'][0][1]==99
    unknown=read(mysql_root/f'{stage}_unknown.json.gz')
    assert unknown['passed'] and unknown['resources']==current and len(unknown['client_truth'])==8
    assert all(row['adapter_write_attempts']==1 for row in unknown['client_truth'])
    assert mysql['disposable_schema_removed'] and unknown['disposable_schema_removed']
    sqlite=read(sqlite_root/f'adjacent_{stage}.json.gz')
    delta=[key for key in current if current[key]!=sqlite['resources'][key]]
    assert delta==['database/mysql.py'] and sqlite['passed']
    assert sqlite['matrix_cases']==120 and sqlite['adapter_attempts']==254
    for row in sqlite['records']:
        committed,rolled=row['adapter_phases']
        assert committed['outcome']=='committed' and committed['post_cleanup_rows']==row['native_after']
        assert rolled['outcome']=='rolled_back' and rolled['post_cleanup_rows']==row['native_before']
    reused[stage]={'mysql_groups':14,'mysql_faults':19,'sqlite_cases':120,'sqlite_attempts':254,'sqlite_resource_delta':delta,
                   'reuse_reason':'only MySQL-specific module differs; SQLite write/transaction/shared resources unchanged'}

binding=read(mysql_root/'binding_sentinels.json')
assert binding['passed'] and binding['database_statements']==0 and len(binding['records'])==10
bad=read(sqlite_root/'sentinels_known_bad.json');good=read(sqlite_root/'sentinels_current.json')
assert bad['passed'] and good['passed'] and all(r['invariant_violated'] for r in bad['records']) and not any(r['invariant_violated'] for r in good['records'])
sentinel_resources={k.removeprefix('sql_safety_executor/'):v for k,v in good['resources'].items()}
assert set(sentinel_resources)==set(current)
assert [k for k in current if current[k]!=sentinel_resources[k]]==['database/mysql.py']
sentinels=read(E/'result_sentinels.json')
assert sentinels['passed'] and len(sentinels['records'])==2
assert sentinels['source_sha256']==current['core/results.py']
assert all(r['injection_hits']==1 and r['target_contract_detected'] for r in sentinels['records'])
assert read(E/'postflight.json')['remaining_contract_fixture_schemas']==0
latest_native=read(ROOT/'local_archive/v382_review/20261022_mysql_write_contracts/resident_restart/evidence/checks.json')
assert latest_native['passed'] and latest_native['native_passed']==6

families=[]
for row in plan['families']:
    entry=dict(row)
    entry['status']='accepted in frozen scope'
    entry['fresh_selected_cases']=sum(1 for c in cases if any(c.attrib['classname']==s.split('::')[0][:-3].replace('/','.') and (c.attrib['name']==s.split('::')[1] or c.attrib['name'].startswith(s.split('::')[1]+'[')) for s in row['selectors']))
    entry['supplementary_evidence']=['source/installed_semantics','source/installed_read_boundaries','source/installed_mysql_reads'] if row['id'] in {'C02','C03','C04','C06','C08','C09','C10','C11','C12','C13'} else []
    if row['id']=='C16':entry['supplementary_evidence']=['sealed SQLite real lifecycle matrices (unchanged SQLite/shared resources)','sealed current-source/package real MySQL lifecycle matrices','known-bad source sentinels']
    families.append(entry)
path=E/'checks.json'
assert not path.exists()
result={'passed':True,'families':families,'accepted_families':16,'frozen_gaps_closed':4,'selected_tests_passed':254,'selected_tests_skipped':0,
        'applications_per_stage':applications,'reused_write_evidence':reused,'new_result_variants_detected':2,
        'reused_known_bad_families':{'sqlite':2,'mysql':5},'previous_full_suite':'3505 passed/four optional skips; not rerun',
        'old_certified_seals_verified':85,'old_file_records_verified':records,'manifest_digests_unchanged':len(plan['prior_manifest_digests']),
        'runtime_resources_unchanged':77,'private_tomls_unchanged':3,'configured_business_writes':0,'runtime_changes':0,
        'gates':{'transactional_business_truth':'passed in declared scope; actual failures versus injections preserved',
                 'cross_entry_contracts':'passed in the frozen 16-family matrix; documented temp/schema/parser boundaries retained',
                 'test_effectiveness':'target-detecting historical sentinels plus two function variants, positive controls and independent truth'},
        'new_model_trials':0,'new_performance_claim':False,'new_token_claim':False,'further_restart_required':False,
        'limits':['finite declared capabilities, not proof of no remaining defects','real unknown client injection in-process, not arbitrary packet-loss proof',
                  'existing MySQL trusted temporary-object/session contract retained','native6/6 is reused within its read/refusal scope, not a new native full-matrix/write run',
                  'no new model interpretation or cost evidence; prior weak wording1/3 retained','application results are not full protocol frames']}
path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in {'families','reused_write_evidence','limits'}},ensure_ascii=False))
