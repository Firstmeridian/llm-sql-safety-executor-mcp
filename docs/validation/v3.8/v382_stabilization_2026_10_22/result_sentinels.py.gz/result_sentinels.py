"""Two isolated, target-specific result-boundary variants with positive controls.

Compile altered function objects in private namespaces; no source file is edited.
An unrelated exception never counts as a detected target defect.
"""
import ast
import hashlib
import inspect
import json
from pathlib import Path
import sqlite3
from types import SimpleNamespace

from sqlalchemy import create_engine
from sql_safety_executor.core import results

ROOT = Path.cwd()
E = ROOT / 'local_archive/v382_review/20261022_stabilization/evidence'
runtime = SimpleNamespace(config=SimpleNamespace(server=SimpleNamespace(limits=SimpleNamespace(result_rows=100, result_chars=16000))))


def variant(kind):
    functions = [results._serialize_result, results._truncate_result, results._prepare_read_result]
    tree = ast.parse('\n\n'.join(inspect.getsource(f) for f in functions))
    class Change(ast.NodeTransformer):
        hits = 0
        def visit_If(self, node):
            self.generic_visit(node)
            if kind == 'duplicate-label-check' and ast.unparse(node.test) == 'len(set(labels)) != len(labels)':
                self.hits += 1
                return []
            if kind == 'first-row-limit' and ast.unparse(node.test) == 'candidate > char_limit':
                self.hits += 1
                node.test = ast.BoolOp(op=ast.And(), values=[node.test, ast.Compare(left=ast.Name(id='returned_rows',ctx=ast.Load()), ops=[ast.Gt()], comparators=[ast.Constant(value=0)])])
            return node
    change = Change()
    tree = ast.fix_missing_locations(change.visit(tree))
    assert change.hits == 1, 'Variant did not hit the intended contract branch'
    namespace = dict(vars(results))
    exec(compile(tree, '<isolated-result-variant>', 'exec'), namespace)
    return namespace['_prepare_read_result'], change.hits


def observation(function, rows):
    try:
        value = function(runtime, rows)
        return {'error_code': None, 'row_count': value['row_count'],
                'data_chars': len(results.to_json(value['data']).decode('utf-8')),
                'first_n': value['data'][0].get('n') if value['data'] else None}
    except results.ReadResultError as error:
        return {'error_code': error.error_code}


with sqlite3.connect(':memory:') as native:
    cur = native.execute('SELECT 7 AS n,99 AS n')
    assert [c[0] for c in cur.description] == ['n','n'] and cur.fetchall() == [(7,99)]
engine = create_engine('sqlite:///:memory:')
records = []
try:
    with engine.connect() as db:
        normal = db.exec_driver_sql('SELECT 7 AS n').fetchall()
        duplicate = db.exec_driver_sql('SELECT 7 AS n,99 AS n').fetchall()
        wide = db.exec_driver_sql("SELECT printf('%.*c',20000,'x') AS payload").fetchall()
    for kind, rows in [('duplicate-label-check',duplicate), ('first-row-limit',wide)]:
        bad, hits = variant(kind)
        control_current = observation(results._prepare_read_result, normal)
        control_variant = observation(bad, normal)
        assert control_current == control_variant and control_current['first_n'] == 7
        current = observation(results._prepare_read_result, rows)
        broken = observation(bad, rows)
        if kind == 'duplicate-label-check':
            assert current == {'error_code':'duplicate_result_columns'}
            assert broken['error_code'] is None and broken['row_count'] == 1 and broken['first_n'] == 99
        else:
            assert current['error_code'] is None and current['row_count'] == 0 and current['data_chars'] <= 16000
            assert broken['error_code'] is None and broken['row_count'] == 1 and broken['data_chars'] > 16000
        records.append({'kind':kind,'injection_hits':hits,'current':current,'variant':broken,
                        'positive_control':control_current,'target_contract_detected':True})
finally:
    engine.dispose()
path = E / 'result_sentinels.json'
assert not path.exists()
path.write_text(json.dumps({'passed':True,'records':records,'source_sha256':hashlib.sha256(Path(results.__file__).read_bytes()).hexdigest(),
    'scope':'two private function variants; not real historical versions or exhaustive mutation testing; native duplicate-label truth and unchanged positive controls'}, indent=2)+'\n')
print(json.dumps({'passed':True,'target_variants_detected':2,'positive_controls_passed':2}))
