"""Append one stabilization checkpoint; never modify previous sealed evidence."""
import ast
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

ROOT=Path.cwd()
HERE=ROOT/'local_archive/v382_review/20261022_stabilization'
E=HERE/'evidence'
PUBLIC=ROOT/'docs/validation/v3.8/v382_stabilization_2026_10_22'
PUBLIC.mkdir(exist_ok=True)
assert not (HERE/'manifest.json').exists() and not (PUBLIC/'manifest.json').exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def packed(path,destination):
    destination.write_bytes(path.read_bytes() if path.suffix=='.gz' else gzip.compress(path.read_bytes(),mtime=0))


files=[]
for folder in (E,HERE/'scripts'):
    for path in sorted(folder.iterdir()):
        if not path.is_file() or path.name=='documentation_checks.json':continue
        name=path.name if path.suffix=='.gz' else path.name+'.gz'
        packed(path,PUBLIC/name);files.append(name)
for name in ('stabilization_mysql_reads','mysql_writes','installed_semantics','read_boundaries'):
    path=ROOT/'scripts/validation'/f'{name}.py'
    packed(path,PUBLIC/path.with_suffix('.py.gz').name);files.append(path.with_suffix('.py.gz').name)
main='V3_8_2_STABILIZATION_2026_10_22_ZH.md'
(PUBLIC/'README.md').write_text('''# Bounded v3.8.2 stabilization — October 22, 2026

S1–S4 complete within16 frozen contract families and three declared gates.254 selected existing regressions pass/no skips (93 framework deprecation warnings retained). Source/existing normal wheel each332 application calls pass:204 SQLite child-stdio and128 actual MySQL calls across in-process/stdio and auto/legacy. New result variants specifically demonstrate duplicate-label loss and first-row overflow; unchanged positive controls pass. There is no new confirmed P1/P2 in this finite scope, not a defect-free guarantee.

The [acceptance and limitations](../V3_8_2_STABILIZATION_2026_10_22_ZH.md) explain oracle independence, exact source/wheel parity, cross-entry coverage and stop conditions. Existing real write matrices and historical bad-source sentinels are reused only after verifying provenance:77 current MySQL resources match, and SQLite evidence differs solely in the MySQL-specific file. Actual server errors/session loss and labelled client injections remain distinct. MySQL unknown client injections are in-process, not arbitrary packet-loss tests. Native6/6 is reused only in its prior read/refusal scope, not a new native full-matrix/confirmed-write trial.

No runtime, prompt, dependency, private TOML, grant or mandatory Agent-step change. Only disposable SQLite/MySQL fixtures are seeded; the own-schema cleanup helper verifies exact removal and the final bounded prefix count is zero. Keep prior model failures/cost regressions and parser/temp-object boundaries; no new model, speed or token claim. No further restart, build or full-suite rerun is required. The earlier3505 full passes/four optional skips remain a separate checkpoint, not increased by254 selected reruns.

All85 prior certified seals/2809 file records fully verify;128 prior manifest-file digests are unchanged (a different count). Old failed/pending checkpoints remain byte-for-byte unchanged. A preparation KeyError from a historical resource-key prefix is retained separately; it is neither a production defect nor a killed target variant. This new checkpoint is sealed separately; do not rewrite it for later work.

Application results do not reconstruct full wire frames, notifications or model usage. The reusable MySQL script uses the sibling mysql_writes.py ownership/cleanup helper; select an explicitly approved test alias, use --source for source or omit it under the normal-wheel interpreter, and provide a fresh output. It requires disposable-schema privileges and never writes existing business tables. Audit/freeze scripts also require the referenced historical archives; they are evidence-specific, not a standalone portable public test runner.

Evidence and scripts (gzip; encoded/decoded hashes in the manifest):

'''+ '\n'.join(f'- [{name}]({name})' for name in files)+ '\n\n- [Report snapshot](assessment.md.gz)\n- [Documentation check](documentation_checks.json.gz)\n- [Manifest](manifest.json)\n')
documents=[ROOT/name for name in (
 'REFACTORING_LOG.md','REFACTORING_LOG_ZH.md','docs/README.md','docs/README_ZH.md',
 'docs/releases/RELEASE_NOTES_v3_8.md','docs/security/V3_8_SECURITY.md',
 'docs/security/DESIGN_RISK_REGISTER.md','docs/security/DESIGN_RISK_REGISTER_ZH.md',
 'docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md','docs/guides/TEST_MCP_CLIENT_GUIDE.md',
 'docs/validation/v3.8/V3_8_2_STABILIZATION_PLAN_2026_10_22_ZH.md',
 'docs/validation/v3.8/'+main,'local_archive/v382_review/README.md',
 'local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md',
 'local_archive/v382_review/handoff/commit-message-v382.txt')]
packed(ROOT/'docs/validation/v3.8'/main,PUBLIC/'assessment.md.gz')
links=0
for path in documents+[PUBLIC/'README.md',HERE/'reports/README_ZH.md']:
    if path.suffix!='.md':continue
    for value in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)',path.read_text()):
        value=value.strip().strip('<>')
        if re.match(r'[a-zA-Z]+:',value) or value.startswith('#'):continue
        value=unquote(value.split('#',1)[0])
        if not value:continue
        if path==PUBLIC/'README.md' and value in {'documentation_checks.json.gz','manifest.json'}:continue
        destination=Path(value) if value.startswith('/') else path.parent/value
        assert destination.exists(),(str(path),value)
        links+=1
ids=[]
for name in ('docs/security/DESIGN_RISK_REGISTER.md','docs/security/DESIGN_RISK_REGISTER_ZH.md'):
    text=(ROOT/name).read_text();rows=re.findall(r'^\| (DRR-2026-\d+) \|',text,re.M)
    assert len(rows)==len(set(rows)) and re.search(r'^\| DRR-2026-144 .*\n\| DRR-2026-145 ',text,re.M)
    ids.append(set(rows))
assert ids[0]==ids[1]
diff=subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True,text=True)
assert diff.returncode==0,diff.stdout+diff.stderr
# Check actual secret/host/account strings without printing their values.
from sql_safety_executor import load_config
config=load_config(ROOT/'config/server.toml').connections['sakila_mysql']
sensitive=[config.mysql_password.get_secret_value() if config.mysql_password else None,config.mysql_host,config.mysql_user]


def mask_metadata_digests(value, path=()):
    if isinstance(value,dict):return {k:mask_metadata_digests(v,(*path,k)) for k,v in value.items()}
    if isinstance(value,list):return [mask_metadata_digests(v,(*path,str(i))) for i,v in enumerate(value)]
    if isinstance(value,str) and re.fullmatch(r'[0-9a-f]{64}',value):
        if any(k in {'resources','test_files','configuration','prior_manifest_digests','source_sha256','installed_source_sha256'} for k in path) or path[-1].endswith('sha256'):
            return '<integrity-digest>'
    return value


for path in PUBLIC.iterdir():
    if not path.is_file():continue
    raw=gzip.decompress(path.read_bytes()) if path.suffix=='.gz' else path.read_bytes()
    if path.name.endswith('.py.gz'):
        # Source variable names are not exported configured account values.
        constants=[node.value for node in ast.walk(ast.parse(raw.decode())) if isinstance(node,ast.Constant) and isinstance(node.value,str)]
        for index,value in enumerate(sensitive):
            if value and len(value)>=4:
                assert not any(value==literal if index==2 else value in literal for literal in constants),(path.name,'configured literal found; review before publishing')
        continue
    try:raw=json.dumps(mask_metadata_digests(json.loads(raw)),ensure_ascii=False).encode()
    except (json.JSONDecodeError,UnicodeDecodeError):pass
    for value in sensitive:
        if value and len(value)>=4:assert value.encode() not in raw,(path.name,'sensitive value found; do not publish')
checks={'passed':True,'links_checked':links,'diff_check':'passed','bilingual_drr_ids':'same; unique;144/145 contiguous',
        'source_runtime_changes':0,'commit_draft':'English groups updated for independent bounded stability gates',
        'no_export_of_configured_sensitive_values':True,'documents':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in documents}}
(E/'documentation_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
packed(E/'documentation_checks.json',PUBLIC/'documentation_checks.json.gz')
snap=E/'docs';snap.mkdir(exist_ok=True)
for path in documents:packed(path,snap/(str(path.relative_to(ROOT)).replace('/','__')+'.gz'))
for folder in (HERE,PUBLIC):
    entries={}
    for path in sorted(folder.rglob('*')):
        if not path.is_file() or path.name=='manifest.json' or '__pycache__' in path.parts:continue
        raw=path.read_bytes();meta={'bytes':len(raw),'sha256':sha(raw)}
        if path.suffix=='.gz':
            decoded=gzip.decompress(raw);meta.update(decoded_bytes=len(decoded),decoded_sha256=sha(decoded))
        entries[str(path.relative_to(folder))]=meta
    (folder/'manifest.json').write_text(json.dumps({'date':'2026-10-22','checkpoint':'Finite16-family stabilization and scoped three gates passed; no runtime changes',
        'append_rule':'Preserve previous and current seals/failures; append later evidence as a new checkpoint.','files':entries},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':True,'links':links,'private_files':len(json.loads((HERE/'manifest.json').read_text())['files']),
                  'public_files':len(json.loads((PUBLIC/'manifest.json').read_text())['files'])}))
