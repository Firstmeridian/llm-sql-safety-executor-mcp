from __future__ import annotations
import logging
from dataclasses import dataclass, field
from pydantic import SecretStr
from .identifiers import ascii_identifier_lower
from .relations import RelationReference

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ConnectionPolicy:
    """Read and mutation policy bound to one configured database connection."""

    allow_union: bool = False
    allowed_tables: frozenset[str] = frozenset()
    read_mode: str = "allowlist"
    allow_mutations: bool = False
    mutation_skills: frozenset[str] = frozenset()
    # MySQL table identity may be case-sensitive (lower_case_table_names=0).
    case_sensitive_tables: bool = False
    _relation_grants: frozenset[RelationReference] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "_relation_grants", frozenset(
            self.relation_key(RelationReference.from_declaration(name))
            for name in self.allowed_tables or () if name != "*"
        ))

    def table_key(self, name: str) -> str:
        return name if self.case_sensitive_tables else ascii_identifier_lower(name)

    def allows_table(self, name: str) -> bool:
        """Check a configured/declarative name, not a decoded SQL token."""
        return self.allows_relation(RelationReference.from_declaration(name))

    def relation_key(self, relation: RelationReference) -> RelationReference:
        return relation.key(case_sensitive=self.case_sensitive_tables)

    def allows_relation(self, relation: RelationReference) -> bool:
        if self.allowed_tables is None or "*" in self.allowed_tables:
            return True
        return self.relation_key(relation) in self._relation_grants

    def allows_metadata_table(self, name: str, schema: str | None) -> bool:
        """Metadata is bound to a known schema; names here are already decoded."""
        return self.allows_relation(RelationReference(name)) or (
            schema is not None and self.allows_relation(RelationReference(name, schema))
        )


@dataclass(frozen=True)
class DatabaseConfig:
    """Sanitized runtime configuration for one named database connection."""

    connection_id: str
    db_type: str
    query_timeout_seconds: int
    connect_timeout_seconds: int
    policy: ConnectionPolicy
    mysql_user: str | None = None
    mysql_password: SecretStr | None = field(default=None, repr=False)
    mysql_host: str | None = None
    mysql_database: str | None = None
    sqlite_database_path: str | None = None
    sqlite_progress_handler_interval: int = 100
