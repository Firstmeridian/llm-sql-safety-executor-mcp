"""Close this evidence batch without changing earlier snapshots."""
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "docs/validation/v3.8/schema_binding_2026_10_15"
sha = lambda data: hashlib.sha256(data).hexdigest()
source = {p.relative_to(ROOT).as_posix(): sha(p.read_bytes())
          for p in sorted((ROOT / "src/sql_safety_executor").rglob("*"))
          if p.is_file() and p.suffix in (".py", ".md")}
installed = json.loads((OUT / "installed_wheel.json").read_text())
assert source == {"src/" + p: value for p, value in installed["installed_source_sha256"].items()}
assert installed["total_calls"] == 60 and installed["import_outside_repository"]
live = json.loads((OUT / "live_mysql.json").read_text())
assert live["total_calls"] == 18 and not live["real_database_writes"]
full = Path("/tmp/v381-schema-binding-full-final.log").read_text()
match = re.search(r"(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s", full)
assert match and match.group(1, 2, 3) == ("1210", "4", "61")
assert "0 errors, 0 warnings" in Path("/tmp/v381-schema-binding-pyright-final.log").read_text()
assert "Installed prompt resources and routing guidance valid" in Path("/tmp/v381-schema-binding-prompt.log").read_text()
matrix = json.loads(gzip.decompress((OUT / "after-calls.json.gz").read_bytes()))
assert matrix["calls"] == 130 and matrix["source_sha256"] == source
adjacent = json.loads(gzip.decompress((OUT / "after-adjacent-calls.json.gz").read_bytes()))
assert adjacent["calls"] == 22 and adjacent["private_fixtures_cleaned"]
baseline = json.loads((OUT / "baseline_source.json").read_text())
changed = [name for name in source if source[name] != baseline.get(name)]
patch = []
with tarfile.open(OUT / "baseline_package_source.tar.gz") as archive:
    for name in changed:
        before = archive.extractfile(name).read().decode().splitlines(keepends=True)
        after = (ROOT / name).read_text().splitlines(keepends=True)
        patch.extend(difflib.unified_diff(before, after, fromfile="before/" + name, tofile="after/" + name))
(OUT / "change_from_prior.patch").write_text("".join(patch))
automation = {"version": "3.8.1", "source_sha256": source,
    "test_source_sha256": {p.relative_to(ROOT).as_posix(): sha(p.read_bytes()) for p in sorted((ROOT / "tests").rglob("*.py"))},
    "full_suite": {"passed": 1210, "skipped": 4, "warnings": 61, "seconds": float(match[4]), "mysql_optin": False},
    "new_regressions": 48, "installed_stdio_calls": 60, "real_mysql_readonly_calls": 18,
    "baseline_client_calls": 152, "after_client_calls": 152, "changed_production_files": changed,
    "pyright": {"errors": 0, "warnings": 0}, "prompt_contract": "passed",
    "real_database_writes": False, "production_config_modified": False,
    "resident_host": "Pending maintainer restart after these source changes; earlier 18/18 belongs to prior source",
    "production_ast": False, "sqlite_authorizer": False, "model_cost": "Not remeasured"}
if (OUT / "native_after_restart.json").exists():
    native = json.loads((OUT / "native_after_restart.json").read_text())
    assert native["checks"]["failed"] == 0
    automation["resident_host"] = "Current primary native acceptance passed after maintainer restart"
    automation["resident_host_checks"] = native["checks"]
(OUT / "automation.json").write_text(json.dumps(automation, ensure_ascii=False, indent=2) + "\n")
for p in Path("/tmp").glob("v381-schema-binding-*.log"):
    (OUT / (p.name + ".gz")).write_bytes(gzip.compress(p.read_bytes(), mtime=0))
for p in Path(__file__).parent.glob("*.py"):
    (OUT / (p.name + ".gz")).write_bytes(gzip.compress(p.read_bytes(), mtime=0))
# The same complete successful records are in after-calls.json.gz.
(OUT / "completed-scenarios.json.gz").unlink(missing_ok=True)
assert 'version = "3.8.1"' in (ROOT / "pyproject.toml").read_text()
assert not subprocess.check_output(["git", "diff", "--", "pyproject.toml", "uv.lock"], cwd=ROOT)
subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
links = 0
documents = [ROOT / "docs/validation/V3_8_1_SCHEMA_BINDING_2026_10_15_ZH.md"]
for line in subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT, text=True).splitlines():
    path = ROOT / line[3:]
    if path.is_file() and path.suffix == ".md":
        documents.append(path)
for path in set(documents):
    for target in re.findall(r"\]\(([^)\n]+)\)", path.read_text()):
        target = target.strip().strip("<>")
        if "://" in target or target.startswith(("#", "mailto:", "data:")):
            continue
        filename = target.split("#", 1)[0]
        if filename:
            resolved = (path.parent / unquote(filename)).resolve()
            assert resolved == OUT / "manifest.json" or resolved.exists(), (path, filename)
            links += 1
for name in ("DESIGN_RISK_REGISTER.md", "DESIGN_RISK_REGISTER_ZH.md"):
    content = (ROOT / "docs/security" / name).read_text()
    ids = re.findall(r"^\| DRR-2026-(\d{3}) \|", content, re.M)
    assert sorted(ids) == [f"{n:03}" for n in range(1, 94)]
    recent = content[content.index("| DRR-2026-088 |"):].splitlines()[:6]
    assert [line.split("|")[1].strip() for line in recent] == [f"DRR-2026-{n:03}" for n in range(88, 94)]
for name in ("README.md", "README_ZH.md"):
    content = (ROOT / name).read_text()
    sample = content[content.index("### 5. `sample`"):content.index("### 6. `get_full_schema`")]
    response = json.loads(re.findall(r"```json\n(.*?)\n```", sample, re.S)[1])
    assert response["query"] == 'SELECT * FROM "main"."users" LIMIT 5'
(OUT / "document_checks.json").write_text(json.dumps({"local_document_link_targets": links,
    "bilingual_drr_ids": 93, "latest_drr_rows_contiguous": True, "diff_check": "passed",
    "bilingual_sample_json_and_scoped_sql": "passed",
    "version_runtime_dependencies_unchanged": True,
    "scope": "Local file links, not all remote URLs/anchors"}, indent=2) + "\n")
manifest = {"version": "3.8.1", "source_reference": "automation.json#source_sha256",
    "recording_profile": "Decoded application input/results and SQLAlchemy statements; compressed logs/source, not complete transport frames",
    "omitted": ["Issued bearer tokens", "Complete JSON-RPC frames/IDs/notifications",
                "No new model task or provider usage", "Repeated successful partial checkpoint deduplicated into after-calls.json.gz"],
    "cleanup": "Private SQLite fixtures/processes closed and removed; no real database or configured TOML writes",
    "history": "Earlier dated batches untouched; initial harness/mock/sandbox failures retained", "artifacts": []}
for path in sorted(OUT.iterdir()):
    if path.name == "manifest.json":
        continue
    data = path.read_bytes()
    item = {"path": path.name, "bytes": len(data), "sha256": sha(data)}
    if path.suffix == ".gz":
        uncompressed = gzip.decompress(data)
        item.update(uncompressed_bytes=len(uncompressed), uncompressed_sha256=sha(uncompressed))
    manifest["artifacts"].append(item)
(OUT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"full_passed": 1210, "installed_calls": 60, "real_mysql_readonly_calls": 18,
    "before_after_calls_each": 152, "production_files": len(source), "changed_files": len(changed),
    "document_links": links, "drr_ids": 93, "artifacts": len(manifest["artifacts"]),
    "resident_host": automation["resident_host"]}))
