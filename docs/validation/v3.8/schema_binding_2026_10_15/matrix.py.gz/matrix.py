"""Read-only assessment: isolated SQLite fixtures, no production edits/config writes."""
import asyncio
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile

from fastmcp import Client
from sqlalchemy import event
from sql_safety_executor import create_server, load_config

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = ROOT / "docs/validation/v3.8/schema_binding_2026_10_15"
sys.path.insert(0, str(ROOT))
from tests.support import write_toml


def hashes():
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((ROOT / "src/sql_safety_executor").rglob("*"))
            if p.is_file() and p.suffix in (".py", ".md")}


async def scenario(mode, variant, grant):
    with tempfile.TemporaryDirectory(prefix="v381-schema-binding-") as temporary:
        directory = Path(temporary)
        if variant in ("both", "temp_view"):
            with sqlite3.connect(directory / "fixture.sqlite") as db:
                db.executescript("CREATE TABLE orders(n INTEGER, main_label TEXT);"
                                 "INSERT INTO orders VALUES(7,'main');"
                                 "CREATE INDEX main_probe ON orders(n);")
        for name, sql in (("qualified", "SELECT n FROM main.orders"),
                          ("bare", "SELECT n FROM orders")):
            skill = directory / "skills" / name
            skill.mkdir(parents=True)
            (skill / "skill_def.md").write_text(
                f"---\nname: {name}\ntype: query\nsource: query.sql\n"
                "risk: low\ndescription: Schema binding assessment\nparams: {}\n---\n")
            (skill / "query.sql").write_text(sql)
        write_toml(directory / "server.toml", {
            "schema_version": 1, "files": {"connections": "connections.toml", "skills": "skills.toml"},
            "server": {"default_connection": "demo"},
            "tools": {"schema": True, "table_summary": True},
        })
        write_toml(directory / "connections.toml", {
            "schema_version": 1, "connections": {"demo": {
                "type": "sqlite", "sqlite": {"path": "fixture.sqlite"},
                "read": {"mode": "allowlist", "tables": [grant]},
            }},
        })
        write_toml(directory / "skills.toml", {
            "schema_version": 1, "skills": {"enabled": True, "directory": "skills",
                "readiness": {"check_schema": True}, "audit": {"path": "audit.jsonl"}},
        })
        server = create_server(load_config(directory / "server.toml"))
        record = {"mode": mode, "variant": variant, "grant": grant, "calls": []}
        try:
            async with Client(server, mode=mode) as client:
                adapter = server.gateway_runtime.registry.get_adapter("demo")
                assert adapter.connect()
                engine = adapter._engine
                assert engine is not None
                with engine.begin() as connection:
                    if variant == "aux_only":
                        connection.exec_driver_sql("ATTACH ':memory:' AS aux")
                        connection.exec_driver_sql("CREATE TABLE aux.orders(n INTEGER, aux_label TEXT)")
                        connection.exec_driver_sql("INSERT INTO aux.orders VALUES(201,'aux'),(202,'aux'),(203,'aux')")
                    elif variant == "temp_view":
                        connection.exec_driver_sql("CREATE TEMP TABLE shadow_values(n INTEGER, temp_label TEXT)")
                        connection.exec_driver_sql("INSERT INTO shadow_values VALUES(99,'temp'),(100,'temp')")
                        connection.exec_driver_sql("CREATE TEMP VIEW orders AS SELECT * FROM shadow_values")
                    else:
                        connection.exec_driver_sql("CREATE TEMP TABLE orders(n INTEGER, temp_label TEXT)")
                        connection.exec_driver_sql("INSERT INTO temp.orders VALUES(99,'temp'),(100,'temp')")
                        connection.exec_driver_sql("CREATE INDEX temp.temp_probe ON orders(n)")
                    truth = {}
                    for schema in ("main", "temp", "aux"):
                        try:
                            truth[schema] = [dict(row._mapping) for row in
                                connection.exec_driver_sql(f'SELECT * FROM "{schema}"."orders"')]
                        except Exception as error:
                            truth[schema] = {"error_type": type(error).__name__}
                    record["independent_truth"] = truth
                statements = []
                def capture(conn, cursor, statement, parameters, context, executemany):
                    statements.append(statement)
                event.listen(engine, "before_cursor_execute", capture)
                async def call(tool, arguments):
                    start = len(statements)
                    result = await client.call_tool(tool, arguments, raise_on_error=False)
                    payload = result.structured_content
                    record["calls"].append({
                        "tool": tool, "arguments": arguments, "isError": result.is_error,
                        "structuredContent": payload, "meta": result.meta,
                        "content": [item.model_dump(mode="json", exclude_none=True) for item in result.content],
                        "adapter_statements": statements[start:],
                    })
                    if result.is_error:
                        assert tool == "execute_query_skill" and (grant == "orders" or variant in ("temp_only", "aux_only"))
                    return payload
                raw_main = await call("query", {"sql": "SELECT n FROM main.orders"})
                raw_shadow = await call("query", {"sql": f"SELECT n FROM {'aux' if variant == 'aux_only' else 'temp'}.orders"})
                assert raw_shadow["error_code"] == "table_access_denied"
                assert record["calls"][-1]["adapter_statements"] == []
                literal = await call("query", {"sql": 'SELECT n FROM "main.orders"'})
                assert literal["error_code"] == "table_access_denied"
                raw_bare = await call("query", {"sql": "SELECT n FROM orders"})
                sampled = await call("sample", {"table_name": "orders"})
                estimate = await call("get_table_summary", {"table_name": "orders"})
                counted = await call("get_table_summary", {"table_name": "orders", "exact_count": True})
                tables = await call("list_tables", {})
                described = await call("describe_table", {"table_name": "orders"})
                full = await call("get_full_schema", {})
                skills = await call("list_skills", {"available_only": False, "detail_level": "full"})
                detail = await call("get_skill_detail", {"skill_name": "qualified"})
                skill_result = await call("execute_query_skill", {"skill_name": "qualified", "params": {}})
                expected_shadow = truth["aux" if variant == "aux_only" else "temp"]
                if variant in ("both", "temp_view"):
                    assert sampled["success"] and sampled["data"] == truth["main"]
                    assert 'FROM "main"."orders"' in sampled["query"]
                else:
                    assert not sampled["success"] and sampled["error_code"] == "unknown_table"
                if variant in ("both", "temp_view"):
                    assert estimate["row_count"] == counted["row_count"] == 1
                    assert [col["column_name"] for col in counted["columns"]] == ["n", "main_label"]
                    assert [col["column_name"] for col in described["columns"]] == ["n", "main_label"]
                    assert [table["table_name"] for table in tables["tables"]] == ["orders"]
                    assert {item["name"] for item in described["indexes"]} == {"main_probe"}
                    if grant == "main.orders":
                        assert raw_main["data"] == skill_result["data"] == [{"n": 7}]
                        assert detail["skill"]["schema_ready"]
                        assert raw_bare["error_code"] == "table_access_denied"
                    else:
                        assert raw_main["error_code"] == "table_access_denied"
                        assert raw_bare["data"] == [{"n": 99}, {"n": 100}]
                else:
                    assert not counted["success"] and not estimate["success"]
                    count_call = record["calls"][6]
                    assert any('SELECT COUNT(*) as total_rows FROM "main"."orders"' == sql
                               for sql in count_call["adapter_statements"])
                    assert tables["tables"] == [] and not described["success"]
                    assert detail["skill"]["missing_tables"] == ["main.orders"]
                record["checks"] = "passed: repaired fixed-schema reads and scoped controls"
                event.remove(engine, "before_cursor_execute", capture)
        finally:
            server.gateway_runtime.close()
        record["fixture_cleanup"] = "all private engines closed; temporary directory removed on exit"
        return record


async def main():
    baseline = hashes()
    records = []
    for mode in ("legacy", "auto"):
        for variant, grant in (("both", "main.orders"), ("both", "orders"),
                               ("temp_only", "main.orders"), ("aux_only", "main.orders"),
                               ("temp_view", "main.orders")):
            records.append(await scenario(mode, variant, grant))
            with gzip.open(OUTPUT / "completed-scenarios.json.gz", "wt", encoding="utf-8") as stream:
                json.dump(records, stream, ensure_ascii=False, indent=2)
            print(mode, variant, grant, "13 calls; verified", flush=True)
    assert hashes() == baseline
    output = {"version": "3.8.1", "recording_layer": "FastMCP Client application results; SQLAlchemy statements",
              "protocol_frames_recorded": False, "source_unchanged": True,
              "source_sha256": baseline, "real_database_writes": False,
              "production_config_modified": False, "calls": sum(len(r["calls"]) for r in records),
              "records": records}
    with gzip.open(OUTPUT / "after-calls.json.gz", "wt", encoding="utf-8") as stream:
        json.dump(output, stream, ensure_ascii=False, indent=2)
    print("total calls:", output["calls"], "; production source resources unchanged:", len(baseline))


if __name__ == "__main__":
    asyncio.run(main())
