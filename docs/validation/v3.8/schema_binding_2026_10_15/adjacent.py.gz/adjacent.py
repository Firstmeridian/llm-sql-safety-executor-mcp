"""Additional readiness/object-type and callback-result robustness checks."""
import asyncio
import gzip
import json
from pathlib import Path
import sqlite3
import sys
import tempfile

from fastmcp import Client
from sql_safety_executor import create_server, load_config

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = ROOT / "docs/validation/v3.8/schema_binding_2026_10_15"
sys.path.insert(0, str(ROOT))
from tests.support import write_toml


async def probe(mode):
    with tempfile.TemporaryDirectory(prefix="v381-adjacent-") as temporary:
        directory = Path(temporary)
        with sqlite3.connect(directory / "fixture.sqlite") as db:
            db.executescript("CREATE VIEW orders AS SELECT 7 AS n; CREATE TABLE untouched(n INTEGER); INSERT INTO untouched VALUES(0);")
        query = directory / "skills" / "view-read"
        query.mkdir(parents=True)
        (query / "skill_def.md").write_text("---\nname: view-read\ntype: query\nsource: query.sql\nrisk: low\ndescription: View readiness\nparams: {}\n---\n")
        (query / "query.sql").write_text("SELECT n FROM main.orders")
        mutation = directory / "skills" / "nonserializable-validation"
        mutation.mkdir()
        (mutation / "skill_def.md").write_text("---\nname: nonserializable-validation\ntype: mutation\nsource: mutation.py\nrisk: low\ndescription: Invalid callback contract\nparams: {}\n---\n")
        (mutation / "mutation.py").write_text('''from sql_safety_executor.skills.mutation import MutationBase
from sql_safety_executor.database.errors import DatabaseQueryError
class Mutation(MutationBase):
    validations = 0
    def validate(self, params):
        type(self).validations += 1
        if type(self).validations > 1:
            return {"valid": False, "errors": [DatabaseQueryError("unknown_table")]}
        return {"valid": True}
    def preview(self, params):
        return {"affected_rows_estimate": 1}
    def execute(self, params):
        raise AssertionError("Execution must not be reached")
''')
        write_toml(directory / "server.toml", {"schema_version": 1,
            "files": {"connections": "connections.toml", "skills": "skills.toml"},
            "server": {"default_connection": "demo"}, "tools": {"schema": True, "table_summary": True}})
        write_toml(directory / "connections.toml", {"schema_version": 1, "connections": {"demo": {
            "type": "sqlite", "sqlite": {"path": "fixture.sqlite"},
            "read": {"mode": "allowlist", "tables": ["main.orders"]},
            "mutation": {"enabled": True, "skills": ["nonserializable-validation"]}}}})
        write_toml(directory / "skills.toml", {"schema_version": 1, "skills": {
            "enabled": True, "directory": "skills", "readiness": {"check_schema": True},
            "audit": {"path": "audit.jsonl"}, "mutation": {"enabled": True, "allowed_connections": ["demo"]}}})
        server = create_server(load_config(directory / "server.toml"))
        records = []
        try:
            async with Client(server, mode=mode) as client:
                async def call(tool, args):
                    result = await client.call_tool(tool, args, raise_on_error=False)
                    public_args = {**args}
                    if "preview_token" in public_args:
                        public_args["preview_token"] = "<omitted; same issued token>"
                    content = [item.model_dump(mode="json", exclude_none=True) for item in result.content]
                    payload = result.structured_content
                    if payload and "preview_token" in payload:
                        payload = {**payload, "preview_token": "<omitted; token was issued>"}
                        content = [{"type": "text", "text": json.dumps(payload)}]
                    records.append({"tool": tool, "arguments": public_args, "isError": result.is_error,
                                    "structuredContent": payload, "content": content, "meta": result.meta})
                    return result
                raw = await call("query", {"sql": "SELECT n FROM main.orders"})
                listed = await call("list_skills", {"available_only": False, "detail_level": "full"})
                default = await call("list_skills", {})
                detail = await call("get_skill_detail", {"skill_name": "view-read"})
                executed = await call("execute_query_skill", {"skill_name": "view-read", "params": {}})
                described = await call("describe_table", {"table_name": "orders"})
                sampled = await call("sample", {"table_name": "orders"})
                counted = await call("get_table_summary", {"table_name": "orders", "exact_count": True})
                assert raw.structured_content["data"] == sampled.structured_content["data"] == [{"n": 7}]
                assert described.structured_content["success"] and counted.structured_content["row_count"] == 1
                state = detail.structured_content["skill"]
                assert state["policy_allowed"] and state["missing_tables"] == []
                assert state["schema_ready"] and state["executable"]
                assert not executed.is_error and executed.structured_content["data"] == [{"n": 7}]
                assert "view-read" in {skill["name"] for skill in default.structured_content["skills"]}
                preview = await call("execute_mutation_skill", {"skill_name": "nonserializable-validation", "params": {}})
                args = {"skill_name": "nonserializable-validation", "params": {}, "confirm": True,
                        "preview_token": preview.structured_content["preview_token"]}
                failed = await call("execute_mutation_skill", args)
                replay = await call("execute_mutation_skill", args)
                assert not failed.is_error and replay.is_error
                assert failed.structured_content["error_code"] == "validation_failed"
                assert failed.structured_content["execution_outcome"] == "not_executed"
                assert failed.meta["preview_token_consumed"] is True
                with sqlite3.connect(directory / "fixture.sqlite") as db:
                    assert db.execute("SELECT n FROM untouched").fetchall() == [(0,)]
                return {"mode": mode, "calls": records, "checks": "verified",
                        "callback_violation": "validate returns exception instead of documented string reasons",
                        "write_execution_reached": False, "token_replay_rejected": True}
        finally:
            server.gateway_runtime.close()


async def main():
    records = [await probe(mode) for mode in ("legacy", "auto")]
    with gzip.open(OUTPUT / "after-adjacent-calls.json.gz", "wt", encoding="utf-8") as stream:
        json.dump({"calls": sum(len(r["calls"]) for r in records), "records": records,
                   "private_fixtures_cleaned": True, "real_database_writes": False,
                   "production_config_modified": False, "protocol_frames_recorded": False},
                  stream, ensure_ascii=False, indent=2)
    print("22 adjacent calls verified; private fixtures cleaned")


if __name__ == "__main__":
    asyncio.run(main())
