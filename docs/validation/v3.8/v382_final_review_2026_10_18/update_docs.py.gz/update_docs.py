"""Document the independent P3; preserve runtime code and historical seals."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
REPORT = 'V3_8_2_FINAL_REVIEW_2026_10_18_ZH.md'


def append_risk(name, row):
    path = ROOT / name
    lines = path.read_text().splitlines()
    assert not any(line.startswith('| DRR-2026-109 |') for line in lines)
    indices = [i for i, line in enumerate(lines) if line.startswith('| DRR-2026-108 |')]
    assert len(indices) == 1
    lines.insert(indices[0] + 1, row)
    path.write_text('\n'.join(lines) + '\n')


append_risk('docs/security/DESIGN_RISK_REGISTER.md',
    '| DRR-2026-109 | Open; non-blocking P3 | Low (functional compatibility) | 2026-10-18 | SQLite IS NULL COLLATE parsing | Pinned SQLGlot 30.22.0 rejects valid unparenthesized NULL RHS COLLATE before authorizer; same-input 3323f9c accepts it. | Documentation only; no runtime fix | Keep refusal and original SQL; verified right-operand parentheses preserve the reported binding. Evaluate a narrow dialect adaptation or verified upstream fix separately. | e49cd0e full regression 2275 passed/four skipped; clean type/prompt checks; eight native observations and 16-case/two-mode Client comparison per version (baseline 32 successes, current ten forms refused in both modes); 75 current resources and 487 prior sealed files match. [Evidence](../validation/v3.8/' + REPORT + '). | Whole-predicate parentheses can change text-comparison semantics; no regex rewrite, grant expansion or authorizer exemption. DRR-108 stays closed within its verified scope; other SQLGlot versions untested. |')
append_risk('docs/security/DESIGN_RISK_REGISTER_ZH.md',
    '| DRR-2026-109 | 开放；非阻断 P3 | 低（功能兼容） | 2026-10-18 | SQLite IS NULL COLLATE 解析 | 固定 SQLGlot 30.22.0 在 authorizer 前拒绝合法的 NULL 右侧 COLLATE 写法；3323f9c 同输入成功。 | 仅文档，未修运行代码 | 保留拒绝及原 SQL；右操作数括号已验证保持所报结合位置，后续单独验证方言适配或上游修复。 | e49cd0e 全量 2275 passed／四项跳过，类型／提示通过；八次原生及每版 16 例／两模式 Client 对照（旧版 32 次成功，当前十种写法在两模式被拒）；75 项资源及旧 487 项封存核验一致。[证据](../validation/v3.8/' + REPORT + ')。 | 整个判断加括号可能改变字符串比较语义，不用正则改写、不扩大 grant 或豁免 authorizer；DRR-108 保持限定关闭，其他 SQLGlot 版本未测。 |')

for name, old_date, new_date, content in [
    ('REFACTORING_LOG.md', 'Updated: October 17, 2026', 'Updated: October 18, 2026',
     '## v3.8.2 Final committed-source review and COLLATE limitation (October 18, 2026)\n\n'
     '- Verify e49cd0e with a clean initial worktree: 75 accepted runtime resources and 487 prior sealed files match; 22 changed Markdown documents have 757 valid local links with committed targets. Full regression passes 2275/four optional skips; type and prompt checks pass.\n'
     '- Reproduce the independent P3 in eight native observations and matched private Client cases. SQLGlot 30.22.0 rejects NULL RHS COLLATE; baseline 3323f9c accepts all 16 inputs in both modes. Right-operand parentheses work; whole-predicate parentheses can change string semantics.\n'
     '- Record open DRR-109, retaining the scoped DRR-108 closure. Update current evidence links; preserve historical source attribution. Runtime code, dependencies, tests, configuration and data are unchanged; no restart needed.\n'
     '- [Findings, limits and sealed evidence](docs/validation/v3.8/' + REPORT + ').\n\n'),
    ('REFACTORING_LOG_ZH.md', '**最近更新：** 2026-10-17', '**最近更新：** 2026-10-18',
     '## v3.8.2 已提交版本最终复核与 COLLATE 限制（2026-10-18）\n\n'
     '- 核验 e49cd0e，开始时工作区干净：75 项运行资源及旧 487 项封存一致，提交内 22 篇变更 Markdown 的 757 个本地链接有效，目标均已提交。全量 2275 passed／四项可选跳过，类型／提示通过。\n'
     '- 八次原生及同输入私有 Client 复现独立 P3：SQLGlot 30.22.0 拒绝 NULL 右侧 COLLATE，3323f9c 的 16 条 SQL／两模式均成功。右操作数括号可恢复，整个判断括号可能改变字符串比较语义。\n'
     '- 单独登记开放 DRR-109，DRR-108 保持限定关闭；更新最新证据入口，保留旧源码及历史结果。未改运行代码、依赖、正式测试、配置及数据，无需重启。\n'
     '- [结论、限制与封存证据](docs/validation/v3.8/' + REPORT + ')。\n\n'),
]:
    path = ROOT / name
    text = path.read_text()
    assert text.count(old_date) == 1
    text = text.replace(old_date, new_date)
    index = text.index('## v3.8.2 ')
    path.write_text(text[:index] + content + text[index:])

path = ROOT / 'docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md'
with path.open('a') as output:
    output.write('\n## 2026-10-18 已提交版本复核与独立 P3\n\n'
        'e49cd0e 再次通过 2275 项回归、类型／提示及源码／封存核对。SQLGlot 30.22.0 对合法的 SQLite `IS NULL COLLATE`／`IS NOT NULL COLLATE` 存在解析兼容回归，authorizer 尚未参与；记录为开放、非阻断 DRR-109，不重开触发器／计划的 DRR-108。所报常量例可写为 `NULL IS (NULL COLLATE NOCASE)`；不能机械地将整个判断加括号，字符串比较可能改变语义。后续修复须在真实运算符优先级及拒绝对照下验证，当前不改原 SQL 或完整性策略。\n\n'
        '新证据、旧版同输入对照及最终文档核对见[复核报告](../validation/v3.8/' + REPORT + ')；仅文档／证据增量，运行资源与 e49cd0e 一致。\n')

for name, label in [('docs/README.md', 'v3.8.2 committed-source final review and open COLLATE P3'),
                    ('docs/README_ZH.md', 'v3.8.2 已提交版本最终复核与 COLLATE P3')]:
    path = ROOT / name
    lines = path.read_text().splitlines()
    index = next(i for i, line in enumerate(lines) if 'V3_8_2_TRIGGER_WHEN_2026_10_17_ZH.md' in line)
    lines.insert(index + 1, '- [' + label + '](validation/v3.8/' + REPORT + ').')
    path.write_text('\n'.join(lines) + '\n')

for name, notice in [
    ('V3_8_2_VALIDATION_2026_10_16_ZH.md',
     '> 最新状态：e49cd0e 的[最终复核与独立 COLLATE P3](' + REPORT + ')已完成；WHEN 修复及限定驻留验收见[后续报告](V3_8_2_TRIGGER_WHEN_2026_10_17_ZH.md)。下文模型／成本／原生结果保留其原源码归属，不改标为后续版本的再次验收。'),
    ('V3_8_2_TRIGGER_CTE_2026_10_17_ZH.md',
     '> 后续 WHEN 回归已修复，DRR-108 限定驻留验收通过，最新三次双轮 Luna 最终 3/3，见[WHEN 报告](V3_8_2_TRIGGER_WHEN_2026_10_17_ZH.md)。[e49cd0e 最终复核](' + REPORT + ')另记独立非阻断 COLLATE P3。下文 57 项验收、当时发现及模型／成本记录保留原源码范围。'),
]:
    path = ROOT / 'docs/validation/v3.8' / name
    lines = path.read_text().splitlines()
    assert lines[2].startswith('> ')
    lines[2] = notice
    path.write_text('\n'.join(lines) + '\n')
print('Updated nine narrative documents; DRR-108 and historical evidence unchanged.')
