"""Seal final review evidence; preserve all previously accepted checkpoints."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
LOCAL = BATCH / 'evidence'
PUBLIC = ROOT / 'docs/validation/v3.8/v382_final_review_2026_10_18'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)


def main():
    assert not PUBLIC.exists(), 'Append new evidence; do not overwrite seals'
    commit = 'e49cd0eebb9bdf56ac6c114522af5b8743ba3bbf'
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == commit
    old_parent = ROOT / 'docs/validation/v3.8/v382_when_2026_10_17'
    accepted = read(old_parent / 'verification.json')
    for name, digest in accepted['runtime_resources'].items():
        assert sha(ROOT / 'src/sql_safety_executor' / name) == digest, name
    assert not subprocess.check_output(['git', 'diff', '--name-only', '--', 'src', 'tests', 'scripts', 'config', 'pyproject.toml', 'uv.lock'], cwd=ROOT, text=True).strip()
    preserved = 0
    for name in list(accepted['preserved_manifests']) + [str((old_parent / 'manifest.json').relative_to(ROOT)), str((old_parent / 'resident_restart/manifest.json').relative_to(ROOT))]:
        manifest = ROOT / name
        base = manifest.parent.parent if name.startswith('local_archive/') else manifest.parent
        for relative, info in read(manifest)['files'].items():
            path = base / relative
            assert sha(path) == info['sha256'] and path.stat().st_size == info['bytes'], path
            preserved += 1
    assert preserved == 487
    current, baseline = read(LOCAL / 'collate_current.json.gz'), read(LOCAL / 'collate_baseline.json.gz')
    assert current['source_sha256'] == accepted['runtime_resources']
    expected_old = read(ROOT / 'docs/validation/v3.8/v382_2026_10_16/baseline_source.json')['source_sha256']
    assert {'src/sql_safety_executor/' + k: v for k, v in baseline['source_sha256'].items()} == expected_old
    assert current['independent'] == baseline['independent'] and len(current['independent']) == 16
    assert len(current['records']) == len(baseline['records']) == 32
    assert all(r['structured']['success'] for r in baseline['records'])
    refusals = [r for r in current['records'] if not r['structured']['success']]
    assert len(refusals) == 20 and all(r['structured']['error_code'] == 'sql_parse_failed' for r in refusals)
    native = read(LOCAL / 'native_collate.json')
    assert len(native['records']) == 8
    for row in native['records']:
        raw = row['raw']
        assert not raw['isError']
        assert json.loads(next(c['text'] for c in raw['content'] if c['type'] == 'text')) == raw['structuredContent']
        match = next(r for r in current['records'] if r['mode'] == 'auto' and r['name'] == row['name'])['structured']
        for key in ('success', 'error_code', 'data'):
            assert raw['structuredContent'].get(key) == match.get(key), row['name']
    full = (LOCAL / 'full_regression.log').read_text()
    assert '2275 passed, 4 skipped, 240 warnings in 165.25s' in full
    assert '0 errors, 0 warnings' in (LOCAL / 'pyright.log').read_text()
    assert 'Installed prompt resources and routing guidance valid.' in (LOCAL / 'prompt_contract.log').read_text()
    initial_docs = read(LOCAL / 'commit_and_docs.json')
    assert initial_docs['initial_worktree_clean'] and not initial_docs['missing_links'] and not initial_docs['local_targets_not_in_commit']
    location = read(LOCAL / 'baseline_location.json')
    owned = Path(location['path']).resolve()
    assert owned.parent == Path('/tmp') and owned.name.startswith('v382-collate-baseline-')
    for name, digest in expected_old.items():
        assert sha(owned / name) == digest
    shutil.rmtree(owned)
    verification = {
        'version': '3.8.2', 'commit': commit, 'closed_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'final_checks_passed_with_open_nonblocking_P3_DRR_2026_109',
        'runtime_code_changes_this_batch': False, 'dependencies_or_config_changes': False,
        'current_resources_match_last_accepted_batch': 75, 'prior_sealed_files_verified': 487,
        'full_regression': {'passed': 2275, 'skipped': 4, 'warnings': 240, 'seconds': 165.25},
        'type_and_prompt_checks_passed': True,
        'committed_docs': {'changed_markdown_files': 22, 'local_links_valid': 757, 'uncommitted_link_targets': 0},
        'collate': {'priority': 'P3, non-blocking', 'risk': 'functional compatibility regression',
            'native_observations': 8, 'native_parse_refusals': 2, 'private_inputs_per_version': 16,
            'client_modes': ['auto', 'legacy'], 'client_calls_per_version': 32,
            'baseline_success': 32, 'current_success': 12, 'current_parse_refusals': 20,
            'sqlglot': current['sqlglot_version'], 'sqlite': current['sqlite_version'],
            'cause': 'Pinned SQLGlot IS/NULL parsing rejects following COLLATE; shared analysis refuses before authorizer.',
            'safe_reported_recovery': 'NULL IS (NULL COLLATE NOCASE)',
            'whole_predicate_parentheses_not_a_general_equivalence': True,
            'other_SQLGlot_versions_tested': False},
        'baseline': {'commit': '3323f9c29add7fd158410d5ce57a70fb58c5f2cb', 'verified_resources': 70,
            'actual_loaded_package_path_asserted': True, 'frozen_source_temporary_directory_cleaned': True,
            'scope': 'Fresh subprocess using current dependencies, not historical environment replay.'},
        'scope_limits': [
            'New private Client observations are in-process, not new stdio or native Host package-identity proof.',
            'No new wheel install, live MySQL matrix, Luna business task or remote CI run; prior results retain source attribution.',
            'Targeted parser cases are not workload failure-rate estimates; no configured writes, semantic rewrite or policy exemption.',
            'DRR-108 remains closed within its existing verified scope; DRR-109 is documented and unresolved.',
            'This batch adds narrative documentation and evidence after e49cd0e; runtime resources remain byte-identical.',
        ],
    }
    PUBLIC.mkdir()
    (PUBLIC / 'native_collate.json.gz').write_bytes(gzip.compress((LOCAL / 'native_collate.json').read_bytes(), mtime=0))
    for name in ('collate_current.json.gz', 'collate_baseline.json.gz', 'commit_and_docs.json'):
        shutil.copy2(LOCAL / name, PUBLIC / name)
    for name in ('full_regression.log', 'pyright.log', 'prompt_contract.log'):
        (PUBLIC / (name + '.gz')).write_bytes(gzip.compress((LOCAL / name).read_bytes(), mtime=0))
    for name in ('probe_collate.py', 'update_docs.py', 'seal.py'):
        (PUBLIC / (name + '.gz')).write_bytes(gzip.compress((BATCH / 'scripts' / name).read_bytes(), mtime=0))
    (PUBLIC / 'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
    manifest = {'closed_utc': verification['closed_utc'], 'scope': 'Final committed-source audit; open P3 documented, runtime unchanged.',
                'files': {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(PUBLIC.iterdir())}}
    (PUBLIC / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'sealed_files': len(manifest['files']), 'prior_files_unchanged': preserved, 'runtime_resources': 75, 'open_P3': 'DRR-2026-109'}))


if __name__ == '__main__':
    main()
