"""Current-source Client checks on the already authorized MySQL; constants only."""
import asyncio,gzip,hashlib,json
from pathlib import Path
from fastmcp import Client
from sql_safety_executor import create_server,load_config
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/lexical_identity_2026_10_15"
cases=[
    ("SELECT 7 AS n", None),
    ("WITH business AS (SELECT 7 AS n) SELECT n FROM business",None),
    ("WITH `offſet` AS (SELECT 7 AS n) SELECT n FROM `offſet`",None),
    ("SELECT 7 AS load_fıle",None),
    ('SELECT "load_file"(NULL)',"file_operation_denied"),
    ("SELECT USER()","server_state_denied"),
]
async def main():
    records=[]
    for mode in ("legacy","auto"):
        server=create_server(load_config(ROOT/"config/server.toml"))
        try:
            async with Client(server,mode=mode) as client:
                for sql,code in cases:
                    args={"connection_id":"trade_analysis_mysql","sql":sql}
                    r=await client.call_tool("query",args,raise_on_error=False)
                    d=r.structured_content
                    assert not r.is_error
                    if code:assert not d["success"] and d["error_code"]==code
                    else:assert d["success"] and list(d["data"][0].values())==[7]
                    records.append({"mode":mode,"tool":"query","arguments":args,"isError":r.is_error,"structuredContent":d,"content":[c.model_dump(mode="json",exclude_none=True) for c in r.content]})
        finally:server.gateway_runtime.close()
    source={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in (".py",".md")}
    data={"source_sha256":source,"checks":{"passed":len(records),"failed":0},"records":records,"configured_database_writes":False,
          "scope":"Current-source in-process Client, real configured MySQL constant reads and pre-execution refusals; not resident Host or physical Unicode object matrix"}
    (OUT/"live_mysql.json.gz").write_bytes(gzip.compress((json.dumps(data,ensure_ascii=False,indent=2)+"\n").encode(),mtime=0))
    print(json.dumps(data["checks"]))
asyncio.run(main())
