from scenarios import check_installed, populate_fixture
