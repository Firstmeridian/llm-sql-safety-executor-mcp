"""Private SQLite lexical-identity checks; identical requests before/after/install."""
from pathlib import Path
import sqlite3
from fastmcp import Client
from fastmcp.client.transports import StdioTransport

NAMES = ("window", "offſet", "unıon", "ınsert")
RESERVED = [
    ('SELECT "load_file"(1)', "file_operation_denied"),
    ('SELECT `load_file`(1)', "file_operation_denied"),
    ('SELECT [user](1)', "server_state_denied"),
    ('SELECT "CURRENT_USER"()', "server_state_denied"),
]

def populate_fixture(directory, admitted=False):
    directory.mkdir(exist_ok=True)
    with sqlite3.connect(directory/"fixture.sqlite") as db:
        for name in ("orders", *NAMES):
            db.execute(f'CREATE TABLE "{name}"(n INTEGER)')
            db.execute(f'INSERT INTO "{name}" VALUES(7)')
        assert all(db.execute(f"SELECT n FROM {name}").fetchall()==[(7,)] for name in NAMES)
    (directory/"server.toml").write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="demo"\n')
    import json
    grants=["orders",*NAMES] if admitted else ["orders"]
    (directory/"connections.toml").write_text('schema_version=1\n[connections.demo]\ntype="sqlite"\n[connections.demo.sqlite]\npath="fixture.sqlite"\n[connections.demo.read]\nmode="allowlist"\ntables='+json.dumps(grants,ensure_ascii=False)+'\n')
    (directory/"skills.toml").write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=true\n[skills.audit]\npath="audit.jsonl"\n')
    for i,name in enumerate(NAMES):
        skill=directory/"skills"/f"lexical-{i}";skill.mkdir(parents=True)
        (skill/"skill_def.md").write_text(f'---\nname: lexical-{i}\ntype: query\nsource: query.sql\nrisk: low\ndescription: Lexical identity probe\nparams: {{}}\n---\n')
        (skill/"query.sql").write_text(f"SELECT n FROM {name}")

async def check_client(client,mode,*,admitted,expect_fixed):
    requests=[("query",{"sql":f"SELECT n FROM {name}"}) for name in NAMES]
    requests += [("list_skills",{"detail_level":"full","available_only":False})]
    requests += [("get_skill_detail",{"skill_name":f"lexical-{i}","detail_level":"full"}) for i in range(len(NAMES))]
    requests += [("execute_query_skill",{"skill_name":f"lexical-{i}","params":{}}) for i in range(len(NAMES))]
    requests += [("query",{"sql":sql}) for sql,code in RESERVED]
    records=[]
    for tool,args in requests:
        r=await client.call_tool(tool,args,raise_on_error=False)
        records.append({"tool":tool,"arguments":args,"isError":r.is_error,"structuredContent":r.structured_content,
            "content":[c.model_dump(mode="json",exclude_none=True) for c in r.content],"meta":r.meta})
    if expect_fixed:
        for i in (*range(4),*range(9,13)):
            d=records[i]["structuredContent"]
            assert not records[i]["isError"] and d["success"] is admitted,(i,d)
            if admitted:assert d["data"]==[{"n":7}]
            else:assert d["error_code"]=="table_access_denied"
        for r in records[5:9]:
            s=r["structuredContent"]["skill"]
            assert s["policy_allowed"] is admitted and s["executable"] is admitted,s
            assert s["schema_ready"] is True,s
        assert len(records[4]["structuredContent"]["skills"])==4
        for r,(_,code) in zip(records[13:],RESERVED):
            assert not r["isError"] and r["structuredContent"]["error_code"]==code
    return {"mode":mode,"admitted":admitted,"requests":requests,"calls":records}

async def check_installed(target,fixture,logs):
    import sys
    records=[]
    for mode in ("legacy","auto"):
        for admitted in (False,True):
            stage=fixture/f"{mode}-{admitted}"
            populate_fixture(stage,admitted)
            transport=StdioTransport(command=sys.executable,args=["-m","sql_safety_executor","serve","--config",str(stage/"server.toml")],
                env={"PYTHONPATH":str(target)},cwd=str(stage),keep_alive=False,log_file=logs/f"installed-{mode}-{admitted}.log")
            async with Client(transport,mode=mode) as client:
                records.append(await check_client(client,mode,admitted=admitted,expect_fixed=True))
    return records
