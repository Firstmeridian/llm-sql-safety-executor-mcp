"""Seal the lexical-boundary evidence; never relabel prior accepted batches."""
import difflib,gzip,hashlib,json,re,subprocess
from pathlib import Path
from urllib.parse import unquote
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/lexical_identity_2026_10_15"
sha=lambda b:hashlib.sha256(b).hexdigest()
def read_result(name):
    p=OUT/name
    if not p.exists():p=OUT/(name+".gz")
    raw=p.read_bytes()
    return json.loads(gzip.decompress(raw) if p.suffix==".gz" else raw)
def read_log(name):
    p=Path("/tmp")/name
    return p.read_text() if p.exists() else gzip.decompress((OUT/(name+".gz")).read_bytes()).decode()
source={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in (".py",".md")}
baseline=read_result("baseline_source.json")
changed=[n for n in source if source[n]!=baseline[n]]
assert changed==["src/sql_safety_executor/core/policy.py","src/sql_safety_executor/core/sql.py"]
before=read_result("before-calls.json.gz")
after=json.loads(gzip.decompress((OUT/"after-calls.json.gz").read_bytes()))
assert before["source_sha256"]==baseline and after["source_sha256"]==source
assert before["total_calls"]==after["total_calls"]==68
for old,new in zip(before["records"],after["records"]):
    assert (old["mode"],old["admitted"],old["requests"])==(new["mode"],new["admitted"],new["requests"])
    if not old["admitted"]:
        assert all(old["calls"][i]["structuredContent"]["success"] for i in (0,1))
        assert all(new["calls"][i]["structuredContent"]["error_code"]=="table_access_denied" for i in range(4))
wheel=read_result("installed_wheel.json")
assert wheel["total_calls"]==68 and wheel["source_files_verified"]==69
assert source=={"src/"+name:value for name,value in wheel["installed_source_sha256"].items()}
audit=read_result("adjacent_audit.json")
assert audit["source_sha256"]==source
assert (audit["candidate_names"],audit["native_valid_cases"],audit["unapproved_scope_misses"],audit["approved_conservative_refusals"])==(97,542,0,18)
refusals=[r for r in audit["records"] if not r["approved_allowed"]]
assert all(r["quoted_recovery_allowed"] and r["quoted_recovery_native_rows"]==[[99]] and r["archived_baseline_approved_code"] for r in refusals)
assert len(audit["function_records"])==12
mysql=json.loads(gzip.decompress((OUT/"live_mysql.json.gz").read_bytes()))
assert mysql["source_sha256"]==source and mysql["checks"]=={"passed":12,"failed":0}
previous={}
for name in ("pragma_identity_2026_10_15","sqlite_prefix_2026_10_15","real_tasks_2026_10_15","schema_binding_2026_10_15"):
    d=ROOT/"docs/validation/v3.8"/name
    rows=json.loads((d/"manifest.json").read_text())["artifacts"]
    for row in rows:assert sha((d/row["path"]).read_bytes())==row["sha256"],(name,row["path"])
    previous[name]=len(rows)
full=read_log("v381-lexical-full.log")
m=re.search(r"(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s",full)
assert m and m.group(1,2,3)==("1385","4","71")
assert "0 errors, 0 warnings" in read_log("v381-lexical-pyright.log")
assert "Installed prompt resources and routing guidance valid" in read_log("v381-lexical-prompt.log")
for p in Path("/tmp").glob("v381-lexical-*.log"):
    (OUT/(p.name+".gz")).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in Path(__file__).parent.glob("*.py"):
    (OUT/(p.name+".gz")).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
patch=""
for name in ("policy","sql"):
    path=f"src/sql_safety_executor/core/{name}.py"
    old=gzip.decompress((OUT/f"baseline_{name}.py.gz").read_bytes()).decode()
    patch+="".join(difflib.unified_diff(old.splitlines(keepends=True),(ROOT/path).read_text().splitlines(keepends=True),fromfile="before/"+path,tofile="after/"+path))
(OUT/"change_from_prior.patch").write_text(patch)
for name in ("adjacent_audit.json","installed_wheel.json"):
    p=OUT/name
    if p.exists():
        (OUT/(name+".gz")).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
        p.unlink()
attempts={"first_focused":{"failed":45,"passed":60,"warnings":3,"seconds":5.27,"full_log_saved":False,
    "scope":"Summary only: empty allowlist test setup, discovery metadata sentinel/readiness assumptions, unsupported bare-IN assumptions and an account-like CTE-header false refusal"},
    "intermediate_focused":{"failed":2,"passed":103,"warnings":3,"seconds":4.97,"log":"v381-lexical-focused-intermediate.log.gz","cause":"Discovery schema observation was incorrectly included in execution-denial I/O sentinel scope"},
    "early_focused_pass":{"passed":105,"warnings":3,"seconds":4.52,"log":"v381-lexical-focused-initial-pass.log.gz","scope":"Before two explicit conservative-IN/recovery tests and final formatting; final full run includes all 107"},
    "initial_after_client":{"complete_result_set":False,"cause":"schema_ready was incorrectly assumed to equal policy_allowed","full_log_saved":False,"final_same_requests_completed":68}}
(OUT/"retained_attempts.json").write_text(json.dumps(attempts,ensure_ascii=False,indent=2)+"\n")
native_before=read_result("native_before_restart.json")
assert [r["raw"]["structuredContent"]["error_code"] for r in native_before["records"]]==["unknown_table","unknown_table","unknown_function","unknown_function"]
automation={"version":"3.8.1","source_sha256":source,"test_source_sha256":{p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted((ROOT/"tests").rglob("*.py"))},
    "changed_production_files":changed,"new_regressions":107,"full_suite":{"passed":1385,"skipped":4,"warnings":71,"seconds":float(m[4]),"mysql_optin":False},
    "pyright":{"errors":0,"warnings":0},"prompt_contract":"passed","baseline_client_calls":68,"after_client_calls":68,"installed_cli_stdio_calls":68,"current_source_real_mysql_checks":12,
    "adjacent_native_audit":{"candidate_names":97,"valid_cases":542,"scope_misses":0,"conservative_refusals":18,"verified_quoted_recoveries":18,"harmless_udf_identity_cases":12},
    "resident_host":"Final lexical patch awaiting maintainer restart; four safe probes still show pre-patch behavior",
    "previous_unicode_patch_native":{"passed":6,"failed":0,"source_reference":"../pragma_identity_2026_10_15/automation.json"},
    "configured_database_writes":False,"production_config_changes":False,"new_model_cost_claim":False,"prior_artifact_counts_verified":previous}
if (OUT/"native_after_restart.json").exists():
    native=read_result("native_after_restart.json")
    assert native["checks"]["failed"]==0
    automation["resident_host"]="Final lexical patch native probes/controls passed after maintainer restart"
    automation["resident_host_checks"]=native["checks"]
(OUT/"automation.json").write_text(json.dumps(automation,ensure_ascii=False,indent=2)+"\n")
links=0
for line in subprocess.check_output(["git","status","--porcelain"],cwd=ROOT,text=True).splitlines():
    p=ROOT/line[3:]
    if not p.is_file() or p.suffix!=".md":continue
    for target in re.findall(r"\]\(([^)\n]+)\)",p.read_text()):
        target=target.strip().strip("<>")
        if "://" in target or target.startswith(("#","mailto:","data:")):continue
        filename=target.split("#",1)[0]
        if filename:
            resolved=(p.parent/unquote(filename)).resolve()
            assert resolved==OUT/"manifest.json" or resolved.exists(),(p,filename)
            links+=1
for name in ("DESIGN_RISK_REGISTER.md","DESIGN_RISK_REGISTER_ZH.md"):
    lines=(ROOT/"docs/security"/name).read_text().splitlines()
    ids=[m[1] for line in lines if (m:=re.match(r"^\| DRR-2026-(\d{3}) \|",line))]
    assert sorted(ids)==[f"{i:03}" for i in range(1,97)]
    i=next(i for i,line in enumerate(lines) if line.startswith("| DRR-2026-096 |"))
    assert lines[i-1].startswith("| DRR-2026-095 |")
draft=(ROOT/"local_archive/v381_review/commit-message-complete-v381.txt").read_text()
assert sum(line.startswith("- ") for line in draft.splitlines())==7 and len(draft)<850 and "through 096" in draft
subprocess.run(["git","diff","--check"],cwd=ROOT,check=True)
assert not subprocess.check_output(["git","diff","--","pyproject.toml","uv.lock"],cwd=ROOT)
(OUT/"document_checks.json").write_text(json.dumps({"local_file_links":links,"bilingual_drr_ids":96,"latest_drr_contiguous":True,"commit_draft_bullets":7,"commit_draft_characters":len(draft),"diff_check":"passed","scope":"Local link targets and latest DRR/navigation, not every remote URL/anchor"},indent=2)+"\n")
manifest={"version":"3.8.1","source_reference":"automation.json#source_sha256","recording_profile":"Source/test hashes, compressed complete application results, native Host application observations and check/build logs; not full protocol frames",
    "omitted":["Full JSON-RPC frames/notifications","Initial failed focused/after-collector complete logs not saved; summary retained","No new native model usage/cost or physical MySQL Unicode matrix"],
    "cleanup":"Private SQLite/install/CLI fixtures auto-cleaned; configured resident/database/TOML untouched","prior_evidence":"Prior manifests byte-verified; dated source/model results not relabeled","artifacts":[]}
for p in sorted(OUT.iterdir()):
    if not p.is_file() or p.name=="manifest.json":continue
    raw=p.read_bytes();row={"path":p.name,"bytes":len(raw),"sha256":sha(raw)}
    if p.suffix==".gz":
        b=gzip.decompress(raw);row.update(uncompressed_bytes=len(b),uncompressed_sha256=sha(b))
    manifest["artifacts"].append(row)
(OUT/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"full_passed":1385,"new_regressions":107,"source_files":len(source),"test_files":len(automation["test_source_sha256"]),"changed":changed,"client_calls_per_stage":68,"installed_calls":68,"live_mysql_checks":12,"adjacent_valid_cases":542,"local_links":links,"drr_ids":96,"draft_characters":len(draft),"artifacts":len(manifest["artifacts"]),"resident_host":automation["resident_host"]}))
