"""Read-only real MySQL qualified scope in an isolated gateway/catalog."""
import asyncio
from dataclasses import replace
import json
from pathlib import Path
import sys
import tempfile
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from fastmcp import Client
from sql_safety_executor import create_server, load_config
from sql_safety_executor.config.models import Skills
from sql_safety_executor.database.models import ConnectionPolicy


async def main():
    original = load_config(ROOT / 'config/server.toml')
    alias = 'trade_analysis_mysql'
    configured = original.connections[alias]
    schema = configured.mysql_database
    assert configured.db_type == 'mysql' and schema
    sql = f'SELECT COUNT(*) AS n FROM `{schema.replace(chr(96), chr(96) * 2)}`.`orders`'
    records = []
    with tempfile.TemporaryDirectory(prefix='v381-qualified-mysql-') as directory:
        stage = Path(directory)
        skill = stage / 'skills' / 'qualified-mysql-probe'
        skill.mkdir(parents=True)
        (skill / 'skill_def.md').write_text('---\nname: qualified-mysql-probe\ntype: query\nsource: query.sql\nrisk: low\ndescription: Qualified scope check\nparams: {}\n---\n')
        (skill / 'query.sql').write_text(sql)
        for mode in ('legacy', 'auto'):
            policy = ConnectionPolicy(allowed_tables=frozenset({f'{schema}.orders'}), case_sensitive_tables=True)
            config = replace(original, connections={alias: replace(configured, policy=policy)},
                skills=Skills(enabled=True, directory=str(skill.parent),
                    readiness={'check_schema': True}, audit={'path': str(stage / f'audit-{mode}.jsonl')}))
            server = create_server(config)
            try:
                async with Client(server, mode=mode) as client:
                    requests = [('query', {'sql': sql, 'connection_id': alias}),
                        ('list_skills', {'connection_id': alias, 'detail_level': 'full'}),
                        ('get_skill_detail', {'skill_name': 'qualified-mysql-probe', 'connection_id': alias}),
                        ('execute_query_skill', {'skill_name': 'qualified-mysql-probe', 'params': {}, 'connection_id': alias}),
                        ('list_tables', {'connection_id': alias}),
                        ('describe_table', {'table_name': 'orders', 'connection_id': alias})]
                    responses = []
                    for tool, arguments in requests:
                        value = await client.call_tool(tool, arguments)
                        responses.append({'isError': value.is_error, 'structuredContent': value.structured_content})
                    assert responses[0]['structuredContent']['data'] == responses[3]['structuredContent']['data']
                    assert responses[1]['structuredContent']['skills'][0]['schema_ready']
                    assert responses[2]['structuredContent']['skill']['missing_tables'] == []
                    assert [row['table_name'] for row in responses[4]['structuredContent']['tables']] == ['orders']
                    assert responses[5]['structuredContent']['success']
                    records.append({'mode': mode, 'requests': [{'tool':t, 'arguments':a} for t,a in requests], 'responses': responses})
            finally:
                server.gateway_runtime.close()
    result = {'version': '3.8.1', 'connection_id': alias, 'scope': 'Isolated policy/catalog with configured real MySQL; SELECT/metadata only',
        'real_database_writes': False, 'calls': records, 'total_calls': 12}
    (ROOT / 'docs/validation/v3.8/relation_identity_2026_10_15/live_mysql.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'live_mysql_calls': 12, 'passed': True, 'writes': False}))


asyncio.run(main())
