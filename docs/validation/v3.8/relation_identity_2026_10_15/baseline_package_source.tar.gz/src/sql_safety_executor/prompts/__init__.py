"""Prompts components."""
