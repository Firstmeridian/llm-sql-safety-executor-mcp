"""Source-attributed acceptance; earlier snapshots are never rewritten."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'docs/validation/v3.8/relation_identity_2026_10_15'
sha = lambda data: hashlib.sha256(data).hexdigest()
full = Path('/tmp/v381-identity-full-final.log').read_text()
result = re.search(r'(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s', full)
assert result and result.group(1, 2, 3) == ('1162', '4', '40')
assert '0 errors, 0 warnings' in Path('/tmp/v381-identity-pyright-final.log').read_text()
assert 'Installed prompt resources and routing guidance valid' in Path('/tmp/v381-identity-prompt.log').read_text()
source = {p.relative_to(ROOT).as_posix(): sha(p.read_bytes()) for p in sorted((ROOT/'src/sql_safety_executor').rglob('*')) if p.is_file() and p.suffix in {'.py', '.md'}}
installed = json.loads((OUT/'installed_wheel.json').read_text())
assert installed['total_calls'] == 36 and installed['import_outside_repository']
assert source == {'src/' + name: value for name, value in installed['installed_source_sha256'].items()}
if (OUT/'automation.json').exists():
    assert source == json.loads((OUT/'automation.json').read_text())['source_sha256']
live = json.loads((OUT/'live_mysql.json').read_text())
assert live['total_calls'] == 12 and live['real_database_writes'] is False
assert 'version = "3.8.1"' in (ROOT/'pyproject.toml').read_text()
assert not subprocess.check_output(['git', 'diff', '--', 'pyproject.toml', 'uv.lock'], cwd=ROOT)
automation = {'version':'3.8.1', 'source_sha256':source,
    'full_suite': {'passed':1162,'skipped':4,'warnings':40,'seconds':float(result.group(4)),'mysql_optin':False},
    'new_regressions':48,'pyright':{'errors':0,'warnings':0},'prompt_contract':'passed',
    'installed_stdio_calls':36,'real_mysql_readonly_calls':12,'real_database_writes':False,
    'resident_host':'Pending maintainer restart; native_before_restart.json records old policy',
    'reported_earlier_oct15_checks':{'passed':7,'attribution':'User-provided external report, before this repair; original frames not inspected'},
    'model_cost':'Not remeasured; earlier Luna source snapshots remain dated',
    'production_ast':False,'sqlite_authorizer':False}
if (OUT/'native_after_restart.json').exists():
    native = json.loads((OUT/'native_after_restart.json').read_text())
    assert native['checks']['failed'] == 0
    automation['resident_host'] = 'Final primary native checks passed after maintainer restart'
    automation['resident_host_checks'] = native['checks']
(OUT/'automation.json').write_text(json.dumps(automation,ensure_ascii=False,indent=2)+'\n')
for path in Path('/tmp').glob('v381-identity-*.log'):
    (OUT/(path.name+'.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
for path in Path(__file__).parent.glob('*.py'):
    (OUT/(path.name+'.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
archive_path=OUT/'baseline_package_source.tar.gz'
if not archive_path.exists():
    baseline=json.loads((OUT/'baseline_source.json').read_text())['source_sha256']
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w') as tar:
        for name, digest in sorted(baseline.items()):
            path=Path('/tmp/v381-identity-before-src')/name.removeprefix('src/')
            data=path.read_bytes()
            assert sha(data)==digest
            entry=tarfile.TarInfo(name)
            entry.size=len(data)
            entry.mtime=0
            tar.addfile(entry,io.BytesIO(data))
    archive_path.write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
links=0
for line in subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).splitlines():
    path=ROOT/line[3:]
    if not path.is_file() or path.suffix!='.md':continue
    for target in re.findall(r'\]\(([^)\n]+)\)',path.read_text()):
        target=target.strip().strip('<>')
        if '://' in target or target.startswith(('#','mailto:','data:')):continue
        name=target.split('#',1)[0]
        if name:
            resolved=(path.parent/unquote(name)).resolve()
            assert resolved==(OUT/'manifest.json').resolve() or resolved.exists(),(path,name)
            links+=1
for name in ['DESIGN_RISK_REGISTER.md','DESIGN_RISK_REGISTER_ZH.md']:
    ids=re.findall(r'^\| DRR-2026-(\d{3}) \|',(ROOT/'docs/security'/name).read_text(),re.M)
    assert sorted(ids)==[f'{n:03}' for n in range(1,91)]
(OUT/'document_checks.json').write_text(json.dumps({'local_document_link_targets':links,'bilingual_drr_ids':90,
    'diff_check':'passed','version_and_runtime_dependencies_unchanged':True,'scope':'Local file targets, not all remote URLs/heading anchors'},indent=2)+'\n')
manifest={'version':'3.8.1','source_reference':'automation.json#source_sha256',
    'recording_profile':'Decoded application results and compressed source/logs, not full transport frames',
    'omitted':['Issued preview token material','Complete JSON-RPC frames/notifications/IDs','Model reasoning; no new model usage trial'],
    'history':'Earlier validation batches are unchanged; initial failed harness/mock/sandbox logs retained',
    'artifacts':[]}
for path in sorted(OUT.iterdir()):
    if path.name=='manifest.json':continue
    data=path.read_bytes()
    row={'path':path.name,'bytes':len(data),'sha256':sha(data)}
    if path.suffix=='.gz':
        raw=gzip.decompress(data)
        row.update(uncompressed_bytes=len(raw),uncompressed_sha256=sha(raw))
    manifest['artifacts'].append(row)
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'full_passed':1162,'installed_calls':36,'live_readonly_calls':12,'source_files':len(source),'document_links':links,'artifacts':len(manifest['artifacts']),'resident_host':automation['resident_host']}))
