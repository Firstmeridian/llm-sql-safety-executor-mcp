"""Installed package checks; fixtures never use configured live databases."""
import json
import sqlite3
import sys
from fastmcp import Client
from fastmcp.client.transports import StdioTransport


def populate_fixture(fixture):
    fixture.mkdir()
    skill_root = fixture / "skills"
    for name, sql in [("qualified-read", "SELECT n FROM main.orders"), ("literal-read", 'SELECT n FROM "main.orders"')]:
        skill = skill_root / name
        skill.mkdir(parents=True)
        (skill / "skill_def.md").write_text(f"---\nname: {name}\ntype: query\nsource: query.sql\nrisk: low\ndescription: Relation identity\nparams: {{}}\n---\n")
        (skill / "query.sql").write_text(sql)
    skill = skill_root / "revalidation-probe"
    skill.mkdir()
    (skill / "skill_def.md").write_text("---\nname: revalidation-probe\ntype: mutation\nsource: mutation.py\nrisk: low\ndescription: Revalidation error\nparams: {}\n---\n")
    (skill / "mutation.py").write_text('''from sql_safety_executor.skills.mutation import MutationBase
class Mutation(MutationBase):
    validations = 0
    def validate(self, params):
        type(self).validations += 1
        if type(self).validations > 1:
            self.adapter.execute("SELECT * FROM missing_fixture_table")
        return {"valid": True}
    def preview(self, params):
        return {"affected_rows_estimate": 1}
    def execute(self, params):
        raise AssertionError("Execution must not be reached")
''')
    with sqlite3.connect(fixture / "fixture.sqlite") as db:
        db.executescript('CREATE TABLE orders(n INTEGER); INSERT INTO orders VALUES(7); CREATE TABLE "main.orders"(n INTEGER); INSERT INTO "main.orders" VALUES(99);')
    (fixture / "server.toml").write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="demo"\n')
    (fixture / "connections.toml").write_text('schema_version=1\n[connections.demo]\ntype="sqlite"\n[connections.demo.sqlite]\npath="fixture.sqlite"\n[connections.demo.read]\nmode="allowlist"\ntables=["main.orders"]\n[connections.demo.mutation]\nenabled=true\nskills=["revalidation-probe"]\n')
    (fixture / "skills.toml").write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=true\n[skills.audit]\npath="audit.jsonl"\n[skills.mutation]\nenabled=true\nallowed_connections=["demo"]\n')


async def check_installed(target, fixture, logs):
    records = []
    for mode in ("legacy", "auto"):
        transport = StdioTransport(command=sys.executable, args=["-m", "sql_safety_executor", "serve", "--config", str(fixture / "server.toml")],
            env={"PYTHONPATH": str(target)}, cwd=str(fixture), keep_alive=False, log_file=logs / f"installed-{mode}.log")
        async with Client(transport, mode=mode) as client:
            requests, responses = [], []
            async def call(tool, arguments):
                result = await client.call_tool(tool, arguments, raise_on_error=False)
                value = {"isError": result.is_error, "structuredContent": result.structured_content,
                    "content": [item.model_dump(mode="json", exclude_none=True) for item in result.content], "meta": result.meta}
                recorded = {**arguments}
                if "preview_token" in recorded:
                    recorded["preview_token"] = "<omitted; same issued token>"
                requests.append({"tool": tool, "arguments": recorded})
                responses.append(value)
                return value
            fixed = [("query", {"sql": "SELECT n FROM main.orders"}),
                ("query", {"sql": 'SELECT n FROM "main.orders"'}),
                ("query", {"sql": 'SELECT n FROM main."main.orders"'}),
                ("list_skills", {"detail_level": "full", "available_only": False}),
                ("get_skill_detail", {"skill_name": "qualified-read"}),
                ("execute_query_skill", {"skill_name": "qualified-read", "params": {}}),
                ("execute_query_skill", {"skill_name": "literal-read", "params": {}}),
                ("list_tables", {}), ("describe_table", {"table_name": "orders"}),
                ("query", {"sql": 'WITH "main.orders" AS (SELECT 7 AS n) SELECT n FROM "main.orders"'}),
                ("query", {"sql": "SELECT 'a  b' AS label, ABS(-7) AS n"}),
                ("query", {"sql": "SELECT SLEEP(0)"}),
                ("query", {"sql": "SELECT n FROM MAIN.ORDERS"}),
                ("query", {"sql": "SELECT * FROM pragma_table_info('orders')"})]
            for tool, arguments in fixed:
                await call(tool, arguments)
            assert all(responses[i]["structuredContent"]["data"] == [{"n": 7}] for i in [0, 5, 9, 12])
            assert all(responses[i]["structuredContent"]["error_code"] == "table_access_denied" for i in [1, 2, 6])
            by_name = {row["name"]: row for row in responses[3]["structuredContent"]["skills"]}
            assert by_name["qualified-read"]["executable"] and by_name["qualified-read"]["missing_tables"] == []
            assert not by_name["literal-read"]["policy_allowed"]
            assert responses[4]["structuredContent"]["skill"]["schema_ready"]
            assert [row["table_name"] for row in responses[7]["structuredContent"]["tables"]] == ["orders"]
            assert responses[8]["structuredContent"]["success"]
            assert responses[10]["structuredContent"]["data"] == [{"label": "a  b", "n": 7}]
            assert responses[11]["structuredContent"]["error_code"] == "expensive_function_denied"
            assert responses[13]["structuredContent"]["error_code"] == "server_state_denied"
            preview = await call("execute_mutation_skill", {"skill_name": "revalidation-probe", "params": {}})
            token = preview["structuredContent"]["preview_token"]
            preview["structuredContent"]["preview_token"] = "<omitted; token was issued>"
            preview["content"] = [{"type": "text", "text": json.dumps(preview["structuredContent"], ensure_ascii=False)}]
            arguments = {"skill_name": "revalidation-probe", "params": {}, "confirm": True, "preview_token": token}
            failed = await call("execute_mutation_skill", arguments)
            assert not failed["isError"] and failed["structuredContent"]["error_code"] == "validation_failed"
            assert failed["structuredContent"]["execution_outcome"] == "not_executed"
            assert failed["structuredContent"]["validation"]["errors"] == ["Table not found."]
            assert failed["meta"]["preview_token_consumed"] is True
            assert (await call("execute_mutation_skill", arguments))["isError"]
            assert (await call("query", {"sql": "SELECT n FROM main.orders"}))["structuredContent"]["data"] == [{"n": 7}]
            initialized = client.initialize_result
            records.append({"mode": mode, "protocol": initialized.protocolVersion if initialized is not None else None,
                "protocol_note": "Unobserved when the legacy Client exposes no initialize_result",
                "requests": requests, "responses": responses})
    return records
