# v3.8.2 名称、方言与执行保障验收（2026-10-16）

基线为维护者提交 `3323f9c29add7fd158410d5ce57a70fb58c5f2cb`。维护者批准实施 v3.8.2，代码／接口已落地；**维护者选择“稍后重启，先查看报告”；当前驻留 Host 核验与新源码原生 Luna 完整任务尚待完成，不能宣称整体验收已闭环。** 未替用户暂存或提交。

## 完整改动及取舍

| 变更 | 原状态／问题 | 现方案与原理 | 原因／好处 | 代价及范围 |
| --- | --- | --- | --- | --- |
| 名称与方言接口 | 字符串简写不能无歧义表达所有 schema/name；业务名称容易被通用规范化误伤 | 保留 RelationReference，词法名称／引用／角色／位置／作用域和每次关系来源分开记录；只做 ASCII 保留词比较 | 区分限定名、字面点号、空格与 Unicode 名称；引用等价不自动扩权 | 仍是支持包络，不是完整数据库语义引擎；MySQL 物理名不能套用 SQLite 示例 |
| 结构化声明 | read.tables 与 Skill tables 都按首点拆分 | 新增严格 read.relations 和 Skill relations 映射数组；默认 schema readiness 共用结构化依赖 | 配置、raw、Skill、发现、详情和元数据身份一致；字面 * 不是全局 wildcard | 增加可选声明形式；限定引用仍需相应 grant；其他 schema readiness 明确 unverified |
| 统一 SQL 分析 | 分类、关系、CTE 和依赖检查存在多次独立解析 | SQLGlot 30.22.0 显式 SQLite/MySQL 上下文；移除旧 core/structure.py 及重复读取解析；原 SQL／参数执行 | partial/failed 不再表示零依赖；SQLite 名称槽、索引提示、别名和 IN 保留真实边界；普通 CURRENT_USER／LOCALTIME 等列不套用 SQL 标准裸函数语义；函数体不被声明掩盖 | 新运行依赖和解析适配维护成本；不支持项仍拒绝，无旧解析执行回退；受管写计划仍独立检查 |
| CTE 方言 | SQLite 被保守套用有序／显式递归规则 | SQLite 所有同块声明可见／隐式递归；MySQL 有序声明／显式递归自引用；大小写能力另行测量 | 减少 SQLite 假依赖，保留 MySQL 同名物理表检查 | 数据库仍决定循环／语法有效性；没有全方言兼容承诺 |
| MySQL 会话 | 另一连接探测的 mode 不能代表整个池；rollback 不清理会话状态 | 每个物理 connect 在方言检测前初始化／校验完整模式；显式完整集合或继承首个集合；可信任意操作／完整写事务后退休连接 | 执行连接和分析上下文一致；重连／池重建保持约定；明确物理拒绝先于模式初始化 I/O | 可信操作增加重新连接成本；仅受控 read/metadata 复用；私有 engine 扩展自行遵约；不保证存储例程无副作用 |
| SQLite authorizer | 编译后的真实 main/temp/aux 对象和视图来源缺少独立核验 | 稳定物理回调、完整连接独占、cached_statements=0；回调至取完结果生效；实际对象／函数／操作核验 | 同名 temp 不继承主库裸 grant；视图 grant 可经核验来源链读取，不赋予直接底表 grant | 串行访问、目录检查和重新编译有成本；复杂／歧义来源及预算超限拒绝；schema/UDF/Python 可信边界不变 |
| 视图／生命周期 | 缓存、来源标签和准备后 schema 变化可能让朴素 authorizer 失真 | 每请求重建有界来源边，核验视图内部 CTE；空数据库 READ 仅接受唯一已解析候选；异常清理与完整事务锁 | 不沿用旧编译授权；正常 count/rowid 计划可执行；回调不执行 SQL，不用 IGNORE 替换 NULL | 2048 次目录查找／128 视图／1024 边；冲突来源／部分虚拟关系视图返回 view_scope_unresolved；外层取消不强制停止所有同步工作 |
| 元数据及传输 | 统一 64 字符／字符白名单误拒合法 SQLite 名；SQLAlchemy 把名称／字符串里的冒号当绑定 | 方言名称支持包络＋组件引用；独立 transport 只绑定真实占位符并保留原字符串、名称、注释和反斜线 | 工具授权目标与生成 SQL 一致；支持带点／空格／引用符／冒号及长 SQLite 名 | 元数据支持面扩大，需维护方言矩阵；服务器仍是最终语法裁判；不 trim 非法 MySQL 名到另一对象 |
| 配置／文档／固化 | 新类型可能遗漏到离线命令；历史实测脚本带固定日期／版本 | 修复 config explain 结构化数组序列化；统一包／MCP 版本；新增矩阵、会话、成本、安装验收脚本，任务采集按真实版本／唯一 agent ID | 安装、离线命令和真实 MCP 一起验；后续不重复临时安装与手工探测 | 保留中间失败；脚本默认不覆盖证据；历史数据不重写为新版本结果 |

## 已完成的验证

| 项目 | 结果／证据 | 结论的边界 |
| --- | --- | --- |
| 改前基线 | 1750 passed、4 skipped、77 warnings，137.10s；baseline_*.json | 实际工作环境及 owner commit，非干净环境／远端 CI |
| 当前完整回归 | **1881 passed、4 skipped、82 warnings，93.35s**；[日志](v382_2026_10_16/logs/full-accepted.log.gz) | 四项 opt-in MySQL 测试未运行；警告为既有 legacy logging 类，新增夹具增加出现次数；中间失败另存 |
| 类型／提示 | Pyright 0 errors/0 warnings；当前 TOML 提示契约通过 | 未改 prompt 资源；类型／文本通过不等于模型任务验收 |
| 独立原生 SQLite | 完整矩阵见 semantics_matrix_accepted.json.gz：542 物理名称、1000 上下文、300 合法 CTE、4 个拒绝对照、576 无害保留函数调用 | 原生私有 sqlite3 真值＋应用判定，不是 Host 调用；本机 SQLite 3.45.1；不将失败夹具计成语法无效 |
| MySQL 名称／模式 | 同矩阵：8 种 ANSI_QUOTES／NO_BACKSLASH_ESCAPES／PIPES_AS_CONCAT 组合，144 条原生观察，包含别名、临时关系、非递归自身／前向物理表及递归；真实私有池的显式／继承生命周期两组通过 | Oracle MySQL 8.0.25、lower_case_table_names=1；预期非法尾空格／ANSI 标识符找不到列不算实现失败；其他设置／MariaDB 未测 |
| 安装包 | sdist→wheel，独立 /tmp 非 editable 环境；两协议 48 次定点 child stdio 工具调用，另有通用 CLI／提示／两协议安装核验 | 模拟器不替代真实 stdio；已解码 content/structured 记录不包含完整协议帧和通知；75 个资源已与安装包逐项核对 |
| Luna 就绪 | 新 GPT-6 Luna 确实调用 SELECT 7，公开事件及 Host 用量保留 | 这是重启前可调用性验证，**不是 v3.8.2 完整业务任务通过证据** |
| 当前 Host／完整 Luna | 待维护者重启后，以相同 canary 和新三次／场景、四类多轮任务验证 | 12 个新 trial／36 轮计划已冻结，独立真值及数据指纹已保存；不冒用 v3.8.1 结果 |

原生 MySQL 的结果别名观察：当前服务／原始 PyMySQL cursor 都返回去掉开头空格的结果标签（例如输入 ` f `，返回 `f `）。反斜线及反引号的 12 个别名观察原样保留。这不能推导为物理表名 trim，也不说明所有方言／所有对象类别等价；不会据此扩大授权或修改名称。

## 成本与记录约定

第一次 A1/B/A2 与构建／回归并发，保留为探索记录，不作为主要对照。正式 serial_A1/B/A2 使用冻结旧 src 和当前 src、相同私有数据／SQL／绑定／两协议，独立进程串行执行并关闭日志，区分首轮、启动及 warm 样本。正式三阶段均完成，每阶段两协议、各 13 轮 7 次调用（182 次），warm 统计排除首轮；以下给出绝对数值，不以字符数冒充 token，不承诺同工具调用数就等成本。语句缓存 128/0 的原生对照只隔离缓存代价，不代表整个应用成本。

| 测量 | A1：3323f9c | B：v3.8.2 最终源码 | A2：3323f9c |
| --- | ---: | ---: | ---: |
| 策略 SELECT 7 AS n，中位 ms | 2.978 | 0.181 | 3.043 |
| 策略 SELECT COUNT(*) AS n FROM orders，中位 ms | 6.184 | 0.281 | 6.260 |
| 策略 WITH selected AS (SELECT id,amount FROM orders WHERE amount>=10) SELECT SUM(amount) AS n FROM selected，中位 ms | 18.404 | 0.623 | 17.945 |
| 策略 WITH sums AS (SELECT order_id,SUM(amount) AS n FROM items GROUP BY order_id) SELECT SUM(s.n) AS n FROM orders o JOIN sums s ON s.order_id=o.id，中位 ms | 28.129 | 0.924 | 27.973 |
| 策略 SELECT SUM(n) AS n FROM report，中位 ms | 6.683 | 0.308 | 6.351 |
| 策略 SELECT SLEEP(0) AS n，中位 ms | 2.621 | 0.227 | 2.576 |
| 现代 7 调用链 中位 ms | 147.67 | 25.91 | 140.50 |
| 现代 7 调用链 p95 ms | 199.25 | 27.94 | 157.67 |
| legacy 7 调用链 中位 ms | 147.10 | 27.84 | 144.13 |
| legacy 7 调用链 p95 ms | 150.74 | 32.92 | 163.91 |
| 策略冷导入 ms（每阶段一次） | 99.99 | 180.97 | 82.92 |
| 进程峰值 RSS KiB | 110248 | 119024 | 110172 |
| 固定 instructions＋工具描述／input schema 字符数 | 22680 | 22680 | 22680 |

范围：最终 accepted_A1/B/A2（原始记录 cost_accepted_*.json.gz）；6 条相同 SQL 的策略各 80 个 warm 样本；每条工具链包含 6 次 raw query（含预期 SLEEP 拒绝）和 1 次 Query Skill，私有数据 200 订单／400 明细。每阶段两协议、各 13 轮，共 182 次；warm 排除首轮。B 的 75 个当前源码资源与安装包哈希一致，三阶段脚本哈希一致。真实 in-process Client、相同关闭日志，非网络 Host／模型计费。A1/A2 导入及 p95 仍有漂移，不能泛化一个比值。此样本的策略／Client 链下降，同时 SQLGlot 冷导入和进程峰值内存上升（约 8.6 MiB）；SQLite 独占／目录／回调／重新编译及可信 MySQL 操作重连的成本继续保留。前一 serial_* 和并发探索 A1/B/A2 都作为源码／条件独立的检查点保存，不冒充最终源码。

原生 SQLite cache 对照（B，同 SQL 各 100 个 warm 样本，只测 sqlite3，不含应用检查）：

| SQL | cache=128 中位 ms | cache=0 中位 ms |
| --- | ---: | ---: |
| SELECT 7 AS n | 0.00143 | 0.00292 |
| SELECT COUNT(*) AS n FROM orders | 0.00658 | 0.00918 |
| WITH selected AS (SELECT id,amount FROM orders WHERE amount>=10) SELECT SUM(amount) AS n FROM selected | 0.02236 | 0.02698 |
| WITH sums AS (SELECT order_id,SUM(amount) AS n FROM items GROUP BY order_id) SELECT SUM(s.n) AS n FROM orders o JOIN sums s ON s.order_id=o.id | 0.15125 | 0.19573 |

JSON 新规范保留：摘要／清单＋一次原始公开应用结果＋重复测量数组，适当 gzip，源与脚本哈希、失败、未测项、时间和环境范围明确。原始协议帧／通知未采集就明确说明，不笼统称完全没有信息减少。预览 bearer 值按既有规范脱敏，隐藏推理不归档。旧批次封存，不改写。

## 决议、数据状态和待办

- v3.8.2；旧 env／旧入口／旧 SDK 和假想历史调用方兼容不纳入范围；真实扩展点变更及迁移已明确记录。RelationReference／授权／原 SQL 是独立契约；AST 和 authorizer 分别接入，不互相冒充证明。
- 不新增每请求 MySQL 模式探测，不新增 Agent 必需工具步骤，不更改写入批准、token、mutation outcome 或审计边界。authorizer 仅 SQLite；MySQL 控制会话生命周期仍须数据库权限和可信部署。
- 只使用私有 SQLite、MySQL SESSION／临时对象；未修改当前 TOML、既有业务数据或全局模式。任务真值以只读方式读取；真实写入仍须按实际授权审批。
- 已校验临时 uv 0.8.22 和 SQLGlot 30.22.0 官方 wheel；只将 SQLGlot 加入项目运行依赖／锁文件，其他锁定版本不升级。项目 editable 安装元数据已更新到 3.8.2（此前实际为 3.8.0），uv 为 /tmp 工具，未全局安装。
- 待重启后的 Host canary、fresh Luna 真实可调用性／完整任务与实际 usage、truth_after 数据不变检查、清单封存。待完成项目不计入已通过。

设计／来源：[架构及官方文档取舍](../../architecture/V3_8_2_SQL_SEMANTICS_ZH.md)。决议另记中英 REFACTORING_LOG 和 DRR-2026-100–105；旧 v3.8.1 原因判断及证据保持原记录，不把重启后通过写成已证明缓存根因。


### 最后方言复核

收尾原生检查确认 CURRENT_USER 在 SQLite 中可为普通列；先前实现及旧测试把它套用为其他方言的裸函数。SQLGlot SQLite tokenizer 现只保留实际三个 current-time 词汇，普通业务列、raw／Skill／发现／执行按 SQLite 真值对齐；真正 CURRENT_USER() 调用和 MySQL 裸 CURRENT_USER 继续拒绝。新增十项语义／真实列对照，并把旧 SQLite 拒绝夹具改为真实调用，加上 ASCII 业务列正对照，而非删除函数限制。先前 1871 项整套记录、后续四个旧假设失败和修正分别保留。最后 **1881 passed／4 skipped**、48 次两协议安装语义调用及最终同源成本均通过核对。


## 可复用内容与交接

- 项目依赖／版本固定在 pyproject.toml 与 uv.lock，后续用 `uv sync --frozen --group dev` 建环境，无需再次临时寻找 SQLGlot；源码／安装包／MCP 版本一致。临时 uv 未全局安装。
- `scripts/validation/` 固化名称／模式矩阵、私有 MySQL 会话生命周期、冻结源码成本、仓库外 wheel 语义验证。现有完整任务 truth/collect 工具改为读取真实版本、按唯一 agent ID 查找会话，支持独立 output-dir；当前计划已冻结。历史封存输出不重跑覆盖。
- 证据索引：[验证摘要](v382_2026_10_16/verification.json)、[源码与脚本清单](v382_2026_10_16/source_final.json)、[成本摘要](v382_2026_10_16/cost_summary.json)、[原生矩阵](v382_2026_10_16/semantics_matrix_accepted.json.gz)、[安装 stdio](v382_2026_10_16/installed_semantics_accepted.json.gz)、[完整任务计划](v382_2026_10_16/real_tasks/plan.json)。中间错误、过时假设、被中断或仅有进度的运行日志均保留，不能以无结尾日志声称通过。
- 当前只建立 `manifest_pre_restart.json` 检查点，不封存最终 manifest；重启后继续 canary、fresh Luna 原生可调用性和四类各三次多轮任务，核验 truth_after／实际 usage 后再完成最终封存。
- 提交建议草案：`local_archive/v382_review/commit-message-v382.txt`。当前源码和文档均未替维护者暂存／提交；最终提交前补齐待验范围或明确采用当前范围。
