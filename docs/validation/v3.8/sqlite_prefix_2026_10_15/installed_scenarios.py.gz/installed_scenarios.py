"""Installed CLI checks of literal prefix handling on private table/view fixtures."""
import json
import sqlite3
import sys

from fastmcp import Client
from fastmcp.client.transports import StdioTransport


def populate_fixture(fixture):
    fixture.mkdir()


async def check_installed(target, fixture, logs):
    records = []
    for mode in ("legacy", "auto"):
        for kind in ("table", "view"):
            for name in ("sqliteXorders", "SQLITEXorders", "sqlite"):
                stage = fixture / f"{mode}-{kind}-{name}"
                stage.mkdir()
                skill = stage / "skills" / "prefix-read"
                skill.mkdir(parents=True)
                (skill / "skill_def.md").write_text("---\nname: prefix-read\ntype: query\nsource: query.sql\nrisk: low\ndescription: Literal prefix\nparams: {}\n---\n")
                sql = f'SELECT n FROM main."{name}"'
                (skill / "query.sql").write_text(sql)
                with sqlite3.connect(stage / "fixture.sqlite") as db:
                    if kind == "table":
                        db.execute(f'CREATE TABLE "{name}"(n INTEGER)')
                        db.execute(f'INSERT INTO "{name}" VALUES(7)')
                    else:
                        db.execute(f'CREATE VIEW "{name}" AS SELECT 7 AS n')
                    db.executescript("CREATE TABLE control(id INTEGER PRIMARY KEY AUTOINCREMENT); INSERT INTO control DEFAULT VALUES;")
                    assert db.execute(sql).fetchall() == [(7,)]
                (stage / "server.toml").write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="demo"\n')
                (stage / "connections.toml").write_text('schema_version=1\n[connections.demo]\ntype="sqlite"\n[connections.demo.sqlite]\npath="fixture.sqlite"\n[connections.demo.read]\nmode="allowlist"\ntables='+json.dumps(["main."+name])+'\n')
                (stage / "skills.toml").write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=true\n[skills.audit]\npath="audit.jsonl"\n')
                transport = StdioTransport(command=sys.executable,
                    args=["-m", "sql_safety_executor", "serve", "--config", str(stage / "server.toml")],
                    env={"PYTHONPATH": str(target)}, cwd=str(stage), keep_alive=False,
                    log_file=logs / f"installed-{mode}-{kind}-{name}.log")
                async with Client(transport, mode=mode) as client:
                    requests = [("query", {"sql": sql}), ("list_tables", {}),
                        ("get_full_schema", {"detail_level": "full"}),
                        ("list_skills", {"detail_level": "full", "available_only": False}),
                        ("list_skills", {}), ("get_skill_detail", {"skill_name": "prefix-read"}),
                        ("execute_query_skill", {"skill_name": "prefix-read", "params": {}})]
                    responses = []
                    for tool, args in requests:
                        result = await client.call_tool(tool, args, raise_on_error=False)
                        assert not result.is_error
                        responses.append({"isError": result.is_error, "structuredContent": result.structured_content,
                            "content": [item.model_dump(mode="json", exclude_none=True) for item in result.content], "meta": result.meta})
                    assert responses[0]["structuredContent"]["data"] == responses[6]["structuredContent"]["data"] == [{"n": 7}]
                    assert [t["table_name"] for t in responses[1]["structuredContent"]["tables"]] == ([name] if kind == "table" else [])
                    assert set(responses[2]["structuredContent"]["schema"]) == ({name} if kind == "table" else set())
                    assert responses[3]["structuredContent"]["skills"][0]["schema_ready"]
                    assert len(responses[4]["structuredContent"]["skills"]) == 1
                    assert responses[5]["structuredContent"]["skill"]["missing_tables"] == []
                    initialize = client.initialize_result
                    records.append({"mode": mode, "kind": kind, "name": name,
                        "protocol": initialize.protocol_version if initialize is not None else None,
                        "requests": [{"tool": t, "arguments": a} for t, a in requests], "responses": responses})
    return records
