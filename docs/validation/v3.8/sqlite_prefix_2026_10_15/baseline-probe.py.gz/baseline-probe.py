"""Isolated literal-prefix review; no configured databases or server edits."""
import asyncio
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile

from fastmcp import Client
from sql_safety_executor import create_server, load_config

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT))
from tests.support import write_toml


async def scenario(mode, kind, name):
    with tempfile.TemporaryDirectory(prefix="v381-prefix-") as temporary:
        directory = Path(temporary)
        identifier = '"' + name.replace('"', '""') + '"'
        with sqlite3.connect(directory / "fixture.sqlite") as db:
            if kind == "table":
                db.execute(f"CREATE TABLE {identifier}(n INTEGER)")
                db.execute(f"INSERT INTO {identifier} VALUES(7)")
            else:
                db.execute(f"CREATE VIEW {identifier} AS SELECT 7 AS n")
            db.executescript("CREATE TABLE internal_control(id INTEGER PRIMARY KEY AUTOINCREMENT); INSERT INTO internal_control DEFAULT VALUES;")
            assert db.execute(f"SELECT n FROM main.{identifier}").fetchall() == [(7,)]
        skill = directory / "skills" / "prefix-read"
        skill.mkdir(parents=True)
        (skill / "skill_def.md").write_text("---\nname: prefix-read\ntype: query\nsource: query.sql\nrisk: low\ndescription: Prefix review\nparams: {}\n---\n")
        sql = f"SELECT n FROM main.{identifier}"
        (skill / "query.sql").write_text(sql)
        write_toml(directory / "server.toml", {"schema_version": 1,
            "files": {"connections": "connections.toml", "skills": "skills.toml"},
            "server": {"default_connection": "demo"}})
        write_toml(directory / "connections.toml", {"schema_version": 1, "connections": {"demo": {
            "type": "sqlite", "sqlite": {"path": "fixture.sqlite"},
            "read": {"mode": "allowlist", "tables": ["main." + name]}}}})
        write_toml(directory / "skills.toml", {"schema_version": 1, "skills": {
            "enabled": True, "directory": "skills", "readiness": {"check_schema": True},
            "audit": {"path": "audit.jsonl"}}})
        server = create_server(load_config(directory / "server.toml"))
        calls = []
        try:
            async with Client(server, mode=mode) as client:
                for tool, arguments in [
                    ("query", {"sql": sql}), ("list_tables", {}),
                    ("list_skills", {"detail_level": "full", "available_only": False}),
                    ("list_skills", {}), ("get_skill_detail", {"skill_name": "prefix-read"}),
                    ("execute_query_skill", {"skill_name": "prefix-read", "params": {}})]:
                    result = await client.call_tool(tool, arguments, raise_on_error=False)
                    calls.append({"tool": tool, "arguments": arguments, "isError": result.is_error,
                        "structuredContent": result.structured_content,
                        "content": [c.model_dump(mode="json", exclude_none=True) for c in result.content], "meta": result.meta})
                adapter = server.gateway_runtime.registry.get_adapter("demo")
                tables = adapter.get_tables()
                relations = adapter.get_read_relations()
                assert not any(t["table_name"].startswith("sqlite_") for t in tables)
                assert not any(r.reference.name.startswith("sqlite_") for r in relations)
                raw = calls[0]["structuredContent"]
                state = calls[4]["structuredContent"]["skill"]
                assert raw["data"] == [{"n": 7}]
                outcome = {"raw_success": True, "schema_ready": state["schema_ready"],
                    "missing_tables": state["missing_tables"],
                    "default_discovered": any(s["name"] == "prefix-read" for s in calls[3]["structuredContent"]["skills"]),
                    "execution_tool_error": calls[5]["isError"],
                    "table_directory_present": any(t["table_name"] == name for t in tables),
                    "read_relation_present": any(r.reference.name == name for r in relations)}
                return {"mode": mode, "kind": kind, "name": name, "calls": calls, "outcome": outcome}
        finally:
            server.gateway_runtime.close()


async def main():
    records = []
    for mode in ("legacy", "auto"):
        for kind in ("table", "view"):
            for name in ("sqliteXorders", "SQLITEXorders", "sqlite"):
                record = await scenario(mode, kind, name)
                records.append(record)
                print(mode, kind, name, json.dumps(record["outcome"]), flush=True)
    source = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in (ROOT / "src/sql_safety_executor").rglob("*")
              if p.is_file() and p.suffix in (".py", ".md")}
    with gzip.open(OUT / "application-records.json.gz", "wt", encoding="utf-8") as stream:
        json.dump({"version": "3.8.1", "source_sha256": source, "calls": 72,
                   "records": records, "private_fixtures_cleaned": True, "real_database_writes": False,
                   "recording_layer": "in-process Client application results, not full protocol frames"},
                  stream, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    asyncio.run(main())
