"""Source-attributed prefix batch; preserve all prior accepted snapshots."""
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "docs/validation/v3.8/sqlite_prefix_2026_10_15"
sha = lambda data: hashlib.sha256(data).hexdigest()
source = {p.relative_to(ROOT).as_posix(): sha(p.read_bytes()) for p in sorted((ROOT / "src/sql_safety_executor").rglob("*"))
          if p.is_file() and p.suffix in (".py", ".md")}
baseline = json.loads((OUT / "baseline_source.json").read_text())
changed = [p for p in source if source[p] != baseline[p]]
assert changed == ["src/sql_safety_executor/database/sqlite.py"]
installed = json.loads((OUT / "installed_wheel.json").read_text())
assert installed["total_calls"] == 84 and installed["source_files_verified"] == 69
assert source == {"src/" + p: value for p, value in installed["installed_source_sha256"].items()}
before = json.loads(gzip.decompress((OUT / "baseline-calls.json.gz").read_bytes()))
after = json.loads(gzip.decompress((OUT / "after-calls.json.gz").read_bytes()))
assert before["source_sha256"] == baseline and after["source_sha256"] == source
assert before["calls"] == after["calls"] == 72
assert sum(not r["outcome"]["schema_ready"] for r in before["records"]) == 8
assert all(r["outcome"]["schema_ready"] and not r["outcome"]["execution_tool_error"] for r in after["records"])
for left, right in zip(before["records"], after["records"]):
    assert (left["mode"], left["kind"], left["name"]) == (right["mode"], right["kind"], right["name"])
    assert [(c["tool"], c["arguments"]) for c in left["calls"]] == [(c["tool"], c["arguments"]) for c in right["calls"]]
def read_log(name):
    temporary = Path("/tmp") / name
    if temporary.exists():
        return temporary.read_text()
    # A maintainer restart may outlive /tmp; retain the accepted archived logs.
    return gzip.decompress((OUT / (name + ".gz")).read_bytes()).decode()


full = read_log("v381-prefix-full.log")
match = re.search(r"(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s", full)
assert match and match.group(1, 2, 3) == ("1222", "4", "67")
assert "0 errors, 0 warnings" in read_log("v381-prefix-pyright.log")
assert "Installed prompt resources and routing guidance valid" in read_log("v381-prefix-prompt.log")
patch = []
with tarfile.open(OUT / "baseline_package_source.tar.gz") as archive:
    for name in changed:
        old = archive.extractfile(name).read().decode().splitlines(keepends=True)
        new = (ROOT / name).read_text().splitlines(keepends=True)
        patch.extend(difflib.unified_diff(old, new, fromfile="before/" + name, tofile="after/" + name))
(OUT / "change_from_prior.patch").write_text("".join(patch))
automation = {"version": "3.8.1", "source_sha256": source,
    "test_source_sha256": {p.relative_to(ROOT).as_posix(): sha(p.read_bytes()) for p in sorted((ROOT / "tests").rglob("*.py"))},
    "changed_production_files": changed, "new_regressions": 12,
    "full_suite": {"passed": 1222, "skipped": 4, "warnings": 67, "seconds": float(match[4]), "mysql_optin": False},
    "focused": {"passed": 101, "skipped": 3, "warnings": 27, "seconds": 10.38},
    "pyright": {"errors": 0, "warnings": 0}, "prompt_contract": "passed",
    "baseline_client_calls": 72, "after_client_calls": 72, "installed_stdio_calls": 84,
    "real_database_writes": False, "production_config_modified": False,
    "new_live_mysql_checks": False, "model_cost": "Not remeasured",
    "resident_host": "Pending maintainer restart to load the final SQLite SQL predicate; previous 20/20 belongs to prior source"}
if (OUT / "native_after_restart.json").exists():
    native = json.loads((OUT / "native_after_restart.json").read_text())
    assert native["checks"]["failed"] == 0
    automation["resident_host"] = "Current configured-tool native checks passed after maintainer restart"
    automation["resident_host_checks"] = native["checks"]
    automation["resident_host_scope"] = native["scope"]["resident_scope"]
    automation["new_live_mysql_checks"] = native["checks"]["mysql_connection_calls"] > 0
    automation["live_mysql_scope"] = "Seven native Host smoke calls after restart; no new independent adapter matrix"
(OUT / "automation.json").write_text(json.dumps(automation, ensure_ascii=False, indent=2) + "\n")
for p in Path("/tmp").glob("v381-prefix-*.log"):
    (OUT / (p.name + ".gz")).write_bytes(gzip.compress(p.read_bytes(), mtime=0))
old_logs = ROOT / "local_archive/v381_review/sqlite_prefix_reassessment_20261015"
(OUT / "baseline-probe.log.gz").write_bytes(gzip.compress((old_logs / "baseline.log").read_bytes(), mtime=0))
(OUT / "baseline-probe.py.gz").write_bytes(gzip.compress((old_logs / "probe.py").read_bytes(), mtime=0))
for p in Path(__file__).parent.glob("*.py"):
    (OUT / (p.name + ".gz")).write_bytes(gzip.compress(p.read_bytes(), mtime=0))
subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
assert not subprocess.check_output(["git", "diff", "--", "pyproject.toml", "uv.lock"], cwd=ROOT)
links = 0
for line in subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT, text=True).splitlines():
    path = ROOT / line[3:]
    if not path.is_file() or path.suffix != ".md":
        continue
    for target in re.findall(r"\]\(([^)\n]+)\)", path.read_text()):
        target = target.strip().strip("<>")
        if "://" in target or target.startswith(("#", "mailto:", "data:")):
            continue
        filename = target.split("#", 1)[0]
        if filename:
            resolved = (path.parent / unquote(filename)).resolve()
            assert resolved == OUT / "manifest.json" or resolved.exists(), (path, filename)
            links += 1
for name in ("DESIGN_RISK_REGISTER.md", "DESIGN_RISK_REGISTER_ZH.md"):
    ids = re.findall(r"^\| DRR-2026-(\d{3}) \|", (ROOT / "docs/security" / name).read_text(), re.M)
    assert sorted(ids) == [f"{n:03}" for n in range(1, 95)]
for name in ("README.md", "README_ZH.md"):
    content = (ROOT / name).read_text()
    section = content[content.index("### 5. `sample`"):content.index("### 6. `get_full_schema`")]
    response = json.loads(re.findall(r"```json\n(.*?)\n```", section, re.S)[1])
    assert response["query"] == 'SELECT * FROM "main"."users" LIMIT 5'
    assert "MySQL" in section and ("same session" in section or "同一会话" in section)
draft = (ROOT / "local_archive/v381_review/commit-message-complete-v381.txt").read_text()
assert sum(line.startswith("- ") for line in draft.splitlines()) == 7
assert len(draft) < 850
(OUT / "document_checks.json").write_text(json.dumps({"local_file_links": links, "bilingual_drr_ids": 94,
    "diff_check": "passed", "bilingual_sample_json_and_dialect_scope": "passed",
    "commit_draft_bullets": 7, "commit_draft_characters": len(draft),
    "scope": "Local file links, not all remote URLs/anchors"}, indent=2) + "\n")
manifest = {"version": "3.8.1", "source_reference": "automation.json#source_sha256",
    "recording_profile": "Application input/results in gzip, source/test hashes and compressed build/stdio logs; not full transport frames",
    "omitted": ["Complete JSON-RPC frames/IDs/notifications", "No new model usage/cost trial"],
    "cleanup": "Private SQLite directories and installed targets/processes removed; no configured database/TOML writes",
    "history": "Previous source/Host batches and old verbose draft preserved with their attribution", "artifacts": []}
for p in sorted(OUT.iterdir()):
    if p.name == "manifest.json":
        continue
    data = p.read_bytes()
    item = {"path": p.name, "bytes": len(data), "sha256": sha(data)}
    if p.suffix == ".gz":
        uncompressed = gzip.decompress(data)
        item.update(uncompressed_bytes=len(uncompressed), uncompressed_sha256=sha(uncompressed))
    manifest["artifacts"].append(item)
(OUT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"full_passed": 1222, "installed_calls": 84, "before_after_calls_each": 72,
    "source_files": len(source), "changed_files": changed, "document_links": links,
    "drr_ids": 94, "draft_characters": len(draft), "resident_host": automation["resident_host"]}))
