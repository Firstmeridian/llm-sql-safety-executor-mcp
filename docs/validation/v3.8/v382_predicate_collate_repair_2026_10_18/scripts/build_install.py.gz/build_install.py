"""Offline cached-backend build; normal wheel install with frozen dependency reuse."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import venv
import io
import zipfile
import csv
import base64

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parents[1] / 'evidence'
cache = Path.home() / '.cache/uv/archive-v0'
backend_paths = []
for name in ('hatchling', 'pathspec', 'trove_classifiers', 'tomlkit'):
    matches = [p for p in cache.iterdir() if (p / name).is_dir()]
    assert len(matches) == 1, (name, matches)
    backend_paths.append(str(matches[0]))
build_env = os.environ.copy()
build_env['PYTHONPATH'] = os.pathsep.join(backend_paths)
build_env['PYTHONDONTWRITEBYTECODE'] = '1'
folder = Path(tempfile.mkdtemp(prefix='v382-predicate-wheel-'))
dist = folder / 'dist'
print(json.dumps({'build_directory': str(folder), 'offline_cached_backend': True}), flush=True)
code = 'import importlib.metadata as m,json;print(json.dumps({n:m.version(n) for n in ["build","hatchling","pathspec","tomlkit","trove-classifiers"]}))'
backends = json.loads(subprocess.check_output([sys.executable, '-c', code], env=build_env))
subprocess.run([sys.executable, '-m', 'build', '--no-isolation', '--outdir', str(dist)],
               cwd=ROOT, env=build_env, check=True)
wheel = dist / 'llm_sql_safety_executor_mcp-3.8.2-py3-none-any.whl'
assert wheel.is_file()
target = folder / 'wheel_env'
venv.EnvBuilder(with_pip=False).create(target)
site = next((target / 'lib').glob('python*/site-packages'))
dependencies = ROOT / '.venv-v38/lib/python3.12/site-packages'
(site / 'frozen_dependencies.pth').write_text(str(dependencies) + '\n')
python = target / 'bin/python'
def fetch(url):
    return subprocess.check_output(['curl', '-fsSL', '--connect-timeout', '10', '--max-time', '60', url], timeout=65)
previous = ROOT / 'local_archive/v382_review/20261018_collate_repair/evidence/is_only_checkpoint/installed_resources.json'
cached = json.loads(previous.read_text()) if previous.exists() else None
cached_installer = Path(cached['build_directory']) / 'installer' if cached else None
if cached_installer is not None and cached_installer.is_dir():
    # Reuse this batch's previously hash-verified official wheel extraction.
    # Verify its complete wheel RECORD before importing any installer code.
    installer = cached_installer
    record_file = installer / 'installer-0.7.0.dist-info/RECORD'
    checked = 0
    for name, digest, size in csv.reader(record_file.read_text().splitlines()):
        path = (installer / name).resolve()
        assert path.is_relative_to(installer.resolve())
        if digest:
            algorithm, expected = digest.split('=', 1)
            assert algorithm == 'sha256'
            content = path.read_bytes()
            assert base64.urlsafe_b64encode(hashlib.sha256(content).digest()).decode().rstrip('=') == expected
            assert len(content) == int(size)
            checked += 1
    assert checked > 0
    entry = {'filename': cached['installer'], 'digests': {'sha256': cached['installer_sha256']}}
    provenance = {'reused_previous_official_extraction': True, 'wheel_record_files_verified': checked,
                  'record_sha256': hashlib.sha256(record_file.read_bytes()).hexdigest()}
else:
    metadata = json.loads(fetch('https://pypi.org/pypi/installer/0.7.0/json'))
    entry = next(item for item in metadata['urls'] if item['filename'] == 'installer-0.7.0-py3-none-any.whl')
    assert entry['url'].startswith('https://files.pythonhosted.org/')
    data = fetch(entry['url'])
    assert hashlib.sha256(data).hexdigest() == entry['digests']['sha256']
    installer = folder / 'installer'
    installer.mkdir()
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in archive.namelist())
        archive.extractall(installer)
    provenance = {'reused_previous_official_extraction': False}
install_env = os.environ.copy()
install_env['PYTHONPATH'] = str(installer)
subprocess.run([str(python), '-m', 'installer', str(wheel)], cwd='/tmp', env=install_env, check=True)
install_env.pop('PYTHONPATH', None)
inspect_code = '''import importlib.metadata as m,hashlib,json,pathlib,sys,sql_safety_executor
p=pathlib.Path(sql_safety_executor.__file__).parent
assert p.is_relative_to(pathlib.Path(sys.prefix))
assert not any('__editable__' in str(x) for x in sys.meta_path)
print(json.dumps(dict(package=str(p),version=m.version('llm-sql-safety-executor-mcp'),resources={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file() and f.suffix in {'.py','.md'}})))'''
installed = json.loads(subprocess.check_output([str(python), '-c', inspect_code], cwd='/tmp', env=install_env))
package = ROOT / 'src/sql_safety_executor'
current = {str(p.relative_to(package)): hashlib.sha256(p.read_bytes()).hexdigest()
           for p in package.rglob('*') if p.is_file() and p.suffix in {'.py', '.md'}}
assert current == installed['resources'] and len(current) == 75
record = {'version': '3.8.2', 'wheel': str(wheel), 'python': str(python),
          'wheel_sha256': hashlib.sha256(wheel.read_bytes()).hexdigest(), 'installed': installed,
          'backend_versions': backends, 'build_directory': str(folder),
          'installer': entry['filename'], 'installer_sha256': entry['digests']['sha256'],
          'installer_provenance': provenance,
          'dependency_scope': 'Offline cached-backend sdist/wheel build. Fresh interpreter uses verified official PyPA installer 0.7.0 for a normal wheel install, explicitly reusing existing frozen dependency directory. No global installation, editable import or fresh dependency resolution. Previously verified installer cache is reused after RECORD validation.'}
(OUT / 'installed_resources.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'installed_resources': 75, 'python': str(python), 'wheel_sha256': record['wheel_sha256']}), flush=True)
