"""Publish the completed repair and its pending resident scope, preserving history."""
import re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4]
BATCH=Path(__file__).resolve().parents[1]


def replace(name,old,new):
    p=ROOT/name;s=p.read_text()
    assert s.count(old)==1,(name,old,s.count(old))
    p.write_text(s.replace(old,new,1))


def row(name,text):
    p=ROOT/name;lines=p.read_text().splitlines()
    indexes=[i for i,x in enumerate(lines)if x.startswith("| DRR-2026-110 |")]
    assert len(indexes)==1
    lines[indexes[0]]=text
    p.write_text("\n".join(lines)+"\n")


def main():
    full=(BATCH/"evidence/full_regression.log").read_text()
    m=re.search(r"(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s",full)
    assert m and m[1]=="2565" and m[2]=="4"
    report=(BATCH/"drafts/repair_report.md.tpl").read_text()
    for marker,value in zip(["@FULL@","@SKIP@","@WARN@","@TIME@"],m.groups(),strict=True):
        report=report.replace(marker,value)
    target=ROOT/"docs/validation/v3.8/V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md"
    assert not target.exists()
    target.write_text(report)
    replace("README.md",
        "### v3.8.1 Review corrections and task validation (October 2026)",
        "SQLite completed ISNULL/NOTNULL/NOT NULL and IN/NOT IN predicates now retain postfix COLLATE and arithmetic/concatenation continuations. Final validation passes **2565 tests, four skipped**, with 524 installed targeted calls; scoped resident checks await the maintainer restart. See the [predicate repair and remaining limits](docs/validation/v3.8/V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md).\n\n### v3.8.1 Review corrections and task validation (October 2026)")
    replace("README_ZH.md",
        "### v3.8.1 复核修正与完整任务验收（2026 年 10 月）",
        "SQLite 完整 ISNULL／NOTNULL／NOT NULL、IN／NOT IN 判断现保留后缀 COLLATE 及算术／拼接续接。最终 **2565 passed／四项跳过**、524 次安装定点调用通过；限定原生复验待维护者重启。见[完整判断补修与限制](docs/validation/v3.8/V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md)。\n\n### v3.8.1 复核修正与完整任务验收（2026 年 10 月）")
    replace("REFACTORING_LOG.md",
        "## v3.8.2 Repair SQLite operand COLLATE binding (October 18, 2026)",
        "## v3.8.2 Repair SQLite collation and predicate continuations (October 18, 2026)")
    replace("REFACTORING_LOG.md","Add 100 regressions: final 2375 passed/four skipped",
        "The first operand checkpoint added 100 regressions: 2375 passed/four skipped")
    replace("REFACTORING_LOG.md",
        "- Later adjacent assessment confirms a separate existing P3 after complete ISNULL/NOTNULL/NOT NULL and IN/NOT IN predicates; record open DRR-110. Matched 57-case inputs, 15 native calls and private Skill discovery/detail/execution effects are preserved; no further runtime change. The earlier 25-check closure remains limited to IS/ESCAPE operands. [Assessment and workaround](docs/validation/v3.8/V3_8_2_PREDICATE_COLLATE_REVIEW_2026_10_18_ZH.md).",
        "- Preserve the [adjacent review](docs/validation/v3.8/V3_8_2_PREDICATE_COLLATE_REVIEW_2026_10_18_ZH.md), then repair DRR-110 after maintainer approval: resume complete-predicate COLLATE/arithmetic/concatenation/bitwise/JSON tails with explicit grouping, without moving collation or executing regenerated SQL. Add 190 regressions; final **2565 passed/four skipped**, clean type/prompt, 130 source stdio and **524 installed calls**. Restore all 114 matched reads and 480 additional valid analysis forms. Seven pre-existing SQL-generator grouping differences retain independent original-SQL controls. Scoped native verification awaits manual restart under a frozen 71-call plan. [Repair and evidence](docs/validation/v3.8/V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md).")
    replace("REFACTORING_LOG_ZH.md",
        "## v3.8.2 修复 SQLite 操作数 COLLATE 结合（2026-10-18）",
        "## v3.8.2 修复 SQLite COLLATE 与判断续接（2026-10-18）")
    replace("REFACTORING_LOG_ZH.md","新增 100 项，最终全量 2375 passed／四项跳过",
        "首批操作数补修新增 100 项，阶段全量 2375 passed／四项跳过")
    replace("REFACTORING_LOG_ZH.md",
        "- 后续相邻评估确认完整 ISNULL／NOTNULL／NOT NULL、IN／NOT IN 判断后的既有 P3，单列开放 DRR-110。保留 57 条同输入、15 次原生及私有 Skill 发现／详情／执行影响；未继续修改运行代码。此前 25 项关闭仍限 IS／ESCAPE 操作数。[评估与临时恢复](docs/validation/v3.8/V3_8_2_PREDICATE_COLLATE_REVIEW_2026_10_18_ZH.md)。",
        "- 保留[相邻复评](docs/validation/v3.8/V3_8_2_PREDICATE_COLLATE_REVIEW_2026_10_18_ZH.md)，经维护者批准后补修 DRR-110：完整判断后继续消费 COLLATE、算术／拼接／位运算／JSON，并显式保留结合位置，原 SQL 继续执行。新增 190 项，最终 **2565 passed／四项跳过**、类型／提示通过，源码 stdio 130 次及**安装 524 次**通过；同输入 114 次全成功，另恢复 480 条合法分析。七项既有生成器括号差异保留原 SQL 工具对照。限定原生待手动重启，71 项计划已固定。[补修与证据](docs/validation/v3.8/V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md)。")
    for name,label in [("docs/README.md","v3.8.2 complete-predicate COLLATE repair and pending resident checks"),
                       ("docs/README_ZH.md","v3.8.2 完整判断后缀补修及待原生复验")]:
        p=ROOT/name;s=p.read_text();line=next(x for x in s.splitlines()if "V3_8_2_PREDICATE_COLLATE_REVIEW_2026_10_18_ZH.md"in x)
        p.write_text(s.replace(line,line+"\n- ["+label+"](validation/v3.8/V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md)。",1))
    replace("docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md",
        "建议同层定点适配及结合位置回归，本次仅评估未继续修改运行代码。",
        "该阶段只评估并建议同层定点适配，未改运行代码。")
    p=ROOT/"docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md"
    p.write_text(p.read_text()+"\n维护者随后批准实施：SQLite range 返回后按实际优先级续接后缀、算术／拼接／位运算和 JSON，再交回原 range；完整判断在 AST 中保持独立结合，复用现有节点及操作数解析。此处增加方言适配与轻量解析检查，未改原 SQL／授权／依赖，新增 190 项及最终 2565 项回归、524 次安装验证通过；DRR-110 待手动重启后按 71 项计划验收。七项既有生成器打印差异有原 SQL 工具对照，不将生成 SQL 用于执行。[实现、成本与限制](../validation/v3.8/V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md)。\n")
    replace("docs/releases/RELEASE_NOTES_v3_8.md",
        "\n---\n\n# v3.8.0 — FastMCP 4, explicit TOML, instance state and managed MRTR",
        "\n### October 18 complete-predicate postfix and continuation repair\n\nDRR-110 restores COLLATE after completed ISNULL/NOTNULL/NOT NULL and IN/NOT IN predicates, including adjacent arithmetic/concatenation/bitwise/JSON continuations. Retain complete-predicate grouping, original SQL/bindings, dependency authorization and authorizer checks. Add 190 regressions: final 2565 passes/four skips, clean type/prompt and 524 installed targeted calls. The frozen 71-call native plan awaits maintainer restart. Seven existing SQL-generator grouping differences are documented with successful original-SQL tool controls; no new dependency, grant, required Agent step or zero-cost claim. See [decisions and evidence](../validation/v3.8/V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md).\n\n---\n\n# v3.8.0 — FastMCP 4, explicit TOML, instance state and managed MRTR")
    name="docs/guides/TEST_MCP_CLIENT_GUIDE.md"
    replace(name,
        "including IS/ESCAPE COLLATE operands and bound Query Skills.",
        "including IS/ESCAPE operands, completed-predicate COLLATE/arithmetic continuations and bound Query Skills.")
    p=ROOT/"docs/validation/v3.8/V3_8_2_PREDICATE_COLLATE_REVIEW_2026_10_18_ZH.md"
    text=p.read_text();first=text.index("\n")+1
    p.write_text(text[:first]+"\n> 后续维护者已批准[补修](V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md)，源码／安装验证通过，待限定原生重启验收。下文保留本批只读复评时的开放状态及原始失败。\n"+text[first:])
    name="docs/validation/v3.8/V3_8_2_COLLATE_REPAIR_2026_10_18_ZH.md"
    replace(name,
        "本报告的关闭范围限于已实测的 IS／ESCAPE 操作数，不代表完整 COLLATE 语法支持。",
        "本报告的关闭范围限于已实测的 IS／ESCAPE 操作数，不代表完整 COLLATE 语法支持。后续 DRR-110 已获准[补修](V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md)，源码／安装通过，待限定原生复验。")
    row("docs/security/DESIGN_RISK_REGISTER.md",
        "| DRR-2026-110 | Implemented; scoped resident verification pending | Low (functional compatibility) | 2026-10-18 | SQLite complete-predicate continuations | Inherited range parsing omitted postfix COLLATE and higher-precedence tails, falsely refusing valid reads and skipping Query Skills. | Yes | Resume SQLite range continuations with explicit predicate grouping and existing node/operand builders; retain original SQL/bindings, independent policy and authorizer. | 190 new regressions; final 2565 passes/four skips, clean type/prompt; all 114 matched calls and 540 analysis cases complete, 480 newly accepted round trips agree. Source stdio 130 and installed 524 calls pass with 75 matching resources. [Repair](../validation/v3.8/V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md). | Await manual maintainer restart and frozen 71-call native plan. Seven unchanged SQL-generator grouping differences have actual original-SQL tool controls. Preserve 573 prior sealed files and review failures. No new grant/dependency/required Agent step or zero-cost claim; earlier scoped DRR-109/108 closures retain their source attribution. |")
    row("docs/security/DESIGN_RISK_REGISTER_ZH.md",
        "| DRR-2026-110 | 已补修；限定驻留复验待完成 | 低（功能兼容） | 2026-10-18 | SQLite 完整判断后缀与续接 | 继承的 range 解析遗漏后缀 COLLATE 及高优先级续接，误拒合法读取并跳过 Query Skill。 | 是 | SQLite range 续接时显式保留完整判断结合位置，复用节点／操作数；原 SQL、绑定、独立策略及 authorizer 保留。 | 新增 190 项，最终 2565 passed／四项跳过，类型／提示通过；同输入 114 次及 540 条分析全通过，新增接受 480 条往返语义一致；源码 stdio 130 次、安装 524 次及 75 项资源一致。[补修](../validation/v3.8/V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md)。 | 待维护者手动重启，71 项原生计划已固定。七项既有生成器括号差异有原 SQL 工具对照；此前 573 项封存及复评失败保留。无新 grant／依赖／Agent 必需步骤或零成本承诺；DRR-109／108 保留原源码限定关闭。 |")
    p=ROOT/"local_archive/v382_review/README.md"
    p.write_text(p.read_text()+"\n## 完整判断后缀与续接补修（2026-10-18）\n\n@BT@20261018_predicate_collate_repair/@BT@ 按 scripts／evidence／drafts 组织，正式[报告](../../docs/validation/v3.8/V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md)记录新增 190 项、最终 2565 项回归、540 条相邻分析及 524 次安装验证；保留红测试、夹具校正、类型／中间实现和七项生成器差异。DRR-110 待维护者重启后的 71 项限定原生核验，旧 573 项封存不改写。报告和复评分开，新材料不平铺归档根目录。\n".replace("@BT@","`"))
    draft="""fix(v3.8.2): preserve SQLite predicate and collation semantics

- retain COLLATE binding for operands and completed predicates
- resume predicate arithmetic and restore parameterized Query Skills
- preserve original SQL and scoped read/plan authorization
- add regression, installed-wheel and native acceptance evidence
- document DRR-109/110 and retain review failures and limits
"""
    for name in ["local_archive/v382_review/20261018_collate_repair/drafts/commit-message.txt",
                 "local_archive/v382_review/20261018_predicate_collate_repair/drafts/commit-message.txt"]:
        (ROOT/name).write_text(draft)
    print("Repair report, bilingual narrative, DRR-110 and commit drafts synchronized; resident checks pending.")


if __name__=="__main__":
    main()
