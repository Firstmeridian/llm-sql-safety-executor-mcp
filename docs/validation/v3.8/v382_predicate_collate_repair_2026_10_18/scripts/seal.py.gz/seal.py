"""Seal final predicate repair, keeping prior evidence and intermediate failures."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil

ROOT=Path(__file__).resolve().parents[4]
BATCH=Path(__file__).resolve().parents[1]
LOCAL=BATCH/"evidence"
PUBLIC=ROOT/"docs/validation/v3.8/v382_predicate_collate_repair_2026_10_18"
REVIEW=ROOT/"docs/validation/v3.8/v382_predicate_collate_review_2026_10_18"


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    data=path.read_bytes()
    return json.loads(gzip.decompress(data)if path.suffix==".gz"else data)
def check(path):
    base=path.parent.parent if "local_archive"in path.parts else path.parent
    fs=read(path)["files"]
    for n,info in fs.items():
        f=base/n
        assert sha(f)==info["sha256"] and f.stat().st_size==info["bytes"],f
    return len(fs)
def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n")


def main():
    assert not PUBLIC.exists(),"Append a new batch; never overwrite evidence"
    previous=read(REVIEW/"verification.json")
    preserved=dict(previous["preserved_manifests"])
    p=REVIEW/"manifest.json"
    preserved[str(p.relative_to(ROOT))]={"sha256":sha(p),"files":check(p)}
    for n,info in preserved.items():
        assert sha(ROOT/n)==info["sha256"]and check(ROOT/n)==info["files"],n
    assert sum(x["files"]for x in preserved.values())==573
    package=ROOT/"src/sql_safety_executor"
    current={p.relative_to(package).as_posix():sha(p)for p in sorted(package.rglob("*"))if p.is_file()and p.suffix in {".py",".md"}}
    before=read(LOCAL/"source_before.json")
    assert before["source_sha256"]==previous["runtime_resources"]
    assert len(current)==75
    changed=[n for n in current if current[n]!=before["source_sha256"][n]]
    assert changed==["core/analysis.py"]
    final=read(LOCAL/"matched_final.json.gz")
    assert final["source_sha256"]==current and len(final["records"])==114
    assert all(r["structured"]["success"]for r in final["records"])
    a=read(LOCAL/"audit_before.json.gz");b=read(LOCAL/"audit_final.json.gz")
    assert a["source_sha256"]==before["source_sha256"]and b["source_sha256"]==current
    assert a["summary"]["analysis_complete"]==60 and b["summary"]["analysis_complete"]==540
    assert b["summary"]["roundtrip_equal"]==533
    old={r["sql"]:r for r in a["records"]}
    assert all(old[r["sql"]].get("roundtrip_equal")is False for r in b["summary"]["mismatches"])
    newly=[r for r in b["records"]if old[r["sql"]]["analysis_status"]!="complete"]
    assert len(newly)==480 and all(r["roundtrip_equal"]for r in newly)
    full=(LOCAL/"full_regression.log").read_text()
    match=re.search(r"(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s",full)
    assert match and int(match[1])==2565 and int(match[2])==4
    assert "0 errors, 0 warnings" in (LOCAL/"pyright_final.log").read_text()
    assert "Installed prompt resources and routing guidance valid."in(LOCAL/"prompt_contract.log").read_text()
    installed=read(LOCAL/"installed_resources.json")
    assert installed["installed"]["resources"]==current
    counts={};protocols=set()
    for name,count,field in [
        ("source_stdio",130,"installed_source_sha256"),("installed_semantics",130,"installed_source_sha256"),
        ("installed_trigger_ctes",254,"source_sha256"),("installed_plans",140,"source_sha256")]:
        data=read(LOCAL/(name+".json.gz"))
        assert data[field]==current and data["calls"]==len(data["records"])==count
        for row in data["records"]:
            assert not row["isError"]
            assert json.loads(next(c["text"]for c in row["content"]if c["type"]=="text"))==row["structured"]
            protocols.add(row["protocol"])
        counts[name]=count
    assert protocols=={"2026-07-28","2025-11-25"}
    assert "outside_repository" in (LOCAL/"installed_generic.log").read_text()
    plan=read(LOCAL/"native_plan.json");native=read(LOCAL/"native_before_restart.json")
    assert len(plan["records"])==71 and len(native["records"])==1
    assert native["records"][0]["result"]["structuredContent"]["error_code"]=="sql_parse_failed"
    frozen=Path(before["path"])
    assert frozen.parent==Path("/tmp")and frozen.name.startswith("v382-predicate-repair-before-")
    for n,digest in before["source_sha256"].items():assert sha(frozen/"src/sql_safety_executor"/n)==digest,n
    shutil.rmtree(frozen)
    names=["scripts/validation/installed_semantics.py","tests/test_sqlite_collate_v382.py",
           "tests/test_sqlite_predicate_collate_v382.py",
           "local_archive/v382_review/20261018_predicate_collate_assessment/scripts/probe.py"]
    names += [p.relative_to(ROOT).as_posix()for p in sorted((BATCH/"scripts").glob("*.py"))]
    result={
        "version":"3.8.2","base_commit":"e49cd0eebb9bdf56ac6c114522af5b8743ba3bbf",
        "comparison_baseline":"Previously accepted working-tree IS/ESCAPE checkpoint; exact source_before hashes.",
        "sealed_utc":datetime.now(timezone.utc).isoformat(),"risk":"DRR-2026-110",
        "status":"source_package_passed_resident_restart_pending",
        "runtime_resources":current,"changed_runtime_resources":changed,
        "scripts_tests":{n:sha(ROOT/n)for n in names},
        "full_regression":{"passed":int(match[1]),"skipped":int(match[2]),"warnings":int(match[3]),"seconds":float(match[4])},
        "new_regressions":190,"matched_calls":114,"matched_restored_refusals":54,
        "audit":{"total":540,"complete_before":60,"complete_after":540,"newly_accepted_roundtrip_equal":480,
                 "raw_roundtrip_equal":533,"unchanged_upstream_generator_mismatches":7},
        "calls":counts,"installed_targeted_calls":524,"protocols":sorted(protocols),
        "wheel":{"sha256":installed["wheel_sha256"],"dependency_scope":installed["dependency_scope"],
                 "installer_provenance":installed["installer_provenance"]},
        "native":{"before_restart_refusals":1,"frozen_plan_calls":71,"status":"pending manual maintainer restart"},
        "preserved_sealed_files":573,"preserved_manifests":preserved,
        "limits":[
            "No version/dependency/config/grant/approval/MySQL change; original SQL and bindings execute.",
            "Earlier 276/290 targeted passes, ungrouped/grouped diagnostic and first build are intermediate checkpoints, not final package evidence.",
            "Initial invalid three-column IN fixture, sandbox type failure and None-branch type correction remain recorded.",
            "No fresh Luna task/live MySQL/remote CI/model-server cost A/B; previous results keep their source attribution.",
            "Private views/triggers/parameter Skills retain source/package coverage; no configured native fixture or write.",
            "Application content/structured records are not full protocol frames or native protocol/code-object attestation.",
            "The seven diagnostic SQL-generator grouping differences existed before; actual original-SQL calls have explicit regressions.",
            "Normal wheel installation explicitly reuses frozen dependencies and a RECORD-verified official installer cache, not fresh dependency resolution."
        ]}
    PUBLIC.mkdir()
    for p in sorted(LOCAL.iterdir()):
        if not p.is_file():continue
        if p.suffix in {".log",".py"}or p.name=="native_before_restart.json":
            (PUBLIC/"evidence").mkdir(exist_ok=True)
            (PUBLIC/"evidence"/(p.name+".gz")).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
        else:
            (PUBLIC/"evidence").mkdir(exist_ok=True)
            shutil.copyfile(p,PUBLIC/"evidence"/p.name)
    (PUBLIC/"evidence/analysis_after.py.gz").write_bytes(gzip.compress((package/"core/analysis.py").read_bytes(),mtime=0))
    (PUBLIC/"scripts").mkdir()
    for n in names:
        p=ROOT/n
        (PUBLIC/"scripts"/(p.name+".gz")).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
    write(PUBLIC/"verification.json",result)
    files={p.relative_to(PUBLIC).as_posix():{"sha256":sha(p),"bytes":p.stat().st_size}
           for p in sorted(PUBLIC.rglob("*"))if p.is_file()}
    write(PUBLIC/"manifest.json",{"sealed_utc":result["sealed_utc"],
        "scope":"Final source/package checkpoint; manual native restart pending. Old seals and failed/intermediate evidence remain.",
        "files":files})
    assert check(PUBLIC/"manifest.json")==len(files)
    print(json.dumps({"passed":int(match[1]),"installed_calls":524,"new_files":len(files),"prior_files":573,"native":"pending"}))


if __name__=="__main__":
    main()
