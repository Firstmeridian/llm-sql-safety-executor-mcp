"""Compare native constants and parsed-tree round trips across predicate continuations."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

p=argparse.ArgumentParser()
p.add_argument("--source",type=lambda x:Path(x).resolve(),required=True)
p.add_argument("--output",type=Path,required=True)
args=p.parse_args()
sys.path.insert(0,str(args.source))
import sql_safety_executor as package
from sql_safety_executor.core.analysis import _tokens,analyze_sql
from sql_safety_executor.database.semantics import DialectContext
folder=Path(package.__file__).resolve().parent
assert folder==args.source/"sql_safety_executor"
forms=["NULL ISNULL","0 ISNULL","7 NOTNULL","NULL NOTNULL","7 NOT NULL","NULL NOT NULL",
       "7 IN (7)","7 IN (8)","NULL IN (7,NULL)","7 NOT IN (8)"]
suffixes=[""," COLLATE NOCASE"," COLLATE BINARY COLLATE NOCASE"]
tails=[""," + 1"," * 2"," / 2"," % 2"," || 2"," << 1"," >> 1"," & 3"," | 2",
       " -> '$'"," ->> '$'"," + 2 * 3"," IN (0,1,2)"," = 1"," AND 1"," OR 0"," NOTNULL"]
records=[]
context=DialectContext("sqlite")
with sqlite3.connect(":memory:")as db:
 for form in forms:
  for suffix in suffixes:
   for tail in tails:
    sql="SELECT "+form+suffix+tail+" AS n"
    try:truth=db.execute(sql).fetchall()
    except sqlite3.Error as err:
     records.append({"sql":sql,"native_error":str(err)});continue
    a=analyze_sql(sql,context)
    row={"sql":sql,"native_rows":truth,"analysis_status":a.status}
    try:
     d,t=_tokens(sql,context);tree=d.parser().parse(t,sql)[0]
     emitted=tree.sql(dialect="sqlite")
     row["roundtrip_sql"]=emitted
     row["roundtrip_rows"]=db.execute(emitted).fetchall()
     row["roundtrip_equal"]=truth==row["roundtrip_rows"]
    except Exception as err:row["parse_or_roundtrip_error"]={"type":type(err).__name__,"error":str(err)}
    records.append(row)
summary={"total":len(records),"native_valid":sum("native_rows"in r for r in records),
         "analysis_complete":sum(r.get("analysis_status")=="complete"for r in records),
         "roundtrip_equal":sum(r.get("roundtrip_equal",False)for r in records),
         "mismatches":[r for r in records if r.get("roundtrip_equal")is False]}
out={"scope":"Diagnostic only: original SQL is always executed in production; emitted AST SQL is used only as a semantic test in an independent in-memory SQLite.",
     "package":str(folder),"sqlite_version":sqlite3.sqlite_version,"summary":summary,"records":records,
     "source_sha256":{f.relative_to(folder).as_posix():hashlib.sha256(f.read_bytes()).hexdigest()for f in sorted(folder.rglob("*"))if f.is_file()and f.suffix in {".py",".md"}}}
assert not args.output.exists()
args.output.write_bytes(gzip.compress((json.dumps(out,ensure_ascii=False,indent=2)+"\n").encode(),mtime=0))
print(json.dumps(summary,ensure_ascii=False))
