"""Advance current handoff without rewriting historical assessment/sealed reports."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
handoff = ROOT / "local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md"
text = handoff.read_text()
old = "> 2026-10-22 最新开放项：SQLite 写入物理事务／RETURNING 两项已复现，P1需优先修复；目前仅评估，生产未改，无待重启。见下方当前最新，不以此前业务／读取验收推断实际写入正确。"
new = "> 2026-10-22 当前：DRR-142／143 SQLite 物理写事务／RETURNING 已补修，3493回归、类型／提示及源码／正常wheel各432调用通过；待维护者重启当前MCP后做限定驻留核验。实际写入只在私有文件库验证，未写配置数据库；旧评估与模型失败保持历史范围。"
assert old in text
text = text.replace(old, new, 1)
text = text.replace("**先处理2026-10-22已复现、未修复的SQLite写入P1／P2。** 以下为此前限定验收：", "**先完成DRR-142／143维护者手动重启后的限定驻留复验；源码／安装已经通过。** 以下保留此前历史限定验收：", 1)
anchor = "## 当前最新：SQLite写入事务与RETURNING开放问题（2026-10-22，仅评估）"
assert anchor in text
current = """## 当前最新：SQLite真实写事务与完成态计数（2026-10-22）

维护者批准后实施DRR-142／143：同一独占连接显式建立／核验物理BEGIN，再执行原SQL；在截止时间内分批完成关闭RETURNING，取原生完成态计数，实际DML仍未知时才同连接changes()。不累计触发器／级联／返回行。SQLite rolled_back要有前后物理证据，COMMIT不明／自行回滚仍unknown；游标、回调、事务清理不明则退休连接。读取authorizer／全局引擎模式、MySQL证据规则、提示、依赖、配置和grant均不改；不新增Agent必需调用。

新增120回归，全量3493通过／4可选跳过，类型0/0及提示通过；源码／正常wheel各432应用调用、136完整预览→确认→重放流程，覆盖两分类器／Client模式／传输，清理后独立文件库真值一致，令牌消费后仍拒绝重放。77资源与安装一致。普通提交串行A/B/A中位9.051→8.994→8.979ms；回滚0.380→0.315→0.287ms，基准漂移24%，不承诺提速／模型token。历史十五项Luna及弱提示1/3不是本批实测，不重跑替代写入矩阵。

待维护者手动重启当前Codex SQL MCP并重连；按本批冻结既有别名计划做读取／元数据／继续拒绝／未确认预览，不能据此宣称特殊CTE实际写入已在配置库验证。不执行配置库确认、不新增grant。脚本／wheel已固化，不需反复安装、导入数据或重跑全量。无Full access需求；stdio／类型用定点升级权限完成。两项夹具PRAGMA设置失败、沙盒类型解析和提示脚本缺参的准备错误保留。

[公开契约与证据](../../../docs/validation/v3.8/V3_8_2_SQLITE_WRITE_TRANSACTIONS_2026_10_22_ZH.md)、[本地修复批次](../20261022_sqlite_write_repair/reports/README_ZH.md)。所有旧封存／配置保持，英文分组commit草案已加入物理事务及完成态行数，版本仍v3.8.2；未暂存／提交。

## 历史评估：SQLite写入事务与RETURNING开放问题（2026-10-22，当时仅评估）"""
handoff.write_text(text.replace(anchor, current, 1))

index = ROOT / "local_archive/v382_review/README.md"
text = index.read_text()
anchor = "## 常用入口\n"
assert anchor in text
index.write_text(text.replace(anchor, anchor+"\n- [SQLite真实写入事务与RETURNING补修](20261022_sqlite_write_repair/reports/README_ZH.md)（DRR-142／143；3493通过／4跳过，源码／wheel各432调用；当前待维护者重启，未写配置库）\n- [SQLite写事务历史评估](20261022_sqlite_write_assessment/reports/README_ZH.md)（修复前物理BEGIN／游标生命周期反例保留）\n", 1))

commit = ROOT / "local_archive/v382_review/handoff/commit-message-v382.txt"
text = commit.read_text()
text = text.replace("align SQL semantics, read capabilities and schema costs", "align SQL semantics, write outcomes and schema costs")
text = text.replace("[Fixes]\n", "[Fixes]\n- establish physical SQLite transactions and complete RETURNING before row checks\n", 1)
commit.write_text(text)

guide = ROOT / "docs/guides/TEST_MCP_CLIENT_GUIDE.md"
guide.write_text(guide.read_text()+"""

## SQLite physical write lifecycle (October22, DRR-142/143)

Use `tests/test_sqlite_write_transactions_v382.py` for adapter-level private-file truth and `scripts/validation/sqlite_writes.py --source /absolute/repository/src --output /fresh/source.json.gz` for both in-process/stdio, auto/legacy and SQLGlot/sqlparse full preview-confirm-replay flows. With a normal wheel interpreter, omit --source and run outside editable imports; the script asserts the installed package location. Every write targets its disposable database, never configured business tables. Application records redact tokens and are not full protocol frames or model usage.

Freeze ordinary/CTE/semicolon INSERT/UPDATE/DELETE with/without RETURNING, correct/zero/multiple counts, partial failure and engine-auto-rollback, plus unchanged data after response, token replay and server/cursor cleanup. Check real BEGIN/COMMIT/ROLLBACK traces and independent sqlite3 connections. Include count_changes, direct versus trigger/cascade counts, INSTEAD OF view zero counts, non-DML stale-count prevention, result cancellation/deadline/fetch/close faults and missing physical acknowledgements. Preserve initial fixture/preparation failures separately.

Never substitute logical SQLAlchemy transaction activity, returned-row length or a cached rowcount for physical evidence. Uncertain commit/cleanup stays unknown and tokens remain spent. Measure costs serially on ordinary operations correct in both snapshots; a formerly failing CTE/RETURNING case is capability recovery, not a comparable speed baseline. Owner restart checks on existing aliases are limited reads, refusals and unconfirmed previews unless configured writes are separately approved. [Repair, cost and current acceptance](../validation/v3.8/V3_8_2_SQLITE_WRITE_TRANSACTIONS_2026_10_22_ZH.md).
""")
print("handoff, archive index, English grouped draft and validation guide updated")
