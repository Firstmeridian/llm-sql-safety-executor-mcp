"""Verify exact source/package scope and retain old seals; prepare restart plan."""
import gzip
import hashlib
import importlib.metadata as metadata
import json
from pathlib import Path
import platform
import re
import shutil
import sqlite3
import subprocess
import tomllib
from urllib.parse import unquote

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[2]
E = HERE / "evidence"
PUBLIC = ROOT / "docs/validation/v3.8/v382_sqlite_write_transactions_2026_10_22"
sha = lambda data: hashlib.sha256(data).hexdigest()

baseline = json.loads((E/"baseline.json").read_text())
changed = [name for name, digest in baseline["resources"].items() if sha((ROOT/name).read_bytes()) != digest]
assert sorted(changed) == ["src/sql_safety_executor/database/outcomes.py", "src/sql_safety_executor/database/sqlite.py"], changed
for name, digest in baseline["configuration"].items():
    assert sha((ROOT/name).read_bytes()) == digest
for name, digest in baseline["previous_public_evidence"].items():
    assert sha((ROOT/name).read_bytes()) == digest, name
for name, digest in baseline["resources"].items():
    assert sha((HERE/"baseline"/name).read_bytes()) == digest

source = json.loads(gzip.decompress((E/"source_client.json.gz").read_bytes()))
installed = json.loads(gzip.decompress((E/"installed_client.json.gz").read_bytes()))
installation = json.loads((E/"installed_resources.json").read_text())
resources = {str(p.relative_to(ROOT/"src/sql_safety_executor")): sha(p.read_bytes())
             for p in (ROOT/"src/sql_safety_executor").rglob("*") if p.is_file() and p.suffix in {".py", ".md"}}
assert source["resources"] == installed["resources"] == installation["installed"]["resources"] == resources
assert len(resources) == 77

def stable(value):
    if isinstance(value, dict):
        return {k: stable(v) for k,v in value.items() if k not in {"preview_token_expires_at", "execution_ms"}}
    if isinstance(value, list):
        return [stable(v) for v in value]
    return value

for a, b in zip(source["records"], installed["records"], strict=True):
    for key in ("transport", "parser", "client_mode", "tool", "arguments", "isError", "structured"):
        assert stable(a[key]) == stable(b[key]), (key, a["arguments"])
for record in (source, installed):
    assert record["passed"] and record["flows"] == 136 and len(record["records"]) == 432
    assert record["independent_truth"] == source["independent_truth"]

full = (E/"full_tests.log").read_text()
assert "3493 passed, 4 skipped" in full
assert "197 passed, 1 skipped" in (E/"targeted_final.log").read_text()
assert "0 errors, 0 warnings" in (E/"types_final.log").read_text()
assert "Installed prompt resources and routing guidance valid." in (E/"prompt_contract_final.log").read_text()

frozen = json.loads(gzip.decompress((ROOT/"local_archive/v382_review/20261021_complete_agent_eval/evidence/frozen.json.gz").read_bytes()))
prior = list(frozen["prior_seals"])
for name in ("local_archive/v382_review/20261021_complete_agent_eval/manifest.json",
             "docs/validation/v3.8/v382_complete_agent_eval_2026_10_21/manifest.json"):
    prior.append({"manifest":name, "sha256":sha((ROOT/name).read_bytes())})
count = 0
for spec in prior:
    manifest = ROOT/spec["manifest"]
    assert sha(manifest.read_bytes()) == spec["sha256"]
    record = json.loads(manifest.read_bytes())
    items = record["files"].items() if isinstance(record["files"], dict) else ((x["path"],x) for x in record["files"])
    paths = {}
    for name, meta in items:
        path = next(p for p in [manifest.parent/name, manifest.parent.parent/name, ROOT/name] if p.is_file())
        paths[name] = path
        raw = path.read_bytes()
        assert sha(raw) == (meta["sha256"] if isinstance(meta,dict) else meta), (manifest,name)
        if isinstance(meta,dict):
            if "bytes" in meta: assert len(raw) == meta["bytes"]
            if "decoded_sha256" in meta:
                decoded = gzip.decompress(raw)
                assert sha(decoded) == meta["decoded_sha256"] and len(decoded) == meta["decoded_bytes"]
        count += 1
    for name, meta in record.get("compressed_decoded_records",{}).items():
        raw = gzip.decompress(paths[name].read_bytes())
        assert sha(raw) == meta.get("decoded_sha256",meta.get("sha256"))
        assert len(raw) == meta.get("decoded_bytes",meta.get("bytes"))
assert len(prior) == 77 and count == 2478, (len(prior),count)

versions = {name:metadata.version(name) for name in ["SQLAlchemy","sqlglot","sqlparse","pydantic","fastmcp","mcp"]}
(E/"runtime_versions.json").write_text(json.dumps({"python":platform.python_version(), "sqlite":sqlite3.sqlite_version,
    "distributions":versions, "dependency_resolution":"Reused frozen dependencies; no runtime install/update."},indent=2)+"\n")

connections = tomllib.loads((ROOT/"config/connections.toml").read_text())["connections"]
truth = {}
for alias in ("sqlite_features_sqlite", "rich_mutation_sqlite"):
    path = Path(connections[alias]["sqlite"]["path"])
    path = path if path.is_absolute() else ROOT/"config"/path
    path = path.resolve()
    before = sha(path.read_bytes())
    with sqlite3.connect(path.as_uri()+"?mode=ro",uri=True) as db:
        if alias == "sqlite_features_sqlite":
            rows = db.execute("PRAGMA main.table_xinfo('pages')").fetchall()
            truth[alias] = {"pages_visible_columns":[r[1] for r in rows if r[6] in (0,2,3)]}
        else:
            truth[alias] = {"order_1":db.execute("SELECT id,status FROM orders WHERE id=1").fetchall()}
    assert sha(path.read_bytes()) == before
    truth[alias]["sha256"] = before
assert len(truth["sqlite_features_sqlite"]["pages_visible_columns"]) == 10
assert truth["rich_mutation_sqlite"]["order_1"] == [(1,"confirmed")]
plan = [
    ("check_connection", {"connection_id":"sqlite_features_sqlite"}, "connected"),
    ("query", {"connection_id":"sqlite_features_sqlite", "sql":"SELECT 7 AS n"}, "n=7"),
    ("describe_table", {"connection_id":"sqlite_features_sqlite", "table_name":"pages"}, "10 visible columns, primary position"),
    ("get_full_schema", {"connection_id":"sqlite_features_sqlite", "detail_level":"compact"}, "complete visible columns"),
    ("query", {"connection_id":"sqlite_features_sqlite", "sql":"SELECT SLEEP(1)"}, "expensive_function_denied"),
    ("query", {"connection_id":"sqlite_features_sqlite", "sql":"UPDATE pages SET title=title WHERE id=1"}, "read_only_required, no write"),
    ("query", {"connection_id":"sqlite_features_sqlite", "sql":"EXPLAIN UPDATE pages SET title=title WHERE id=1"}, "non-executing plan succeeds"),
    ("query", {"connection_id":"sakila_mysql", "sql":"SELECT 7 AS n"}, "n=7"),
    ("query", {"connection_id":"sakila_mysql", "sql":"SELECT SLEEP(1)"}, "expensive_function_denied"),
    ("query", {"connection_id":"rich_mutation_sqlite", "sql":"SELECT id,status FROM orders WHERE id=1"}, "confirmed, independent truth"),
    ("execute_mutation_skill", {"connection_id":"rich_mutation_sqlite", "skill_name":"sample-update-order-status", "params":{"order_id":1,"new_status":"shipped"}}, "preview/not_executed only; never confirm"),
    ("query", {"connection_id":"rich_mutation_sqlite", "sql":"SELECT id,status FROM orders WHERE id=1"}, "still confirmed"),
]
(E/"resident_plan.json").write_text(json.dumps({"status":"pending owner manual restart", "truth":truth,
    "plan":[{"tool":tool,"arguments":arguments,"expected":expected} for tool,arguments,expected in plan],
    "limits":"Existing aliases, reads/refusals/non-executing plans/unconfirmed preview only. No configured write approval. Special CTE/RETURNING transaction proof remains source/package private-file scope."},ensure_ascii=False,indent=2)+"\n")

subprocess.run(["git","diff","--check"],cwd=ROOT,check=True)
summary = {"passed":True,"runtime_changes":changed,"resources":77,"configuration_unchanged":3,
    "previous_public_evidence_unchanged":1982,"previous_manifests_unchanged":len(prior),"previous_sealed_file_records":count,
    "full_tests_passed":3493,"optional_skipped":4,"new_regressions":120,"targeted_passed":197,
    "source_calls":432,"installed_calls":432,"flows_per_stage":136,"text_structured_consistent":True,
    "source_installed_semantics_agree":True,"types":"0 errors, 0 warnings", "prompts":"passed",
    "configured_database_writes":0,"resident":"pending owner manual restart and 12 scoped checks",
    "new_model_trials":0,"cost":json.loads((E/"cost.json").read_text())["comparison"],
    "prior_manifests":prior}
(E/"final_checks.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n")

distributions = E/"distributions"
distributions.mkdir(exist_ok=True)
wheel = Path(installation["wheel"])
assert sha(wheel.read_bytes()) == installation["wheel_sha256"]
shutil.copyfile(wheel, distributions/wheel.name)
print(json.dumps({k:v for k,v in summary.items() if k not in {"prior_manifests","cost"}},ensure_ascii=False))
