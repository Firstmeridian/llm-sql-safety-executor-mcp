"""Serial adapter-only A/B/A; ordinary DML correct in both snapshots.

No model, protocol, token or CTE/RETURNING speed claims. Separate subprocesses
avoid import/cache mixing. Baseline is the exact pre-repair 77-resource source.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import statistics
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parents[1] / "evidence"


def measure(source):
    sys.path.insert(0, str(source))
    from sql_safety_executor.database.models import ConnectionPolicy, DatabaseConfig
    from sql_safety_executor.database.sqlite import SQLiteAdapter
    from sql_safety_executor.database.outcomes import ExpectedRowcountMismatchError
    with tempfile.TemporaryDirectory(prefix="sqlite-write-cost-") as directory:
        database = Path(directory) / "fixture.sqlite"
        with sqlite3.connect(database) as db:
            db.executescript("CREATE TABLE orders(id INTEGER PRIMARY KEY,n); INSERT INTO orders VALUES(1,7);")
        adapter = SQLiteAdapter(config=DatabaseConfig(connection_id="fixture", db_type="sqlite",
            query_timeout_seconds=10, connect_timeout_seconds=5, policy=ConnectionPolicy(),
            sqlite_database_path=str(database)))
        assert adapter.connect()
        measurements = {}
        for mismatch in (False, True):
            samples = []
            for index in range(440):
                start = time.perf_counter_ns()
                try:
                    result = adapter.execute_write("UPDATE orders SET n=:n WHERE id=1", {"n": index}, expected_rowcount=2 if mismatch else 1)
                    assert not mismatch and result["rowcount"] == 1
                except ExpectedRowcountMismatchError as error:
                    assert mismatch and error.execution_outcome.value == "rolled_back"
                elapsed = (time.perf_counter_ns() - start) / 1e6
                if index >= 40:
                    samples.append(elapsed)
            with sqlite3.connect(database) as db:
                assert db.execute("SELECT n FROM orders").fetchone() == (439,)
            measurements["mismatch_rollback" if mismatch else "commit"] = {
                "samples_ms": samples, "median_ms": statistics.median(samples),
                "p95_ms": sorted(samples)[int(len(samples)*.95)-1]}
        trace = []
        with adapter._engine.connect() as conn:
            conn.connection.dbapi_connection.set_trace_callback(trace.append)
        adapter.execute_write("UPDATE orders SET n=:n WHERE id=1", {"n": 440}, expected_rowcount=1)
        adapter.close()
        return {"measurements": measurements, "ordinary_write_trace": trace,
            "source": str(source), "resources": {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in (source/"sql_safety_executor").rglob("*") if p.is_file() and p.suffix in {".py", ".md"}}}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path)
    args = parser.parse_args()
    if args.source:
        print(json.dumps(measure(args.source.resolve())))
    else:
        output = OUT / "cost.json"
        assert not output.exists()
        phases = []
        for name, source in [("A1", OUT.parent/"baseline/src"), ("B", ROOT/"src"), ("A2", OUT.parent/"baseline/src")]:
            env = os.environ.copy()
            env.pop("PYTHONPATH", None)
            record = json.loads(subprocess.check_output([sys.executable, str(Path(__file__).resolve()), "--source", str(source)], cwd="/tmp", env=env))
            phases.append({"phase": name, **record})
        comparison = {}
        for name in ("commit", "mismatch_rollback"):
            a1, b, a2 = [p["measurements"][name]["median_ms"] for p in phases]
            comparison[name] = {"A1_ms": a1, "B_ms": b, "A2_ms": a2,
                "B_vs_A1_percent": (b/a1-1)*100, "B_vs_A2_percent": (b/a2-1)*100,
                "A2_vs_A1_percent": (a2/a1-1)*100}
        output.write_text(json.dumps({"scope": __doc__, "phases": phases, "comparison": comparison}, indent=2)+"\n")
        print(json.dumps(comparison))
