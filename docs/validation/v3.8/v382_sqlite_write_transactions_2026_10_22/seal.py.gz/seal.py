"""Seal the source/package checkpoint, preserving old bytes and pending restart."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
from urllib.parse import unquote

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[2]
E = HERE / "evidence"
PUBLIC = ROOT / "docs/validation/v3.8/v382_sqlite_write_transactions_2026_10_22"
sha = lambda data: hashlib.sha256(data).hexdigest()
assert not (HERE/"manifest.json").exists() and not (PUBLIC/"manifest.json").exists()
checks = json.loads((E/"final_checks.json").read_text())
assert checks["passed"] and checks["previous_sealed_file_records"] == 2478

for path in E.iterdir():
    if not path.is_file():
        continue
    if path.suffix in {".log", ".json"}:
        (PUBLIC/(path.name+".gz")).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
    else:
        shutil.copyfile(path,PUBLIC/path.name)
shutil.copytree(E/"distributions",PUBLIC/"distributions")
for path in (HERE/"scripts").glob("*.py"):
    (PUBLIC/(path.name+".gz")).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
for name in ("scripts/validation/sqlite_writes.py", "tests/test_sqlite_write_transactions_v382.py"):
    path = ROOT/name
    (PUBLIC/(path.name+".gz")).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
for name in ("sqlite.py", "outcomes.py"):
    path = HERE/"baseline/src/sql_safety_executor/database"/name
    (PUBLIC/("baseline_"+name+".gz")).write_bytes(gzip.compress(path.read_bytes(),mtime=0))

names = ["README.md", "README_ZH.md", "REFACTORING_LOG.md", "REFACTORING_LOG_ZH.md",
    "docs/README.md", "docs/README_ZH.md", "docs/architecture/SQLITE_ADAPTER_DESIGN.md",
    "docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md", "docs/guides/TEST_MCP_CLIENT_GUIDE.md",
    "docs/releases/RELEASE_NOTES_v3_8.md", "docs/security/DESIGN_RISK_REGISTER.md",
    "docs/security/DESIGN_RISK_REGISTER_ZH.md", "docs/security/V3_8_SECURITY.md",
    "docs/validation/v3.8/V3_8_2_SQLITE_WRITE_TRANSACTIONS_2026_10_22_ZH.md",
    "local_archive/v382_review/README.md",
    "local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md",
    "local_archive/v382_review/handoff/commit-message-v382.txt",
    str((HERE/"reports/README_ZH.md").relative_to(ROOT)), str((PUBLIC/"README.md").relative_to(ROOT))]

def files(folder):
    return sorted(p for p in folder.rglob("*") if p.is_file() and p.name != "manifest.json" and "__pycache__" not in p.parts)

(E/"documentation_checks.json").write_text("{}\n")
(PUBLIC/"documentation_checks.json.gz").write_bytes(gzip.compress(b"{}\n",mtime=0))
private_count, public_count = len(files(HERE)),len(files(PUBLIC))
handoff = ROOT/"local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md"
text = handoff.read_text()
anchor = "## 历史评估：SQLite写入事务与RETURNING开放问题"
assert anchor in text
text = text.replace(anchor, f"本批源码／安装检查点另封存private{private_count}／public{public_count}条文件记录，当前累计**79份manifest／{2478+private_count+public_count}条记录**；旧77份／2478记录及1982份旧公开证据保持。父pending封存不改，重启另建补充。\n\n"+anchor,1)
handoff.write_text(text)

links = 0
broken = []
for name in names:
    path = ROOT/name
    for link in re.findall(r"\[[^\]\n]+\]\(([^)\s]+)\)",path.read_text()):
        if re.match(r"^[a-zA-Z]+:",link) or link.startswith("#"):
            continue
        link = unquote(link.split("#",1)[0].strip("<>"))
        if not link:
            continue
        target = Path(link) if link.startswith("/") else path.parent/link
        links += 1
        if not target.exists() and not target.with_suffix(target.suffix+".gz").exists():
            broken.append({"document":name,"link":link})
assert not broken,broken
subprocess.run(["git","diff","--check"],cwd=ROOT,check=True)
docs = {"documents":{name:sha((ROOT/name).read_bytes()) for name in names},
    "local_links_checked":links,"broken_links":broken,"git_diff_check":"passed",
    "previous_manifests":77,"previous_file_records":2478,"new_private_records":private_count,
    "new_public_records":public_count,"cumulative_manifests":79,
    "cumulative_records":2478+private_count+public_count,
    "scope":"DRR142/143 source/normal-wheel private-file proof; pending owner restart, no configured database writes or new Agent/provider usage claims."}
(E/"documentation_checks.json").write_text(json.dumps(docs,ensure_ascii=False,indent=2)+"\n")
(PUBLIC/"documentation_checks.json.gz").write_bytes(gzip.compress((E/"documentation_checks.json").read_bytes(),mtime=0))
for folder, count in [(HERE,private_count),(PUBLIC,public_count)]:
    entries = {}
    for path in files(folder):
        raw = path.read_bytes()
        meta = {"bytes":len(raw),"sha256":sha(raw)}
        if path.suffix == ".gz":
            decoded = gzip.decompress(raw)
            meta.update(decoded_bytes=len(decoded),decoded_sha256=sha(decoded))
        entries[str(path.relative_to(folder))] = meta
    assert len(entries) == count
    (folder/"manifest.json").write_text(json.dumps({"date":"2026-10-22","checkpoint":"DRR142/143 SQLite physical transactions and completed counts",
        "append_rule":"Preserve earlier failed assessments and all previous seals; resident restart is pending and must be a separate supplement.",
        "files":entries},ensure_ascii=False,indent=2)+"\n")
    for name,meta in entries.items():
        assert sha((folder/name).read_bytes()) == meta["sha256"]
print(json.dumps({key:value for key,value in docs.items() if key != "documents"},ensure_ascii=False))
