"""Read-only acceptance audit; preserve the pre-restart seals and private databases."""
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import tomllib

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[3]
PARENT = HERE.parent
E = HERE / "evidence"
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda p: json.loads(gzip.decompress(p.read_bytes()) if p.suffix == ".gz" else p.read_bytes())

base = read(PARENT / "evidence/baseline.json")
for name, digest in base["configuration"].items():
    assert sha((ROOT / name).read_bytes()) == digest, name
for name, digest in base["previous_public_evidence"].items():
    assert sha((ROOT / name).read_bytes()) == digest, name

native = read(E / "native.json")
assert len(native) == 12
values = []
for row in native:
    packet = row["result"]
    text = [x["text"] for x in packet["content"] if x["type"] == "text"]
    value = packet.get("structuredContent", json.loads(text[0]))
    assert value == json.loads(text[0]), row["index"]
    values.append(value)
assert values[0]["all_connected"]
assert values[1]["data"] == [{"n": 7}]
assert len(values[2]["columns"]) == 10
assert values[3]["total_tables"] == 6 and values[3]["total_columns"] == 34
for i, code in [(4,"expensive_function_denied"), (5,"read_only_required"), (8,"expensive_function_denied")]:
    assert values[i]["error_code"] == code
assert values[6]["success"] and values[6]["data"]
assert values[7]["data"] == [{"n": 7}]
assert values[9]["data"] == values[11]["data"] == [{"id": 1, "status": "confirmed"}]
assert values[10]["mode"] == "preview" and values[10]["execution_outcome"] == "not_executed"

plan = read(PARENT / "evidence/resident_plan.json")
connections = tomllib.loads((ROOT / "config/connections.toml").read_text())["connections"]
for alias, truth in plan["truth"].items():
    path = Path(connections[alias]["sqlite"]["path"])
    path = (path if path.is_absolute() else ROOT / "config" / path).resolve()
    assert sha(path.read_bytes()) == truth["sha256"], alias
    with sqlite3.connect(path.as_uri() + "?mode=ro", uri=True) as db:
        if alias == "rich_mutation_sqlite":
            assert [list(r) for r in db.execute("SELECT id,status FROM orders WHERE id=1")] == truth["order_1"]
        else:
            assert [r[1] for r in db.execute("PRAGMA main.table_xinfo('pages')") if r[6] != 1] == truth["pages_visible_columns"]
    assert sha(path.read_bytes()) == truth["sha256"]

current = {str(p.relative_to(ROOT / "src/sql_safety_executor")): sha(p.read_bytes())
           for p in (ROOT / "src/sql_safety_executor").rglob("*") if p.is_file() and p.suffix in {".py", ".md"}}
installation = read(PARENT / "evidence/installed_resources.json")
assert current == installation["installed"]["resources"] and len(current) == 77
stages = [read(E / f"adjacent_{name}.json.gz") for name in ("source", "installed")]
for stage in stages:
    assert stage["passed"] and stage["resources"] == current
    assert stage["matrix_cases"] == len(stage["records"]) == 120
    assert stage["adapter_attempts"] == 254
    for row in stage["records"]:
        commit, rollback = row["adapter_phases"]
        assert commit["outcome"] == "committed" and commit["post_cleanup_rows"] == row["native_after"]
        assert rollback["outcome"] == "rolled_back" and rollback["post_cleanup_rows"] == row["native_before"]
    assert len(stage["concurrency"]) == 6
    for race in stage["concurrency"]:
        assert sorted((r["outcome"], r["rowcount"]) for r in race["attempts"]) == [("committed",1),("rolled_back",0)]
        winner = next(r["new"] for r in race["attempts"] if r["outcome"] == "committed")
        assert race["post_cleanup_rows"] == [[1,winner,"a"],[2,8,"a"]]
    assert len(stage["real_commit_failures"]) == 2
    for failure in stage["real_commit_failures"]:
        assert failure["outcome"] == "unknown" and failure["error_code"] == "commit_outcome_unknown"
        assert failure["independent_post_cleanup_value"] == [7]
assert stages[0]["records"] == stages[1]["records"]
old, new = (read(E / f"sentinels_{name}.json") for name in ("known_bad", "current"))
assert old["passed"] and new["passed"]
assert old["records"][0]["invariant_violated"] and not new["records"][0]["invariant_violated"]
assert old["records"][1]["outcome"] == "rolled_back" and new["records"][1]["outcome"] == "committed"
probe = read(E / "interface_contract_probe.json")
assert probe["internal_contract_asymmetry_confirmed"] and probe["database_statements_executed"] == 0
assert not probe["production_mcp_failure_reproduced"]

specs = read(PARENT / "evidence/final_checks.json")["prior_manifests"]
for path in [PARENT / "manifest.json", ROOT / "docs/validation/v3.8/v382_sqlite_write_transactions_2026_10_22/manifest.json"]:
    specs.append({"manifest": str(path.relative_to(ROOT)), "sha256": sha(path.read_bytes())})
count = 0
for spec in specs:
    manifest = ROOT / spec["manifest"]
    assert sha(manifest.read_bytes()) == spec["sha256"]
    record = read(manifest)
    items = record["files"].items() if isinstance(record["files"],dict) else ((x["path"],x) for x in record["files"])
    paths = {}
    for name, meta in items:
        path = next(p for p in [manifest.parent/name,manifest.parent.parent/name,ROOT/name] if p.is_file())
        paths[name] = path
        raw = path.read_bytes()
        assert sha(raw) == (meta["sha256"] if isinstance(meta,dict) else meta), (manifest,name)
        if isinstance(meta,dict):
            if "bytes" in meta: assert len(raw) == meta["bytes"]
            if "decoded_sha256" in meta:
                decoded = gzip.decompress(raw)
                assert sha(decoded) == meta["decoded_sha256"] and len(decoded) == meta["decoded_bytes"]
        count += 1
    for name, meta in record.get("compressed_decoded_records",{}).items():
        raw = gzip.decompress(paths[name].read_bytes())
        assert sha(raw) == meta.get("decoded_sha256",meta.get("sha256"))
        assert len(raw) == meta.get("decoded_bytes",meta.get("bytes"))
assert len(specs) == 79 and count == 2625
result = {
    "passed": True, "native_checks":12, "text_structured_consistent":True,
    "source_installed_resources_unchanged":77, "configuration_unchanged":3,
    "configured_database_writes":0, "configured_sqlite_hashes_unchanged":2,
    "adjacent_adapter_attempts_per_stage":254, "adjacent_matrix_cases_per_stage":120,
    "two_writer_races_per_stage":6, "real_commit_failures_per_stage":2,
    "sentinels_detect_known_bad_and_pass_current":True,
    "internal_binding_asymmetry": "confirmed internally; no current MCP failure reproduced; not repaired this turn",
    "previous_manifests_unchanged":79, "previous_sealed_file_records":2625,
    "previous_public_evidence_unchanged":1982,
    "no_runtime_edit_this_turn":True, "new_model_trials":0,
    "prior_full_suite": "3493 passed / 4 optional skips; retained, not rerun without runtime changes",
    "limits": "Native checks are reads, denials, non-executing plan and unconfirmed preview. Actual transaction/failure proof is private source/wheel evidence, not a configured native confirmed write."
}
(E / "checks.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(result,ensure_ascii=False))
