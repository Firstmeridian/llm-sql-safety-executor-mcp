"""Show that native-file invariants distinguish known bad source from the repair."""
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile


def main(args):
    sys.path.insert(0,str(args.source.resolve()))
    from sql_safety_executor.database.models import ConnectionPolicy,DatabaseConfig
    from sql_safety_executor.database.sqlite import SQLiteAdapter
    from sql_safety_executor.database.outcomes import WriteExecutionError
    assert not args.output.exists()
    records=[]
    with tempfile.TemporaryDirectory(prefix="write-regression-oracle-") as directory:
        for name,sql,expected in [
            ("false_rollback","WITH chosen AS(SELECT 1) UPDATE orders SET n=99 WHERE id=1",2),
            ("returning_false_refusal","UPDATE orders SET n=99 WHERE id=1 RETURNING n",1),
        ]:
            path=Path(directory)/(name+".sqlite")
            with sqlite3.connect(path) as db:
                db.executescript("CREATE TABLE orders(id INTEGER PRIMARY KEY,n);INSERT INTO orders VALUES(1,7);")
            subject=SQLiteAdapter(config=DatabaseConfig(connection_id="private",db_type="sqlite",
                query_timeout_seconds=5,connect_timeout_seconds=5,policy=ConnectionPolicy(),sqlite_database_path=str(path)))
            try:
                result=subject.execute_write(sql,{},expected_rowcount=expected)
                outcome=result.execution_outcome.value
                actual=result["rowcount"]
                error_code=None
            except WriteExecutionError as error:
                outcome=error.execution_outcome.value
                actual=getattr(error,"actual_rowcount",None)
                error_code=error.error_code
            subject.close()
            with sqlite3.connect(path) as db:
                observed=db.execute("SELECT n FROM orders WHERE id=1").fetchone()[0]
            violates=(outcome=="rolled_back" and observed!=7) if name=="false_rollback" else not(outcome=="committed" and observed==99 and actual==1)
            assert violates is (args.stage=="known_bad"),(name,outcome,actual,observed)
            records.append({"case":name,"sql":sql,"expected_rowcount":expected,"outcome":outcome,
                "actual_rowcount":actual,"error_code":error_code,"independent_post_cleanup_value":observed,"invariant_violated":violates})
    args.output.write_text(json.dumps({"stage":args.stage,"passed":True,"records":records,
        "source":str(args.source.resolve()),"resources":{str(p.relative_to(args.source.resolve())):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (args.source.resolve()/"sql_safety_executor").rglob("*") if p.is_file() and p.suffix in {".py",".md"}}},indent=2)+"\n")
    print(json.dumps({"stage":args.stage,"records":records}))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source",type=Path,required=True)
    parser.add_argument("--stage",choices=["known_bad","current"],required=True)
    parser.add_argument("--output",type=Path,required=True)
    main(parser.parse_args())
