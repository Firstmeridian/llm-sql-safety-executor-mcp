"""New write-boundary combinations, native truth and independent file observers.

No configured database writes. No model/performance claim. Reuse the existing
normal wheel; do not count this focused matrix as another full-suite run.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import threading


def main(args):
    if args.source:
        sys.path.insert(0,str(args.source.resolve()))
    import sql_safety_executor
    from sql_safety_executor.database.models import ConnectionPolicy, DatabaseConfig
    from sql_safety_executor.database.outcomes import ExpectedRowcountMismatchError, WriteExecutionError
    from sql_safety_executor.database.sqlite import SQLiteAdapter
    package=Path(sql_safety_executor.__file__).resolve().parent
    assert package == args.source.resolve()/"sql_safety_executor" if args.source else package.is_relative_to(Path(sys.prefix))
    assert not args.output.exists()

    def adapter(path):
        result=SQLiteAdapter(config=DatabaseConfig(connection_id="private",db_type="sqlite",
            query_timeout_seconds=5,connect_timeout_seconds=5,policy=ConnectionPolicy(),sqlite_database_path=str(path)))
        assert result.connect()
        return result

    def seed(path,without):
        with sqlite3.connect(path) as db:
            db.executescript("CREATE TABLE orders(id INTEGER PRIMARY KEY,n INTEGER UNIQUE CHECK(n>=0),tag TEXT DEFAULT 'a')"
                             +(" WITHOUT ROWID" if without else "")+"; INSERT INTO orders(id,n) VALUES(1,7),(2,8);")

    def truth(path):
        with sqlite3.connect(path) as db:
            return db.execute("SELECT id,n,tag FROM orders ORDER BY id").fetchall()

    statements=[
        "INSERT INTO orders(id,n) VALUES(3,99)",
        "INSERT OR IGNORE INTO orders(id,n) VALUES(1,99)",
        "REPLACE INTO orders(id,n) VALUES(1,99) RETURNING id,n",
        "INSERT INTO orders(id,n) VALUES(1,99) ON CONFLICT(id) DO UPDATE SET n=excluded.n RETURNING id,n",
        "INSERT INTO orders(id,n) VALUES(1,99) ON CONFLICT(id) DO NOTHING RETURNING id",
        "UPDATE orders SET n=n WHERE id=1 RETURNING id,zeroblob(3) AS payload",
        "UPDATE OR REPLACE orders SET n=8 WHERE id=1 RETURNING id,n",
        "UPDATE orders SET n=n+100 RETURNING id,n,(SELECT COUNT(*) FROM orders) AS c",
        "DELETE FROM orders WHERE id=999 RETURNING id",
        "DELETE FROM orders WHERE id=1 RETURNING id,n",
    ]
    prefixes=["", "WITH chosen AS(SELECT 1) ", ";", "; /*leading*/ WITH chosen AS(VALUES(1)) ",
              'WITH "replace" AS(SELECT 1) ', "WITH replace(n) AS MATERIALIZED (SELECT 1) "]
    records=[]
    with tempfile.TemporaryDirectory(prefix="sqlite-adjacent-boundary-") as directory:
        root=Path(directory)
        for without in (False,True):
            for prefix in prefixes:
                for statement in statements:
                    index=len(records)
                    sql=prefix+statement
                    native=root/f"native-{index}.sqlite"
                    seed(native,without)
                    before=truth(native)
                    with sqlite3.connect(native) as db:
                        db.execute("BEGIN")
                        cursor=db.execute(sql)
                        if cursor.description:
                            cursor.fetchall()
                        direct=db.execute("SELECT changes()").fetchone()[0]
                        db.commit()
                    after=truth(native)
                    phases=[]
                    for mismatch in (False,True):
                        path=root/f"adapter-{index}-{mismatch}.sqlite"
                        seed(path,without)
                        subject=adapter(path)
                        trace=[]
                        with subject._engine.connect() as connection:
                            connection.connection.dbapi_connection.set_trace_callback(trace.append)
                        try:
                            value=subject.execute_write(sql,{},expected_rowcount=direct+(1 if mismatch else 0))
                            assert not mismatch and value["rowcount"]==direct
                            outcome=value.execution_outcome.value
                        except ExpectedRowcountMismatchError as error:
                            assert mismatch and error.actual_rowcount==direct
                            outcome=error.execution_outcome.value
                            assert outcome=="rolled_back"
                        assert outcome==("rolled_back" if mismatch else "committed")
                        assert truth(path)==(before if mismatch else after)
                        assert "BEGIN" in trace and ("ROLLBACK" if mismatch else "COMMIT") in trace
                        subject.close()
                        observed=truth(path)
                        assert observed==(before if mismatch else after)
                        phases.append({"expected":direct+(1 if mismatch else 0),"outcome":outcome,
                                       "post_cleanup_rows":observed,"trace":trace})
                    records.append({"without_rowid":without,"sql":sql,"native_direct_count":direct,
                                    "native_before":before,"native_after":after,"adapter_phases":phases})

        concurrency=[]
        for index in range(6):
            path=root/f"race-{index}.sqlite"
            seed(path,False)
            subjects=[adapter(path),adapter(path)]
            barrier=threading.Barrier(2)
            sql="WITH old_state AS(SELECT :expected AS n) UPDATE orders SET n=:new WHERE id=1 AND n IN(SELECT n FROM old_state) RETURNING id"
            def write(pair):
                subject,new=pair
                barrier.wait(timeout=10)
                try:
                    value=subject.execute_write(sql,{"expected":7,"new":new},expected_rowcount=1)
                    return {"new":new,"outcome":value.execution_outcome.value,"rowcount":value["rowcount"]}
                except ExpectedRowcountMismatchError as error:
                    return {"new":new,"outcome":error.execution_outcome.value,"rowcount":error.actual_rowcount}
            with ThreadPoolExecutor(max_workers=2) as pool:
                attempts=list(pool.map(write,zip(subjects,[99,100])))
            assert sorted((a["outcome"],a["rowcount"]) for a in attempts)==[("committed",1),("rolled_back",0)]
            winner=next(a["new"] for a in attempts if a["outcome"]=="committed")
            assert truth(path)==[(1,winner,"a"),(2,8,"a")]
            for subject in subjects:subject.close()
            assert truth(path)==[(1,winner,"a"),(2,8,"a")]
            concurrency.append({"attempts":attempts,"post_cleanup_rows":truth(path)})

        commit_failures=[]
        for kind in ("deferred_foreign_key","commit_busy"):
            path=root/f"{kind}.sqlite"
            seed(path,False)
            subject=adapter(path)
            blocker=None
            if kind=="deferred_foreign_key":
                with sqlite3.connect(path) as db:
                    db.executescript("CREATE TABLE parent(id INTEGER PRIMARY KEY);INSERT INTO parent VALUES(7),(8);"
                        "CREATE TABLE child(id INTEGER PRIMARY KEY,parent_id INTEGER REFERENCES parent(id) DEFERRABLE INITIALLY DEFERRED);"
                        "INSERT INTO child VALUES(1,7);")
                with subject._engine.connect() as connection:
                    connection.exec_driver_sql("PRAGMA foreign_keys=ON").close()
                sql="WITH c AS(SELECT 1) UPDATE child SET parent_id=99 WHERE id=1 RETURNING id"
            else:
                blocker=sqlite3.connect(path)
                blocker.execute("BEGIN")
                blocker.execute("SELECT * FROM orders").fetchall()
                with subject._engine.connect() as connection:
                    connection.exec_driver_sql("PRAGMA busy_timeout=30").close()
                sql="WITH c AS(SELECT 1) UPDATE orders SET n=99 WHERE id=1 RETURNING id"
            try:
                subject.execute_write(sql,{},expected_rowcount=1)
                raise AssertionError("Expected real COMMIT failure")
            except WriteExecutionError as error:
                assert error.phase.value=="commit" and error.execution_outcome.value=="unknown"
                assert error.error_code=="commit_outcome_unknown"
                result={"case":kind,"outcome":error.execution_outcome.value,"error_code":error.error_code}
            finally:
                if blocker is not None:
                    blocker.rollback();blocker.close()
                subject.close()
            with sqlite3.connect(path) as db:
                value=db.execute("SELECT parent_id FROM child WHERE id=1").fetchone() if kind=="deferred_foreign_key" else db.execute("SELECT n FROM orders WHERE id=1").fetchone()
                assert value==(7,)
            commit_failures.append({**result,"independent_post_cleanup_value":value})

    output={"passed":True,"scope":__doc__,"package":str(package),"matrix_cases":len(records),
        "adapter_attempts":sum(len(r["adapter_phases"]) for r in records)+12+2,
        "records":records,"concurrency":concurrency,"real_commit_failures":commit_failures,
        "resources":{str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in package.rglob("*") if p.is_file() and p.suffix in {".py",".md"}}}
    args.output.write_bytes(gzip.compress(json.dumps(output,ensure_ascii=False,indent=2).encode(),mtime=0))
    print(json.dumps({key:value for key,value in output.items() if key not in {"records","concurrency","real_commit_failures","resources","scope"}}))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source",type=Path)
    parser.add_argument("--output",type=Path,required=True)
    main(parser.parse_args())
