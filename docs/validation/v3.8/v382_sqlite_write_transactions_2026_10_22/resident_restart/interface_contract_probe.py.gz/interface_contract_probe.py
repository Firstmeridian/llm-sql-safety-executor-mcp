"""Internal analysis/original-SQL binding asymmetry; not an MCP bypass claim.

Replace the base executor with a spy, so no MySQL SQL/network/write occurs.
SQLite rejects before opening its fixture path. Normal MCP callers pass the
analysis freshly prepared for the exact executed SQL; that path is inspected.
"""
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[5]
sys.path.insert(0,str(ROOT/"src"))
from sql_safety_executor.core.analysis import analyze_sql
from sql_safety_executor.database.base import DatabaseAdapter
from sql_safety_executor.database.models import ConnectionPolicy,DatabaseConfig
from sql_safety_executor.database.mysql import MySQLAdapter
from sql_safety_executor.database.sqlite import SQLiteAdapter
from sql_safety_executor.database.errors import DatabaseQueryError
from sql_safety_executor.database.semantics import DialectContext

policy=ConnectionPolicy(read_mode="all")
mysql=MySQLAdapter(config=DatabaseConfig(connection_id="private",db_type="mysql",query_timeout_seconds=5,
    connect_timeout_seconds=5,policy=policy,mysql_database="fixture"))
context=DialectContext("mysql",default_schema="fixture")
analysis=analyze_sql("SELECT 7 AS n",context)
assert analysis.complete
with patch.object(mysql,"resolve_analysis_context",return_value=context), patch.object(DatabaseAdapter,"execute_read",return_value=[]) as executor:
    mysql.execute_read("SELECT 99 AS n",policy=policy,analysis=analysis)
    assert executor.call_count==1
    accepted=executor.call_args.args[0]
with tempfile.TemporaryDirectory(prefix="analysis-binding-probe-") as directory:
    path=Path(directory)/"never-opened.sqlite"
    sqlite=SQLiteAdapter(config=DatabaseConfig(connection_id="private",db_type="sqlite",query_timeout_seconds=5,
        connect_timeout_seconds=5,policy=policy,sqlite_database_path=str(path)))
    try:
        sqlite.execute_read("SELECT 99 AS n",policy=policy,analysis=analyze_sql("SELECT 7 AS n",sqlite.analysis_context))
        raise AssertionError("SQLite should reject mismatched analysis")
    except DatabaseQueryError as error:
        assert error.error_code=="session_semantics_unavailable"
    assert not path.exists()
result={"scope":__doc__,"internal_contract_asymmetry_confirmed":True,
    "mysql_passed_mismatched_sql_to_spy":accepted,"sqlite_rejected_before_connect":True,
    "production_mcp_failure_reproduced":False,"database_statements_executed":0,
    "reviewed_mcp_callsite":"core/queries.py prepares plan from sql, passes the same sql and plan.analysis to execute_read; Skill and schema paths reviewed similarly.",
    "recommendation":"Add source_sql binding to the MySQL adapter or a minimal shared validation helper in a separate reviewed change; no new generic framework/cache/switch."}
output=Path(__file__).resolve().parents[1]/"evidence/interface_contract_probe.json"
assert not output.exists()
output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(result,ensure_ascii=False))
