"""Append current acceptance to active navigation; retain sealed pending snapshots."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[5]
report = "../validation/v3.8/V3_8_2_WRITE_RESTART_AND_STABILIZATION_2026_10_22_ZH.md"
for filename, old, new, row in [
    ("docs/security/DESIGN_RISK_REGISTER.md",
     "Implemented; source/package passed, resident restart pending",
     "Implemented; source/package and scoped native12/12 passed",
     f"| DRR-2026-144 | Assessed October22; internal hardening proposed, not implemented | MySQL execute_read omits the analysis.source_sql equality check already present in SQLite. Current MCP query/Skill/metadata callers bind the same SQL. | A zero-database spy probe confirms internal mismatch acceptance; no current MCP failure or authorization bypass reproduced. Recommend a small binding check and contract regression, not a new framework/switch. Additional write combinations pass source/existing-wheel each254 attempts; stabilization gates are proposals. [Evidence and assessment]({report}). |"),
    ("docs/security/DESIGN_RISK_REGISTER_ZH.md",
     "已实现；源码／安装通过，驻留待重启",
     "已实现；源码／安装及限定原生12/12通过",
     f"| DRR-2026-144 | 10月22日已评估；建议内部加固，未实施 | MySQL execute_read 缺少 SQLite 已有的 analysis.source_sql 相等检查；当前 MCP 查询／Skill／元数据调用均绑定同一 SQL。 | 零数据库 spy 确认内部错配会下传，未复现当前 MCP 故障或授权绕过；建议小范围绑定检查及契约回归，不新增框架／开关。另有源码／已有wheel各254次相邻写入尝试通过，稳定性门槛仍属建议。[证据与评估]({report})。 |"),
]:
    path = ROOT / filename
    text = path.read_text()
    assert text.count(old) == 2
    text = text.replace(old, new)
    lines = text.splitlines()
    at = next(i for i,l in enumerate(lines) if l.startswith("| DRR-2026-143 |"))
    # Preserve original contracts, adding a current supplement to each repaired row.
    for i in (at-1, at):
        assert lines[i].startswith("| DRR-2026-14")
        note = (f" Native checks cover reads/refusals/plan/unconfirmed preview only; actual write proof remains private. [Restart supplement]({report}). "
                if filename.endswith("REGISTER.md") else
                f" 原生仅覆盖读取／拒绝／非执行计划／未确认预览，实际写入证明仍属私有夹具。[重启补充]({report})。 ")
        lines[i] = lines[i][:-1] + note + "|"
    lines.insert(at+1, row)
    path.write_text("\n".join(lines)+"\n")

path = ROOT / "local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md"
text = path.read_text()
text = text.replace(
    "待维护者重启当前MCP后做限定驻留核验。实际写入只在私有文件库验证，未写配置数据库；旧评估与模型失败保持历史范围。",
    "维护者重启后限定原生12/12通过，新增源码／已有wheel各254次相邻写入尝试通过。实际写入只在私有文件库验证，未写配置数据库；旧评估与模型失败保持历史范围。DRR-144内部绑定加固仅建议、未实施；本轮未改运行代码，无待重启事项。", 1)
text = text.replace(
    "**先完成DRR-142／143维护者手动重启后的限定驻留复验；源码／安装已经通过。**",
    "**DRR-142／143源码／安装与维护者重启后限定原生12/12均通过，当前无需再重启。先看下方最新稳定性复评，后续建议尚未批准实施。**", 1)
text = text.replace(
    "待维护者手动重启当前Codex SQL MCP并重连；按本批冻结既有别名计划做读取／元数据／继续拒绝／未确认预览，不能据此宣称特殊CTE实际写入已在配置库验证。不执行配置库确认、不新增grant。脚本／wheel已固化，不需反复安装、导入数据或重跑全量。无Full access需求；stdio／类型用定点升级权限完成。两项夹具PRAGMA设置失败、沙盒类型解析和提示脚本缺参的准备错误保留。",
    "维护者重启后冻结12/12限定原生通过：既有别名读取／元数据／继续拒绝／非执行计划／未确认预览；不能据此宣称特殊CTE实际写入已在配置库验证。不执行配置库确认、不新增grant。脚本／wheel已固化，本轮未改运行代码，不需再次重启、安装、导入或重跑全量。无Full access需求；原stdio／类型定点升级权限及两项夹具PRAGMA设置失败、沙盒类型解析、提示脚本缺参的准备错误均保留。", 1)
marker = "## 当前最新：SQLite真实写事务与完成态计数（2026-10-22）"
current = """## 最新补充：重启闭环与稳定性复评（2026-10-22）

原生12/12通过、文本／结构化一致，两配置SQLite摘要及订单不变；旧79份封存／2625记录保持。源码／同一正常wheel各120组合、254次私有适配器写入尝试通过，含六次双写者竞争和两项真实COMMIT错误。已知坏版本哨兵检出假回滚及RETURNING误拒，当前通过；不是新增254项pytest或完整Agent任务，没有新模型／性能声明。

DRR-144：MySQL内部execute_read缺少analysis.source_sql相等核对，SQLite有；零数据库spy证实接口差异，当前MCP各调用点仍绑定同一SQL，无用户可触发故障／授权绕过复现。本轮仅建议后续补检查，未改运行代码。稳定性门槛亦仅建议：优先物理写状态、统一对象绑定、结果保真，再性能／提示；用独立真值、故障注入、有状态组合及已知坏哨兵作发布门槛。不能用3493通过宣称无剩余缺陷，也没有证据要求全盘重写。

[完整复评与最新证据](../../../docs/validation/v3.8/V3_8_2_WRITE_RESTART_AND_STABILIZATION_2026_10_22_ZH.md)、[本地补充](../20261022_sqlite_write_repair/resident_restart/reports/README_ZH.md)。无需再要求重启或Full access；临时sqlparse、COMMIT unknown及弱提示取消严格措辞1/3仍各按旧范围保留。父封存pending及历史失败不回写；版本仍v3.8.2，未暂存／提交。

"""
assert marker in text
text = text.replace(marker, current+marker, 1)
path.write_text(text)
