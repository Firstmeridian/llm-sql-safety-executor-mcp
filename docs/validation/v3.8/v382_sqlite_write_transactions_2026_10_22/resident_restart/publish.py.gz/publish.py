"""Publish an append-only, redacted application-level restart supplement."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[3]
PUBLIC = ROOT / "docs/validation/v3.8/v382_sqlite_write_transactions_2026_10_22/resident_restart"
PUBLIC.mkdir(exist_ok=True)
sha = lambda b: hashlib.sha256(b).hexdigest()

def packed(path, destination):
    raw = path.read_bytes()
    destination.write_bytes(gzip.compress(raw, mtime=0))

(HERE / "reports/README_ZH.md").write_text("""# 2026-10-22 维护者重启后的限定验收与稳定性复评

冻结原生12/12通过；源码／已有正常wheel各254次私有适配器写入尝试通过，含120组合、六次竞争及两项真实COMMIT失败。已知坏版本哨兵能检出旧两项问题，当前通过。DRR-144仅为内部绑定一致性建议，零数据库spy确认，未复现当前MCP故障，本轮未修。

本轮不改运行、提示、依赖、配置或grant，不确认配置库写入；无新模型或性能数据。沿用父3493回归通过／4可选跳过，不再安装／重启／重复全量。维护者重启后的读取／拒绝／计划／未确认预览不能直接证明原生CTE写入修复。父pending和旧79份封存／2625记录、1982旧公开证据保持。

[公开分析与建议](../../../../../docs/validation/v3.8/V3_8_2_WRITE_RESTART_AND_STABILIZATION_2026_10_22_ZH.md)、[核验摘要](../evidence/checks.json)、[原生脱敏记录](../evidence/native.json)、[统一提交草案](../../../handoff/commit-message-v382.txt)。沿用英文分组草案；本轮无新运行实现，不额外加长。稳定性计划待维护者决定，不能标成已实施。没有Full access或再次重启需求。
""")

docs = [ROOT / p for p in [
    "REFACTORING_LOG.md", "REFACTORING_LOG_ZH.md", "docs/README.md", "docs/README_ZH.md",
    "docs/releases/RELEASE_NOTES_v3_8.md", "docs/security/V3_8_SECURITY.md",
    "docs/security/DESIGN_RISK_REGISTER.md", "docs/security/DESIGN_RISK_REGISTER_ZH.md",
    "docs/validation/v3.8/V3_8_2_WRITE_RESTART_AND_STABILIZATION_2026_10_22_ZH.md",
    "local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md",
    "local_archive/v382_review/handoff/commit-message-v382.txt",
]]
entries = []
for folder in (HERE / "scripts", HERE / "evidence"):
    for path in sorted(folder.iterdir()):
        if not path.is_file() or path.name in {"documentation_checks.json"}: continue
        destination = PUBLIC / (path.name if path.suffix == ".gz" else path.name + ".gz")
        if path.suffix == ".gz": destination.write_bytes(path.read_bytes())
        else: packed(path, destination)
        entries.append(destination.name)
snapshot = HERE / "evidence/docs"
snapshot.mkdir(exist_ok=True)
for path in docs:
    packed(path, snapshot / (str(path.relative_to(ROOT)).replace("/", "__") + ".gz"))
packed(docs[8], PUBLIC / "assessment.md.gz")
(PUBLIC / "README.md").write_text("""# Owner-restarted SQLite write supplement — 2026-10-22

Current result: **12/12 scoped native checks pass**. Source and the same normal installed wheel each pass **254 private adapter write attempts** (120 commit/rollback combinations, six two-writer races, two real COMMIT errors). Known-bad-source sentinels detect the original defects; current source passes. No runtime, prompt, dependency, configuration or grant edit; no confirmed configured write or new model/performance trial. Existing3493 regression passes/four optional skips retain their original scope.

See the [Chinese stability/contract assessment](../../V3_8_2_WRITE_RESTART_AND_STABILIZATION_2026_10_22_ZH.md), [original repair checkpoint](../../V3_8_2_SQLITE_WRITE_TRANSACTIONS_2026_10_22_ZH.md), and [verification summary](checks.json.gz). Preserve the parent pending seal and old failed observations; native reads/refusals/non-executing plan/unconfirmed preview do not directly prove a configured confirmed CTE write. Actual transaction/failure truth belongs to private source/wheel fixtures with independent observers after cleanup.

Application records, not complete protocol frames; preview tokens redacted. Resource hashes match all77 source/package resources; three TOMLs and two configured SQLite hashes remain unchanged. The old79 manifests/2625 file records and1982 earlier public files remain intact. DRR-144 only recommends internal MySQL analysis/source-SQL binding hardening: the zero-database spy confirms asymmetry, with no current MCP failure reproduced and no repair claimed.

Scripts and evidence (gzip; timestamps fixed; see manifest for encoded/decoded hashes):

""" + "\n".join(f"- [{name}]({name})" for name in entries) + "\n\n- [Assessment snapshot](assessment.md.gz)\n- [Documentation verification](documentation_checks.json.gz)\n- [Manifest](manifest.json)\n")

links = 0
for path in docs + [HERE / "reports/README_ZH.md", PUBLIC / "README.md"]:
    if path.suffix != ".md": continue
    text = path.read_text()
    for value in re.findall(r"\[[^\]\n]*\]\(([^)\n]+)\)", text):
        value = value.strip().strip("<>")
        if re.match(r"[a-zA-Z]+:", value) or value.startswith("#"): continue
        value = unquote(value.split("#",1)[0])
        if not value or value in {"manifest.json","documentation_checks.json.gz"} and path == PUBLIC / "README.md": continue
        target = Path(value) if value.startswith("/") else path.parent / value
        assert target.exists(), (str(path), value)
        links += 1
for path in docs[6:8]:
    rows = re.findall(r"^\| (DRR-2026-\d+) \|", path.read_text(), re.M)
    assert len(rows) == len(set(rows)) and rows.count("DRR-2026-144") == 1
    assert "| DRR-2026-143 |" in path.read_text() and "\n| DRR-2026-144 |" in path.read_text()
diff = subprocess.run(["git","diff","--check"],cwd=ROOT,capture_output=True,text=True)
assert diff.returncode == 0, diff.stdout + diff.stderr
checks = {"passed":True, "links_checked":links, "diff_check":"passed",
          "bilingual_drr_144":"unique; contiguous with143", "commit_draft":"reviewed; unchanged; grouped English",
          "documents":{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in docs}}
out = HERE / "evidence/documentation_checks.json"
out.write_text(json.dumps(checks,ensure_ascii=False,indent=2)+"\n")
packed(out, PUBLIC / "documentation_checks.json.gz")
for folder in (PUBLIC, HERE):
    files = {}
    for path in sorted(folder.rglob("*")):
        if not path.is_file() or path.name == "manifest.json" or "__pycache__" in path.parts: continue
        raw = path.read_bytes()
        item = {"bytes":len(raw),"sha256":sha(raw)}
        if path.suffix == ".gz":
            decoded = gzip.decompress(raw)
            item.update(decoded_bytes=len(decoded),decoded_sha256=sha(decoded))
        files[str(path.relative_to(folder))] = item
    manifest = {"date":"2026-10-22", "checkpoint":"Owner-restarted12/12 and write-contract/stabilization assessment",
                "scope":"Application records; no configured confirmed writes; retain parent pending and previous seals unchanged.","files":files}
    (folder / "manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"passed":True,"links":links,"public_records":len(json.loads((PUBLIC/"manifest.json").read_text())["files"]),
                  "private_records":len(json.loads((HERE/"manifest.json").read_text())["files"])},ensure_ascii=False))
