"""Reproduce trigger WHEN keyword rejection in both real in-process Clients."""
import asyncio
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'src'))
from fastmcp import Client
from sql_safety_executor import create_server,load_config


async def main():
    records=[]
    with tempfile.TemporaryDirectory(prefix='v382-keyword-clients-') as temporary:
        root=Path(temporary)
        (root/'server.toml').write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="bare"\n')
        connections='schema_version=1\n'
        for name in ['bare','quoted']:
            path=root/(name+'.sqlite')
            field='NEW.begin' if name=='bare' else 'NEW."begin"'
            with sqlite3.connect(path) as db:
                db.executescript('CREATE TABLE orders(n,"begin"); INSERT INTO orders VALUES(7,NULL); CREATE TABLE audit_log(n);'
                    f'CREATE TRIGGER log_orders AFTER INSERT ON orders WHEN {field} IS NULL BEGIN INSERT INTO audit_log VALUES(NEW.n); END;')
                for prefix in ['EXPLAIN','EXPLAIN QUERY PLAN']:
                    db.execute(prefix+' INSERT INTO orders(n) VALUES(99)').fetchall()
            connections+=f'[connections.{name}]\ntype="sqlite"\nsqlite.path="{name}.sqlite"\nread.mode="allowlist"\nread.tables=["orders","audit_log"]\n'
        (root/'connections.toml').write_text(connections)
        (root/'skills.toml').write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=true\n[skills.audit]\npath="audit.jsonl"\n')
        skill=root/'skills/keyword-plan'
        skill.mkdir(parents=True)
        (skill/'skill_def.md').write_text('---\nname: keyword-plan\ntype: query\nsource: query.sql\nrisk: low\ndescription: Private trigger WHEN keyword plan\nconnection_ids: [bare, quoted]\nparams:\n  value:\n    type: int\n    required: true\n---\n')
        (skill/'query.sql').write_text('EXPLAIN INSERT INTO orders(n) VALUES(:value)')
        for mode in ['auto','legacy']:
            server=create_server(load_config(root/'server.toml'))
            try:
                async with Client(server,mode=mode) as client:
                    async def call(tool,args,alias):
                        args={**args,'connection_id':alias}
                        response=await client.call_tool(tool,args,raise_on_error=False)
                        payload=response.structured_content
                        assert isinstance(payload,dict) and not response.is_error
                        text=[item.text for item in response.content if item.type=='text']
                        assert len(text)==1 and json.loads(text[0])==payload
                        records.append(dict(mode=mode,protocol=client.protocol_version,tool=tool,arguments=args,
                            structured=payload,content=[item.model_dump(mode='json',exclude_none=True) for item in response.content]))
                        return payload
                    for alias in ['bare','quoted']:
                        for prefix in ['EXPLAIN','EXPLAIN QUERY PLAN']:
                            result=await call('query',{'sql':prefix+' INSERT INTO orders(n) VALUES(99)'},alias)
                            assert result['success'] is (alias=='quoted')
                            if alias=='bare':
                                assert result['error_code']=='view_scope_unresolved'
                        found=await call('list_skills',{'detail_level':'full'},alias)
                        assert found['skills'][0]['executable'],found
                        detail=await call('get_skill_detail',{'skill_name':'keyword-plan','detail_level':'full'},alias)
                        assert detail['skill']['schema_ready'],detail
                        executed=await call('execute_query_skill',{'skill_name':'keyword-plan','params':{'value':99}},alias)
                        assert executed['success'] is (alias=='quoted'),executed
                        if alias=='bare':
                            assert executed['error_code']=='view_scope_unresolved',executed
                        assert (await call('query',{'sql':'INSERT INTO orders(n) SELECT 99 WHERE 0'},alias))['error_code']=='read_only_required'
                        assert (await call('query',{'sql':'SELECT n,"begin" FROM orders ORDER BY n'},alias))['data']==[{'n':7,'begin':None}]
                        adapter=server.gateway_runtime.registry.get_adapter(alias)
                        assert adapter.execute('SELECT * FROM audit_log')==[]
                        assert adapter._active_guard is None and adapter._read_request is None
            finally:
                server.gateway_runtime.close()
    package=ROOT/'src/sql_safety_executor'
    data=dict(calls=len(records),records=records,data_unchanged=True,configured_database_changes=False,
        source_sha256={str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(package.rglob('*')) if p.is_file() and p.suffix in {'.py','.md'}},
        scope='Actual Client protocols in process, not child stdio or native Host. Original SQL; private automatically cleaned fixtures only.')
    out=ROOT/'local_archive/v382_review/20261017_adjacent_audit/evidence/keyword_clients.json.gz'
    assert not out.exists()
    out.write_bytes(gzip.compress((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
    print(json.dumps(dict(calls=len(records),protocols=sorted({(r['mode'],r['protocol']) for r in records}),confirmed_bare_false_refusals=6,quoted_successes=6,data_unchanged=True)))


if __name__=='__main__':
    asyncio.run(main())
