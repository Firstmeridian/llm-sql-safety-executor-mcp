"""Seal adjacent review and genuine complete-model trials, preserving old seals."""
from datetime import datetime,timezone
import gzip
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4]
BATCH=Path(__file__).resolve().parents[1]
PUBLIC=ROOT/'docs/validation/v3.8/v382_adjacent_audit_2026_10_17'
PARENT=ROOT/'docs/validation/v3.8/v382_trigger_cte_2026_10_17'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(gzip.decompress(path.read_bytes())) if path.suffix=='.gz' else json.loads(path.read_text())


def main():
    assert not (PUBLIC/'manifest.json').exists()
    closure=read(PARENT/'verification.json')
    package=ROOT/'src/sql_safety_executor'
    current={str(p.relative_to(package)):sha(p) for p in package.rglob('*') if p.is_file() and p.suffix in {'.py','.md'}}
    assert current==closure['runtime_resources'] and len(current)==75
    evidence=BATCH/'evidence'
    assessment=read(evidence/'assessment.json')
    assert assessment['source_resources']==current and assessment['runtime_changes_in_review'] is False
    for name in ['matrix_current.json.gz','trigger_keywords_current.json.gz','trigger_keywords_extended_current.json.gz','keyword_clients.json.gz']:
        assert read(evidence/name)['source_sha256']==current,name
    old=read(PARENT/'before_source.json')
    for name in ['trigger_keywords_before.json.gz','trigger_keywords_extended_before.json.gz']:
        assert read(evidence/name)['source_sha256']==old,name
    tasks=PUBLIC/'real_tasks'
    truth_before=read(tasks/'truth_before.json');truth_after=read(tasks/'truth_after.json')
    assert truth_before['source_sha256']==truth_after['source_sha256']
    assert read(tasks/'source_before.json')==current
    for relative,digest in truth_before['source_sha256'].items():
        assert sha(ROOT/relative)==digest,relative
    tables=0
    for alias,entry in truth_before['connections'].items():
        assert entry['results']==truth_after['connections'][alias]['results']
        assert entry['authorized_data']==truth_after['connections'][alias]['authorized_data']
        tables+=len(entry['authorized_data'])
    assert tables==7
    summary=read(tasks/'summary.json')
    assert summary['completed_trials']==3 and summary['passed_check_trials']==2
    assert summary['scripted_user_turns']==6 and summary['mcp_return_observations']==12
    assert summary['manual_review_available']
    manual=read(tasks/'manual_review.json')
    assert [x['business_passed'] for x in manual]==[True,True,False]
    failure=read(tasks/'sales_3.json.gz')
    assert failure['observations']['observed_mcp_responses']==0
    assert any('is not available to the model' in str(e.get('output','')) for e in failure['events'])
    assert len([e for e in failure['events'] if e.get('role')=='assistant' and e.get('channel')=='final'])==2
    resident=read(PARENT/'resident_restart/verification.json')
    manifests=list(resident['preserved_sealed_files_verified'])+[str((PARENT/'resident_restart/manifest.json').relative_to(ROOT))]
    preserved={}
    for name in manifests:
        path=ROOT/name;base=path.parent.parent if name.startswith('local_archive/') else path.parent
        data=read(path)
        for relative,info in data['files'].items():
            p=base/relative
            assert sha(p)==info['sha256'] and p.stat().st_size==info['bytes'],p
        preserved[name]={'files':len(data['files']),'manifest_sha256':sha(path)}
    assert sum(info['files'] for info in preserved.values())==371
    for path in sorted(evidence.iterdir()):
        if path.is_file():
            name=path.name if path.suffix=='.gz' else path.name+'.gz'
            assert not (PUBLIC/name).exists()
            (PUBLIC/name).write_bytes(path.read_bytes() if name==path.name else gzip.compress(path.read_bytes(),mtime=0))
    checkpoint=PUBLIC/'collection_checkpoint'
    assert not checkpoint.exists();checkpoint.mkdir()
    for path in sorted((evidence/'initial_turns').iterdir()):
        (checkpoint/path.name).write_bytes(path.read_bytes())
    scripts=PUBLIC/'scripts';assert not scripts.exists();scripts.mkdir()
    for path in sorted((BATCH/'scripts').glob('*.py')):
        (scripts/(path.name+'.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
    for relative in ['scripts/review_v381/real_task_eval.py','scripts/review_v381/summarize_real_tasks.py']:
        path=ROOT/relative
        (scripts/(path.name+'.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
    verification={'version':'3.8.2','status':'review_complete_P2_confirmed_runtime_unchanged',
        'closed_utc':datetime.now(timezone.utc).isoformat(),
        'source_checkpoint':'../v382_trigger_cte_2026_10_17/verification.json',
        'source_resources_matching_checkpoint':len(current),'runtime_changes_in_review':False,
        'new_P2':{'scope':'Trigger WHEN begin identifier/body marker','unique_forms':6,'prefixes':2,
                  'current_false_refusals':12,'pre_repair_same_input_plan_successes':24,
                  'current_distinct_plan_combinations':76,'current_expectation_matches':64,
                  'actual_Client_calls':28,'Client_false_refusals':6,'Client_quoted_successes':6,
                  'scope_limits':'Private SQLite + policy/adapter and two real in-process Client protocols. No new native trigger fixture, wheel build or full regression rerun.'},
        'complete_Agent_tasks':{'model':summary['model'],'reasoning_effort':summary['reasoning_effort'],
            'fresh_trials':3,'user_turns':6,'business_passed':2,'fixed_checks_passed':2,
            'MCP_return_observations':12,'Host_unavailable_attempts':1,'model_responses':21,
            'host_usage':summary['total_host_usage'],'active_turn_wall_seconds':summary['active_turn_wall_seconds'],
            'independent_preflight_excluded_from_business_cost':True,
            'root_cause':'The failed child used the correct tool name. Further Host startup/timing/binding/cache cause unproven.'},
        'data_integrity':{'configured_writes':False,'authorized_SQLite_table_fingerprints_unchanged':7,
                          'current_source_unchanged':True,'private_fixtures_automatically_cleaned':True},
        'preserved_manifests':preserved,
        'coverage_limits':['No new whole-task coverage for every trigger/keyword fixture; successful sales tasks do not close the new P2.',
                           'Generated columns retain the existing trusted-schema/UDF boundary; repeated outer CTE labels retain conservative scope limits.',
                           'Public application events only; no hidden reasoning, complete transport frames, per-request server latency or invoice comparison.',
                           'Old source/package/native/model outcomes remain attached to their own snapshots; parent then-accepted statuses are unchanged.']}
    (PUBLIC/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')
    files={str(p.relative_to(PUBLIC)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(PUBLIC.rglob('*')) if p.is_file()}
    (PUBLIC/'manifest.json').write_text(json.dumps({'closed_utc':verification['closed_utc'],
        'scope':'Immutable read-only adjacent audit; new P2 remains open, complete task result 2/3. Preserve all failure records and prior manifests.',
        'files':files},ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'sealed_files':len(files),'prior_sealed_files_verified':371,'runtime_resources':75,'new_P2_false_refusals':12,'complete_Agent_tasks_passed':'2/3'}))


if __name__=='__main__':
    main()
