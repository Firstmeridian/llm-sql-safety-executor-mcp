"""Publish review findings without editing runtime code or sealed evidence."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4]
REPORT='V3_8_2_ADJACENT_AUDIT_2026_10_17_ZH.md'
changes={}


def edit(name,old,new):
    text=changes.get(name,(ROOT/name).read_text())
    assert text.count(old)==1,(name,old)
    changes[name]=text.replace(old,new,1)


for name,title,body in [
    ('REFACTORING_LOG.md','v3.8.2 Adjacent audit and current complete Agent trials (October 17, 2026)',
     'Review only; runtime/configuration/dependencies/data unchanged. Reopen DRR-108 for a begin column in trigger WHEN mistaken for the body delimiter: six forms/two prefixes give 12 false refusals, while all 24 same-input cases pass on frozen pre-repair source. Twenty-eight Client calls reproduce raw/Skill failures and quoted-definition controls. Repair this role boundary before final acceptance.\n\n- Current 76 fixture/prefix combinations include 64 expectation matches and those 12 refusals. Generated-column evaluation retains the documented trusted-schema/UDF boundary; repeated outer CTE labels remain a separate conservative limit.\n\n- Three fresh GPT-6 Luna medium two-turn sales trials on current source pass business/fixed checks 2/3; seven SQLite table fingerprints unchanged. Keep one correct-name Host tool-unavailable failure, later empty catalogs and both incomplete turns. No cache root-cause claim. Twelve successful MCP returns do not make three complete tasks pass; verify availability in each actual trial context. Prior source/package evidence keeps its scope.'),
    ('REFACTORING_LOG_ZH.md','v3.8.2 相邻复查与当前完整 Agent 任务（2026-10-17）',
     '本批仅复查，运行代码、配置、依赖与数据未改。新 P2 重开 DRR-108：触发器 WHEN 的合法 begin 列误作正文边界，六种写法／两前缀共 12 项误拒，冻结旧源码同输入 24 项全通过；两种 Client 共 28 次调用复现 raw／Skill 失败及带引号定义对照。应先补角色分界再最终验收。\n\n- 当前 76 个夹具／前缀组合中 64 项符合预期，12 项暴露上述同一问题；其余依赖／函数拒绝保持。生成列属于已记录可信 schema／UDF 范围；外层重复 CTE 限制另列。\n\n- 当前源码三次 fresh GPT-6 Luna medium 双轮销售任务，业务和固定检查均通过 2/3，七张 SQLite 授权表指纹不变。一次正确工具名被 Host 拒绝，随后目录为空，两个未完成轮次保留，不确认缓存根因。12 次实际 MCP 返回成功不代表三个任务全通过；以后逐实际待测子会话核验可调用性，不以别处成功替代。本批不将旧回归／安装结果改写为已覆盖新问题.'),
]:
    p=ROOT/name;text=p.read_text();offset=text.index('## v3.8.2 ')
    block=f'## {title}\n\n- {body}\n\n- [Findings / 问题、证据、用量及建议](docs/validation/v3.8/{REPORT})。\n\n'
    assert title not in text
    changes[name]=text[:offset]+block+text[offset:]

for name,marker,block in [
    ('README.md','The later trigger-local CTE repair adds 129 regressions',f'A [later adjacent audit](docs/validation/v3.8/{REPORT}) reopens DRR-108 for trigger-WHEN keyword handling. Fresh current-source complete sales trials pass 2/3; the Host availability failure remains recorded. Final acceptance awaits that P2 repair.'),
    ('README_ZH.md','后续局部 CTE 补修新增 129 项回归',f'后续[相邻复查](docs/validation/v3.8/{REPORT})确认触发器 WHEN 关键字边界误拒，DRR-108 重开。当前源码新增完整销售试验通过 2/3，Host 可用性失败保留；最终验收仍待该 P2 补修。'),
    ('docs/releases/RELEASE_NOTES_v3_8.md','Trigger-local CTE count callbacks exposed',f'The [later adjacent audit](../validation/v3.8/{REPORT}) reopens DRR-108 for a trigger-WHEN begin-column false refusal; previous scoped checks remain historical evidence. Three current-source complete two-turn Luna trials pass 2/3; retain one correct-name Host unavailable error without a cache root-cause claim. This review changes no runtime code; final acceptance awaits the P2 repair.'),
    ('docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md','最新补充：触发器子查询 CTE',f'再后续相邻审计确认 WHEN 中 begin 列误作正文标记，DRR-108 对新边界重开；旧限定关闭保留历史范围。当前源码完整 Luna 销售任务通过 2/3，Host 可用性失败与生成列既有信任边界单列，见[审计报告](../validation/v3.8/{REPORT})。'),
]:
    text=(ROOT/name).read_text();lines=[line for line in text.splitlines() if marker in line]
    assert len(lines)==1,(name,lines)
    edit(name,lines[0],lines[0]+'\n\n'+block)

edit('docs/security/V3_8_SECURITY.md','# v3.8 security boundary / 安全边界',f'# v3.8 security boundary / 安全边界\n\nCurrent follow-up: the [adjacent audit](../validation/v3.8/{REPORT}) reopens DRR-108 for a confirmed functional regression: a begin column in trigger WHEN is mistaken for the body delimiter. Prior scoped checks retain their evidence boundaries; no unauthorized read/write was demonstrated. The audit also confirms the already-documented generated-column trusted-schema limit and records a separate Host availability failure in one of three complete Agent trials. Runtime code remains unchanged in this review.')

edit('docs/README.md','- [v3.8.2 trigger-local CTE plan repair](validation/v3.8/V3_8_2_TRIGGER_CTE_2026_10_17_ZH.md).',f'- [v3.8.2 trigger-local CTE plan repair](validation/v3.8/V3_8_2_TRIGGER_CTE_2026_10_17_ZH.md).\n- [v3.8.2 adjacent audit and current complete Agent trials](validation/v3.8/{REPORT}).')
edit('docs/README_ZH.md','- [v3.8.2 触发器局部 CTE 计划补修](validation/v3.8/V3_8_2_TRIGGER_CTE_2026_10_17_ZH.md)。',f'- [v3.8.2 触发器局部 CTE 计划补修](validation/v3.8/V3_8_2_TRIGGER_CTE_2026_10_17_ZH.md)。\n- [v3.8.2 相邻问题复查与当前完整 Agent 任务](validation/v3.8/{REPORT})。')
edit('docs/validation/v3.8/V3_8_2_TRIGGER_CTE_2026_10_17_ZH.md','# v3.8.2 触发器局部 CTE 计划补修（2026-10-17）',f'# v3.8.2 触发器局部 CTE 计划补修（2026-10-17）\n\n> 后续审计确认 WHEN 中 begin 列名的功能回归，DRR-108 对新边界重开；当前三次双轮 Luna 任务通过 2/3，见[后续审计]({REPORT})。下文 57 项限定验收保留真实范围，不代表已覆盖后续发现。')

for name,zh in [('docs/security/DESIGN_RISK_REGISTER.md',False),('docs/security/DESIGN_RISK_REGISTER_ZH.md',True)]:
    text=(ROOT/name).read_text();line=next(x for x in text.splitlines() if x.startswith('| DRR-2026-108 |'))
    cells=line.split('|');assert len(cells)==12
    cells[2]=' 重开；WHEN 关键字误拒已复现 ' if zh else ' Reopened; trigger WHEN keyword false refusal confirmed '
    cells[9]+= (f' 相邻审计新增确认六种 begin 列形式／两前缀 12 项功能回归，冻结旧源码同输入 24 项全通过；两种 Client 共 28 次调用复现。当前完整 Luna 销售 2/3，另一次 Host 可用性失败保留。[最新审计](../validation/v3.8/{REPORT})。 ' if zh else f' Later audit confirms 12 false refusals across six begin-column forms/two prefixes; all 24 matched cases pass on pre-repair source, with 28 Client calls reproducing raw/Skill behavior. Current complete Luna sales trials pass 2/3 with one Host availability failure retained. [Latest audit](../validation/v3.8/{REPORT}). ')
    cells[10]+= (' 下一步修 WHEN／正文真实角色边界并复验，当前不宣称最终关闭。 ' if zh else ' Repair the actual WHEN/body role boundary and rerun matched inputs before final closure. ')
    edit(name,line,'|'.join(cells))

name='local_archive/v382_review/README.md'
text=(ROOT/name).read_text()
changes[name]=text+f'\n## 相邻审计与当前完整任务\n\n`20261017_adjacent_audit/` 按 scripts／evidence 归档。76 个不同计划组合中 12 项 WHEN begin 误拒，冻结旧源码及两种 Client 对照，DRR-108 重开；本批仅审查不改运行代码。当前三次双轮 Luna 销售任务通过 2/3，Host 工具不可用失败保留。正式[报告](../../docs/validation/v3.8/{REPORT})及 `v382_adjacent_audit_2026_10_17/` 证据单独封存。\n'

for name,text in changes.items():
    (ROOT/name).write_text(text)
print({'documentation_files':len(changes),'runtime_changed':False,'DRR_108':'reopened'})
