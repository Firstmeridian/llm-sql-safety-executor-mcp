"""Explicitly opted-in tests against TOML-selected test MySQL; never print secrets."""
import json
import os
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

from sql_safety_executor import load_config
from sql_safety_executor.database.mysql import MySQLAdapter
from sqlalchemy import event, text
from sqlalchemy.engine import Engine

config = load_config(ROOT / "config/server.toml").connections["trade_analysis_mysql"]
assert config.db_type == "mysql" and config.mysql_password is not None
os.environ.update({
    "RUN_MYSQL_INTEGRATION_TESTS": "1",
    "DB_HOST": config.mysql_host,
    "DB_USER": config.mysql_user,
    "DB_NAME": config.mysql_database,
    "DB_PASSWORD": config.mysql_password.get_secret_value(),
})
created = set()
events = []

def capture(conn, cursor, statement, parameters, context, executemany):
    names = re.findall(r"\bmcp_v372_race_[a-f0-9]{32}\b", statement)
    if names:
        op = statement.strip().split()[0].upper()
        events.append({"operation": op, "table": names[0]})
        if op == "CREATE":
            created.update(names)

event.listen(Engine, "before_cursor_execute", capture)
import pytest

class Results:
    records = []
    def pytest_runtest_logreport(self, report):
        if report.when == "call" or report.skipped or report.failed:
            self.records.append({"test": report.nodeid, "phase": report.when, "outcome": report.outcome})

results = Results()
code = int(pytest.main([
    "-q", "--tb=short",
    "tests/test_db_adapter.py::TestMySQLAdapter::test_mysql_connection",
    "tests/test_db_adapter.py::TestMySQLAdapter::test_mysql_check_connection",
    "tests/test_db_adapter.py::TestMySQLAdapter::test_mysql_db_type",
    "tests/test_v372_write_outcomes.py::test_mysql_stale_conditional_updates_allow_at_most_one_commit",
], plugins=[results]))
event.remove(Engine, "before_cursor_execute", capture)
adapter = MySQLAdapter(config=config)
cleanup = []
try:
    assert adapter.connect(), "Selected test MySQL must be reachable"
    with adapter._engine.connect() as conn:
        for name in sorted(created):
            count = conn.execute(text(
                "SELECT COUNT(*) FROM information_schema.tables "
                "WHERE table_schema = DATABASE() AND table_name = :table_name"
            ), {"table_name": name}).scalar_one()
            cleanup.append({"table": name, "remaining": count})
            assert count == 0, "Isolated race fixture was not removed"
finally:
    adapter.close()
record = {
    "selected_connection": "trade_analysis_mysql",
    "credentials": "Loaded privately from current TOML into the test process only",
    "pytest_exit_code": code,
    "tests": results.records,
    "fixture_operations": events,
    "cleanup": cleanup,
    "existing_business_rows_written": False,
    "asserted_race": "Exactly one COMMITTED and one ROLLED_BACK ExpectedRowcountMismatch",
}
output = ROOT / "docs/validation/v3.8/review_2026_10_13/supplemental/mysql_optin.json"
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
assert len(created) == 1 and len(results.records) == 4 and all(r["outcome"] == "passed" for r in results.records)
sys.exit(code)
