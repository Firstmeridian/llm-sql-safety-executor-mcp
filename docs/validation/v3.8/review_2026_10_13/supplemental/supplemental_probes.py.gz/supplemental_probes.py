"""Full Query Skill CTE reproducer and isolated authorizer lifecycle probes."""
import asyncio
import json
from pathlib import Path
import sqlite3
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "src"))
from fastmcp import Client
from sql_safety_executor import create_server, load_config

OUTPUT = ROOT / "docs/validation/v3.8/review_2026_10_13/supplemental"
OUTPUT.mkdir(parents=True, exist_ok=True)

def toml_value(value):
    if isinstance(value, dict):
        return "{" + ", ".join(json.dumps(k) + " = " + toml_value(v) for k, v in value.items()) + "}"
    if isinstance(value, list):
        return "[" + ", ".join(map(toml_value, value)) + "]"
    return json.dumps(value, ensure_ascii=False)

def write_toml(path, data):
    path.write_text("\n".join(json.dumps(k) + " = " + toml_value(v) for k, v in data.items()), encoding="utf-8")

def pack(result):
    return {"isError": result.is_error, "structuredContent": result.structured_content,
            "text": [c.text for c in result.content if c.type == "text"]}

async def skill_case():
    records = []
    with tempfile.TemporaryDirectory(prefix="v381-skill-case-") as directory:
        root = Path(directory)
        with sqlite3.connect(root / "fixture.sqlite") as conn:
            conn.executescript("CREATE TABLE orders(id INTEGER); INSERT INTO orders VALUES(1);")
        sqls = {
            "case-exact": "WITH F AS (SELECT id FROM orders) SELECT id FROM F",
            "case-mixed": "WITH F AS (SELECT id FROM orders) SELECT id FROM f",
        }
        for name, sql in sqls.items():
            target = root / "skills" / name
            target.mkdir(parents=True)
            (target / "skill_def.md").write_text(
                f"---\nname: {name}\nversion: '1.0'\ndescription: Isolated CTE case probe\n"
                "type: query\nsource: query.sql\nrisk: low\nparams: {}\n"
                "tables: [orders]\n---\n", encoding="utf-8")
            (target / "query.sql").write_text(sql, encoding="utf-8")
        write_toml(root / "server.toml", {"schema_version": 1,
            "files": {"connections": "connections.toml", "skills": "skills.toml"},
            "server": {"default_connection": "allowlisted"}})
        write_toml(root / "connections.toml", {"schema_version": 1, "connections": {
            "allowlisted": {"type": "sqlite", "sqlite": {"path": "fixture.sqlite"},
                            "read": {"mode": "allowlist", "tables": ["orders"]}},
            "unrestricted": {"type": "sqlite", "sqlite": {"path": "fixture.sqlite"},
                             "read": {"mode": "all"}},
        }})
        write_toml(root / "skills.toml", {"schema_version": 1, "skills": {
            "enabled": True, "directory": str(root / "skills"),
            "readiness": {"check_schema": True}, "audit": {"path": str(root / "audit.jsonl")}}})
        for mode in ("legacy", "auto"):
            server = create_server(load_config(root / "server.toml"))
            try:
                inferred = {name: server.gateway_runtime.catalog.get_skills_cache()[name].tables for name in sqls}
                assert inferred["case-exact"] == ["orders"]
                assert set(inferred["case-mixed"]) == {"orders", "f"}
                async with Client(server, mode=mode) as client:
                    for alias in ("allowlisted", "unrestricted"):
                        requests = [
                            ("query", {"sql": sqls["case-mixed"], "connection_id": alias}),
                            ("list_skills", {"available_only": True, "connection_id": alias}),
                            ("list_skills", {"available_only": False, "detail_level": "full", "connection_id": alias}),
                            ("execute_query_skill", {"skill_name": "case-exact", "params": {}, "connection_id": alias}),
                            ("execute_query_skill", {"skill_name": "case-mixed", "params": {}, "connection_id": alias}),
                        ]
                        responses = []
                        for name, params in requests:
                            response = await client.call_tool(name, params, raise_on_error=False)
                            responses.append(pack(response))
                        assert responses[0]["structuredContent"]["success"] is True
                        assert responses[0]["structuredContent"]["data"] == [{"id": 1}]
                        assert responses[3]["structuredContent"]["success"] is True
                        assert [s["name"] for s in responses[1]["structuredContent"]["skills"]] == ["case-exact"]
                        if alias == "allowlisted":
                            assert not responses[4]["isError"]
                            assert responses[4]["structuredContent"]["error_code"] == "table_access_denied"
                        else:
                            assert responses[4]["isError"]
                            assert "f" in " ".join(responses[4]["text"])
                        records.append({"client_mode": mode, "protocol_version": client.protocol_version, "connection_id": alias,
                                        "inferred_tables": inferred,
                                        "requests": [{"tool": n, "arguments": a} for n, a in requests],
                                        "responses": responses})
            finally:
                server.gateway_runtime.close()
    return {"status": "Known unresolved defect reproduced; not a repair acceptance",
            "calls": 20, "existing_config_modified": False, "fixture_removed": True, "records": records}

def authorizer_cases():
    with sqlite3.connect(":memory:") as conn:
        conn.executescript("CREATE TABLE protected(id INTEGER); INSERT INTO protected VALUES(1); "
                           "CREATE VIEW visible AS SELECT id FROM protected;")
        state = {"deny": False}
        reads = []
        def callback(action, one, two, database, trigger):
            if action == sqlite3.SQLITE_READ:
                reads.append({"table": one, "column": two, "schema": database, "origin": trigger})
                if state["deny"] and one == "protected":
                    return sqlite3.SQLITE_DENY
            return sqlite3.SQLITE_OK
        conn.set_authorizer(callback)
        query = "SELECT id FROM protected"
        first = conn.execute(query).fetchall()
        first_count = len(reads)
        state["deny"] = True
        cached = conn.execute(query).fetchall()
        cached_count = len(reads)
        conn.set_authorizer(callback)
        try:
            conn.execute(query).fetchall()
            raise AssertionError("Re-registering must enforce the new policy")
        except sqlite3.DatabaseError:
            denied = True
        assert first == cached == [(1,)] and first_count == cached_count
        lifecycle = {"first_rows": first, "first_read_callbacks": first_count,
                     "state_changed_cached_rows": cached, "cached_read_callbacks": cached_count,
                     "reregistered_denied": denied}
        grants = {"visible"}
        reads.clear()
        def scoped(action, one, two, database, trigger):
            if action == sqlite3.SQLITE_READ:
                reads.append({"table": one, "column": two, "origin": trigger})
                if one not in grants:
                    return sqlite3.SQLITE_DENY
            return sqlite3.SQLITE_OK
        conn.set_authorizer(scoped)
        try:
            conn.execute("SELECT id FROM visible").fetchall()
            raise AssertionError("Underlying table must be encountered")
        except sqlite3.DatabaseError:
            view_only = {"grants": sorted(grants), "denied": True, "reads": list(reads)}
        grants.add("protected")
        reads.clear()
        conn.set_authorizer(scoped)
        view_both = {"grants": sorted(grants), "rows": conn.execute("SELECT id FROM visible").fetchall(), "reads": list(reads)}
        reads.clear()
        count_rows = conn.execute("SELECT count(*) FROM protected").fetchall()
        assert count_rows == [(1,)] and any(r["column"] == "" for r in reads)
        return {"sqlite_version": sqlite3.sqlite_version, "production_callback_installed": False,
                "cache_lifecycle": lifecycle, "view_only_grant": view_only,
                "view_and_base_grants": view_both, "count_star": {"rows": count_rows, "reads": list(reads)}}

skill_record = asyncio.run(skill_case())
auth_record = authorizer_cases()
for name, record in (("skill_cte_case.json", skill_record), ("authorizer_lifecycle.json", auth_record)):
    (OUTPUT / name).write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("20 real Client tool calls reproduced the unresolved CTE dependency defect; authorizer lifecycle/view/count probes passed.")
