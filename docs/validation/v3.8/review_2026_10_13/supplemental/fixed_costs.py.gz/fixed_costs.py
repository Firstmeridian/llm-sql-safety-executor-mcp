"""Matched source A/B without LLM discovery or batching variation."""
import asyncio
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import statistics
import subprocess
import sys
import tarfile
import tempfile
import time

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = ROOT / "docs/validation/v3.8/review_2026_10_13/supplemental"
BASE = "af3420f58d426b4f657b1214949dc48544afde56"
QUERIES = [
    "SELECT id, status, 'union' AS label FROM orders ORDER BY id LIMIT 3",
    "SELECT missing_column FROM orders",
    "SELECT 1; SELECT 2",
]

def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))

def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()

async def child(source, path, fixture_config):
    sys.path.insert(0, str(Path(source) / "src"))
    from sql_safety_executor import create_server, load_config
    from fastmcp import Client
    server = create_server(load_config(ROOT / "config/server.toml"))
    try:
        async with Client(server, mode="legacy") as client:
            tools = await client.list_tools()
            definitions = [{"name": t.name, "description": t.description, "inputSchema": t.inputSchema} for t in tools]
            public_metadata = {"instructions": client.instructions, "tools": definitions}
            metadata = {"protocol_version": client.protocol_version, "configured_connections": len(server.gateway_runtime.config.connections),
                        "instructions_characters": len(client.instructions or ""),
                        "tools_characters": len(compact(definitions)),
                        "includes_outputSchema": False, "public_snapshot": public_metadata}
    finally:
        server.gateway_runtime.close()
    server = create_server(load_config(fixture_config))
    samples = [[] for _ in QUERIES]
    results = []
    try:
        async with Client(server, mode="legacy") as client:
            for index, sql in enumerate(QUERIES):
                result = await client.call_tool("query", {"sql": sql, "connection_id": "demo"}, raise_on_error=False)
                public = {"isError": result.is_error, "structuredContent": result.structured_content,
                          "content": [c.model_dump(mode="json", exclude_none=True) for c in result.content]}
                # Host visibility varies: record structured and text projections separately.
                results.append({"sql": sql, "response": public,
                                "structured_characters": len(compact(result.structured_content)),
                                "text_characters": sum(len(c.text) for c in result.content if c.type == "text"),
                                "public_json_characters": len(compact(public))})
            # The preceding calls are warmups. Same calls, same order, no LLM or discovery.
            for repetition in range(12):
                for index, sql in enumerate(QUERIES):
                    start = time.perf_counter()
                    result = await client.call_tool("query", {"sql": sql, "connection_id": "demo"}, raise_on_error=False)
                    samples[index].append((time.perf_counter() - start) * 1000)
                    assert result.structured_content == results[index]["response"]["structuredContent"]
    finally:
        server.gateway_runtime.close()
    path.write_text(json.dumps({"metadata": metadata, "queries": results, "latency_ms": samples}, ensure_ascii=False), encoding="utf-8")

if len(sys.argv) > 1 and sys.argv[1] == "--child":
    asyncio.run(child(sys.argv[2], Path(sys.argv[3]), sys.argv[4]))
    sys.exit(0)

OUTPUT.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory(prefix="v381-fixed-costs-") as directory:
    stage = Path(directory)
    archive = stage / "baseline.tar"
    baseline = stage / "baseline"
    baseline.mkdir()
    subprocess.run(["git", "archive", "--format=tar", "-o", str(archive), BASE], cwd=ROOT, check=True)
    with tarfile.open(archive) as stream:
        stream.extractall(baseline, filter="data")
    fixture = stage / "fixture"
    fixture.mkdir()
    with sqlite3.connect(fixture / "fixture.sqlite") as conn:
        conn.executescript("CREATE TABLE orders(id INTEGER, status TEXT); "
                           "INSERT INTO orders VALUES(1,'completed'),(2,'completed'),(3,'shipped');")
    (fixture / "server.toml").write_text('schema_version = 1\n[files]\nconnections = "connections.toml"\n[server]\ndefault_connection = "demo"\n', encoding="utf-8")
    (fixture / "connections.toml").write_text('schema_version = 1\n[connections.demo]\ntype = "sqlite"\n[connections.demo.sqlite]\npath = "fixture.sqlite"\n[connections.demo.read]\nmode = "allowlist"\ntables = ["orders"]\n', encoding="utf-8")
    rounds = []
    for number, order in enumerate((("baseline", "current"), ("current", "baseline")), 1):
        for phase in order:
            out = stage / f"{number}-{phase}.json"
            log = stage / f"{number}-{phase}.log"
            with log.open("w") as stream:
                subprocess.run([sys.executable, str(Path(__file__).resolve()), "--child",
                                str(baseline if phase == "baseline" else ROOT), str(out), str(fixture / "server.toml")],
                               cwd=stage, stdout=stream, stderr=subprocess.STDOUT, check=True)
            record = json.loads(out.read_text())
            # Raw metadata once per phase; repeated metadata is referenced by digest.
            raw = compact(record["metadata"].pop("public_snapshot"))
            filename = f"metadata-{phase}.json.gz"
            if number == 1:
                (OUTPUT / filename).write_bytes(gzip.compress(raw.encode(), mtime=0))
            else:
                assert raw.encode() == gzip.decompress((OUTPUT / filename).read_bytes())
            record["metadata"]["snapshot_file"] = filename
            record["metadata"]["snapshot_sha256"] = digest(raw)
            rounds.append({"round": number, "phase": phase, **record})
            (OUTPUT / f"fixed-costs-{number}-{phase}.log.gz").write_bytes(gzip.compress(log.read_bytes(), mtime=0))
    phases = {}
    for phase in ("baseline", "current"):
        selected = [r for r in rounds if r["phase"] == phase]
        queries = []
        for index, sql in enumerate(QUERIES):
            samples = sum((r["latency_ms"][index] for r in selected), [])
            queries.append({**selected[0]["queries"][index], "samples": len(samples),
                            "median_ms": statistics.median(samples),
                            "p95_ms": statistics.quantiles(samples, n=100, method="inclusive")[94]})
        phases[phase] = {"metadata": selected[0]["metadata"], "queries": queries}
    record = {"baseline_commit": BASE, "method": "Same interpreter/dependencies; in-process FastMCP Client, legacy protocol; two rounds with reversed phase order; one warmup then 12 fixed sequences per round",
              "metadata_context": "Current unchanged five-connection TOML; metadata listing only, no query or schema readiness calls",
              "query_context": "Identical isolated single-connection SQLite fixture; same three query requests regardless of result",
              "limits": "Characters are not tokens. No LLM, Host discovery, billing, RSS or production stdio latency measurement. Baseline label rejection means the fixed sequence is not equivalent completed-task cost.",
              "fixtures_removed": True, "phases": phases,
              "latency_samples": [{"round": r["round"], "phase": r["phase"], "latency_ms": r["latency_ms"]} for r in rounds]}
    (OUTPUT / "fixed_costs.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("Fixed metadata/response comparison complete; 24 latency samples per SQL and phase. No model-cost claim.")
