"""Index supplemental evidence without rewriting earlier records."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = ROOT / "docs/validation/v3.8/review_2026_10_13/supplemental"
sha = lambda data: hashlib.sha256(data).hexdigest()
for source, target in [
    ("/tmp/v381-supplemental-mysql.log", "mysql-optin.log.gz"),
    ("/tmp/v381-supplemental-probes.log", "skill-probes-fixture-error.log.gz"),
    ("/tmp/v381-supplemental-probes-v2.log", "skill-probes.log.gz"),
    ("/tmp/v381-supplemental-fixed-costs.log", "fixed-costs-driver.log.gz"),
]:
    (OUTPUT / target).write_bytes(gzip.compress(Path(source).read_bytes(), mtime=0))
for name in ("mysql_optin.py", "supplemental_probes.py", "fixed_costs.py", "finalize_supplemental.py"):
    (OUTPUT / (name + ".gz")).write_bytes(gzip.compress((Path(__file__).parent / name).read_bytes(), mtime=0))

automation = json.loads((OUTPUT.parent / "automation.json").read_text())
assert all(sha((ROOT / k).read_bytes()) == v for k, v in automation["source_sha256"].items())
mysql = json.loads((OUTPUT / "mysql_optin.json").read_text())
assert mysql["pytest_exit_code"] == 0 and len(mysql["tests"]) == 4
assert all(t["outcome"] == "passed" for t in mysql["tests"])
assert len(mysql["cleanup"]) == 1 and mysql["cleanup"][0]["remaining"] == 0
skill = json.loads((OUTPUT / "skill_cte_case.json").read_text())
assert skill["calls"] == 20 and len(skill["records"]) == 4
assert {r["protocol_version"] for r in skill["records"]} == {"2025-11-25", "2026-07-28"}
assert sum(len(r["requests"]) for r in skill["records"]) == 20
cost = json.loads((OUTPUT / "fixed_costs.json").read_text())
assert all(q["samples"] == 24 for p in cost["phases"].values() for q in p["queries"])

manifest = {
    "version": "3.8.1", "baseline_commit": automation["baseline_commit"],
    "scope": "Maintainer-authorized targeted verification and documentation only; no product source or local TOML changes",
    "source_hash_reference": "../automation.json#source_sha256", "source_sha256_unchanged": True,
    "fixture_state": "One unique MySQL table removed and independently verified absent; temporary SQLite fixtures removed; existing business rows untouched",
    "findings": {"mysql_optin": "4 passed, 0 skipped; conditional race exactly one commit and one rollback",
                 "skill_cte_case": "Known unresolved defect reproduced on both protocols and both read scopes; 20 actual in-process Client calls, not resident Host calls",
                 "authorizer": "Isolated cache/view/count probes only; no production callback",
                 "fixed_costs": "Matched fixed requests, 24 samples per SQL/phase; characters and in-process latency, no model/billing/RSS measurement"},
    "failed_attempt": "Initial probe used unsupported db_types frontmatter; loader correctly rejected it. Corrected fixture before tool-path verification; failure log retained.",
    "format_decision": "Keep all previous JSON unchanged; index new evidence; metadata stored once per phase; compressed original logs and reproducible harness sources; do not duplicate unrelated discovery or model reasoning",
    "reproduce": "Harness sources are gzip archived. Restore to local_archive/v381_review/followup_20261013_tools and run with .venv-v38/bin/python. MySQL opt-in writes a unique fixture table; never uses existing business rows. Current TOML supplies credentials privately.",
    "artifacts": [],
}
for path in sorted(OUTPUT.iterdir()):
    if path.name in ("manifest.json", "document_checks.json"):
        continue
    data = path.read_bytes()
    row = {"path": path.name, "bytes": len(data), "sha256": sha(data)}
    if path.suffix == ".gz":
        raw = gzip.decompress(data)
        row.update({"uncompressed_bytes": len(raw), "uncompressed_sha256": sha(raw)})
        if ".json.gz" in path.name:
            json.loads(raw)
    elif path.suffix == ".json":
        json.loads(data)
    manifest["artifacts"].append(row)
(OUTPUT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

changed = subprocess.check_output(["git", "diff", "--name-only"], cwd=ROOT, text=True).splitlines()
changed.append("docs/validation/V3_8_1_FOLLOWUP_2026_10_13_ZH.md")
links = 0
for name in changed:
    if not name.endswith(".md"):
        continue
    path = ROOT / name
    source = re.sub(r"```.*?```", "", path.read_text(), flags=re.S)
    for match in re.finditer(r"!?\[[^\]]*\]\(([^\s)]+)(?:\s+[^)]*)?\)", source):
        uri = unquote(match.group(1).strip("<>").split("#", 1)[0])
        if not uri or re.match(r"[a-zA-Z][a-zA-Z0-9+.-]*:", uri):
            continue
        assert (path.parent / uri).exists(), (name, uri)
        links += 1
registrations = []
for name in ("docs/security/DESIGN_RISK_REGISTER.md", "docs/security/DESIGN_RISK_REGISTER_ZH.md"):
    source = (ROOT / name).read_text()
    rows = list(re.finditer(r"^\| (DRR-2026-\d{3}) \|.*$", source, flags=re.M))
    ids = [int(m.group(1).rsplit("-", 1)[-1]) for m in rows]
    assert len(ids) == 82 and sorted(ids) == list(range(1, 83))
    latest = [m for m in rows if int(m.group(1).rsplit("-", 1)[-1]) >= 78]
    assert all(source[a.end():b.start()] == "\n" for a, b in zip(latest, latest[1:]))
    row = next(m.group(0) for m in rows if m.group(1) == "DRR-2026-081")
    assert len(row.split("|")) == 12
    registrations.append(ids)
assert registrations[0] == registrations[1]
assert re.search(r'^version = "3\.8\.1"', (ROOT / "pyproject.toml").read_text(), re.M)
assert re.search(r'__version__\s*=\s*"3\.8\.1"', (ROOT / "src/sql_safety_executor/__init__.py").read_text())
assert re.search(r'name = "llm-sql-safety-executor-mcp"\nversion = "3\.8\.1"', (ROOT / "uv.lock").read_text())
subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
checks = {"source_hashes_match_installed_acceptance": True, "product_version": "3.8.1",
          "relative_markdown_links_checked": links, "bilingual_drr_ids": 82, "latest_rows_contiguous": True,
          "drr_081_unresolved_boundary_recorded": True, "diff_check": "passed",
          "scope": "Relative file targets, not remote URL or heading anchor verification; no repeated full-suite/type/build checks for documentation-only supplement"}
(OUTPUT / "document_checks.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(checks, ensure_ascii=False))
