"""Append scoped native/model evidence; preserve the sealed pre-restart batch."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[5]
LOCAL = Path(__file__).resolve().parents[1]
PARENT = LOCAL.parent
OUT = LOCAL / 'evidence'
PUBLIC = ROOT / 'docs/validation/v3.8/v382_read_capabilities_2026_10_19'


def read(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compressed(path, value):
    path.write_bytes(gzip.compress((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))


def main():
    assert not PUBLIC.exists(), 'Append another supplement, do not overwrite a seal.'
    parent = read(PARENT / 'manifest.json')
    for record in parent['files']:
        p = PARENT / record['path']
        assert sha(p) == record['sha256'] and p.stat().st_size == record['bytes'], p
    checkpoint = read(PARENT / 'evidence/source_checkpoint.json')
    for path, digest in checkpoint['resources'].items():
        assert sha(ROOT / 'src/sql_safety_executor' / path) == digest, path
    native = read(OUT / 'native.json.gz')
    scope = read(OUT / 'native_scope.json.gz')
    after = read(OUT / 'native_after_models.json')
    assert native['summary'] == {'cases': 26, 'passed': 26}
    assert all(r['match'] for r in native['records'] + scope['records'])
    assert after['result']['structuredContent']['data'] == after['expected_data']
    records = native['records'] + scope['records'] + [after]
    for r in records:
        result = r['result']
        assert not result.get('isError')
        text = [c['text'] for c in result['content'] if c['type'] == 'text']
        assert len(text) == 1 and json.loads(text[0]) == result['structuredContent']
    summary = read(OUT / 'summary.json')
    assert summary['completed_business_trials'] == summary['planned_trials'] == 9
    assert summary['actual_canaries_passed'] == 9
    assert summary['all_mcp_returns'] == 87 and summary['business_mcp_returns'] == 78
    assert summary['independently_replayed_sql'] == 39 and summary['all_replayed_sql_match']
    trials = []
    local_refs = {}
    for path in sorted(OUT.glob('*.json.gz')):
        if not re.fullmatch(r'(telemetry|knowledge|search)_[123]_complete\.json\.gz', path.name):
            continue
        d = read(path)
        local_refs[path.name] = {'sha256': sha(path), 'bytes': path.stat().st_size}
        # Keep all public task messages, SQL/code, actual MCP application results
        # and provider counts. Omit unrelated Host-wide catalog output and log paths.
        messages = [e for e in d['events'] if e['type'] == 'message' and (
            e.get('role') == 'assistant' or any(c.get('text', '').startswith(d['agent']['marker'])
                                             for c in e.get('content', [])))]
        calls = [e for e in d['events'] if e['type'] in ('custom_tool_call', 'function_call')]
        trials.append({'task': d['agent']['task'], 'trial': d['agent']['trial'], 'agent_id': d['agent']['agent_id'],
                       'model': 'gpt-6-luna', 'reasoning_effort': 'medium', 'fork_context': False,
                       'messages': messages, 'tool_calls': calls, 'mcp_application_results': d['observations'],
                       'per_response_usage': d['per_response_usage'], 'usage': d['usage'], 'phase_usage': d['phase_usage'],
                       'local_full_record': path.name, 'local_full_record_sha256': sha(path)})
    assert len(trials) == 9
    assert not read(OUT / 'tool_output_final_checks.json')['top_level_tool_errors']
    installed = read(PARENT / 'evidence/installed_capabilities_release.json.gz')
    installed['package'] = '<independently installed wheel package>'
    assert installed['package_files'] == checkpoint['resources']
    facts = native['connections']['structuredContent']
    facts = {'connection_count': facts['connection_count'], 'relevant_policy': [
        {'connection_id': r['connection_id'], 'policy': {k: r['policy'][k] for k in
            ('read_mode', 'read_scope', 'default_schema')}}
        for r in facts['connections'] if r['connection_id'] in
        ('analytics_demo_sqlite', 'sqlite_features_sqlite', 'trade_analysis_mysql')]}
    evidence = {'native_records': records, 'configuration_facts': facts, 'installed_stdio': installed,
                'model_trials': trials, 'model_summary': summary, 'manual_review': read(OUT / 'manual_review.json'),
                'sql_replay': read(OUT / 'sql_replay.json.gz'), 'cost_summary': read(PARENT / 'evidence/cost_summary.json'),
                'capture_limits': 'Application-layer evidence, not full JSON-RPC frames. Source paths, full configuration discovery, unrelated Host-wide tool-directory outputs and source-log paths omitted in public; complete local public-I/O records retained by digest. No hidden reasoning captured. Output-token reasoning fields are counts only.'}
    verification = {'closed_utc': datetime.now(timezone.utc).isoformat(), 'version': '3.8.2',
                    'status': 'accepted_with_explicit_native_and_model_coverage_limits',
                    'base_commit': checkpoint['head'], 'runtime_resources': checkpoint['resources'],
                    'regression': checkpoint['regression'], 'wheel_sha256': checkpoint['wheel_sha256'],
                    'source_stdio_calls': 108, 'installed_stdio_calls': 108,
                    'native_checks': 30, 'frozen_native_checks': 26, 'additional_scope_snapshot_checks': 4,
                    'native_configuration_discovery_calls': 1, 'text_structured_matches': 30,
                    'native_protocol': 'Not exposed by this native facade; source/wheel protocols recorded separately.',
                    'model_trials_final_passed': 9, 'actual_child_canaries': 9, 'business_inputs': 18,
                    'business_mcp_returns': 78, 'all_model_mcp_returns': 87, 'native_sql_replays': 39,
                    'data_integrity': {'business_files_unchanged': summary['database_hashes_unchanged'],
                                       'original_order_snapshot_reads': 3, 'rows': 5, 'columns': 5, 'configured_writes': False},
                    'parent_seal': {'sha256': sha(PARENT / 'manifest.json'), 'files_verified': len(parent['files'])},
                    'local_full_trial_records': local_refs,
                    'limitations': ['Sample/exact-count tools not exposed by native Host; source/wheel coverage retained.',
                                    'No configured trigger/UDF/new Skill fixture, no actual MySQL locks or writes.',
                                    'One extra telemetry aggregation draft corrected before final answer; repeated discovery retained.',
                                    'All nine preflights have oversized Host-catalog output truncation, no business-data truncation.',
                                    'Author-name grouping happens to be valid in this no-duplicate-name sample; not a general query guarantee.',
                                    'No matched older-source model/billing A/B, no MariaDB or MySQL case-mode 0/2 live acceptance.']}
    PUBLIC.mkdir()
    compressed(PUBLIC / 'evidence.json.gz', evidence)
    compressed(PUBLIC / 'frozen_tasks.json.gz', read(PARENT / 'evidence/agent_tasks_frozen.json'))
    compressed(PUBLIC / 'pre_restart_manifest.json.gz', parent)
    (PUBLIC / 'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
    (PUBLIC / 'regression_release.log.gz').write_bytes(gzip.compress((PARENT / 'evidence/full_regression_release.log').read_bytes(), mtime=0))
    for name in ('collect_trials.py', 'summarize_trials.py', 'seal_restart.py'):
        (PUBLIC / (name + '.gz')).write_bytes(gzip.compress((LOCAL / 'scripts' / name).read_bytes(), mtime=0))
    (PUBLIC / 'README.md').write_text(
        '# v3.8.2 read-capability acceptance evidence\n\n'
        '本批独立评审补修及维护者重启后验收；行为、取舍及成本见[正式报告](../V3_8_2_READ_CAPABILITIES_2026_10_19_ZH.md)。\n\n'
        '- `verification.json`：源码／包摘要、2667 项回归、30 项原生核验、九个完整任务及覆盖限制。\n'
        '- `evidence.json.gz`：108 次安装 stdio、原生应用结果、九个双轮任务的公开消息／调用／实际结果／usage、独立 SQL 重放与人工复核、成本摘要。\n'
        '- `frozen_tasks.json.gz`：试验前冻结的提示、评分和独立真值。\n'
        '- `pre_restart_manifest.json.gz`：保持不变的本地 67 项父检查点；`regression_release.log.gz` 保留最终完整回归输出。\n'
        '- 三个 `.py.gz`：采集、复核和封存脚本；原始本地记录按摘要引用，不重跑封存覆盖既有文件。\n\n'
        '公开记录省略无关 Host 全工具目录输出、日志／机器路径及完整配置发现，完整本地公开 I/O 保留；这是应用层证据，不是完整协议帧，也不采集隐藏推理。保留额外汇总表达式的自行修正、重复查询及目录截断，不把最终 9/9 推广为零错误、总体可用率或成本下降。\n', encoding='utf-8')
    public_files = {str(p.relative_to(PUBLIC)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
                    for p in sorted(PUBLIC.iterdir()) if p.is_file()}
    (PUBLIC / 'manifest.json').write_text(json.dumps({'files': public_files}, ensure_ascii=False, indent=2) + '\n')
    local_files = {str(p.relative_to(LOCAL)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
                   for p in sorted(LOCAL.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
    (LOCAL / 'manifest.json').write_text(json.dumps({'files': local_files,
        'parent_files_preserved': len(parent['files']), 'public_manifest_sha256': sha(PUBLIC / 'manifest.json')},
        ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'public_files': len(public_files), 'local_files': len(local_files),
                      'parent_files_preserved': len(parent['files']), 'native_checks': 30, 'complete_business_passed': 9}))


if __name__ == '__main__':
    main()
