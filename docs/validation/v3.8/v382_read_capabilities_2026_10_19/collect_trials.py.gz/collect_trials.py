"""Collect public trial messages, tool I/O and usage, excluding hidden reasoning."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import re
import sys

OUT = Path(__file__).resolve().parents[1] / 'evidence'
SESSIONS = Path('/home/andy/.codex/sessions/2026/10/19')


def mcp_values(value):
    if isinstance(value, dict):
        for key in ('structuredContent', 'structured_content'):
            if isinstance(value.get(key), dict):
                return [{'body': value[key], 'isError': value.get('isError', value.get('is_error'))}]
        if 'success' in value and any(k in value for k in ('data', 'error_code', 'schema', 'table_name', 'tables')):
            return [{'body': value, 'isError': None}]
        return [r for v in value.values() for r in mcp_values(v)]
    if isinstance(value, list):
        return [r for v in value for r in mcp_values(v)]
    if isinstance(value, str):
        try:
            return mcp_values(json.loads(value))
        except (ValueError, RecursionError):
            return []
    return []


def collect(agent, checkpoint):
    paths = list(SESSIONS.glob('*' + agent['agent_id'] + '.jsonl'))
    assert len(paths) == 1, paths
    path = paths[0]
    public, usage, observations = [], [], []
    phase = 'preflight'
    calls = {}
    turn = None
    for line in path.open():
        e = json.loads(line)
        p = e.get('payload', {})
        timestamp = e.get('timestamp')
        if e.get('type') == 'token_usage_record':
            usage.append({'timestamp': timestamp, 'phase': phase, 'usage': p.get('usage'),
                          'turn_token_usage': p.get('turn_token_usage'), 'thread_token_usage': p.get('thread_token_usage')})
        if e.get('type') != 'response_item':
            continue
        kind = p.get('type')
        if kind == 'message':
            role = p.get('role')
            channel = p.get('channel', p.get('phase'))
            if role == 'user':
                content = '\n'.join(c.get('text', '') for c in p.get('content', []) if isinstance(c, dict))
                if '.TURN1\n' in content:
                    phase = 'turn1'
                elif '.TURN2\n' in content:
                    phase = 'turn2'
            if role == 'assistant' and channel not in ('final', 'final_answer', 'commentary'):
                continue
            if role not in ('user', 'assistant'):
                continue
        elif kind not in ('custom_tool_call', 'custom_tool_call_output', 'function_call', 'function_call_output'):
            continue
        item = {k: v for k, v in p.items() if k in {
            'type', 'name', 'role', 'content', 'input', 'arguments', 'output', 'call_id', 'id', 'status'
        }}
        item.update(timestamp=timestamp, phase=phase, message_phase=p.get('phase', p.get('channel')))
        public.append(item)
        call_id = p.get('call_id')
        if kind in ('custom_tool_call', 'function_call'):
            calls[call_id] = p
        elif kind in ('custom_tool_call_output', 'function_call_output'):
            prior = calls.get(call_id, {})
            code = str(prior.get('input', prior.get('arguments', '')))
            methods = re.findall(r'tools\.(mcp__sql_safety_executor_mcp__\w+)\s*\(', code)
            if prior.get('name', '').startswith('mcp__sql_safety_executor_mcp__'):
                methods.append(prior['name'])
            for r in mcp_values(p.get('output')):
                observations.append({'timestamp': timestamp, 'phase': phase, 'call_id': call_id,
                                     'methods_in_call': methods, **r})
    total = usage[-1]['thread_token_usage'] if usage else {}
    per_phase = {}
    for label in ('preflight', 'turn1', 'turn2'):
        selected = [x for x in usage if x['phase'] == label]
        per_phase[label] = {key: sum(x['usage'].get(key, 0) for x in selected) for key in total}
    record = {
        'collector_version': 2, 'agent': agent, 'checkpoint': checkpoint,
        'source_log': path.name, 'source_bytes': path.stat().st_size,
        'source_sha256_at_collection': hashlib.sha256(path.read_bytes()).hexdigest(),
        'events': public, 'per_response_usage': usage, 'usage': total, 'phase_usage': per_phase,
        'observations': observations,
        'limits': 'Public user/final/commentary messages and tool I/O only; reasoning messages are excluded. MCP results are reconstructed from tool output JSON, not complete protocol frames. Tool-name candidates may be shared by a batched call; inspect public code to attribute. Provider usage is not billing or causal A/B.',
    }
    filename = f"{agent['task']}_{agent['trial']}_{checkpoint}.json.gz"
    target = OUT / filename
    assert not target.exists(), target
    target.write_bytes(gzip.compress((json.dumps(record, ensure_ascii=False, indent=2) + '\n').encode(), mtime=0))
    return {'task': agent['task'], 'trial': agent['trial'], 'checkpoint': checkpoint,
            'public_events': len(public), 'mcp_observations': len(observations), 'usage': total}


if __name__ == '__main__':
    agents = json.loads(Path(sys.argv[1]).read_text())
    checkpoint = sys.argv[2]
    if len(sys.argv) > 3:
        agents = [a for a in agents if a['task'] in sys.argv[3:]]
    for agent in agents:
        print(json.dumps(collect(agent, checkpoint), ensure_ascii=False))
