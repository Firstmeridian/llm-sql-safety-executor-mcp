"""Independently replay successful public SQL and summarize frozen task trials."""
from collections import Counter
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path
import re
import sqlite3

ROOT = Path(__file__).resolve().parents[5]
BATCH = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parents[1] / 'evidence'


def read(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)


def numbers(text, values):
    found = {Decimal(x) for x in re.findall(r'(?<![\w])\d+(?:\.\d+)?', text.replace(',', ''))}
    return all(Decimal(str(x)) in found for x in values)


def main():
    assert not (OUT / 'summary.json').exists()
    frozen = read(BATCH / 'evidence/agent_tasks_frozen.json')
    tasks = {t['id']: t for t in frozen['tasks']}
    aliases = {'iot_telemetry_sqlite': 'iot_telemetry_demo.db', 'sqlite_features_sqlite': 'sqlite_features_demo.db'}
    manual = read(OUT / 'manual_review.json')
    trials = []
    replay = []
    for wave in range(1, 4):
        for agent in read(OUT / f'agents_wave{wave}.json'):
            task = tasks[agent['task']]
            record = read(OUT / f"{agent['task']}_{wave}_complete.json.gz")
            observations = record['observations']
            setup = [o for o in observations if o['phase'] == 'preflight']
            business = [o for o in observations if o['phase'] in ('turn1', 'turn2')]
            finals = {e['phase']: '\n'.join(c.get('text', '') for c in e.get('content', []))
                      for e in record['events'] if e['type'] == 'message'
                      and e.get('message_phase') in ('final', 'final_answer')}
            code = '\n'.join(e.get('input', e.get('arguments', '')) for e in record['events']
                             if e['type'] in ('custom_tool_call', 'function_call'))
            methods = re.findall(r'tools\.(\w+)\s*\(', code)
            checks = {
                'actual_child_canary': len(setup) == 1 and setup[0]['body'].get('data') == [{'n': 1}]
                    and setup[0]['body'].get('connection_id') == task['connection_id'],
                'two_business_finals': all(k in finals for k in ('turn1', 'turn2')),
                'business_calls_each_turn': all(any(o['phase'] == k for o in business) for k in ('turn1', 'turn2')),
                'only_requested_target': all(o['body'].get('connection_id', task['connection_id']) == task['connection_id'] for o in observations),
                'no_non_sql_tools': all(m.startswith('mcp__sql_safety_executor_mcp__') for m in methods),
                'read_methods_only': all(m.removeprefix('mcp__sql_safety_executor_mcp__') in {
                    'query', 'list_tables', 'describe_table', 'get_full_schema', 'list_skills', 'get_skill_detail'
                } for m in methods),
                'no_truncated_business_data': all(o['body'].get('truncated') is not True for o in business),
            }
            replay_checks = []
            for o in business:
                body = o['body']
                sql = body.get('query')
                if body.get('success') is not True or not isinstance(sql, str):
                    continue
                assert re.match(r'\s*(SELECT|WITH)\b', sql, re.I), sql
                path = ROOT / 'local_data/sample_dbs_20261019' / aliases[task['connection_id']]
                with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as db:
                    db.row_factory = sqlite3.Row
                    rows = [dict(r) for r in db.execute(sql)]
                match = rows == body['data']
                replay_checks.append(match)
                replay.append({'task': task['id'], 'trial': wave, 'phase': o['phase'], 'sql': sql,
                               'match': match, 'native_rows': rows})
            checks['all_successful_business_sql_matches_native'] = bool(replay_checks) and all(replay_checks)
            first, second = finals.get('turn1', ''), finals.get('turn2', '')
            if task['id'] == 'telemetry':
                checks['business_numbers'] = numbers(first, [44, 11, 23.70, 21.31, 23.33, 24.67, 2, 1, 0]) and numbers(second, [13, 99.692, 1]) and 'TYO-SHB-POW-013' in second and '2026-10-14 23:46:43' in second
            elif task['id'] == 'knowledge':
                checks['business_numbers'] = numbers(first, [32, 6, 4, 19, 16, 10, 9, 7, 93]) and all(x in first for x in ['eng', 'howto', 'ops', 'policy', 'people']) and numbers(second, [19, 2]) and all(x in second for x in ['Amira Smith', 'Noah Chan', 'Zoe Nakamura'])
            else:
                checks['business_numbers'] = numbers(first, [7, 6, 23, 17, 25]) and numbers(second, [5, 4, 1, 3, 2]) and all(x in first for x in ['Noah Chan', 'Amira Smith', 'Zoe Smith']) and all(x in second for x in ['Quin Singh', 'Kai Chan', 'Noah Smith', 'Yara Lau'])
            key = f"{task['id']}_{wave}"
            checks.update(manual[key]['checks'])
            usage = record['usage']
            summed = {k: sum(x['usage'].get(k, 0) for x in record['per_response_usage']) for k in usage}
            assert summed == usage, (key, summed, usage)
            business_usage = {k: sum(record['phase_usage'][phase][k] for phase in ('turn1', 'turn2')) for k in usage}
            rejections = [{'phase': o['phase'], 'error_code': o['body'].get('error_code'), 'isError': o['isError']}
                          for o in observations if o['body'].get('success') is False or o['isError'] is True]
            outputs = [e for e in record['events'] if e['type'] in ('custom_tool_call_output', 'function_call_output')]
            trials.append({'task': task['id'], 'trial': wave, 'agent_id': agent['agent_id'],
                           'passed': all(checks.values()), 'checks': checks, 'business_mcp_returns': len(business),
                           'all_mcp_returns': len(observations), 'business_returns_by_turn': dict(Counter(o['phase'] for o in business)),
                           'rejections': rejections, 'without_policy_rejection': not rejections,
                           'all_usage': usage, 'business_usage': business_usage,
                           'model_responses': len(record['per_response_usage']),
                           'public_tool_output_bytes': sum(len(json.dumps(e.get('output'), ensure_ascii=False).encode()) for e in outputs),
                           'notes': manual[key]['notes']})
    after = {n: hashlib.sha256((ROOT / 'local_data/sample_dbs_20261019' / n).read_bytes()).hexdigest() for n in frozen['database_sha256']}
    assert after == frozen['database_sha256']
    summary = {'planned_trials': 9, 'completed_business_trials': sum(t['passed'] for t in trials),
               'actual_canaries_passed': sum(t['checks']['actual_child_canary'] for t in trials),
               'trials_without_policy_rejection': sum(t['without_policy_rejection'] for t in trials),
               'business_inputs': 18, 'canary_inputs': 9, 'business_mcp_returns': sum(t['business_mcp_returns'] for t in trials),
               'all_mcp_returns': sum(t['all_mcp_returns'] for t in trials),
               'independently_replayed_sql': len(replay), 'all_replayed_sql_match': all(r['match'] for r in replay),
               'trials': trials, 'database_hashes_unchanged': after,
               'all_usage': {k: sum(t['all_usage'][k] for t in trials) for k in trials[0]['all_usage']},
               'business_usage': {k: sum(t['business_usage'][k] for t in trials) for k in trials[0]['business_usage']},
               'limits': 'Nine fresh Luna medium trials with real canaries and two frozen business turns each. No matched older-source model trial or billing comparison. Cached input is a subset of input; reasoning tokens are counts only. Shared-service/concurrent model timing is not server latency. SQL-result replay does not alone grade business interpretation; explicit manual checks remain separate. Historical failures unchanged.'}
    for name, value in [('sql_replay.json.gz', replay), ('summary.json', summary)]:
        path = OUT / name
        if path.suffix == '.gz':
            path.write_bytes(gzip.compress(json.dumps(value, ensure_ascii=False, indent=2).encode(), mtime=0))
        else:
            path.write_text(json.dumps(value, ensure_ascii=False, indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k not in ('trials','limits')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
