"""Seal a read-only follow-up without rewriting accepted evidence."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
LOCAL = Path(__file__).resolve().parents[1]
PUBLIC_ROOT = ROOT / 'docs/validation/v3.8/v382_read_capabilities_2026_10_19'
PUBLIC = PUBLIC_ROOT / 'followup_2026_10_20'


def read(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not PUBLIC.exists() and not (LOCAL / 'manifest.json').exists()
    preserved = read(PUBLIC_ROOT / 'manifest.json')
    for name, row in preserved['files'].items():
        assert sha(PUBLIC_ROOT / name) == row['sha256'], name
    setup = read(LOCAL / 'evidence/setup.json')
    for name, digest in setup['current_source_sha256'].items():
        assert sha(ROOT / 'src' / name) == digest, name
    clients = read(LOCAL / 'evidence/client_adjacencies.json.gz')
    assert len(clients) == 24
    assert sum(row['guarded_function_calls'] for row in clients) == 2
    assert sum(row['payload'].get('error_code') == 'relation_scope_unresolved' for row in clients) == 12
    costs = read(LOCAL / 'evidence/mysql_meta_summary.json')
    assert costs['calls'] == 312
    data = {'adjacent_current': read(LOCAL / 'evidence/adjacent_current_v2.json'),
            'adjacent_baseline': read(LOCAL / 'evidence/adjacent_baseline.json'),
            'client_adjacencies': clients, 'native_fts_write_plans': read(LOCAL / 'evidence/native_fts_write_plans.json.gz'),
            'mysql_cost_summary': costs,
            'mysql_cost_stages': {label: read(LOCAL / f'evidence/mysql_meta_{label}.json.gz') for label in ('A1', 'B', 'A2')},
            'capture_limits': 'Application results, direct adapter probes and serial read-only real stdio costs. No complete protocol frames/model trial or configured database writes. Counter-only SQLite UDF; explicit trusted warmup is not a normal query request.'}
    data['adjacent_current']['source'] = '<current source>'
    data['adjacent_baseline']['source'] = '<2c0a9e7 source>'
    PUBLIC.mkdir()
    (PUBLIC / 'evidence.json.gz').write_bytes(gzip.compress(json.dumps(data, ensure_ascii=False, indent=2).encode(), mtime=0))
    (PUBLIC / 'verification.json').write_text(json.dumps({
        'closed_utc': datetime.now(timezone.utc).isoformat(), 'version': '3.8.2', 'audit_only': True,
        'source_unchanged': setup['current_source_sha256'], 'adapter_cases_each_version': 15,
        'client_calls': 24, 'native_calls': 2, 'mysql_metadata_stdio_calls': 312,
        'open_followups': ['DRR-2026-116', 'DRR-2026-117'], 'configured_writes': False,
        'previous_public_manifest_sha256': sha(PUBLIC_ROOT / 'manifest.json'),
        'previous_public_files_preserved': len(preserved['files']),
        'scope': 'Prior 30/30 and nine complete Luna outcomes retain their original scope; these two additional conditions remain open.'}, ensure_ascii=False, indent=2) + '\n')
    for name in ('adjacent_reads.py', 'client_adjacencies.py', 'mysql_metadata_cost.py', 'seal_audit.py'):
        (PUBLIC / (name + '.gz')).write_bytes(gzip.compress((LOCAL / 'scripts' / name).read_bytes(), mtime=0))
    (PUBLIC / 'README.md').write_text(
        '# v3.8.2 post-repair audit supplement\n\n'
        '[结论、完整问题状态与性能表](../../V3_8_2_POSTREPAIR_AUDIT_2026_10_20_ZH.md)。\n\n'
        '`evidence.json.gz` 保留旧／当前适配器组合、24 次双协议工具结果、两条原生非执行计划和 312 次 MySQL 元数据成本原值。`verification.json` 记录源码不变、未写配置数据库及两项开放后续。脚本压缩保留，不重跑封存覆盖原文件。\n\n'
        '前批九项公开封存不改写；新发现不反写旧 30/30、9/9 的限定结果。不是完整协议帧，没有新增模型 A/B；第一条原生 EXPLAIN 结果有既有限额截断。\n', encoding='utf-8')
    files = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(PUBLIC.iterdir()) if p.is_file()}
    (PUBLIC / 'manifest.json').write_text(json.dumps({'files': files}, ensure_ascii=False, indent=2) + '\n')
    files_local = {str(p.relative_to(LOCAL)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
                   for p in sorted(LOCAL.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
    (LOCAL / 'manifest.json').write_text(json.dumps({'files': files_local, 'public_manifest_sha256': sha(PUBLIC / 'manifest.json')}, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'source_resources_unchanged': len(setup['current_source_sha256']),
                      'previous_public_files_preserved': len(preserved['files']),
                      'new_public_files': len(files), 'new_local_files': len(files_local), 'open_followups': 2}))


if __name__ == '__main__':
    main()
