"""Source-selectable readonly MySQL child-stdio metadata benchmark.

Run stages serially, using the same Python/config/alias/workload. Never writes
business data; configured check_connection uses its fresh diagnostic session.
"""
import argparse
import asyncio
import gzip
import hashlib
import json
import os
from pathlib import Path
import statistics
import sys
import tempfile
import time


async def main(args):
    sys.path.insert(0, str(args.source))
    import sql_safety_executor
    from sql_safety_executor.mcp.bootstrap import prepare_framework
    prepare_framework()
    from fastmcp import Client
    from fastmcp.client.transports import StdioTransport
    assert Path(sql_safety_executor.__file__).is_relative_to(args.source)
    assert not args.output.exists()
    records = []
    with tempfile.TemporaryDirectory(prefix='v382-mysql-meta-cost-') as folder:
        launcher = Path(folder) / 'serve.py'
        launcher.write_text(
            f'import sys;sys.path.insert(0,{str(args.source)!r})\n'
            'import logging\nlogging.disable(logging.CRITICAL)\n'
            'from sql_safety_executor import create_server,load_config\n'
            f'server=create_server(load_config({str(args.config)!r}))\n'
            'server.run(transport="stdio",show_banner=False)\n')
        for mode in ('auto', 'legacy'):
            started = time.perf_counter()
            transport = StdioTransport(command=sys.executable, args=[str(launcher)], cwd=folder)
            async with Client(transport, mode=mode) as client:
                startup_ms = 1000 * (time.perf_counter() - started)
                for name, arguments in [
                    ('list_tables', {}),
                    ('describe_table', {'table_name': 'film'}),
                    ('get_full_schema', {'detail_level': 'compact'}),
                    ('check_connection', {}),
                ]:
                    samples, trace = [], None
                    for repeat in range(13):
                        start = time.perf_counter_ns()
                        response = await client.call_tool(name, {'connection_id': 'sakila_mysql', **arguments}, raise_on_error=False)
                        elapsed = (time.perf_counter_ns() - start) / 1e6
                        body = response.structured_content
                        assert not response.is_error, body
                        if name == 'check_connection':
                            assert body['all_connected'], body
                        else:
                            assert body['success'], body
                        samples.append(elapsed)
                        if trace is None:
                            trace = body
                    warm = samples[1:]
                    records.append({'protocol': client.protocol_version, 'tool': name, 'startup_ms': startup_ms,
                                    'cold_first_call_ms': samples[0], 'warm_ms': warm,
                                    'median_ms': statistics.median(warm),
                                    'p95_ms': sorted(warm)[int(len(warm) * .95) - 1],
                                    'response': trace})
    package = args.source / 'sql_safety_executor'
    data = {'stage': args.stage, 'connection_id': 'sakila_mysql', 'observed_version': 'Oracle MySQL 8.0.25',
            'records': records, 'calls': 104,
            'source_sha256': {str(p.relative_to(package)): hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in sorted(package.rglob('*')) if p.is_file() and p.suffix in ('.py', '.md')},
            'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'limits': 'One machine, one read-only alias, real local child stdio and frozen dependencies. 13 calls/tool/protocol/stage, discard first for warm. Separate startup. No model/network-service load equivalence, production-log overhead or invoice claim. list/describe/schema compared on identical table set; statistics are approximate and can vary independently. Diagnostic opens its own fresh session by design.'}
    args.output.write_bytes(gzip.compress(json.dumps(data, ensure_ascii=False, indent=2).encode(), mtime=0))
    print(json.dumps({'stage': args.stage, 'calls': data['calls'], 'summary': [
        {k:r[k] for k in ('protocol', 'tool', 'median_ms', 'p95_ms')} for r in records]}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('source', 'config', 'output'):
        parser.add_argument('--' + key, type=Path, required=True)
    parser.add_argument('--stage', required=True)
    args = parser.parse_args()
    for key in ('source', 'config', 'output'):
        setattr(args, key, getattr(args, key).resolve())
    asyncio.run(main(args))
