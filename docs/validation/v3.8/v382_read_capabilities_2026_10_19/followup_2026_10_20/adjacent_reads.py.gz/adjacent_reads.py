"""Disposable functional probes; no configured database or source changes."""
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile


def main(args):
    sys.path.insert(0, str(args.source))
    from sql_safety_executor.database.sqlite import SQLiteAdapter
    from sql_safety_executor.database.models import ConnectionPolicy, DatabaseConfig
    from sql_safety_executor.database.errors import DatabaseQueryError
    from sql_safety_executor.database.relations import RelationReference
    def make_policy(**kwargs):
        # Baseline 2c0a9e7 did not yet bind default_schema on the policy object;
        # its adapter still provides the same main execution context.
        if 'default_schema' not in ConnectionPolicy.__dataclass_fields__:
            kwargs.pop('default_schema', None)
        return ConnectionPolicy(**kwargs)
    records = []
    for scope in ('root', 'all'):
        for warm in ('none', 'columns', 'trusted_projection'):
            with tempfile.TemporaryDirectory(prefix='v382-audit-content-') as folder:
                path = Path(folder) / 'probe.sqlite'
                with sqlite3.connect(path) as db:
                    db.executescript("CREATE TABLE docs(id INTEGER PRIMARY KEY,body TEXT);INSERT INTO docs VALUES(1,'alpha');CREATE VIEW content_view AS SELECT id,SLEEP(0) AS title,body FROM docs;CREATE VIRTUAL TABLE view_fts USING fts5(title,body,content='content_view',content_rowid='id');INSERT INTO view_fts(rowid,title,body) VALUES(1,'Hello world','alpha');")
                policy = make_policy(allowed_tables=frozenset({'*'} if scope == 'all' else {'view_fts'}), read_mode='all' if scope == 'all' else 'allowlist', default_schema='main')
                adapter = SQLiteAdapter(config=DatabaseConfig('probe', 'sqlite', 5, 5, policy, sqlite_database_path=str(path)))
                adapter.connect()
                calls = []
                try:
                    with adapter._engine.begin() as db:
                        db.connection.dbapi_connection.create_function('SLEEP', 1, lambda n: calls.append(n) or 'Hello world')
                    if warm == 'columns':
                        adapter.get_columns('view_fts')
                    if warm == 'trusted_projection':
                        adapter.execute("SELECT title FROM view_fts WHERE view_fts MATCH 'hello'")
                    before = len(calls)
                    result, status = None, 'success'
                    try:
                        result = [list(row) for row in adapter.execute_read("SELECT title FROM view_fts WHERE view_fts MATCH 'hello'", policy=policy)]
                    except DatabaseQueryError as error:
                        status = error.error_code
                    records.append({'case': 'cached_content_function', 'scope': scope, 'warm': warm, 'status': status,
                                    'rows': result, 'guarded_function_calls': len(calls) - before, 'trusted_function_calls': before})
                finally:
                    adapter.close()
    # An FTS-writing trigger is distinct from a trigger that SELECTs an FTS root.
    for prefix in ('EXPLAIN', 'EXPLAIN QUERY PLAN'):
        with tempfile.TemporaryDirectory(prefix='v382-audit-fts-trigger-') as folder:
            path = Path(folder) / 'probe.sqlite'
            ddl = "CREATE TABLE docs(id INTEGER PRIMARY KEY,title TEXT);INSERT INTO docs VALUES(1,'Hello');CREATE VIRTUAL TABLE docs_fts USING fts5(title,content='docs',content_rowid='id');INSERT INTO docs_fts(rowid,title) SELECT id,title FROM docs;CREATE TRIGGER sync_docs AFTER UPDATE ON docs BEGIN INSERT INTO docs_fts(docs_fts,rowid,title) VALUES('delete',old.id,old.title);INSERT INTO docs_fts(rowid,title) VALUES(new.id,new.title);END;"
            with sqlite3.connect(path) as db:
                db.executescript(ddl)
                truth = [list(r) for r in db.execute(prefix + " UPDATE docs SET title='new' WHERE id=1")]
            before = hashlib.sha256(path.read_bytes()).hexdigest()
            policy = make_policy(allowed_tables=frozenset({'docs', 'docs_fts'}), default_schema='main')
            adapter = SQLiteAdapter(config=DatabaseConfig('probe', 'sqlite', 5, 5, policy, sqlite_database_path=str(path)))
            adapter.connect()
            try:
                status, result = 'success', None
                try:
                    result = [list(r) for r in adapter.execute_read(prefix + " UPDATE docs SET title='new' WHERE id=1", policy=policy)]
                except DatabaseQueryError as error:
                    status = error.error_code
                records.append({'case': 'fts_writing_trigger_plan', 'prefix': prefix, 'status': status,
                                'native_row_count': len(truth), 'guarded_row_count': len(result) if result is not None else None,
                                'data_unchanged': before == hashlib.sha256(path.read_bytes()).hexdigest()})
            finally:
                adapter.close()
    # Names, options and aliases adjacent to the newly supported builtin calls.
    with tempfile.TemporaryDirectory(prefix='v382-audit-shapes-') as folder:
        path = Path(folder) / 'probe.sqlite'
        with sqlite3.connect(path) as db:
            db.executescript("CREATE TABLE docs(id INTEGER PRIMARY KEY,title TEXT);INSERT INTO docs VALUES(1,'Hello');CREATE VIRTUAL TABLE docs_fts USING fts5(title,content='docs',content_rowid='id');INSERT INTO docs_fts(rowid,title) SELECT id,title FROM docs;")
        policy = make_policy(allowed_tables=frozenset({'docs_fts'}), allow_union=True, default_schema='main')
        adapter = SQLiteAdapter(config=DatabaseConfig('probe', 'sqlite', 5, 5, policy, sqlite_database_path=str(path)))
        adapter.connect()
        for sql in [
            "SELECT COUNT(*) FROM docs_fts('hello')",
            "SELECT COUNT(*) FROM main.docs_fts('hello')",
            "SELECT title FROM docs_fts('hello') AS f",
            "WITH found AS MATERIALIZED (SELECT title FROM docs_fts('hello')) SELECT COUNT(*) FROM found",
            "SELECT title FROM docs_fts('hello') UNION ALL SELECT value FROM json_each('[\"hello\"]')",
            "SELECT value FROM main.json_each('[7]')",
            "SELECT value FROM json_tree('[7]') WHERE type='integer'",
        ]:
            try:
                value = [list(r) for r in adapter.execute_read(sql, policy=policy)]
                status = 'success'
            except DatabaseQueryError as error:
                value, status = None, error.error_code
            with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as db:
                truth = [list(r) for r in db.execute(sql)]
            records.append({'case': 'read_shape', 'sql': sql, 'status': status, 'native': truth, 'guarded': value})
        adapter.close()
    args.output.write_text(json.dumps({'source': str(args.source), 'records': records,
        'limits': 'Private temporary SQLite only; adapter boundary to isolate guard behavior. Harmless SLEEP replacement only increments a counter. Explicit trusted projection is an additional warm-up condition, not a normal MCP query or public metadata call.'}, ensure_ascii=False, indent=2))
    print(json.dumps(records, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.source = args.source.resolve()
    assert not args.output.exists()
    main(args)
