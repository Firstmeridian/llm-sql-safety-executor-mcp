"""Both Client protocols, private FTS fixtures, no configured data changes."""
import asyncio
import gzip
import json
from pathlib import Path
import tempfile

from sql_safety_executor import create_server, load_config
from fastmcp import Client


async def main():
    rows = []
    for mode in ('auto', 'legacy'):
        for warm in ('none', 'columns', 'trusted_projection'):
            with tempfile.TemporaryDirectory(prefix='v382-audit-client-') as folder:
                p = Path(folder)
                (p / 'server.toml').write_text('schema_version=1\n[files]\nconnections="connections.toml"\n[server]\ndefault_connection="probe"\n')
                (p / 'connections.toml').write_text('schema_version=1\n[connections.probe]\ntype="sqlite"\nsqlite.path="probe.db"\nread.mode="allowlist"\nread.allow_union=true\nread.relations=[{schema="main",name="view_fts"},{schema="aux",name="aux_fts"}]\n')
                server = create_server(load_config(p / 'server.toml'))
                a = server.gateway_runtime.registry.get_adapter('probe')
                a.connect()
                calls = []
                try:
                    with a._engine.begin() as db:
                        raw = db.connection.dbapi_connection
                        raw.create_function('SLEEP', 1, lambda n: calls.append(n) or 'Hello world')
                        raw.executescript("CREATE TABLE docs(id INTEGER PRIMARY KEY,body TEXT);INSERT INTO docs VALUES(1,'alpha');CREATE VIEW content_view AS SELECT id,SLEEP(0) AS title,body FROM docs;CREATE VIRTUAL TABLE view_fts USING fts5(title,body,content='content_view',content_rowid='id');INSERT INTO view_fts(rowid,title,body) VALUES(1,'Hello world','alpha');ATTACH ':memory:' AS aux;CREATE VIRTUAL TABLE aux.aux_fts USING fts5(title);INSERT INTO aux.aux_fts VALUES('Hello world');")
                    if warm == 'columns':
                        a.get_columns('view_fts')
                    if warm == 'trusted_projection':
                        a.execute("SELECT title FROM view_fts WHERE view_fts MATCH 'hello'")
                    async with Client(server, mode=mode) as client:
                        for sql in [
                            "SELECT title FROM view_fts WHERE view_fts MATCH 'hello'",
                            "SELECT title FROM aux.aux_fts WHERE aux_fts MATCH 'hello'",
                            "SELECT title FROM aux.aux_fts('hello')",
                            "SELECT 'Hello world' IN aux.aux_fts('hello') AS n",
                        ]:
                            before = len(calls)
                            r = await client.call_tool('query', {'connection_id': 'probe', 'sql': sql}, raise_on_error=False)
                            rows.append({'mode': mode, 'protocol': client.protocol_version, 'warm': warm, 'sql': sql,
                                         'isError': r.is_error, 'payload': r.structured_content,
                                         'guarded_function_calls': len(calls) - before})
                finally:
                    server.gateway_runtime.close()
    out = Path(__file__).resolve().parents[1] / 'evidence/client_adjacencies.json.gz'
    assert not out.exists()
    out.write_bytes(gzip.compress(json.dumps(rows, ensure_ascii=False, indent=2).encode(), mtime=0))
    print(json.dumps({'calls': len(rows), 'cached_function_evaluations': sum(r['guarded_function_calls'] for r in rows),
                      'aux_named_calls_refused': sum(r['payload'].get('error_code') == 'relation_scope_unresolved' for r in rows)}))


asyncio.run(main())
