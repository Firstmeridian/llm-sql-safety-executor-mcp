"""Replay every frozen SQL/context/parser verdict through instance-local reuse."""
from dataclasses import asdict
import gzip
import hashlib
import json
from pathlib import Path
import tempfile

from sql_safety_executor import load_config
from sql_safety_executor.core.managed_sql import check_managed_sql
from sql_safety_executor.core.runtime import GatewayRuntime
from sql_safety_executor.database.semantics import DialectContext

BATCH = Path(__file__).resolve().parents[1]
ROOT = Path(__file__).resolve().parents[4]
OUT = BATCH / 'evidence/cache_matrix.json.gz'
assert not OUT.exists()
before = json.loads((BATCH / 'evidence/before.json').read_text())
name = 'src/sql_safety_executor/core/managed_sql.py'
assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == before['files'][name]
corpus = json.loads((BATCH / 'evidence/corpus.json').read_text())
records = []
with tempfile.TemporaryDirectory(prefix='managed-cache-matrix-') as folder:
    root = Path(folder)
    (root / 'server.toml').write_text('schema_version=1\n[files]\nconnections="connections.toml"\n[server]\ndefault_connection="fixture"\n')
    (root / 'connections.toml').write_text('schema_version=1\n[connections.fixture]\ntype="sqlite"\nsqlite.path="unused.sqlite"\n')
    runtime = GatewayRuntime(load_config(root / 'server.toml'))
    try:
        for raw in corpus['contexts']:
            context = DialectContext(raw['dialect'], frozenset(raw['sql_modes']), default_schema=raw['default_schema'])
            for case in corpus['cases']:
                for parser in ('sqlglot', 'sqlparse'):
                    expected = check_managed_sql(case['sql'], context, parser)
                    first = runtime.classify_managed_plan(case['sql'], context, parser)
                    repeated = runtime.classify_managed_plan(case['sql'], context, parser)
                    assert first == expected and repeated is first
                    records.append({'id': case['id'], 'context': raw, 'parser': parser,
                                    'decision': asdict(first), 'repeat_same_immutable_result': True})
        info = runtime.classify_managed_plan.cache_info()._asdict()
        assert info['currsize'] == info['maxsize'] == 128
    finally:
        runtime.close()
    assert not (root / 'unused.sqlite').exists()
result = {'scope': __doc__, 'original_classifier_sha256_unchanged': True,
          'records': records, 'unique_case_context_parser_checks': len(records),
          'cached_api_calls': 2 * len(records), 'cache_info': info,
          'no_database_created_or_used': True, 'all_checks_passed': True}
OUT.write_bytes(gzip.compress(json.dumps(result, ensure_ascii=False, indent=2).encode(), mtime=0))
print(json.dumps({key: value for key, value in result.items() if key != 'records'}, ensure_ascii=False))
