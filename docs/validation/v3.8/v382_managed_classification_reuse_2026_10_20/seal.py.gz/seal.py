"""Seal this source/package checkpoint only; resident results append separately."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4]
BATCH=Path(__file__).resolve().parents[1]
PUBLIC=ROOT/'docs/validation/v3.8/v382_managed_classification_reuse_2026_10_20'
assert not (BATCH/'manifest.json').exists() and not (PUBLIC/'manifest.json').exists()
for root in (BATCH,PUBLIC):
    files={}
    for file in sorted(root.rglob('*')):
        if not file.is_file() or '__pycache__' in file.parts or file.name=='manifest.json':continue
        data=file.read_bytes()
        files[str(file.relative_to(root))]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    (root/'manifest.json').write_text(json.dumps({'date':'2026-10-20','checkpoint':'source_package_passed_resident_pending',
        'scope':'No complete-model or new native acceptance claim. Later resident supplement must not rewrite this checkpoint. Python caches excluded.',
        'files':files},ensure_ascii=False,indent=2)+'\n')
    for name,entry in files.items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==entry['sha256']
    print(str(root.relative_to(ROOT)),len(files))
