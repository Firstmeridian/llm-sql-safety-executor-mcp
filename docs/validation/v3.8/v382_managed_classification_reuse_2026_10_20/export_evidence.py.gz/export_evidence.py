"""Publish the scoped results without rewriting any earlier sealed checkpoint."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
E = BATCH / 'evidence'
PUBLIC = ROOT / 'docs/validation/v3.8/v382_managed_classification_reuse_2026_10_20'
PUBLIC.mkdir(exist_ok=True)
assert not (PUBLIC / 'summary.json').exists()
assert not (PUBLIC / 'manifest.json').exists()
verification = json.loads((E / 'verification.json').read_text())
before = json.loads((E / 'before.json').read_text())
costs = json.loads((E / 'performance_summary.json').read_text())
paired = json.loads(gzip.decompress((E / 'paired_cost.json.gz').read_bytes()))
assert paired['all_checks_passed'] and paired['measured_calls'] == 1920 and paired['warmup_calls'] == 192
for label in ('a1', 'a2'):
    cost = json.loads(gzip.decompress((E / (label + '_lifecycle_cost.json.gz')).read_bytes()))
    assert cost['all_checks_passed'] and cost['measured_calls'] == 1440 and cost['warmup_calls'] == 288
    expected = json.loads((E / (label + '_resources.json')).read_text())
    for phase in cost['phases']:
        selected = expected if phase['phase'] == 'B' else before['resources']
        assert phase['resource_sha256'] == {name.removeprefix('sql_safety_executor/'): value for name, value in selected.items()}
for run in paired['runs']:
    assert run['resource_sha256']['A'] == {name.removeprefix('sql_safety_executor/'): value for name, value in before['resources'].items()}
    assert run['resource_sha256']['B'] == verification['runtime_resources']
for record in before['previous_seals']:
    manifest = ROOT / record['manifest']
    assert hashlib.sha256(manifest.read_bytes()).hexdigest() == record['sha256']
    files = json.loads(manifest.read_text())['files']
    if isinstance(files, list):
        files = {value['path']: value for value in files}
    for name, entry in files.items():
        assert hashlib.sha256((manifest.parent / name).read_bytes()).hexdigest() == entry['sha256']
sources = ['before.json', 'a1_resources.json', 'a2_resources.json', 'verification.json', 'performance_summary.json',
           'corpus.json', 'final_comparison.json.gz', 'rule_comparison_verified.json', 'cache_matrix.json.gz',
           'classification_counts.json', 'a2_classification_counts.json', 'source_stdio.json.gz', 'installed_stdio.json.gz',
           'a1_lifecycle_cost.json.gz', 'a2_lifecycle_cost.json.gz', 'paired_cost.json.gz',
           'full_pytest.log', 'typecheck.log', 'prompt_contract.log', 'installed_prompt_contract.log',
           'installed_resources.json', 'before_runtime.tar.gz', 'a1_runtime.tar.gz', 'after_runtime.tar.gz',
           'a1_lifecycle_preflight_failed.log', 'rule_comparison_container_type_failure.log', 'installed_stdio_process.json',
           'paired_cost_initial_context_failure.transcript.txt', 'paired_cost_edit_syntax_failure.log']
for name in sources:
    source = E / name
    destination = PUBLIC / (name if name.endswith('.gz') else name + '.gz')
    data = source.read_bytes() if name.endswith('.gz') else gzip.compress(source.read_bytes(), mtime=0)
    if destination.exists():
        assert destination.read_bytes() == data
    else:
        destination.write_bytes(data)
for source in sorted((BATCH / 'scripts').glob('*.py')):
    (PUBLIC / (source.name + '.gz')).write_bytes(gzip.compress(source.read_bytes(), mtime=0))
# Check repository Markdown paths, including fresh untracked reports and local handoff.
tracked = subprocess.check_output(['git', 'diff', '--name-only', '--', '*.md'], cwd=ROOT, text=True).splitlines()
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', '*.md'], cwd=ROOT, text=True).splitlines()
documents = [ROOT / name for name in tracked + untracked]
documents += [BATCH / 'reports/README_ZH.md', ROOT / 'local_archive/v382_review/README.md',
              ROOT / 'local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md']
checked = 0
for file in documents:
    if not file.is_file():
        continue
    for target in re.findall(r'\[[^\]]*\]\(([^\s)]+)(?:\s+"[^"]*")?\)', file.read_text()):
        target = unquote(target.strip('<>')).split('#', 1)[0]
        if not target or re.match(r'[a-zA-Z][a-zA-Z0-9+.-]*:', target):
            continue
        path = (file.parent / target).resolve() if not target.startswith('/') else Path(target)
        assert path.exists(), (str(file.relative_to(ROOT)), target)
        checked += 1
summary = {'date': '2026-10-20', 'status': 'source_package_passed_resident_pending',
           'owner_scope': 'Readiness separation and pure classification reuse only; hint/HIGH_NOT_PRECEDENCE work deferred.',
           'verification': verification, 'staged_costs': costs,
           'paired_costs': [{key: value for key, value in run.items() if key != 'resource_sha256'} for run in paired['runs']],
           'measured_calls': 4800, 'warmup_calls': 768, 'complete_restored_cycles': 928,
           'markdown_local_links_checked': checked,
           'limits': 'Application observations, not full protocol frames/model usage. No new native or complete-model acceptance. Prior source/package/native/model evidence retains attribution; manual restart required.'}
(E / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
(PUBLIC / 'summary.json').write_text((E / 'summary.json').read_text())
print(json.dumps({'published_results': len(sources), 'scripts': len(list((BATCH / 'scripts').glob('*.py'))),
                  'local_links_checked': checked, 'previous_files_verified': before['previous_files_verified']}, indent=2))
