"""Freeze no-confirmation native checks, independent DB truth and old seals."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3

from sql_safety_executor import load_config

ROOT = Path(__file__).resolve().parents[5]
LOCAL = Path(__file__).resolve().parents[1]
BATCH = LOCAL.parent
OUT = LOCAL / 'evidence/native_plan.json'
assert not OUT.exists()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

config = load_config(ROOT / 'config/server.toml')
assert config.skills.mutation.managed_plan_parser == 'sqlglot'
assert config.skills.readiness.check_schema is True
resources = {str(p.relative_to(ROOT / 'src/sql_safety_executor')): digest(p)
             for p in (ROOT / 'src/sql_safety_executor').rglob('*')
             if p.is_file() and p.suffix in {'.py', '.md'}}
assert resources == json.loads((BATCH / 'evidence/verification.json').read_text())['runtime_resources']
before = json.loads((BATCH / 'evidence/before.json').read_text())
manifests = [ROOT / record['manifest'] for record in before['previous_seals']]
manifests += [BATCH / 'manifest.json', ROOT / 'docs/validation/v3.8/v382_managed_classification_reuse_2026_10_20/manifest.json']
seals = []
for path in manifests:
    files = json.loads(path.read_text())['files']
    entries = files.items() if isinstance(files, dict) else ((value['path'], value) for value in files)
    for name, entry in entries:
        assert digest(path.parent / name) == entry['sha256']
    seals.append({'manifest': str(path.relative_to(ROOT)), 'sha256': digest(path), 'file_count': len(files)})
assert len(seals) == 23 and sum(value['file_count'] for value in seals) == 580
rich, mysql, features = 'rich_mutation_sqlite', 'orders_demo_mysql', 'sqlite_features_sqlite'
update, reset = 'sample-update-order-status', 'sample-reset-order-to-pending'
databases = {}
for alias in (rich, features):
    path = Path(config.connections[alias].sqlite_database_path)
    state = {'file_sha256': digest(path)}
    with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as db:
        if alias == rich:
            db.row_factory = sqlite3.Row
            state['snapshot'] = [dict(row) for row in db.execute('SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')]
            assert state['snapshot'][0] == {'id': 1, 'status': 'confirmed'}
            rows = [tuple(row) for row in db.execute('SELECT * FROM main.orders ORDER BY id')]
            state['row_count'] = len(rows)
            state['all_order_rows_sha256'] = hashlib.sha256(json.dumps(rows, ensure_ascii=False, default=str).encode()).hexdigest()
        else:
            state['fts_match_count'] = db.execute("SELECT COUNT(*) FROM main.pages_fts WHERE pages_fts MATCH 'sqlite'").fetchone()[0]
    assert digest(path) == state['file_sha256']
    databases[alias] = state

checks = [{'id': 'routing_catalog', 'tool': 'list_connections', 'arguments': {},
           'expected': {'connection_ids': sorted(config.connections)}}]

def add(label, tool, alias, expected, **arguments):
    checks.append({'id': label, 'tool': tool, 'arguments': {'connection_id': alias, **arguments}, 'expected': expected})

add('canary', 'query', rich, {'data': [{'n': 7}]}, sql='SELECT 7 AS n')
add('snapshot_before', 'query', rich, {'data': databases[rich]['snapshot']}, sql='SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')
for phase in ('first', 'repeat'):
    add('available_' + phase, 'list_skills', rich, {'skill_names': sorted((update, reset))}, search=update, detail_level='full')
    add('execution_detail_' + phase, 'get_skill_detail', rich, {'executable': True}, skill_name=update, detail_level='execution')
    add('update_preview_' + phase, 'execute_mutation_skill', rich, {'preview': True, 'new_status': 'shipped'}, skill_name=update, params={'order_id': 1, 'new_status': 'shipped'}, confirm=False)
add('reset_preview', 'execute_mutation_skill', rich, {'preview': True, 'new_status': 'pending'}, skill_name=reset, params={'order_id': 1, 'expected_status': 'confirmed'}, confirm=False)
add('backward_refused', 'execute_mutation_skill', rich, {'error_code': 'validation_failed', 'related': reset}, skill_name=update, params={'order_id': 1, 'new_status': 'pending'}, confirm=False)
add('unexpected_parameter_refused', 'execute_mutation_skill', rich, {'isError': True, 'text_contains': 'Unexpected parameter'}, skill_name=update, params={'order_id': 1, 'new_status': 'shipped', 'unexpected': True}, confirm=False)
add('readonly_catalog', 'list_skills', mysql, {'skill_names': []}, search=update, detail_level='full')
add('readonly_detail', 'get_skill_detail', mysql, {'executable': False}, skill_name=update, detail_level='full')
add('readonly_preview_refused', 'execute_mutation_skill', mysql, {'isError': True, 'text_contains': 'not authorized by skills.mutation.allowed_connections'}, skill_name=update, params={'order_id': 1, 'new_status': 'shipped'}, confirm=False)
add('mysql_canary', 'query', mysql, {'data': [{'n': 7}]}, sql='SELECT 7 AS n')
add('mysql_cte_case', 'query', mysql, {'data': [{'n': 7}]}, sql='WITH CaseData AS (SELECT 7 AS n) SELECT n FROM casedata')
add('fts', 'query', features, {'data': [{'n': databases[features]['fts_match_count']}]}, sql="SELECT COUNT(*) AS n FROM main.pages_fts WHERE pages_fts MATCH 'sqlite'")
add('function_refused', 'query', features, {'error_code': 'expensive_function_denied'}, sql='SELECT SLEEP(0)')
add('shadow_refused', 'query', features, {'error_code': 'table_access_denied'}, sql='SELECT * FROM main.pages_fts_idx LIMIT 1')
add('raw_write_refused', 'query', rich, {'error_code': 'read_only_required'}, sql="UPDATE main.orders SET status='pending' WHERE id=1")
add('snapshot_after', 'query', rich, {'data': databases[rich]['snapshot']}, sql='SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')
assert len(checks) == 22
assert all(not check['arguments'].get('confirm', False) for check in checks)
plan = {'owner_restart_confirmed': True, 'frozen_utc': datetime.now(timezone.utc).isoformat(),
        'parser_default': config.skills.mutation.managed_plan_parser, 'schema_readiness_enabled': True,
        'preview_ttl_seconds': config.skills.mutation.preview.ttl_seconds,
        'databases': databases, 'checks': checks, 'previous_seals': seals,
        'scope': 'Current Host only; existing configured fixtures. Never confirm writes. First/repeat names indicate call order, not an attestation of resident cache temperature. Native outputs do not prove cache hits or in-memory source hashes. Context switches/consumed confirmations/rollback/cache counters remain source/package coverage. Preview handles are redacted and abandoned, not actively revoked; no expiry observation is claimed.'}
OUT.write_text(json.dumps(plan, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'frozen_native_calls': len(checks), 'old_manifests': len(seals), 'old_files': 580, 'matching_runtime_resources': len(resources)}))
