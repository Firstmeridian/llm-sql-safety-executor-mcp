"""Verify scoped native results, unchanged independent data and earlier seals."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3

from sql_safety_executor import load_config

ROOT = Path(__file__).resolve().parents[5]
LOCAL = Path(__file__).resolve().parents[1]
BATCH = LOCAL.parent
OUT = LOCAL / 'evidence/summary.json'
assert not OUT.exists()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

config = load_config(ROOT / 'config/server.toml')
plan = json.loads((LOCAL / 'evidence/native_plan.json').read_text())
raw = json.loads((LOCAL / 'evidence/native_application.json').read_text())
catalog = json.loads((LOCAL / 'evidence/native_catalog.json').read_text())
metadata = []
for tool in catalog['tools']:
    description = catalog['shared_description_prefix'] + tool['description_suffix']
    # JavaScript string lengths count UTF-16 code units.
    assert len(description.encode('utf-16-le')) // 2 == tool['description_characters']
    metadata.append({'name': tool['name'], 'description_sha256': hashlib.sha256(description.encode()).hexdigest()})
checks = []
for index, (record, frozen) in enumerate(zip(raw['records'], plan['checks'], strict=True)):
    assert record['index'] == index and record['id'] == frozen['id']
    assert record['tool'] == frozen['tool'] and record['arguments'] == frozen['arguments']
    response, expected = record['result'], frozen['expected']
    errors = []
    def check(condition, message):
        if not condition:
            errors.append(message)
    check(response.get('isError', False) == expected.get('isError', False), 'Host isError')
    payload = response.get('structuredContent')
    if expected.get('isError'):
        check(payload is None, 'tool rejection has no business payload')
        text = ' '.join(value.get('text', '') for value in response['content'])
        check(expected['text_contains'] in text, 'specific setup refusal')
    else:
        texts = [value['text'] for value in response['content'] if value['type'] == 'text']
        check(len(texts) == 1 and json.loads(texts[0]) == payload, 'text/structured equality after stated redaction')
        if 'connection_id' in frozen['arguments']:
            check(payload['connection_id'] == frozen['arguments']['connection_id'], 'exact target')
        if 'error_code' in expected:
            check(payload['success'] is False and payload['error_code'] == expected['error_code'], 'specific policy refusal')
            if frozen['tool'] == 'execute_mutation_skill':
                check(payload['execution_outcome'] == 'not_executed' and 'preview_token' not in payload, 'rejected preview issued no token')
                check(expected['related'] in payload['related_available_skills'], 'same-target recovery available')
        else:
            check(payload['success'] is True, 'successful handling')
        if 'connection_ids' in expected:
            check(sorted(value['connection_id'] for value in payload['connections']) == expected['connection_ids'], 'configured routing aliases')
            check(payload['connection_count'] == len(expected['connection_ids']), 'routing alias count')
        if 'data' in expected:
            check(payload['data'] == expected['data'] and payload['truncated'] is False, 'complete frozen data')
        if 'skill_names' in expected:
            check(sorted(value['name'] for value in payload['skills']) == expected['skill_names'], 'frozen search names incl related Skills')
            check(all(value['executable'] and value['schema_ready'] and not value['missing_tables'] and not value['unverified_tables'] for value in payload['skills']), 'catalog readiness')
        if 'executable' in expected:
            check(payload['skill']['executable'] is expected['executable'], 'target executable state')
        if expected.get('preview'):
            check(frozen['arguments']['confirm'] is False and payload['mode'] == 'preview', 'explicit preview only')
            check(payload['execution_outcome'] == 'not_executed', 'no write outcome')
            check(payload['preview_token'] == '[REDACTED_PREVIEW_HANDLE]' and isinstance(payload['preview_token_expires_at'], str), 'handle redacted with explicit expiry field')
            check(payload['preview']['preview_sql'] == 'UPDATE orders SET status = :new_status WHERE id = :order_id AND status = :expected_status', 'unchanged original managed SQL')
            check(payload['preview']['bound_params'] == {'order_id': 1, 'expected_status': 'confirmed', 'new_status': expected['new_status']}, 'exact original bindings')
            check(payload['preview']['affected_rows_estimate'] == 1, 'one-row estimate')
    checks.append({'index': index, 'id': frozen['id'], 'passed': not errors, 'errors': errors})
assert len(checks) == 22 and all(value['passed'] for value in checks), checks
assert raw['redacted_preview_handle_count'] == 3
assert all(not value['arguments'].get('confirm', False) for value in raw['records'])
assert sum(bool(value['result'].get('structuredContent', {}).get('preview_token')) for value in raw['records']) == 3
truth = {}
for alias, expected in plan['databases'].items():
    path = Path(config.connections[alias].sqlite_database_path)
    assert digest(path) == expected['file_sha256']
    with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as db:
        state = {'file_sha256_before': expected['file_sha256'], 'file_sha256_after': digest(path)}
        if alias == 'rich_mutation_sqlite':
            db.row_factory = sqlite3.Row
            snapshot = [dict(row) for row in db.execute('SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')]
            assert snapshot == expected['snapshot']
            rows = [tuple(row) for row in db.execute('SELECT * FROM main.orders ORDER BY id')]
            row_digest = hashlib.sha256(json.dumps(rows, ensure_ascii=False, default=str).encode()).hexdigest()
            assert len(rows) == expected['row_count'] and row_digest == expected['all_order_rows_sha256']
            state.update(snapshot=snapshot, row_count=len(rows), all_order_rows_sha256=row_digest)
        else:
            count = db.execute("SELECT COUNT(*) FROM main.pages_fts WHERE pages_fts MATCH 'sqlite'").fetchone()[0]
            assert count == expected['fts_match_count']
            state['fts_match_count'] = count
    assert digest(path) == expected['file_sha256']
    truth[alias] = state
verified = 0
for record in plan['previous_seals']:
    manifest = ROOT / record['manifest']
    assert digest(manifest) == record['sha256']
    files = json.loads(manifest.read_text())['files']
    entries = files.items() if isinstance(files, dict) else ((value['path'], value) for value in files)
    for name, entry in entries:
        path = manifest.parent / name
        assert digest(path) == entry['sha256'] and path.stat().st_size == entry['bytes']
        verified += 1
package = ROOT / 'src/sql_safety_executor'
resources = {str(p.relative_to(package)): digest(p) for p in package.rglob('*') if p.is_file() and p.suffix in {'.py', '.md'}}
assert resources == json.loads((BATCH / 'evidence/verification.json').read_text())['runtime_resources']
assert len(resources) == 77 and verified == 580 and len(plan['previous_seals']) == 23
summary = {'owner_restart_confirmed': True, 'verified_utc': datetime.now(timezone.utc).isoformat(),
           'passed': 22, 'total': 22, 'checks': checks, 'routing_catalog_checks': 1,
           'successful_query_reads': 6, 'catalog_detail_checks': 6, 'successful_previews': 3,
           'expected_refusals': 6, 'independent_truth': truth, 'source_resources_match_final_wheel': 77,
           'old_manifest_count': 23, 'old_sealed_files_verified': 580, 'tool_description_digests': metadata,
           'preview_ttl_seconds': plan['preview_ttl_seconds'],
           'preview_handling': 'Three confirm=false previews; handles redacted before disk export. No confirmation or public revocation. Handles are abandoned subject to configured natural TTL; no observation of expiry is claimed.',
           'source_or_configuration_changes_this_supplement': False, 'configured_business_writes': False,
           'limits': ['Current Host behavior after owner-confirmed restart; not an in-memory source-hash or LRU-hit attestation.',
                      'Repeated native discovery/detail/preview is consistency coverage; isolated counters establish cold/warm parse counts.',
                      'Consumed-confirmation/context-change/transaction evidence remains source/package coverage; no identical native replay.',
                      'No new complete-model trial, provider usage comparison, matched native performance A/B or two-protocol claim.',
                      'Application records and losslessly split model-visible tool descriptions; not full protocol frames or original field omission proof.'],
           'all_checks_passed': True}
OUT.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ('passed', 'total', 'successful_previews', 'expected_refusals', 'old_sealed_files_verified', 'source_resources_match_final_wheel')}))
