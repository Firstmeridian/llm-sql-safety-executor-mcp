"""Record frozen legacy/candidate differences and non-executing SQLite truth."""
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
from sqlalchemy import text

from sql_safety_executor.database.semantics import DialectContext
from sql_safety_executor.skills.mutation import ManagedMutationPlan, ManagedMutationValue, validate_managed_mutation_plan
from sql_safety_executor.core.managed_sql import check_managed_sql

BATCH=Path(__file__).resolve().parents[1]
corpus=json.loads((BATCH/'evidence/corpus.json').read_text())
records=[]
for c in corpus['contexts']:
    context=DialectContext(c['dialect'],frozenset(c['sql_modes']),default_schema=c['default_schema'])
    for case in corpus['cases']:
        sql=case['sql']
        targets=tuple(text(sql).compile().params)
        plan=ManagedMutationPlan(sql,tuple(ManagedMutationValue.constant(name,1) for name in targets),1)
        try:
            validate_managed_mutation_plan(plan, parser='sqlparse', context=context)
            old,reason=True,None
        except Exception as error:
            old,reason=False,str(error)
        try:
            validate_managed_mutation_plan(plan, parser='sqlglot', context=context)
            new,kind=True,None
        except Exception as error:
            new,kind=False,str(error)
        records.append({'id':case['id'],'context':c,'legacy':old,'legacy_reason':reason,'candidate':new,
                        'candidate_reason':kind,'transport_named_binds':targets})
truth=[]
with sqlite3.connect(':memory:') as db:
    columns='(id INTEGER PRIMARY KEY,status TEXT,n INTEGER,note TEXT,"replace" TEXT)'
    for name in ['orders','archive','source','Korders',' f ','a\\:b']:
        quoted='"'+name.replace('"','""')+'"'
        db.execute('CREATE TABLE '+quoted+columns)
    db.execute("INSERT INTO orders VALUES(1,'pending',7,'alpha',NULL)")
    before='\n'.join(db.iterdump())
    for case in corpus['cases']:
        sql=case['sql'];params={name:1 for name in text(sql).compile().params}
        try:
            if case['id']=='qmark':
                db.execute('EXPLAIN '+sql,(99,1)).fetchall()
            elif case['id']=='qmark_number':
                db.execute('EXPLAIN '+sql,{'1':99,'2':1}).fetchall()
            elif case['id']=='dollar_bind':
                db.execute('EXPLAIN '+sql,{'1':99,'2':1}).fetchall()
            else:
                db.execute('EXPLAIN '+sql,params).fetchall()
            native,error=True,None
        except sqlite3.Error as exc:
            native,error=False,str(exc)
        truth.append({'id':case['id'],'explain_compiles':native,'error':error})
    assert before=='\n'.join(db.iterdump())
supplement=[]
for sql in ['UPDATE orders SET n=7 /*! ,status=99 */', 'UPDATE orders SET n=7; /*! DELETE FROM orders */',
            'UPDATE orders SET n=7 /*M! ,status=99 */', 'UPDATE /*+ MAX_EXECUTION_TIME(1000) */ orders SET n=7',
            'UPDATE orders SET n=7--suffix', "UPDATE orders SET note='/*! string */' /* ordinary */"]:
    decision=check_managed_sql(sql,DialectContext('mysql'))
    supplement.append({'sql':sql,'sqlglot':{'allowed':decision.allowed,'code':decision.error_code},
                       'sqlparse':check_managed_sql(sql,DialectContext('mysql'),'sqlparse').allowed})
out=BATCH/'evidence/final_comparison.json.gz';assert not out.exists()
out.write_bytes(gzip.compress(json.dumps({'corpus_sha256':hashlib.sha256((BATCH/'evidence/corpus.json').read_bytes()).hexdigest(),
    'comparison_scope':'Both complete plan validators; same plan fields, SQLAlchemy named-bind targets and concrete context. Supplemental comments were added after the original freeze, not part of its 98 cases.',
    'records':records,'comment_supplement':supplement,'sqlite_truth':truth,'database_unchanged':True,'sqlite':sqlite3.sqlite_version},ensure_ascii=False,indent=2).encode(),mtime=0))
diff=[row for row in records if row['legacy']!=row['candidate']]
print(json.dumps({'records':len(records),'differences':len(diff),'different_case_ids':sorted(set(row['id'] for row in diff)),
 'sqlite_differences':[{'id':row['id'],'legacy':row['legacy'],'candidate':row['candidate'],'reason':row['candidate_reason'],'native':next(t for t in truth if t['id']==row['id'])} for row in diff if row['context']['dialect']=='sqlite']},ensure_ascii=False,indent=2))

previous=json.loads(gzip.decompress((BATCH.parent/"20261020_managed_parser/evidence/final_comparison.json.gz").read_bytes()))
assert json.loads(json.dumps(records))==previous["records"]
assert supplement==previous["comment_supplement"]
assert truth==previous["sqlite_truth"]
print("All 980 paired validator outcomes, 6 comment controls and 98 SQLite plan results exactly unchanged")
