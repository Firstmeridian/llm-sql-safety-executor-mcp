"""Serial matched child-stdio managed-write lifecycle comparison, SQLite only.

Post-migration baseline archive versus the selected optimization checkpoint. Same two frozen built-in plans,
no parser-selector field, and a new disposable database/process per phase.
All writes are temporary fixtures; no private config or configured DB access.
"""
from __future__ import annotations

import argparse
import asyncio
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import sys
import tarfile
import tempfile
import time

ROOT=Path(__file__).resolve().parents[4]
BATCH=Path(__file__).resolve().parents[1]
LABEL=sys.argv[1]
OUT=BATCH/('evidence/'+LABEL+'_lifecycle_cost.json.gz')
WARMUPS=8
REPEATS=40


async def run():
    from sql_safety_executor.mcp.bootstrap import prepare_framework
    prepare_framework()
    from fastmcp import Client
    from fastmcp.client.transports import StdioTransport
    import sqlite3

    assert not OUT.exists()
    before=json.loads((BATCH/'evidence/before.json').read_text())
    final=json.loads((BATCH/('evidence/'+LABEL+'_resources.json')).read_text())
    update,reset='sample-update-order-status','sample-reset-order-to-pending'
    definition_hashes={name:hashlib.sha256((ROOT/'skills'/name/'mutation.py').read_bytes()).hexdigest() for name in (update,reset)}
    for name,digest in definition_hashes.items():assert before['files']['skills/'+name+'/mutation.py']==digest
    records=[];phases=[]
    with tempfile.TemporaryDirectory(prefix='managed-cost-baseline-') as baseline:
        with tarfile.open(BATCH/'evidence/before_runtime.tar.gz') as archive:
            archive.extractall(baseline,filter='data')
        for mode in ('auto','legacy'):
            for phase,source in [('A1',Path(baseline)),('B',ROOT/'src'),('A2',Path(baseline))]:
                with tempfile.TemporaryDirectory(prefix='managed-cost-fixture-') as folder:
                    root=Path(folder)
                    database=root/'fixture.sqlite'
                    with sqlite3.connect(database) as db:
                        db.executescript("CREATE TABLE orders(id INTEGER PRIMARY KEY,status TEXT);INSERT INTO orders VALUES(1,'pending');")
                    original_hash=hashlib.sha256(database.read_bytes()).hexdigest()
                    for name in (update,reset):shutil.copytree(ROOT/'skills'/name,root/'skills'/name)
                    (root/'server.toml').write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="fixture"\n')
                    (root/'connections.toml').write_text('schema_version=1\n[connections.fixture]\ntype="sqlite"\nsqlite.path="fixture.sqlite"\nread.mode="all"\nmutation.enabled=true\nmutation.skills=["'+update+'","'+reset+'"]\n')
                    # Deliberately omit the new selector from both source sets;
                    # compare each default, not baseline with SQLGlot-off config.
                    (root/'skills.toml').write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=true\n[skills.mutation]\nenabled=true\nallowed_connections=["fixture"]\n[skills.mutation.mrtr]\nenabled=false\n[skills.audit]\npath="audit.jsonl"\n')
                    launcher=root/'launcher.py'
                    launcher.write_text('import sys,json,hashlib\nfrom pathlib import Path\nsys.path.insert(0,'+repr(str(source))+')\n'
                        'import sql_safety_executor\np=Path(sql_safety_executor.__file__).resolve().parent\n'
                        'assert p==Path('+repr(str(source))+')/"sql_safety_executor"\n'
                        'r={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob("*") if f.is_file() and f.suffix in {".py",".md"}}\n'
                        'Path("runtime.json").write_text(json.dumps(r))\n'
                        'from sql_safety_executor import create_server,load_config\nserver=create_server(load_config("server.toml"))\n'
                        'server.run(transport="stdio",show_banner=False)\n')
                    env=os.environ.copy();env['PYTHONPATH']=str(source)
                    transport=StdioTransport(command=sys.executable,args=[str(launcher)],cwd=str(root),env=env)
                    async with Client(transport,mode=mode) as client:
                        observed=json.loads((root/'runtime.json').read_text())
                        expected=final if phase=='B' else before['resources']
                        assert observed=={name.removeprefix('sql_safety_executor/'): digest for name,digest in expected.items()}
                        protocol=client.protocol_version
                        async def call(name,arguments,step,iteration):
                            start=time.perf_counter_ns()
                            result=await client.call_tool(name,{'connection_id':'fixture',**arguments},raise_on_error=False)
                            elapsed=(time.perf_counter_ns()-start)/1e6
                            payload=result.structured_content
                            assert not result.is_error and payload['success'],(name,payload)
                            if name=='execute_mutation_skill':
                                assert payload['execution_outcome']==('committed' if arguments.get('confirm') else 'not_executed')
                            records.append({'mode':mode,'phase':phase,'iteration':iteration,'warmup':iteration<0,'step':step,
                                'tool':name,'elapsed_ms':elapsed,'success':payload['success'],'outcome':payload.get('execution_outcome'),
                                'preview_token_present':isinstance(payload.get('preview_token'),str)})
                            return payload
                        for iteration in range(-WARMUPS,REPEATS):
                            listed=await call('list_skills',{'search':update,'detail_level':'full'},'catalog',iteration)
                            assert sorted(x['name'] for x in listed['skills'])==sorted((update,reset))
                            detail=await call('get_skill_detail',{'skill_name':update,'detail_level':'execution'},'detail',iteration)
                            assert detail['skill']['executable']
                            params={'order_id':1,'new_status':'confirmed'}
                            preview=await call('execute_mutation_skill',{'skill_name':update,'params':params,'confirm':False},'update_preview',iteration)
                            assert preview['preview']['bound_params']=={'order_id':1,'new_status':'confirmed','expected_status':'pending'}
                            executed=await call('execute_mutation_skill',{'skill_name':update,'params':params,'confirm':True,'preview_token':preview['preview_token']},'update_confirm',iteration)
                            assert executed['result']['rowcount']==1
                            params={'order_id':1,'expected_status':'confirmed'}
                            preview=await call('execute_mutation_skill',{'skill_name':reset,'params':params,'confirm':False},'reset_preview',iteration)
                            assert preview['preview']['bound_params']=={'order_id':1,'new_status':'pending','expected_status':'confirmed'}
                            restored=await call('execute_mutation_skill',{'skill_name':reset,'params':params,'confirm':True,'preview_token':preview['preview_token']},'reset_confirm',iteration)
                            assert restored['result']['rowcount']==1
                            # Native SQLite truth, deliberately outside timing.
                            with sqlite3.connect(database) as db:
                                assert db.execute('SELECT id,status FROM orders').fetchall()==[(1,'pending')]
                    selected=[x for x in records if x['mode']==mode and x['phase']==phase and not x['warmup']]
                    assert len(selected)==REPEATS*6
                    phases.append({'mode':mode,'phase':phase,'protocol':protocol,'measured_calls':len(selected),
                        'complete_cycles':REPEATS,'warmup_cycles':WARMUPS,'resource_sha256':observed,
                        'step_median_ms':{step:statistics.median(x['elapsed_ms'] for x in selected if x['step']==step) for step in sorted({x['step'] for x in selected})},
                        'cycle_median_ms':statistics.median(sum(x['elapsed_ms'] for x in selected if x['iteration']==n) for n in range(REPEATS)),
                        'truth':[(1,'pending')],'database_file_hash_before':original_hash,
                        'database_file_hash_after':hashlib.sha256(database.read_bytes()).hexdigest()})
                    print(json.dumps({k:v for k,v in phases[-1].items() if k not in {'resource_sha256'}},ensure_ascii=False),flush=True)
    result={'scope':__doc__,'warmup_cycles_per_phase':WARMUPS,'measured_cycles_per_phase':REPEATS,
        'definition_sha256':definition_hashes,'phases':phases,'records':records,'all_checks_passed':True,
        'measured_calls':sum(not x['warmup'] for x in records),'warmup_calls':sum(x['warmup'] for x in records),
        'notes':['Serial warm default A/B/A per Client mode; not a randomized causal estimate or cold startup measure.',
                 'Each iteration includes discovery/detail, update preview/commit and restoration preview/commit on disposable SQLite only.',
                 'Original/restore row truth checked outside timing. File hashes may differ after real temporary writes; row restoration, not byte restoration, is asserted.',
                 'No configured MySQL business write or new complete-model/provider token evidence. Summary retains every measured latency and outcome, not full application responses or protocol frames.']}
    OUT.write_bytes(gzip.compress(json.dumps(result,ensure_ascii=False,indent=2).encode(),mtime=0))
    print('Measured calls',result['measured_calls'],'warmup calls',result['warmup_calls'],flush=True)


if __name__=='__main__':
    asyncio.run(run())
