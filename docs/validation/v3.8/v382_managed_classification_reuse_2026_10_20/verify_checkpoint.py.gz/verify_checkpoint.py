"""Verify exact optimization scope, installed bytes and prior immutable evidence."""
import gzip
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
import tarfile
import zipfile
from email.parser import BytesParser

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
E = BATCH / 'evidence'
OUT = E / 'verification.json'
assert not OUT.exists()
before = json.loads((E / 'before.json').read_text())
resources = {str(p.relative_to(ROOT / 'src')): hashlib.sha256(p.read_bytes()).hexdigest()
             for p in sorted((ROOT / 'src').rglob('*')) if p.is_file() and p.suffix in {'.py', '.md'}}
assert resources == json.loads((E / 'a2_resources.json').read_text())
changed = [name for name in sorted(resources.keys() | before['resources'].keys())
           if resources.get(name) != before['resources'].get(name)]
assert changed == ['sql_safety_executor/core/mutations.py', 'sql_safety_executor/core/runtime.py',
                   'sql_safety_executor/skills/access.py', 'sql_safety_executor/skills/mutation.py']
for name in ('pyproject.toml', 'uv.lock', 'skills/sample-update-order-status/mutation.py',
             'skills/sample-reset-order-to-pending/mutation.py', 'src/sql_safety_executor/core/managed_sql.py'):
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == before['files'][name]
installed = json.loads((E / 'installed_resources.json').read_text())
package_resources = {name.removeprefix('sql_safety_executor/'): digest for name, digest in resources.items()}
assert package_resources == installed['installed']['resources']
for name in ('source_stdio.json.gz', 'installed_stdio.json.gz'):
    doc = json.loads(gzip.decompress((E / name).read_bytes()))
    assert doc['passed'] and len(doc['records']) == 40
    assert doc['resource_sha256'] == package_resources
assert '2815 passed, 4 skipped' in (E / 'full_pytest.log').read_text()
assert '0 errors, 0 warnings' in (E / 'typecheck.log').read_text()
for name in ('prompt_contract.log', 'installed_prompt_contract.log'):
    assert 'Installed prompt resources and routing guidance valid.' in (E / name).read_text()
for record in before['previous_seals']:
    p = ROOT / record['manifest']
    assert hashlib.sha256(p.read_bytes()).hexdigest() == record['sha256']
    files = json.loads(p.read_text())['files']
    if isinstance(files, list):
        files = {item['path']: item for item in files}
    for name, entry in files.items():
        data = (p.parent / name).read_bytes()
        assert hashlib.sha256(data).hexdigest() == entry['sha256']
wheel = Path(installed['wheel'])
assert hashlib.sha256(wheel.read_bytes()).hexdigest() == installed['wheel_sha256']
with zipfile.ZipFile(wheel) as archive:
    metadata = BytesParser().parsebytes(archive.read('llm_sql_safety_executor_mcp-3.8.2.dist-info/METADATA'))
    assert metadata.get_payload(decode=True).decode().strip() == (ROOT / 'README.md').read_text().strip()
with tarfile.open(E / 'after_runtime.tar.gz', 'w:gz') as archive:
    for name in resources:
        archive.add(ROOT / 'src' / name, arcname=name)
(E / 'dist').mkdir(exist_ok=True)
shutil.copy2(wheel, E / 'dist' / wheel.name)
versions = {name: importlib.metadata.version(name) for name in ('sqlglot', 'sqlparse', 'fastmcp', 'mcp', 'sqlalchemy', 'pydantic')}
result = {'date': '2026-10-20', 'scope': 'Source/package checkpoint; new resident acceptance requires owner restart. No configured DB write or complete-model trial.',
          'runtime_resources': package_resources, 'changed_runtime_resources': changed, 'version': '3.8.2',
          'dependency_versions': versions, 'dependency_files_unchanged': True, 'full_tests': {'passed': 2815, 'skipped': 4},
          'source_stdio_calls': 40, 'installed_stdio_calls': 40, 'previous_manifests_verified': len(before['previous_seals']),
          'previous_files_verified': before['previous_files_verified'], 'wheel_sha256': installed['wheel_sha256'], 'all_checks_passed': True}
OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'runtime_resources'}, ensure_ascii=False, indent=2))
