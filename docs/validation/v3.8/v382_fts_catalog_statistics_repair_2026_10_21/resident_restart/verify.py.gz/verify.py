"""Check frozen native results and preserve source/package checkpoints."""
from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import tomllib

ROOT = Path(__file__).resolve().parents[5]
HERE = Path(__file__).resolve().parents[1]
BATCH = HERE.parent
PUBLIC = ROOT / 'docs/validation/v3.8/v382_fts_catalog_statistics_repair_2026_10_21'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    if path.exists():
        return json.loads(path.read_text())
    return json.loads(gzip.decompress(path.with_suffix(path.suffix + '.gz').read_bytes()))


def quote(value):
    return '"' + value.replace('"', '""') + '"'


def literal(value):
    return "'" + value.replace("'", "''") + "'"


def main():
    plan = read(BATCH / 'evidence/native_plan.json')
    before = read(HERE / 'evidence/before.json')
    final = read(BATCH / 'evidence/final-checks.json')
    installed = read(BATCH / 'evidence/installed_resources-final.json')
    resources = {str(p.relative_to(ROOT / 'src/sql_safety_executor')): sha(p)
                 for p in (ROOT / 'src/sql_safety_executor').rglob('*')
                 if p.is_file() and p.suffix in {'.py', '.md'}}
    assert len(resources) == 77 and resources == before['runtime_resources'] == installed['installed']['resources']
    for name, digest in before['private_toml_sha256'].items():
        assert sha(ROOT / name) == digest, name
    cfg = tomllib.loads((ROOT / 'config/connections.toml').read_text())
    path = Path(cfg['connections']['sqlite_features_sqlite']['sqlite']['path'])
    database = path if path.is_absolute() else ROOT / 'config' / path
    expected_database = before['configured_sqlite_sha256']
    assert sha(database) == expected_database

    seals = list(final['prior_seals']['records'])
    for manifest in [BATCH / 'manifest.json', PUBLIC / 'manifest.json']:
        seals.append({'manifest': str(manifest.relative_to(ROOT)), 'sha256': sha(manifest),
                      'files': len(read(manifest)['files'])})
    total = 0
    for record in seals:
        manifest = ROOT / record['manifest']
        assert sha(manifest) == record['sha256'], record['manifest']
        data = read(manifest)
        files = data['files']
        items = files.items() if isinstance(files, dict) else ((x['path'], x) for x in files)
        paths = {}
        count = 0
        for name, spec in items:
            path = next((p for p in [manifest.parent / name, manifest.parent.parent / name, ROOT / name] if p.is_file()), None)
            assert path is not None, (record['manifest'], name)
            paths[name] = path
            assert sha(path) == (spec['sha256'] if isinstance(spec, dict) else spec), (record['manifest'], name)
            if isinstance(spec, dict):
                if 'bytes' in spec:
                    assert path.stat().st_size == spec['bytes']
                if 'decoded_sha256' in spec:
                    decoded = gzip.decompress(path.read_bytes())
                    assert hashlib.sha256(decoded).hexdigest() == spec['decoded_sha256']
                    if 'decoded_bytes' in spec:
                        assert len(decoded) == spec['decoded_bytes']
            count += 1
        for name, spec in data.get('compressed_decoded_records', {}).items():
            decoded = gzip.decompress(paths[name].read_bytes())
            size = spec.get('decoded_bytes', spec.get('bytes'))
            digest = spec.get('decoded_sha256', spec.get('sha256'))
            assert len(decoded) == size and hashlib.sha256(decoded).hexdigest() == digest
        assert count == record['files']
        total += count
    assert len(seals) == 59 and total == 1998, (len(seals), total)

    raw = read(HERE / 'evidence/native_results.json')
    assert len(raw['calls']) == len(plan['calls']) == 10
    values = {}
    for expected, actual in zip(plan['calls'], raw['calls'], strict=True):
        assert (actual['id'], actual['tool'], actual['arguments']) == (expected['id'], expected['tool'], expected['arguments'])
        assert 'transport_error' not in actual
        result = actual['result']
        value = result['structuredContent']
        text = [item['text'] for item in result['content'] if item['type'] == 'text']
        assert len(text) == 1 and json.loads(text[0]) == value
        assert result['isError'] is False
        values[actual['id']] = value
        if actual['id'] != 'connection':
            assert value['connection_id'] == expected['arguments']['connection_id']
            assert value['success'] is (actual['id'] not in {'shadow_denied', 'function_denied'})
        if expected['tool'] == 'query':
            assert value['query'] == expected['arguments']['sql']
            assert value['db_type'] == ('mysql' if actual['id'] == 'mysql_constant' else 'sqlite')
    connection = values['connection']
    assert connection['complete'] and connection['all_connected'] and not connection['cleanup_failed']
    assert connection['scope'] == 'single' and connection['connection_count'] == connection['connected_count'] == 1
    assert connection['results']['sqlite_features_sqlite']['status'] == 'connected'
    for key, expected in [('constant', 7), ('mysql_constant', 7), ('fts_match', 1), ('fts_call', 1)]:
        assert values[key]['data'] == [{'n': expected}] and not values[key]['truncated']
    assert values['shadow_denied']['error_code'] == 'table_access_denied'
    assert values['function_denied']['error_code'] == 'expensive_function_denied'
    describe, compact, full = (values[k] for k in ['columns', 'compact', 'full'])
    assert describe['column_count'] == len(describe['columns']) == 10
    assert [c['column_name'] for c in describe['columns']] == plan['oracle']['pages_visible_columns']
    assert next(c for c in describe['columns'] if c['column_name'] == 'status')['generation_type'] == 'virtual'
    assert describe['indexes_status'] == 'complete'
    assert compact['total_tables'] == full['total_tables'] == compact['returned_table_count'] == full['returned_table_count'] == 6
    assert compact['total_columns'] == full['total_columns'] == 34
    assert not compact['truncated'] and not full['truncated']
    flattened = {t['name']: (g, t) for g in compact['schema_groups'] for t in g['tables']}
    assert set(flattened) == set(full['schema'])
    assert flattened['pages_fts'][0]['columns'] == [['title', 'TEXT'], ['body', 'TEXT']]
    truth = {'scope': 'Independent read-only sqlite3 metadata/count oracle after native checks, not a cold FTS fixture',
             'columns': {}, 'row_counts': {}, 'index_list': [], 'index_parts': {}}
    with sqlite3.connect(database.resolve().as_uri() + '?mode=ro', uri=True) as db:
        for table, returned in full['schema'].items():
            rows = list(db.execute('PRAGMA main.table_xinfo(' + literal(table) + ')'))
            truth['columns'][table] = [list(r) for r in rows]
            expected = []
            for row in rows:
                if row[6] == 1:
                    continue
                col = {'name': row[1], 'type': row[2] or 'TEXT', 'nullable': 'NO' if row[3] else 'YES',
                       'key': 'PRI' if row[5] else '', 'default': row[4]}
                if row[6] in (2, 3):
                    col['generation_type'] = 'virtual' if row[6] == 2 else 'stored'
                expected.append(col)
            assert returned['columns'] == expected, table
            group, item = flattened[table]
            assert group['columns'] == [[c['name'], c['type']] for c in expected]
            assert group.get('generated_columns', {}) == {c['name']: c['generation_type'] for c in expected if 'generation_type' in c}
            count = db.execute('SELECT COUNT(*) FROM main.' + quote(table)).fetchone()[0]
            truth['row_counts'][table] = count
            assert returned['row_count'] == item['row_count'] == count, table
        assert describe['row_count'] == truth['row_counts']['pages']
        match = db.execute("SELECT COUNT(*) FROM main.pages_fts WHERE pages_fts MATCH 'database'").fetchone()[0]
        call = db.execute("SELECT COUNT(*) FROM main.pages_fts('database')").fetchone()[0]
        assert match == call == plan['oracle']['fts_count'] == 1
        truth['fts_count'] = match
        listed = list(db.execute("PRAGMA main.index_list('pages')"))
        truth['index_list'] = [list(r) for r in listed]
        indexes = {}
        for _, name, unique, origin, partial in listed:
            parts = list(db.execute('PRAGMA main.index_xinfo(' + literal(name) + ')'))
            truth['index_parts'][name] = [list(r) for r in parts]
            keys = [r for r in parts if r[5] == 1]
            index = {'name': name, 'primary': origin == 'pk', 'unique': bool(unique),
                     'columns': [None if r[1] == -2 else r[2] for r in keys],
                     'key_parts': [{'column': None if r[1] == -2 else r[2], 'sort_order': 'desc' if r[3] else 'asc', 'collation': r[4]} for r in keys],
                     'partial': bool(partial)}
            if any(r[1] == -2 for r in keys):
                index['has_expression'] = True
            indexes[name] = index
        primary = sorted([r for r in truth['columns']['pages'] if r[5] > 0], key=lambda r: r[5])
        if primary and not any(i['primary'] for i in indexes.values()):
            indexes[None] = {'name': None, 'primary': True, 'unique': True,
                             'columns': [r[1] for r in primary],
                             'key_parts': [{'column': r[1], 'sort_order': None, 'collation': None} for r in primary], 'partial': False}
        assert {i['name']: i for i in describe['indexes']} == indexes
    assert sha(database) == expected_database
    metadata = read(HERE / 'evidence/tool_metadata.json')
    assert len(metadata) == 10 and all(t['name'].startswith('mcp__sql_safety_executor_mcp__') for t in metadata)
    (HERE / 'evidence/metadata_truth.json').write_text(json.dumps(truth, indent=2) + '\n')
    result = {'scope': 'DRR137/138/139 source/package plus 10 existing-alias native checks; no special-fixture native or whole-protocol/model coverage',
              'completed_at': raw['completed_at'], 'native': {'passed': 10, 'total': 10, 'checks': [{'id': k, 'pass': True} for k in values],
              'text_structured_equal': True, 'all_isError_false': True},
              'metadata': {'tables': 6, 'total_columns': 34, 'pages_columns': 10, 'pages_status': 'virtual',
                           'independent_columns_indexes_row_counts_equal': True},
              'runtime_resources_unchanged': 77, 'private_tomls_unchanged': 3,
              'configured_sqlite_sha256_unchanged': expected_database,
              'prior_seals': {'manifests': 59, 'file_records': 1998, 'all_unchanged': True, 'records': seals},
              'new_database_writes': False, 'new_model_trials': 0, 'new_full_regression_runs': 0, 'new_builds': 0,
              'limits': plan['scope']}
    (HERE / 'evidence/integrity.json').write_text(json.dumps(result, indent=2) + '\n')
    (HERE / 'evidence/tool_metadata_summary.json').write_text(json.dumps({'source': 'Host-exposed ALL_TOOLS name/description metadata, not tools/list input/output schemas',
        'count': 10, 'tools': [{'name': t['name'], 'description_chars': len(t['description']), 'description_sha256': hashlib.sha256(t['description'].encode()).hexdigest()} for t in metadata]}, indent=2) + '\n')
    print(json.dumps({'native': '10/10', 'tables': 6, 'total_columns': 34, 'resources_unchanged': 77, 'private_tomls': 3, 'prior_manifests': 59, 'records': 1998}))


if __name__ == '__main__':
    main()
