"""Assess attached JSON-name readiness using disposable fixtures only."""
from __future__ import annotations
import argparse
import asyncio
from collections import Counter
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile

from fastmcp import Client
from fastmcp.client.transports import StdioTransport
from sql_safety_executor import create_server, load_config

ROOT = Path(__file__).resolve().parents[4]
NAMES = ("json_each", "json_tree")
SCENARIOS = {
    "aux_only": {"attached": ["aux"], "objects": ["aux"], "grants": ["aux"], "chosen": "aux"},
    "builtin": {"attached": [], "objects": [], "grants": [], "chosen": None},
    "empty_aux": {"attached": ["aux"], "objects": [], "grants": [], "chosen": None},
    "two_attached": {"attached": ["first", "second"], "objects": ["first", "second"], "grants": ["first", "second"], "chosen": "first"},
    "main_priority": {"attached": ["aux"], "objects": ["main", "aux"], "grants": ["main", "aux"], "chosen": "main"},
    "temp_priority": {"attached": ["aux"], "objects": ["temp", "aux"], "grants": ["temp", "aux"], "chosen": "temp"},
    "aux_denied": {"attached": ["aux"], "objects": ["aux"], "grants": [], "chosen": "aux"},
    "quoted_schema": {"attached": ["a.ux"], "objects": ["a.ux"], "grants": ["a.ux"], "chosen": "a.ux"},
}

def q(name):
    return '"' + name.replace('"', '""') + '"'

def toml_value(value):
    if isinstance(value, dict):
        return "{" + ", ".join(json.dumps(k) + "=" + toml_value(v) for k, v in value.items()) + "}"
    if isinstance(value, list):
        return "[" + ",".join(toml_value(v) for v in value) + "]"
    return json.dumps(value, ensure_ascii=False)

def save_toml(path, data):
    path.write_text("\n".join(json.dumps(k) + "=" + toml_value(v) for k, v in data.items()) + "\n")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def resources():
    paths = list((ROOT / "src/sql_safety_executor").rglob("*"))
    paths += [ROOT / "config" / name for name in ("server.toml", "connections.toml", "skills.toml")]
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted(paths)
            if p.is_file() and p.suffix in (".py", ".md", ".toml")}

def populate(execute, scenario, *, main=False):
    conf = SCENARIOS[scenario]
    if not main:
        for schema in conf["attached"]:
            execute("ATTACH ':memory:' AS " + q(schema))
    for schema in conf["objects"]:
        if (schema == "main") != main:
            continue
        for name in NAMES:
            execute(f"CREATE VIRTUAL TABLE {q(schema)}.{q(name)} USING fts5(value)")
            execute(f"INSERT INTO {q(schema)}.{q(name)} VALUES('hello {schema}')")

def initialize(server, scenario):
    adapter = server.gateway_runtime.registry.get_adapter("scoped")
    adapter.connect()
    with adapter._engine.begin() as db:
        populate(db.exec_driver_sql, scenario)
    return server

def cases(scenario):
    out = []
    for name in NAMES:
        arg = "'" + json.dumps("hello") + "'"
        out.append((name + ":from", f"SELECT value FROM {name}({arg})"))
        if scenario == "aux_only":
            out.extend([
                (name + ":quoted", f"SELECT value FROM {q(name)}({arg})"),
                (name + ":join", f"SELECT j.value FROM main.anchor JOIN {name}({arg}) AS j ON anchor.n=7"),
                (name + ":in", f"SELECT 7 AS n WHERE 'hello aux' IN {name}({arg})"),
                (name + ":cte", f"WITH chosen AS (SELECT value FROM {name}({arg})) SELECT value FROM chosen"),
                (name + ":explicit_aux", f"SELECT value FROM aux.{name}({arg})"),
                (name + ":explicit_main", f"SELECT value FROM main.{name}({arg})"),
            ])
    return out

def make_fixture(folder, scenario):
    database = folder / "fixture.sqlite"
    with sqlite3.connect(database) as db:
        db.executescript("CREATE TABLE anchor(n); INSERT INTO anchor VALUES(7);")
        populate(db.execute, scenario, main=True)
    definitions = cases(scenario)
    for index, (case, sql) in enumerate(definitions):
        child = folder / "skills" / f"probe-{index}"
        child.mkdir(parents=True)
        (child / "skill_def.md").write_text(
            f"---\nname: probe-{index}\ntype: query\nsource: query.sql\nrisk: low\n"
            "description: Disposable attached-name readiness assessment\nparams: {}\n---\n")
        (child / "query.sql").write_text(sql)
    save_toml(folder / "server.toml", {"schema_version": 1,
        "files": {"connections": "connections.toml", "skills": "skills.toml"},
        "server": {"default_connection": "scoped"}})
    grants = [{"schema": "main", "name": "anchor"}]
    grants.extend({"schema": schema, "name": name}
                  for schema in SCENARIOS[scenario]["grants"] for name in NAMES)
    save_toml(folder / "connections.toml", {"schema_version": 1, "connections": {"scoped": {
        "type": "sqlite", "sqlite": {"path": str(database)},
        "read": {"mode": "allowlist", "relations": grants}}}})
    save_toml(folder / "skills.toml", {"schema_version": 1, "skills": {
        "enabled": True, "directory": str(folder / "skills"),
        "readiness": {"check_schema": True}, "audit": {"path": str(folder / "audit.jsonl")}}})
    return database, definitions

async def main(output, scope):
    assert not output.exists() and not output.with_suffix(output.suffix + ".gz").exists()
    before = resources()
    records, observations, truth, errors = [], [], [], []
    folders = []
    with tempfile.TemporaryDirectory(prefix="v382-attached-json-") as temporary:
        base = Path(temporary)
        for scenario in SCENARIOS:
            folder = base / scenario
            folder.mkdir()
            database, definitions = make_fixture(folder, scenario)
            folders.append(database)
            initial = sha(database)
            with sqlite3.connect(database) as db:
                populate(db.execute, scenario)
                for case, sql in definitions:
                    truth.append({"scenario": scenario, "case": case, "sql": sql,
                                  "columns": [c[0] for c in db.execute(sql).description],
                                  "rows": [list(row) for row in db.execute(sql).fetchall()]})
            transports = ("inprocess", "stdio") if scenario == "aux_only" else ("inprocess",)
            for transport in transports:
                for mode in ("auto", "legacy"):
                    server = None
                    if transport == "inprocess":
                        server = initialize(create_server(load_config(folder / "server.toml")), scenario)
                        target = server
                    else:
                        target = StdioTransport(command=sys.executable,
                            args=[str(Path(__file__).resolve()), "--child", str(folder / "server.toml"), "--scenario", scenario],
                            cwd=str(ROOT))
                    try:
                        async with Client(target, mode=mode, timeout=10, init_timeout=10) as client:
                            async def call(case, tool, arguments):
                                result = await client.call_tool(tool, arguments, raise_on_error=False)
                                payload = result.structured_content
                                records.append({"scenario": scenario, "transport": transport, "mode": mode,
                                    "case": case, "tool": tool, "arguments": arguments,
                                    "isError": result.is_error, "structured": payload,
                                    "content": [c.model_dump(mode="json", exclude_none=True) for c in result.content]})
                                return payload
                            await call("discovery-all", "list_skills", {"available_only": False, "detail_level": "full"})
                            await call("discovery-default", "list_skills", {})
                            for index, (case, sql) in enumerate(definitions):
                                raw = await call(case, "query", {"connection_id": "scoped", "sql": sql})
                                detail = await call(case, "get_skill_detail", {"connection_id": "scoped", "skill_name": f"probe-{index}"})
                                executed = await call(case, "execute_query_skill", {"connection_id": "scoped", "skill_name": f"probe-{index}", "params": {}})
                                state = detail["skill"]
                                observations.append({"scenario": scenario, "transport": transport, "mode": mode,
                                    "case": case, "raw_success": raw.get("success"), "raw_error_code": raw.get("error_code"),
                                    "raw_data": raw.get("data"), "inferred_tables": state["inferred_tables"],
                                    "schema_ready": state["schema_ready"], "executable": state["executable"],
                                    "conditional_dependencies": state.get("conditional_dependencies"),
                                    "unverified_tables": state["unverified_tables"],
                                    "skill_success": executed.get("success") if executed else None,
                                    "skill_error_code": executed.get("error_code") if executed else None})
                            if scenario == "aux_only":
                                await call("restricted-function", "query", {"sql": "SELECT SLEEP(0)", "connection_id": "scoped"})
                                await call("shadow", "query", {"sql": "SELECT * FROM aux.json_each_idx", "connection_id": "scoped"})
                    except Exception as error:
                        errors.append({"scenario": scenario, "transport": transport, "mode": mode,
                                       "type": type(error).__name__, "message": str(error)})
                    finally:
                        if server is not None:
                            server.gateway_runtime.close()
                    output.parent.mkdir(parents=True, exist_ok=True)
                    output.with_name(output.stem + "-partial.json").write_text(
                        json.dumps({"calls": records, "observations": observations, "errors": errors},
                                   ensure_ascii=False, indent=2) + "\n")
            assert sha(database) == initial, ("fixture changed", scenario)
    final = resources()
    assert final == before, "runtime/private configuration changed"
    import sql_safety_executor
    result = {"scope": scope + " disposable Client/stdio verification; no resident/model acceptance or configured database access",
        "package": str(Path(sql_safety_executor.__file__).resolve().parent),
        "sqlite_version": sqlite3.sqlite_version, "resources_before": before,
        "resources_unchanged": final == before, "fixtures_cleaned": not Path(temporary).exists(),
        "configured_database_access": False, "truth": truth, "calls": records, "observations": observations,
        "errors": errors,
        "summary": {"calls": len(records), "groups": dict(Counter(r["scenario"] + ":" + r["transport"] + ":" + r["mode"] for r in records)),
                    "tool_errors": sum(r["isError"] for r in records), "observations": len(observations)}}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(result["summary"]))
    print(json.dumps({"unchanged_resources": len(before), "fixtures_cleaned": result["fixtures_cleaned"]}))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    parser.add_argument("--child", type=Path)
    parser.add_argument("--scenario", choices=list(SCENARIOS))
    parser.add_argument("--scope", choices=["source", "installed"], default="source")
    args = parser.parse_args()
    if args.child:
        initialize(create_server(load_config(args.child)), args.scenario).run(transport="stdio", show_banner=False)
    else:
        assert args.output
        asyncio.run(main(args.output, args.scope))

