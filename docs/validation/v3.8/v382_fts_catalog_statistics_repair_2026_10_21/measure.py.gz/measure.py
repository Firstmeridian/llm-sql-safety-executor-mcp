"""Serial warm adapter A/B/A; baseline is immediately before DRR137/138/139."""
import argparse,hashlib,json,statistics,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert not a.output.exists() and not a.output.with_suffix(a.output.suffix+'.gz').exists();sys.path.insert(0,str(a.source.resolve()))
from sql_safety_executor.database.models import DatabaseConfig,ConnectionPolicy
from sql_safety_executor.database.sqlite import SQLiteAdapter
report={'scope':'Serial warm SQLite direct adapter calls, no collisions. Baseline includes prior pending changes, not HEAD. Partial-stat output differs; no speed claim for changed outcomes. Trusted-warm external-default baseline masks its cold defect. Not tool/model/token or cold-boot measurements.','source':str(a.source),'scenarios':{}}
for case in ['fts_internal','fts_external_id','fts_external_default_warm','stats_none','stats_table','stats_full1','stats_full64','stats_without_rowid','stats_partial']:
 policy=ConnectionPolicy(read_mode='all',allowed_tables=frozenset({'*'}),default_schema='main')
 adapter=SQLiteAdapter(config=DatabaseConfig('bench','sqlite',30,10,policy,sqlite_database_path=':memory:'));adapter.connect()
 try:
  with adapter._engine.begin() as db:
   if case.startswith('fts'):
    db.exec_driver_sql('CREATE TABLE docs(id INTEGER PRIMARY KEY,body)');db.exec_driver_sql("INSERT INTO docs VALUES(1,'hello')")
    option='' if case=='fts_internal' else ",content='docs'"+("" if case.endswith('_warm') else ",content_rowid='id'")
    db.exec_driver_sql('CREATE VIRTUAL TABLE search_docs USING fts5(body'+option+')');db.exec_driver_sql("INSERT INTO search_docs(rowid,body) VALUES(1,'hello')")
    sql="SELECT body FROM search_docs('hello')"
    if case.endswith('_warm'):db.exec_driver_sql(sql).fetchall()
    run=lambda:adapter.execute_read(sql,policy=policy)
   else:
    db.exec_driver_sql('CREATE TABLE orders(n INTEGER PRIMARY KEY)'+(' WITHOUT ROWID' if case=='stats_without_rowid' else ''))
    db.exec_driver_sql('INSERT INTO orders VALUES(?)',[(i,) for i in range(1500)])
    for i in range(64 if case=='stats_full64' else 1 if case=='stats_full1' else 0):db.exec_driver_sql(f'CREATE INDEX ix{i} ON orders(n)')
    if case=='stats_partial':db.exec_driver_sql('CREATE INDEX ix_part ON orders(n) WHERE n<1')
    if case!='stats_none':db.exec_driver_sql('ANALYZE orders')
    run=lambda:adapter.get_row_estimate('orders')
   raw=db.connection.dbapi_connection
  for _ in range(10):result=run()
  samples=[]
  for _ in range(7):
   start=time.perf_counter()
   for _ in range(25):result=run()
   samples.append((time.perf_counter()-start)*1000/25)
  trace=[];raw.set_trace_callback(trace.append)
  try:run()
  finally:raw.set_trace_callback(None)
  if case.startswith('fts'):result=[list(r) for r in result]
  report['scenarios'][case]={'median_ms':statistics.median(samples),'samples_ms':samples,'result':result,'trace_events':len(trace),'pragma_events':sum(s.lstrip().upper().startswith('PRAGMA ') for s in trace),'trace':trace}
 finally:adapter.close()
a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:{'ms':v['median_ms'],'result':v['result'],'pragma_events':v['pragma_events']} for k,v in report['scenarios'].items()}))
