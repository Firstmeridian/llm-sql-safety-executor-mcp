"""Validate FTS catalog/statistics/rowid repairs on disposable databases."""
from __future__ import annotations
import argparse
import asyncio
from collections import Counter
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import tomllib

parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path)
parser.add_argument('--output', type=Path)
parser.add_argument('--scope', default='source')
parser.add_argument('--quick', action='store_true')
parser.add_argument('--baseline', action='store_true')
parser.add_argument('--child', type=Path)
parser.add_argument('--scenario')
args = parser.parse_args()
if args.source:
    sys.path.insert(0, str(args.source.resolve()))
from fastmcp import Client
from fastmcp.client.transports import StdioTransport
from sql_safety_executor import create_server, load_config
import sql_safety_executor
from probe import make_fixture, q, resources, save_toml, sha, ROOT

FTS = ['fts-control', *('fts-'+s+'-'+kind for s in ('main', 'temp', 'aux') for kind in ('table', 'view')), *('rowid-'+name for name in ('default','rowid','oid','_rowid_','id'))]
STATS = ['stats-partial', 'stats-full', 'stats-full-then-partial', 'stats-partial-then-full',
         'stats-without-rowid', 'stats-index-only', 'stats-no-analyze', 'stats-large-no-analyze', 'stats-empty', 'stats-stale']

def shadow(execute, schema, kind):
    target = q(schema)+'.pragma_table_list'
    execute('CREATE TABLE '+target+'(name)' if kind == 'table' else 'CREATE VIEW '+target+' AS SELECT 7 AS name')

def initialize(server, scenario):
    if scenario.startswith('fts-') and scenario != 'fts-control':
        _, schema, kind = scenario.split('-')
        if schema != 'main':
            adapter = server.gateway_runtime.registry.get_adapter('scoped'); adapter.connect()
            with adapter._engine.begin() as db:
                if schema == 'aux':
                    db.exec_driver_sql("ATTACH ':memory:' AS aux")
                shadow(db.exec_driver_sql, schema, kind)
    return server

def fixture(folder, scenario):
    database, _ = make_fixture(folder, 'builtin')
    fts = scenario.startswith(('fts-', 'rowid-'))
    with sqlite3.connect(database) as db:
        if fts:
            if scenario.startswith('rowid-'):
                rowid=scenario.removeprefix('rowid-');option='' if rowid=='default' else ",content_rowid='"+rowid+"'"
                db.executescript("CREATE TABLE docs(id INTEGER PRIMARY KEY,body);INSERT INTO docs VALUES(1,'hello');"+
                    "CREATE VIRTUAL TABLE search_docs USING fts5(body,content='docs'"+option+");"+
                    "INSERT INTO search_docs(rowid,body) VALUES(1,'hello');")
            else:db.executescript("CREATE VIRTUAL TABLE search_docs USING fts5(body); INSERT INTO search_docs VALUES('hello');")
            if scenario.startswith('fts-main-'):
                shadow(db.execute, 'main', scenario.split('-')[2])
        else:
            db.execute('CREATE TABLE orders(n INTEGER PRIMARY KEY)'+(' WITHOUT ROWID' if scenario == 'stats-without-rowid' else ''))
            count = 0 if scenario == 'stats-empty' else 15000 if scenario == 'stats-large-no-analyze' else 100 if scenario == 'stats-stale' else 1500
            db.executemany('INSERT INTO orders VALUES(?)', [(n,) for n in range(count)])
            partial = 'CREATE INDEX partial_orders ON orders(n) WHERE n < 1'
            full = 'CREATE INDEX full_orders ON orders(n)'
            if scenario in {'stats-full', 'stats-full-then-partial'}:
                db.execute(full)
            if scenario not in {'stats-full', 'stats-no-analyze', 'stats-large-no-analyze', 'stats-stale'}:
                db.execute(partial)
            if scenario == 'stats-partial-then-full':
                db.execute(full)
            if 'no-analyze' not in scenario:
                db.execute('ANALYZE partial_orders' if scenario == 'stats-index-only' else 'ANALYZE orders')
            if scenario == 'stats-stale':
                db.executemany('INSERT INTO orders VALUES(?)', [(n,) for n in range(100, 1500)])
    connection = tomllib.loads((folder/'connections.toml').read_text())
    connection['connections']['scoped']['read']['relations'] = [
        {'schema':'main', 'name':'anchor'}, {'schema':'main', 'name':'search_docs' if fts else 'orders'}]
    save_toml(folder/'connections.toml', connection)
    config = tomllib.loads((folder/'server.toml').read_text());config['tools']={'table_summary':True}
    save_toml(folder/'server.toml', config)
    sql = "SELECT body FROM search_docs('hello')" if fts else 'SELECT COUNT(*) AS n FROM main.orders'
    (folder/'skills/probe-0/query.sql').write_text(sql)
    with sqlite3.connect(database) as db:
        if scenario.startswith('fts-') and scenario not in {'fts-control', 'fts-main-table', 'fts-main-view'}:
            _, schema, kind = scenario.split('-')
            if schema == 'aux':db.execute("ATTACH ':memory:' AS aux")
            shadow(db.execute,schema,kind)
        truth = {'scenario':scenario,'rows':[list(r) for r in db.execute(sql)]}
        if fts:
            truth['fixed_table_list']=[list(r) for r in db.execute('PRAGMA main.table_list') if r[1].startswith('search_docs')]
        else:
            exists=db.execute("SELECT 1 FROM sqlite_master WHERE name='sqlite_stat1'").fetchone()
            truth['statistics']=[list(r) for r in db.execute("SELECT tbl,idx,stat FROM main.sqlite_stat1 WHERE tbl='orders'")] if exists else []
            truth['index_list']=[list(r) for r in db.execute("PRAGMA main.index_list('orders')")]
    return database, truth

def calls(scenario):
    fts=scenario.startswith(('fts-', 'rowid-'));table='search_docs' if fts else 'orders'
    common=[('list','list_tables',{}),('describe','describe_table',{'table_name':table}),
        ('compact','get_full_schema',{'detail_level':'compact'}),('full','get_full_schema',{'detail_level':'full'}),
        ('exact','get_table_summary',{'table_name':table,'exact_count':True})]
    if fts:
        return [('call','query',{'sql':"SELECT body FROM search_docs('hello')"}),
                ('match','query',{'sql':"SELECT body FROM search_docs WHERE search_docs MATCH 'hello'"}),
                ('detail','get_skill_detail',{'skill_name':'probe-0'}),
                ('skill','execute_query_skill',{'skill_name':'probe-0','params':{}}),*common]
    return [('count','query',{'sql':'SELECT COUNT(*) AS n FROM main.orders'}),*common,
            ('estimate','get_table_summary',{'table_name':table})]

async def main():
    assert args.output and not args.output.exists() and not args.output.with_suffix(args.output.suffix+'.gz').exists()
    before=resources();records=[];truth=[];errors=[]
    scenarios=(['stats-partial'] if args.baseline else ['fts-control','fts-main-table','stats-partial','stats-full'] if args.quick else FTS+STATS)
    with tempfile.TemporaryDirectory(prefix='v382-catalog-stats-') as temporary:
        for scenario in scenarios:
            folder=Path(temporary)/scenario;folder.mkdir();database,oracle=fixture(folder,scenario)
            truth.append(oracle);digest=sha(database)
            transports=['inprocess']
            if not args.baseline and scenario in {'fts-main-table','fts-temp-view','fts-aux-table','stats-partial','stats-without-rowid','stats-index-only','rowid-default','rowid-oid'}:
                transports.append('stdio')
            for transport in transports:
                for mode in ['auto','legacy']:
                    server=None
                    try:
                        if transport=='inprocess':
                            server=initialize(create_server(load_config(folder/'server.toml')),scenario);target=server
                        else:
                            target=StdioTransport(command=sys.executable,args=[str(Path(__file__).resolve()),'--child',str(folder/'server.toml'),'--scenario',scenario],cwd=str(ROOT))
                        async with Client(target,mode=mode,timeout=20,init_timeout=20) as client:
                            for key,tool,arguments in calls(scenario):
                                arguments={'connection_id':'scoped',**arguments}
                                result=await client.call_tool(tool,arguments,raise_on_error=False)
                                records.append({'scenario':scenario,'transport':transport,'mode':mode,'id':key,'tool':tool,'arguments':arguments,'isError':result.is_error,'structured':result.structured_content,'content':[c.model_dump(mode='json',exclude_none=True) for c in result.content]})
                    except Exception as error:
                        errors.append({'scenario':scenario,'transport':transport,'mode':mode,'type':type(error).__name__,'message':str(error)})
                    finally:
                        if server is not None:server.gateway_runtime.close()
            assert sha(database)==digest,scenario
    assert before==resources()
    result={'scope':args.scope+' repaired application results; disposable fixtures only, no configured DB access or resident/model acceptance',
        'package':str(Path(sql_safety_executor.__file__).resolve().parent),'calls':records,'truth':truth,'errors':errors,
        'resources_unchanged':True,'fixtures_cleaned':not Path(temporary).exists(),
        'summary':{'calls':len(records),'scenarios':len(scenarios),'groups':dict(Counter(r['transport']+':'+r['mode'] for r in records)), 'tool_errors':sum(r['isError'] for r in records)}}
    args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['summary']));print(json.dumps(errors))

if __name__=='__main__':
    if args.child:
        initialize(create_server(load_config(args.child)),args.scenario).run(transport='stdio',show_banner=False)
    else:
        asyncio.run(main())
