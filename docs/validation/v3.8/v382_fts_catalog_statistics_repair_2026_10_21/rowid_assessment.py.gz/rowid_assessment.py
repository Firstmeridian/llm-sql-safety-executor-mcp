import argparse,json,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--cold',action='store_true');a=p.parse_args();assert not a.output.exists() and not a.output.with_suffix(a.output.suffix+'.gz').exists();sys.path.insert(0,str(a.source.resolve()))
from sql_safety_executor.database.sqlite import SQLiteAdapter
from sql_safety_executor.database.models import DatabaseConfig,ConnectionPolicy
from sql_safety_executor.database.errors import DatabaseQueryError
records=[]
for declaration in ['id INTEGER PRIMARY KEY','id INTEGER PRIMARY KEY DESC','id TEXT PRIMARY KEY']:
 for option in ['',",content_rowid='rowid'",",content_rowid='_rowid_'",",content_rowid='oid'",",content_rowid='id'"]:
  policy=ConnectionPolicy(allowed_tables=frozenset({'docs_fts'}),default_schema='main')
  adapter=SQLiteAdapter(config=DatabaseConfig('probe','sqlite',30,10,policy,sqlite_database_path=':memory:'));adapter.connect()
  try:
   with adapter._engine.begin() as db:
    db.exec_driver_sql('CREATE TABLE docs('+declaration+',body TEXT)');db.exec_driver_sql("INSERT INTO docs(rowid,id,body) VALUES(1,1,'hello')")
    db.exec_driver_sql("CREATE VIRTUAL TABLE docs_fts USING fts5(body,content='docs'"+option+")")
    db.exec_driver_sql("INSERT INTO docs_fts(rowid,body) VALUES(1,'hello')")
    sql="SELECT body FROM docs_fts('hello')"
    native=None if a.cold else [list(r) for r in db.exec_driver_sql(sql).fetchall()]
   with adapter._engine.connect() as db:changes=db.connection.dbapi_connection.total_changes
   try:observed={'success':True,'rows':[list(r) for r in adapter.execute_read(sql,policy=policy)]}
   except DatabaseQueryError as error:observed={'success':False,'error_code':error.error_code}
   if native is None:native=[list(r) for r in adapter.execute(sql)]
   records.append({'declaration':declaration,'option':option,'native':native,'controlled':observed})
   with adapter._engine.connect() as db:assert db.connection.dbapi_connection.total_changes==changes
  finally:adapter.close()
a.output.write_text(json.dumps({'source':str(a.source),'scope':'Disposable adjacent external-content rowid alias assessment, not a repair','cases':records},indent=2)+'\n')
print(json.dumps({'cases':len(records),'controlled_successes':sum(r['controlled']['success'] for r in records)}))
