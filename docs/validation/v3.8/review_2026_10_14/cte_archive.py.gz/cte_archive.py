"""Archive final current-source checks; leave October 13 records untouched."""
import gzip
import hashlib
import importlib.metadata
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[3]
E = ROOT / "docs/validation/v3.8/review_2026_10_14"
sha = lambda data: hashlib.sha256(data).hexdigest()
logs = [
    "v381-cte-stage1", "v381-cte-focused", "v381-cte-focused-v2",
    "v381-cte-full-unit", "v381-cte-full-unit-v2", "v381-cte-full-unit-v3", "v381-cte-full-unit-final",
    "v381-cte-pyright", "v381-cte-pyright-final", "v381-cte-prompt-contract-final",
    "v381-cte-space-tests", "v381-cte-mysql-optin", "v381-cte-probe-live", "v381-cte-live-client",
    "v381-cte-installed", "v381-cte-installed-v2", "v381-cte-installed-v3", "v381-cte-installed-v4", "v381-cte-installed-final",
]
for name in logs:
    path = Path("/tmp") / (name + ".log")
    if path.exists():
        (E / (name + ".log.gz")).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for name in ("cte_archive.py", "cte_probe_live.py", "cte_mysql_optin.py", "cte_live_client.py", "cte_installed_check.py"):
    (E / (name + ".gz")).write_bytes(gzip.compress((Path(__file__).parent / name).read_bytes(), mtime=0))

full = Path("/tmp/v381-cte-full-unit-final.log").read_text()
assert "1042 passed, 4 skipped, 12 warnings" in full
assert "0 errors, 0 warnings" in Path("/tmp/v381-cte-pyright-final.log").read_text()
assert "Installed prompt resources and routing guidance valid." in Path("/tmp/v381-cte-prompt-contract-final.log").read_text()
source = {p.relative_to(ROOT).as_posix(): sha(p.read_bytes())
          for p in sorted((ROOT / "src/sql_safety_executor").rglob("*"))
          if p.is_file() and p.suffix in {".py", ".md"}}
mysql = json.loads((E / "mysql_optin.json").read_text())
assert mysql["pytest_exit_code"] == 0 and all(r["outcome"] == "passed" for r in mysql["tests"])
assert len(mysql["cleanup"]) == 1 and mysql["cleanup"][0]["remaining"] == 0
live = json.loads((E / "live_client.json").read_text())
assert live["tool_calls"] == 34 and len(live["probe_events"]) == 2
installed = json.loads((E / "installed_wheel.json").read_text())
assert installed["non_editable_pip_target_install"] and installed["import_outside_repository"]
assert {r["protocol"] for r in installed["calls"]} == {"2025-11-25", "2026-07-28"}
automation = {"version": "3.8.1", "baseline_commit": "af3420f58d426b4f657b1214949dc48544afde56",
    "full_suite": {"passed": 1042, "skipped": 4, "warnings": 12, "seconds": 78.29, "mysql_optin": False},
    "separate_mysql": {"passed": 4, "skipped": 0, "seconds": 0.89, "fixture_remaining": 0},
    "pyright": {"errors": 0, "warnings": 0}, "prompt_contract": "passed",
    "source_sha256": source,
    "dependency_versions": {n: importlib.metadata.version(n) for n in ("fastmcp", "mcp", "pydantic", "sqlparse", "SQLAlchemy", "PyMySQL", "PyYAML")},
    "installed_current_source": True, "new_regression_cases": 40,
    "resident_host": "Old dependency projection confirmed; awaiting manual restart and current-source acceptance",
    "model_trials": "None in October 14; October 13 usage is a separate source snapshot"}
(E / "automation.json").write_text(json.dumps(automation, ensure_ascii=False, indent=2) + "\n")

manifest = {"version": "3.8.1", "source_reference": "automation.json#source_sha256",
    "recording_profile": "Decoded application CallToolResult and public inputs/timing; actual Client/stdio execution, not complete transport capture",
    "metadata_snapshots": live["metadata"],
    "omitted": ["Complete JSON-RPC frame bytes/message IDs/notifications", "Original null-vs-omitted presence after SDK normalization", "Internal model reasoning and credentials", "Model inputs/usage: no LLM trial in this batch", "Early live probe Row-serialization failure appeared in tool output; summarized here rather than claiming a preserved disk log"],
    "history": "October 13 JSON remains unchanged; this is a separate finalized source snapshot",
    "approvals": {"full_suite_with_live_mysql": "Rejected for possible wider database side effects; not executed",
                  "safer_alternative": "Full suite with opt-in disabled, separate four exact approved MySQL cases",
                  "timeouts": "Deadline failures retried at most once per failed request; not classified as unsafe actions"},
    "limits": "Current Oracle MySQL setting 1 tested; no independent settings 0/2 or MariaDB server. ASCII capability only, conservative fallback; no LLM cost/performance guarantee.",
    "artifacts": []}
for path in sorted(E.iterdir()):
    if path.name in {"manifest.json", "document_checks.json"}:
        continue
    data = path.read_bytes()
    row = {"path": path.name, "bytes": len(data), "sha256": sha(data)}
    if path.suffix == ".gz":
        raw = gzip.decompress(data)
        row.update({"uncompressed_bytes": len(raw), "uncompressed_sha256": sha(raw)})
        if ".json.gz" in path.name:
            json.loads(raw)
    elif path.suffix == ".json":
        json.loads(data)
    manifest["artifacts"].append(row)
(E / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")

doc = ROOT / "docs/validation/V3_8_1_FOLLOWUP_2026_10_13_ZH.md"
s = doc.read_text().replace("最终结果待当前复验结束；真实 MySQL opt-in 显式关闭", "**1042 passed、4 skipped、12 warnings，78.29 秒**；真实 MySQL opt-in 显式关闭，旧协议 logging warnings 保留")
s = s.replace("当前复验结束后更新", "**Pyright 0 errors、0 warnings**；提示契约通过")
s = s.replace("当前源码 sdist/wheel 构建及非 editable pip --target 安装复验中；隔离 SQLite 两协议真实 stdio", "[当前源码 sdist/wheel 与非 editable pip --target 安装通过](v3.8/review_2026_10_14/installed_wheel.json)；导入位于仓库外，隔离 SQLite 两协议真实 stdio 共六次工具调用")
doc.write_text(s)
for name,marker,info in [
    ("README.md", "**October 14 CTE repair:**", "Validation: **1042 passed, 4 skipped**, plus four separately opted-in MySQL tests; Pyright and both-protocol installed-wheel checks passed. "),
    ("README_ZH.md", "**10 月 14 日 CTE 修复：**", "验收：**1042 passed、4 skipped**，另行四项 MySQL 实库通过；Pyright 和两协议安装验证通过。 ")]:
    p=ROOT / name; lines=p.read_text().splitlines(keepends=True)
    i=next(i for i,line in enumerate(lines) if line.startswith(marker))
    line=lines[i].rstrip()
    if info.strip() not in line:
        line += " " + info.strip()
    lines[i]=line+"\n"
    p.write_text("".join(lines))

changed = subprocess.check_output(["git", "diff", "--name-only"], cwd=ROOT, text=True).splitlines()
changed.append(doc.relative_to(ROOT).as_posix())
links = 0
for name in changed:
    if not name.endswith(".md"):
        continue
    p=ROOT / name; text=re.sub(r"```.*?```", "", p.read_text(), flags=re.S)
    for match in re.finditer(r"!?\[[^\]]*\]\(([^\s)]+)(?:\s+[^)]*)?\)", text):
        uri=unquote(match.group(1).strip("<>").split("#", 1)[0])
        if not uri or re.match(r"[a-zA-Z][a-zA-Z0-9+.-]*:", uri):
            continue
        assert (p.parent / uri).exists(), (name, uri)
        links += 1
registers=[]
for name in ("docs/security/DESIGN_RISK_REGISTER.md", "docs/security/DESIGN_RISK_REGISTER_ZH.md"):
    text=(ROOT / name).read_text();rows=list(re.finditer(r"^\| (DRR-2026-\d{3}) \|.*$", text, re.M))
    ids=[int(m.group(1).rsplit("-",1)[-1]) for m in rows]
    assert len(ids)==84 and sorted(ids)==list(range(1,85))
    latest=[m for m in rows if int(m.group(1).rsplit("-",1)[-1])>=78]
    assert all(text[a.end():b.start()] == "\n" for a,b in zip(latest,latest[1:]))
    registers.append(ids)
assert registers[0]==registers[1]
assert re.search(r'^version = "3\.8\.1"', (ROOT / "pyproject.toml").read_text(), re.M)
assert re.search(r'__version__\s*=\s*"3\.8\.1"', (ROOT / "src/sql_safety_executor/__init__.py").read_text())
assert re.search(r'name = "llm-sql-safety-executor-mcp"\nversion = "3\.8\.1"', (ROOT / "uv.lock").read_text())
assert all(sha((ROOT / k).read_bytes()) == v for k,v in source.items())
subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
checks={"relative_file_links": links, "bilingual_drr_ids": 84, "latest_rows_contiguous": True,
        "version": "3.8.1", "source_sha256_matches_final_checks": True, "diff_check": "passed",
        "scope": "Relative targets only; no remote URL or heading-anchor validation"}
(E / "document_checks.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2)+"\n")
print(json.dumps(checks, ensure_ascii=False))
