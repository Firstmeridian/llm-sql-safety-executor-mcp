"""Finalize observed resident acceptance, retaining pre-restart evidence."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[3]
E = ROOT / "docs/validation/v3.8/review_2026_10_14"

def replace(path, before, after):
    p = ROOT / path
    text = p.read_text()
    if before not in text:
        assert after in text, (path, before)
        return
    p.write_text(text.replace(before, after))

replace("docs/validation/V3_8_1_FOLLOWUP_2026_10_13_ZH.md",
    "**该缺陷仍未修复，优先于新的 enforcement／AST 改造。**",
    "**13 日记录时该缺陷尚未修复；14 日已实施修复，见下方追加验收。**")
replace("docs/validation/V3_8_1_FOLLOWUP_2026_10_13_ZH.md",
    "| 原生 Host | [重启前检查](v3.8/review_2026_10_14/native_before_restart.json)两项 Query Skill 均缺少新依赖来源字段，证明当前服务仍是旧快照；新源码验收待维护者重启 |",
    "| 原生 Host | 保留[重启前旧快照](v3.8/review_2026_10_14/native_before_restart.json)；继续工作时已观察到新字段，[最新原生只读核验 10 次通过](v3.8/review_2026_10_14/native_after_restart.json)：两目标依赖来源、混合大小写 CTE、Skill／等价 SQL 一致、SQLite 限定实体拒绝。MySQL 原生配置为 all，白名单强制与 CTE Skill 依赖修复由前述隔离 Client 矩阵验收；未替用户重启、未新增模型试验 |")
replace("README.md",
    "Current-source verification and pending resident restart are distinguished from",
    "Current-source verification and completed resident checks are distinguished from")
replace("README.md",
    "Supplemental targeted checks passed all four opt-in MySQL tests and verified removal of the isolated race table. An unresolved SQLite F/f CTE false dependency was reproduced in Skill discovery/execution under both protocols, including all-mode readiness; fixing this boundary remains recommended before closing the review.",
    "October 13 supplemental checks passed all four opt-in MySQL tests and verified removal of the isolated race table. They reproduced a SQLite F/f CTE false dependency in Skill discovery/execution, including all-mode readiness. The October 14 repair closes that reproduced boundary; ten latest native Host calls passed.")
replace("README_ZH.md",
    "新源码验收及原生重启状态与 13 日模型快照分开记录",
    "新源码验收及已完成的原生核验与 13 日模型快照分开记录")
replace("README_ZH.md",
    "追加定点验证：四项 opt-in MySQL 实库测试全部通过，独立竞争测试表已删除并核验无残留。两协议确认 SQLite F/f CTE 在 Skill 中产生假依赖，all 模式也会 readiness 误报缺表；该边界尚未修复，建议修复后再关闭复评。",
    "13 日追加定点验证：四项 opt-in MySQL 实库测试全部通过，独立竞争测试表已删除并核验无残留。两协议确认 SQLite F/f CTE 在 Skill 中产生假依赖，all 模式也会 readiness 误报缺表；14 日已修复该复现边界，最新原生 Host 十次核验通过。")
replace("REFACTORING_LOG.md",
    "Supplemental verification found an unresolved SQLite CTE case mismatch that creates false Skill dependencies.",
    "October 13 supplemental verification found a SQLite CTE case mismatch creating false Skill dependencies; the October 14 implementation below closes that reproduced boundary.")
replace("REFACTORING_LOG.md",
    "Exact CTE matching and a case hint are retained; other MySQL case settings and MariaDB remain unverified.",
    "At the October 13 stage, exact CTE matching and a case hint were retained; October 14 replaces this fallback for measured ASCII rules. Other MySQL case settings and MariaDB remain unverified.")
replace("REFACTORING_LOG.md",
    "Recommend fixing it first. Isolated authorizer",
    "This was then prioritized and fixed on October 14. Isolated authorizer")
replace("REFACTORING_LOG_ZH.md",
    "追加核验发现 SQLite CTE 大小写变化仍造成 Skill 假依赖，尚未修复。",
    "13 日追加核验发现 SQLite CTE 大小写变化造成 Skill 假依赖；14 日已修复该复现边界，见下方记录。")
replace("REFACTORING_LOG_ZH.md",
    "优先建议修复；authorizer",
    "当时优先建议修复，14 日已实施；authorizer")
replace("docs/security/V3_8_SECURITY.md",
    "Supplemental verification reproduced an unresolved false refusal:",
    "October 13 supplemental verification reproduced a then-unresolved false refusal (repaired October 14 below):")
replace("docs/releases/RELEASE_NOTES_v3_8.md",
    "34 actual Client calls and pending resident-Host restart from October 13 model evidence.",
    "34 actual Client calls and ten completed resident-Host checks from October 13 model evidence.")

for name in ("docs/security/DESIGN_RISK_REGISTER.md", "docs/security/DESIGN_RISK_REGISTER_ZH.md"):
    p = ROOT / name
    lines = p.read_text().splitlines()
    for i, line in enumerate(lines):
        if any(line.startswith("| " + r + " |") for r in ("DRR-2026-081", "DRR-2026-083", "DRR-2026-084")):
            line = line.replace("Implemented; new Host acceptance awaits restart", "Implemented; current Host checks passed")
            line = line.replace("已实现；新 Host 验收待重启", "已实现；当前 Host 核验通过")
            line = line.replace("pending resident restart.", "completed resident checks (ten read-only calls).")
            line = line.replace("reproduce an unresolved SQLite", "reproduced a then-unresolved SQLite")
            line = line.replace("；未修。", "；13 日当时未修。")
            line = line.replace("最新源码检查与原生重启状态见验收追加章节。", "最新源码检查与十次原生只读核验见验收追加章节。")
            lines[i] = line
    p.write_text("\n".join(lines) + "\n")

for path, note in (
    ("REFACTORING_LOG.md", "- October 14 final acceptance: **1042 passed, 4 skipped**, four separate live MySQL tests passed, Pyright/prompt contracts and both-protocol installed-wheel checks passed. Current resident metadata and ten read-only native calls passed; retain the earlier old-Host observation. Resident MySQL uses all mode and existing Query Skills lack CTEs, so allowlist/CTE-Skill claims rely on the isolated live Client matrix. No new model trial or assistant restart."),
    ("REFACTORING_LOG_ZH.md", "- 14 日最终验收：**1042 passed、4 skipped**，四项独立 MySQL 实库、Pyright／提示契约和两协议安装验证通过；当前原生元数据及十次只读调用通过，旧 Host 观察继续保留。原生 MySQL 为 all，既有 Skill 不含 CTE，白名单／CTE Skill 结论以隔离真实 Client 矩阵为据。未新增模型试验，未替维护者重启。"),
):
    p = ROOT / path
    s = p.read_text()
    if note not in s:
        pos = s.index("\n## ", s.index("\n## ") + 1)
        s = s[:pos].rstrip() + "\n" + note + "\n" + s[pos:]
        p.write_text(s)

host = json.loads((E / "native_after_restart.json").read_text())
assert host["tool_calls"] == 10 and all(v == "passed" for v in host["checks"].values())
auto = json.loads((E / "automation.json").read_text())
for name, expected in auto["source_sha256"].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
auto["resident_host"] = "Current origin fields observed; ten native read-only calls passed, preserving earlier old-Host observation"
auto["native_host_evidence"] = "native_after_restart.json"
(E / "automation.json").write_text(json.dumps(auto, ensure_ascii=False, indent=2) + "\n")
(E / (Path(__file__).name + ".gz")).write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))

# Check relative file targets across changed/untracked documentation.
status = subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT, text=True)
documents = [ROOT / line[3:] for line in status.splitlines() if line[3:].endswith(".md")]
count = 0
for p in documents:
    for raw in re.findall(r"\]\(([^)\n]+)\)", p.read_text()):
        raw = raw.strip().strip("<>")
        if "://" in raw or raw.startswith(("mailto:", "#", "data:")):
            continue
        target = raw.split("#", 1)[0]
        if not target:
            continue
        assert (p.parent / unquote(target)).exists(), (p, target)
        count += 1
drr_ids = []
for name in ("DESIGN_RISK_REGISTER.md", "DESIGN_RISK_REGISTER_ZH.md"):
    text = (ROOT / "docs/security" / name).read_text()
    ids = re.findall(r"^\| DRR-2026-(\d{3}) \|", text, re.M)
    assert sorted(ids) == [f"{n:03}" for n in range(1, 85)], name
    drr_ids.append(sorted(ids))
assert drr_ids[0] == drr_ids[1]
assert 'version = "3.8.1"' in (ROOT / "pyproject.toml").read_text()
subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
checks = {"relative_file_links": count, "bilingual_drr_ids": 84,
    "latest_rows_contiguous": True, "version": "3.8.1",
    "source_sha256_matches_final_checks": True, "diff_check": "passed",
    "native_host": "ten checks passed",
    "scope": "Relative targets only; no remote URL or heading-anchor validation"}
(E / "document_checks.json").write_text(json.dumps(checks, indent=2) + "\n")

manifest = json.loads((E / "manifest.json").read_text())
manifest["resident_host"] = "native_after_restart.json; ten read-only calls passed"
manifest["artifacts"] = []
for path in sorted(E.iterdir()):
    if path.name == "manifest.json":
        continue
    data = path.read_bytes()
    row = {"path": path.name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    if path.suffix == ".gz":
        raw = gzip.decompress(data)
        row.update(uncompressed_bytes=len(raw), uncompressed_sha256=hashlib.sha256(raw).hexdigest())
    manifest["artifacts"].append(row)
(E / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(checks))
