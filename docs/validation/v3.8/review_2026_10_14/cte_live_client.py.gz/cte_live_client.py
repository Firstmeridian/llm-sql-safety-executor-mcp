"""Read-only real MySQL and isolated SQLite through actual Client tool paths."""
import asyncio
from dataclasses import replace
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import time
from types import MappingProxyType

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "src"))
from fastmcp import Client
from sqlalchemy import event
from sqlalchemy.engine import Engine
from sql_safety_executor import create_server, load_config
from sql_safety_executor.database.models import ConnectionPolicy, DatabaseConfig
from sql_safety_executor.database.mysql import _CTE_CASE_PROBE

OUTPUT = ROOT / "docs/validation/v3.8/review_2026_10_14"
OUTPUT.mkdir(parents=True, exist_ok=True)
base = load_config(ROOT / "config/server.toml")
mysql = base.connections["trade_analysis_mysql"]
SQL = "WITH F AS (SELECT COUNT(*) AS n FROM orders) SELECT n FROM f"
probe_events = []

def capture(conn, cursor, statement, parameters, context, executemany):
    if statement == _CTE_CASE_PROBE:
        probe_events.append({"adapter": conn.engine.logging_name, "statement": statement})

def pack(result):
    return {"isError": result.is_error, "structuredContent": result.structured_content,
            "content": [item.model_dump(mode="json", exclude_none=True) for item in result.content], "meta": result.meta}

async def main():
    records = []
    metadata = []
    with tempfile.TemporaryDirectory(prefix="v381-cte-client-") as directory:
        root = Path(directory)
        database = root / "fixture.sqlite"
        with sqlite3.connect(database) as conn:
            conn.executescript("CREATE TABLE orders(id INTEGER); INSERT INTO orders VALUES(1);")
        skill = root / "skills" / "case-probe"
        skill.mkdir(parents=True)
        (skill / "skill_def.md").write_text("---\nname: case-probe\ntype: query\nsource: query.sql\nrisk: low\ndescription: Real CTE inference check\nparams: {}\n---\n")
        (skill / "query.sql").write_text(SQL)
        configs = {
            "mysql_ci": replace(mysql, connection_id="mysql_ci", policy=ConnectionPolicy(
                allowed_tables=frozenset({"orders"}), case_sensitive_tables=True)),
            "mysql_denied": replace(mysql, connection_id="mysql_denied", policy=ConnectionPolicy(
                allowed_tables=frozenset({"other"}), case_sensitive_tables=True)),
            **{alias: DatabaseConfig(connection_id=alias, db_type="sqlite", query_timeout_seconds=30,
                connect_timeout_seconds=10, sqlite_database_path=str(database), policy=ConnectionPolicy(
                    read_mode="all" if alias == "sqlite_all" else "allowlist",
                    allowed_tables=frozenset({"*"}) if alias == "sqlite_all" else frozenset({"orders"})))
               for alias in ("sqlite_allow", "sqlite_all")},
        }
        server_settings = base.server.model_copy(update={"server": base.server.server.model_copy(update={"default_connection": "mysql_ci"})})
        skills = base.skills.model_copy(update={"enabled": True, "directory": str(skill.parent),
            "readiness": base.skills.readiness.model_copy(update={"check_schema": True}),
            "mutation": base.skills.mutation.model_copy(update={"enabled": False}),
            "audit": base.skills.audit.model_copy(update={"path": str(root / "audit.jsonl"), "queries": True})})
        config = replace(base, server=server_settings, skills=skills, connections=MappingProxyType(configs))
        for mode in ("legacy", "auto"):
            server = create_server(config)
            event.listen(Engine, "before_cursor_execute", capture)
            try:
                async with Client(server, mode=mode) as client:
                    tools = await client.list_tools()
                    snapshot = {"instructions": client.instructions,
                                "tools": [{"name": t.name, "description": t.description, "inputSchema": t.inputSchema, "outputSchema": t.outputSchema} for t in tools]}
                    raw = json.dumps(snapshot, ensure_ascii=False, separators=(",", ":")).encode()
                    filename = f"live-metadata-{client.protocol_version}.json.gz"
                    (OUTPUT / filename).write_bytes(gzip.compress(raw, mtime=0))
                    metadata.append({"protocol": client.protocol_version, "path": filename, "sha256": hashlib.sha256(raw).hexdigest()})
                    for alias in ("mysql_denied", "mysql_ci", "sqlite_allow", "sqlite_all"):
                        if alias == "mysql_denied":
                            requests = [("query", {"sql": SQL, "connection_id": alias}),
                                        ("execute_query_skill", {"skill_name": "case-probe", "params": {}, "connection_id": alias})]
                        else:
                            requests = [("query", {"sql": SQL, "connection_id": alias}),
                                        ("list_skills", {"connection_id": alias, "detail_level": "full"}),
                                        ("get_skill_detail", {"skill_name": "case-probe", "connection_id": alias, "detail_level": "full"}),
                                        ("execute_query_skill", {"skill_name": "case-probe", "params": {}, "connection_id": alias}),
                                        ("query", {"sql": SQL, "connection_id": alias})]
                        results = []
                        for tool, arguments in requests:
                            start = time.perf_counter()
                            began = datetime.now(timezone.utc).isoformat()
                            result = await client.call_tool(tool, arguments, raise_on_error=False)
                            results.append({"started_utc": began, "elapsed_ms": (time.perf_counter() - start) * 1000, "result": pack(result)})
                        if alias == "mysql_denied":
                            assert all(not r["result"]["isError"] and r["result"]["structuredContent"]["error_code"] == "table_access_denied" for r in results)
                            adapter = server.gateway_runtime.registry.get_adapter(alias)
                            assert adapter._engine is None and adapter.cte_case_sensitive is None
                        else:
                            assert all(not r["result"]["isError"] for r in results)
                            full = results[1]["result"]["structuredContent"]["skills"][0]
                            assert full["tables"] == full["inferred_tables"] == ["orders"] and full["declared_tables"] == []
                            assert full["executable"] and full["schema_ready"]
                            data = [results[i]["result"]["structuredContent"]["data"] for i in (0, 3, 4)]
                            native = server.gateway_runtime.registry.get_adapter(alias).execute("SELECT COUNT(*) AS n FROM orders")
                            assert data[0] == data[1] == data[2] == [{"n": int(native[0][0])}]
                            if alias == "mysql_ci":
                                assert server.gateway_runtime.registry.get_adapter(alias).cte_case_sensitive is False
                        records.append({"protocol": client.protocol_version, "target": alias,
                            "requests": [{"tool": t, "arguments": a} for t, a in requests], "responses": results})
            finally:
                event.remove(Engine, "before_cursor_execute", capture)
                server.gateway_runtime.close()
        assert len(probe_events) == 2 and all(r["adapter"] == "mysql_adapter.mysql_ci" for r in probe_events)
    result = {"version": "3.8.1", "recording_profile": "Application CallToolResult content/structuredContent/isError/meta plus timestamps, not a full JSON-RPC transport capture",
              "metadata": metadata, "records": records, "tool_calls": sum(len(r["requests"]) for r in records),
              "probe_events": probe_events, "local_TOML_modified": False, "writes_to_existing_databases": False,
              "sqlite_fixture_removed": True, "resident_Host": "Not used; these are real in-process Client calls against new source"}
    (OUTPUT / "live_client.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print("34 Client calls passed; one table-free MySQL capability probe per server instance; known denied dependencies refused before engine/I/O.")

asyncio.run(main())
