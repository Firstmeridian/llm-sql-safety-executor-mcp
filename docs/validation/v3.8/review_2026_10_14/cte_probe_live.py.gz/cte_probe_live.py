"""Read-only live confirmation of the table-free CTE capability probe."""
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "src"))
from sql_safety_executor import load_config
from sql_safety_executor.database.mysql import MySQLAdapter

adapter = MySQLAdapter(load_config(ROOT / "config/server.toml").connections["trade_analysis_mysql"])
try:
    start = time.perf_counter()
    sensitive = adapter.resolve_cte_case_sensitive()
    cold_ms = (time.perf_counter() - start) * 1000
    assert adapter.cte_case_sensitive is False and sensitive is False
    start = time.perf_counter()
    assert adapter.resolve_cte_case_sensitive() is False
    hot_ms = (time.perf_counter() - start) * 1000
    rows = adapter.execute("WITH F AS (SELECT 7 AS n) SELECT n FROM f")
    assert rows == [(7,)]
    record = {"connection": "trade_analysis_mysql", "cte_case_sensitive": sensitive,
              "cold_probe_including_engine_and_connection_ms": cold_ms,
              "cached_lookup_ms": hot_ms, "native_mixed_case_rows": [list(row) for row in rows],
              "probe_physical_tables_read": False, "writes": False}
    path = ROOT / "docs/validation/v3.8/review_2026_10_14/cte_probe_live.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(record))
finally:
    adapter.close()
