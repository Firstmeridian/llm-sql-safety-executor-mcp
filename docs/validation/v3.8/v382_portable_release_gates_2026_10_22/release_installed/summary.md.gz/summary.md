# Contract gate

Profile: release; status: passed
Release ready: True

| Scenario | Status |
| --- | --- |
| fast | passed |
| sqlite_semantics | passed |
| sqlite_reads | passed |
| sqlite_writes | passed |
| mysql_writes | passed |
| mysql_unknown | passed |
| mysql_reads | passed |

not_run means UNVERIFIED, not passed. Fast regression alone is not release acceptance.
Actual dependency/runtime identity is recorded; no automatic reuse of prior results.
