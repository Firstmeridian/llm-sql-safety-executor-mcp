# AI 协作指南 / AI Collaboration Guide (Opt-in)

**状态 / Status：** 按需使用的协作约定，并非自动加载的 Agent 指令文件 / Optional working agreement; not an automatically loaded Agent instruction file

**最近评审 / Last reviewed：** 2026-10-22

## 用途 / Purpose

本文件记录有助于 AI 编码 Agent 审查或修改本仓库的协作偏好。它特意命名为
`AI_COLLABORATION_GUIDE.md`，而不是 `AGENTS.md`：

This file records collaboration preferences that may help an AI coding Agent
review or change this repository. It is deliberately named
`AI_COLLABORATION_GUIDE.md`, not `AGENTS.md`:

## 协作约定 / Working Agreement

### 最佳实践参考 Best Practices Reference
你可以参考调用 MCP 服务的实测数据，以及 web 和 GitHub 上的相关最佳实践和官方文档等资料，例如 OpenAI, Anthropic, Grok(SpaceXAI), Google, FastMCP 和 Microsoft 等知名机构的相关内容。也可以有选择的参考其它web内容和相关讨论，但需要对这些来源和内容进行 review 和思考。

---

### MCP 服务端提示词
目前已有的系统提示词基于 ReAct 思想，基本都反复经过了人工和 Agent 的 ReAct 调用实测。所以在非相关更新时，一般情况下请谨慎（或不要）改动已有的 MCP 服务提示词。当前提示词资源位于 `src/sql_safety_executor/prompts/`，由包内渲染逻辑加载。如果改动，请补充真实工具通道的 Agent 行为验收，分别报告准确性、调用次数、延迟和实际 token 用量；模拟结果作为补充，并明确样本及比较范围。

---

### 截至最近评审日期，本项目尚未正式公开发布，且没有已知的第三方使用者需要向后兼容。
只要这一前提仍成立：

1. 如果一项设计能实质性地提高安全性、清晰度或契约的一致性，应优先考虑它，
   而不是为了尚未发布的行为保留假设性的兼容性。
2. 不要悄然实施会影响兼容性的变更。应说明收益、受影响的调用方或扩展、
   迁移路径，以及测试和文档范围，让维护者明确作出决定。
3. 实施过程中发现更好的设计时，应主动报告，即使它会改变当前的扩展点；
   同时区分必要修复、可选整理与推测性的未来工作。
4. 已实现的契约应按需记录在代码、测试、README、发布说明和安全文档中；
   已接受或暂缓处理的风险应记录在设计风险登记中。
5. 以用户当前的要求和仓库当前的实际行为为准。在依据本指南行事之前，
   先核对其评审日期，以及项目是否仍处于正式发布前阶段。

总的来说，本项目没有什么历史包袱。所以当有更好的设计和改动时，应该主动向用户通知并建议，而不要避开。

正式发布或出现已知第三方使用者后，应重新评估上述前提。届时，破坏兼容性的
变更可能需要弃用流程、迁移窗口，或重大／次要版本的发布决策，而不是立即强制执行。

---

### 重命名和移动文件位置 / Renaming and Moving Files
应该优先使用 git mv 来重命名或移动文件或目录，以保留 Git 历史记录。

---

### 关于 autogen 示例
本项目中的autogen相关示例不是主要内容，也暂时没必要更新，未来也可能单拆出来。现在不必过于关注。不要花太多精力和注意力在它之上。

---

## 与用户合作 / Collaborating with Users

### 验证层次与依赖升级（2026-10-22）

普通pytest／fast通过只代表确定性回归，实库not_run须明确标未验。发布前使用[统一验证入口](scripts/validation/README.md)显式运行隔离MySQL及安装包矩阵，检查实际用例、跳过数、资源身份和清理；缺环境或意外跳过不能算发布通过。仅使用获授权的测试实例和自有临时夹具，不写已有业务表或更改私有配置／grant。

Python、链接的SQLite、SQLGlot、SQLAlchemy、PyMySQL、协议／序列化及传递依赖变化也影响旧证据适用性，不能仅凭产品源码相同复用。入口记录实际身份，baseline仅规划重验、无自动复用；依赖／验证变更由独立CI触发，运行环境／服务端升级仍需发布前重验。保留历史失败、独立真值和正常对照，不将导入、超时或未命中目标当成检错成功。

### 后端验收范围（2026-10-21）

SQLite 继续按本地原生语义验证；MySQL 方言及服务端行为以 MySQL 为验收基准。维护者明确 MariaDB 不作为验收门槛，不因其未实测而阻塞本轮，也不默认追加 MariaDB 环境或兼容专项。准确标注已测 MySQL 版本／会话和未覆盖配置，不能把一次实例结果泛化为所有 MySQL 版本。

Validate SQLite natively and use MySQL as the server/dialect acceptance target. MariaDB is not an acceptance requirement; do not add a separate MariaDB test environment by default. Retain the actual tested MySQL version/session scope.

### 合法 SQL 的表达自由度（2026-10-20）

维护者明确：在保持安全的前提下，尽可能给 Agent 更多表达自由，减少误拒，特别是采用 AST 后。按实际方言／会话和结构化身份判断；解析器的限制应记录为支持限制，不默认当作业务禁令。每次放宽兼容都同时验证合法正例及实际未授权／受限操作仍拒绝；分析不完整不能当作没有依赖，也不改写原 SQL 或跳过执行保障。

The owner prefers fewer false refusals and more valid SQL expression freedom within actual authorization and execution boundaries. Check dialect/session semantics, keep unsupported analysis explicit, preserve original SQL, and pair capability regressions with continued rejection of unauthorized or restricted operations.

### Ask Question / Grill Me
如果需要用户进行澄清、解释、核实、选择、决策或需要更多（背景）信息、以及其它有需要的时候，请使用 askQuestions 或类似工具/操作向用户主动询问。并同时给出建议，方便用户参考。

---

### 汇总更新/更改内容 Summarizing Updates/Changes
在汇总本次完整的更新/更改内容时，应按照每个变更点列出表格，包括变更前的问题/状态、变更的原因、变更后解决的问题和现状、解决方案和原理、带来的好处、代价等。

向维护者汇报完成项目时，在项目名称前附使用半角方括号的简短描述标签，例如“[功能修复] 尾注释误拒” “[速度优化] MySQL 列元数据批读” “[研究验证] 请求内纯分析复用”。标签反映实际交付性质，研究未接入生产须明确标注。

commit message 全文使用英文，包括标题、分组标签和正文。标题沿用 `fix(v3.8.2): …` 等现有类型／版本格式；正文按实际变更分组，在各组条目前使用 `[Fixes]`、`[Performance]`、`[Validation and Docs]` 等英文标签。组内用简短、动词开头的要点，不重复标签或堆放验收数字；详细证据留在对应报告。中文完成项汇报可继续使用中文标签。统一的当前提交草案放在版本归档的 `handoff/`，历史封存草案保留原文。

---

### 实测前应该检查 MCP 服务的状态是否需要重启。若需要重启 MCP 服务进行实测，可以让用户帮助重启。
防止 MCP 服务仍为旧版本而影响测试结果。

开始依赖原生 MCP 的相关工作前，必要时核对当前 Host 的工具定义，并在明确的测试连接执行一次无写入常量查询。涉及子代理验收时，也先验证新子代理实际可调用；主会话成功不代表子代理已就绪。需要维护者重启或刷新时说明理由；已确认操作后先验证结果。区分 Host 工具缓存／会话快照与服务进程加载的源码，记录实际错误，不把缓存或启动时序假设写成已确认根因。

同模型子代理验收还应从公开会话日志的实际model／effort核对每轮，尤其在关闭／恢复之后；不能只相信spawn请求。本机2026-10-20曾观察恢复后从Luna medium变为父会话Sol ultra：恢复成功与模型保持是两件事，混合模型结果单列保留，不并入同模型token对照。

Before work that relies on native MCP, check the current Host's tool definitions
and one read-only constant query when needed. For subagent acceptance, verify a
new subagent's actual call as well. Explain any requested maintainer restart or
refresh, then verify its result. Distinguish Host tool caches/session snapshots
from loaded server code; preserve errors and label root-cause hypotheses.

---
