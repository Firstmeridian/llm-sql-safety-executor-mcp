# MCP SQL Server Refactoring Log

English | [中文](REFACTORING_LOG_ZH.md)

**Date:** December 2, 2025 (Updated: October 22, 2026)

## v3.8.2 Portable sentinels and dependency-aware release gates (October 22, 2026)

- [Test Effectiveness] Move the two result-boundary variants into normal pytest with native-driver truth, exact branch-hit checks and positive controls. Keep existing portable transaction/RETURNING/source-binding regressions and sealed historical failures; no archive or old checkout is required by the new tests.
- [Release Gates] Separate deterministic CI from explicit installed-wheel/isolated-MySQL acceptance. Fast success does not certify live MySQL; missing release environment is unverified/nonzero. Require actual JUnit counts, expected matrix sizes and cleanup; unexpected release skips fail. The four opt-in MySQL cases must really pass, not merely match stdout text.
- [Evidence Decisions] Record Python, linked SQLite/options, installed/transitive dependencies, product and validation identities. Dependency/validation changes trigger the live workflow; manual release checks cover runtime upgrades without source/lock changes. Baseline comparison never authorizes automatic reuse. No runtime/prompt/configuration/grant change, new Agent step or model/performance claim. [Reusable commands and limits](scripts/validation/README.md).
- [Validation] Final normal-wheel release entry passes3541 regular tests/four initial optional skips, then860 application calls and actual live4/4/no skips.36 new tests also pass in a minimal checkout without archives/history/project conftest. Real MySQL8.0.25 matrices and cleanup pass; Hosted workflow execution remains unverified. Preserve550 warnings, the earlier3539 source checkpoint, sandbox interruption and pip-free offline installation scope. [Results and evidence](docs/validation/v3.8/V3_8_2_PORTABLE_RELEASE_GATES_2026_10_22_ZH.md).


## v3.8.2 Bounded stabilization gates and independent evidence audit (October 22, 2026)

- [Validation] Complete S1–S4 within16 frozen contract families and four declared gaps.254 selected regressions pass/no skips; source/existing normal wheel each332 application calls (SQLite204, real MySQL128) agree. Preserve93 framework deprecation warnings. No new confirmed P1/P2 in this scope.
- [Test Effectiveness] Two private function variants concretely expose duplicate-label loss and first-row limit overflow; normal positive controls pass. Recheck existing SQLite/MySQL historical sentinels and actual lifecycle faults; verify only the MySQL-specific file differs before reusing SQLite evidence.
- [Decisions] Three gates pass within the frozen matrix, not a defect-free guarantee. Preserve unknown/network, temporary-object, parser and model-wording limits. No runtime/prompt/dependency/configuration/grant changes or mandatory Agent steps; no new performance/token/model claim or restart required. Reuse the previous3505 full passes/four optional skips without adding254 to that count.
- [Documentation] Add reusable isolated-MySQL read validation, final evidence/stop conditions and updated handoff.85 prior seals/2809 records remain intact; keep the initial audit path-prefix mapping error separate from production findings. [Results and limitations](docs/validation/v3.8/V3_8_2_STABILIZATION_2026_10_22_ZH.md).

## v3.8.2 Exact read-analysis binding and live InnoDB write gate (October 22, 2026)

- [Fixes] DRR-144 requires MySQL analysis.source_sql to equal the exact original SQL, alongside completeness/session checks, before dispatch. Match SQLite's existing contract; keep original SQL/params and supported matching calls. Current MCP callers were consistent; no prior production bypass claim.
- [Integration Verification] Source/normal wheel each pass14 native-oracle commit/rollback groups,19 faults (five real server errors, two own-session disconnects,12 labelled client injections), three races and96 application calls/32 preview-confirm-replay flows. Unknown can accompany unchanged or committed data, with one adapter attempt and consumed-token replay rejection. Explicitly enable the four previous optional MySQL tests:4 pass/0 skip, separate from the default full3505 pass/4 skip.
- [Contract Decisions] Owner confirms three stabilization gates: transactional-business truth across lifecycle failures; cross-entry source/context/object binding with valid capability preserved; independent oracles and known-bad sentinels that fail on the target contract. AUTO_INCREMENT gaps are allowed; no production full-database comparison. Complete stabilization remains broader than these two tasks.
- [Validation and Docs] Twelve new binding regressions,25 binding/session tests, five known-bad/current sentinel pairs, clean types/prompts and77 identical installed resources. Temporary fixture schemas removed; configurations/grants/old seals stay intact. No write-adapter, dependency, prompt or mandatory Agent-step change; no new model/performance claim. [Source/package evidence, costs and scope](docs/validation/v3.8/V3_8_2_MYSQL_WRITE_CONTRACTS_2026_10_22_ZH.md).
- [Restart Verification] After the owner restart, all six frozen native connection/read/refusal checks pass with matching text/structured output.77 resources and three TOMLs remain unchanged;83 prior seals/2785 records fully verify. This does not directly test the internal mismatch argument or native confirmed writes. Keep the parent pending checkpoint unchanged. [Separate supplement](docs/validation/v3.8/v382_mysql_write_contracts_2026_10_22/resident_restart/README.md).
- [Stabilization Plan] The agreed gates now have a [bounded execution table](docs/validation/v3.8/V3_8_2_STABILIZATION_PLAN_2026_10_22_ZH.md): audit existing evidence and freeze gaps, check cross-entry identity/lifecycle, check results/execution, then verify sentinels and close.16 contract families and stop conditions are fixed; S0 is scoped complete and S1–S4 remain pending. No background job, new runtime change or full-stabilization claim.

## v3.8.2 Physical SQLite writes and completed result counts (October 22, 2026)

- [Fixes] DRR-142/143 establish a physical SQLite transaction before original DML, complete/close RETURNING results before direct-row checks, and use same-connection changes() only when the executed DML count remains unknown. WITH/semicolon writes can no longer bypass the row-count rollback through legacy implicit-BEGIN behavior.
- [Outcome Evidence] Confirm physical pre/post rollback state, retain uncertain COMMIT/auto-rollback as unknown, and retire connections with unresolved transaction/cursor/handler state. Trigger/cascade effects and returned rows are not direct DML counts. Keep MySQL evidence independent.
- [Decisions] Local write-boundary repair only: no global engine transaction event, read-authorizer change, dependency, prompt/configuration/grant change or mandatory Agent step. Explicit BEGIN, fallback count queries and RETURNING consumption have costs; do not infer model-token savings. Keep the temporary sqlparse path independent of a second AST validator.
- [Validation and Docs] Private-file source/normal-wheel each432 application calls cover136 preview-confirm-replay flows across both classifiers, Client modes and transports, with independent truth after cleanup. Final full regression, types/prompts and serial A/B/A costs remain in the [pre-restart repair record](docs/validation/v3.8/V3_8_2_SQLITE_WRITE_TRANSACTIONS_2026_10_22_ZH.md). No configured database writes; preserve prior model/guidance failures and assessment evidence.
- [Restart Verification] Owner-restarted native12/12 passes. Additional source/existing-wheel each254 private adapter write attempts cover120 combinations, six two-writer races and two real COMMIT failures; independent post-cleanup truth agrees. Known-bad-source sentinels detect both original defects and pass current source. No runtime edits this turn; retain3493 regression passes/four optional skips without unnecessary reruns. All79 prior seals/2625 records stay intact. [Current evidence and assessment](docs/validation/v3.8/V3_8_2_WRITE_RESTART_AND_STABILIZATION_2026_10_22_ZH.md).
- [Assessment and Follow-up] Repeated failures expose cross-layer contract and coverage gaps; earlier real SQLite tests missed physical transactions for WITH/semicolon and cursor completion. No claim that the project is now defect-free or needs wholesale replacement. DRR-144 records MySQL's missing analysis.source_sql binding check as internal hardening only: current MCP callers bind the same SQL, no production failure reproduced, no repair this turn. Contract-based stabilization gates are proposed, not an approved new implementation plan.


## v3.8.2 Restart closure and complete Agent cost audit (October 21, 2026)

- [Validation] Latest owner restart passes all12 frozen native PRIMARY/column/query/denial checks; preserve earlier native7/12 versus fresh CLI12/12 and the unconfirmed binding/cache cause. All75 previous manifests/2316 records remain intact.
- [Complete Agent Tasks] Fifteen fresh actual Luna-medium trials reuse all fifteen historical two-turn prompts/data; final business15/15,65 successful SQL replays agree. Business calls108→113 and total tokens4,401,500→4,571,061(+3.85%); input+3.91%, output-3.38%. Mean public task time29.673→81.845s; most added time is outside public tool windows, not proof of a causal SQL slowdown.
- [Measured Costs] Separate fixed-flow local A/B/A retains SQLite-1.78% to+5.49% and initial MySQL finance+16.14%. Follow-up A/B/B/A preserves phase drift and a measurable schema cost; no universal zero-cost or speed claim. The immediate pre-DRR141 wheel differs from the historical full-model baseline.
- [Result Guidance] Three additional natural-cancel probes are separate: initial business2/3, one neutral reminder, final preview paths3/3, no writes or post-cancel calls; strict wording1/3. Retain an unsupported current-state claim and ambiguous cancellation language; no guidance-off causal claim or new write-outcome coverage.
- [Decisions and Docs] No runtime/prompt/configuration/grant/dependency/database change or extra mandatory Agent step. Ten SQLite files, four Sakila table hashes, three TOMLs and77 resources stay unchanged; eighteen agents closed. Keep weak-prompt interpretation as a separate follow-up, without reopening scoped metadata acceptance. [Tasks, usage, costs and limits](docs/validation/v3.8/V3_8_2_COMPLETE_AGENT_EVAL_2026_10_21_ZH.md).

## v3.8.2 Actual PRIMARY identity and ordered members (October 21, 2026)

- [Fixes] Owner-approved DRR-141 adds optional positive one-based `primary_key_position` for actual PRIMARY members. SQLite reuses table_xinfo; MySQL single/batch column queries join KEY_COLUMN_USAGE without extra round trips. Preserve native key flags separately; live InnoDB, MyISAM and MEMORY fixtures confirm that PRI alone can misidentify a non-null unique index as PRIMARY.
- [Decisions] Compact orders actual members and grouping includes positions; full/describe/summary preserve the optional field. Non-members omit it. Repeated SQLite physical key parts remain in described indexes, not the member summary. No AST, authorizer, prompt, dependency, configuration, grant or mandatory Agent-step change. Additional catalog-join work and more accurate groups/payloads are accepted costs.
- [Validation and Docs] Compare both backends' shared functional matrix against independent native catalogs and keep serial A/B/A costs distinct from model tokens. Source/package and current resident-channel status, preserved failures and limits are maintained in the [repair record](docs/validation/v3.8/V3_8_2_PRIMARY_KEY_METADATA_REPAIR_2026_10_21_ZH.md). Earlier assessment-only statements below retain their historical scope.

- [Validation and Docs] At the earlier reported-restart checkpoint, the native channel passed7/12;5 describe/full checks still omitted PRIMARY positions. The same12 checks pass in a fresh configured CLI;77 resources, three TOMLs, the SQLite file and73 prior seals/2279 records stay unchanged. Multiple same-entry MCP processes are observed, but exact channel binding/cache cause is unconfirmed. Owner then chose to reconnect later; that historical pending checkpoint is preserved. Latest native12/12 closure is recorded above. [Actual records](docs/validation/v3.8/v382_primary_key_metadata_repair_2026_10_21/resident_restart/README.md).
- [Decisions] MySQL is the server/dialect acceptance target; MariaDB is not an acceptance requirement. Keep native SQLite and the actual tested MySQL version/session scope; do not add a MariaDB environment by default.

## v3.8.2 Composite-key metadata assessment (October 21, 2026)

- [Validation and Docs] A separate expanded assessment adds16 SQLite objects and source/existing-wheel92 calls each, plus read-only8-table/272-column MySQL catalog checks. No new independent confirmed defect; defaults, generated columns and structured indexes match native truth. Repeated SQLite key parts and the officially documented MySQL PRI/PRIMARY distinction must inform any future key contract; the latter is component-confirmed, not reproduced on those live tables. No production change or restart. [Scope and evidence](docs/validation/v3.8/v382_composite_key_metadata_assessment_2026_10_21/extended_scope/README.md).
- [Assessment] Expanded metadata checks confirm DRR-141, an existing nonblocking P3 information limitation: compact primary_key follows table-column order instead of actual composite-key order. Described indexes and raw results are correct; grouping equal adapter-visible column metadata does not breach the stated non-DDL contract.
- [Recommendation] Clarify membership versus order now; consider a small shared primary-key-position contract next. SQLite can reuse existing PRAGMA positions; MySQL needs real key-directory facts and measured single/batch cost. No AST/authorizer relaxation or extra mandatory Agent call. Not implemented, no commit repair claim or restart required.
- Source/existing-wheel each44 application calls across both modes/transports, unchanged77 resources/three TOMLs and67 seals/2133 records. No configured database, new native/model/build/full-suite or performance coverage. [Assessment and evidence](docs/validation/v3.8/V3_8_2_COMPOSITE_KEY_METADATA_ASSESSMENT_2026_10_21_ZH.md).

## v3.8.2 Native SQLite declared types (October 21, 2026)

- [Fixes] Owner-approved DRR-140 preserves raw PRAGMA type strings, including empty and whitespace, in describe/summary and compact/full schema. Undeclared ordinary/generated columns, CTAS, expression views and FTS visible columns no longer acquire invented TEXT types; compact grouping now distinguishes empty from TEXT.
- [Decisions] Keep declaration metadata separate from affinity and runtime storage class. No type inference, new query/cache/configuration/prompt, grant change or mandatory Agent step. Grouping still compares visible metadata, not full SQLite semantics; more groups can increase payload size.
- [Validation and Docs] Add 13 regressions and compare every projection directly with independent native PRAGMA strings. Source/normal-wheel each184 application calls agree in both Client modes and transports. Final full-suite results, resource identity and scoped owner-restart verification are tracked in the [repair record](docs/validation/v3.8/V3_8_2_SQLITE_DECLARED_TYPES_REPAIR_2026_10_21_ZH.md). Preserve old normalized-type evidence and earlier137/138/139 scoped acceptance. No new model/token or latency claim.

- After the owner restart,9/9 frozen native checks pass with independent columns/index/count truth. New adjacent source/wheel each144 calls plus20 component observations cover falsey/default/space/custom/quoted/generated/view metadata; no new confirmed independent production root in that scope.77 resources, three TOMLs, SQLite and65 prior seals/2097 records stay unchanged. Clarify the historical design's TEXT fallback rather than rewriting it; preserve the parent pending checkpoint. No new model/build/full-suite/cost claim; no further restart required.

## Historical assessment: SQLite declared types (October 21, 2026)

- [Assessment] Confirm old P3 DRR-140: empty PRAGMA type strings become TEXT in describe/summary/schema projections and merge distinct ordinary/generated compact groups. Source184 two-mode/two-transport calls, isolated2c0a9e7 32 calls and2 native checks reproduce it. Current raw/Query Skill storage semantics remain correct; previous137/138/139 scoped acceptance stands.
- [Recommendation] Preserve the native type string, including empty; document declaration versus affinity/runtime values. No AST extension, inference, authorizer relaxation or switch. Correct future native-type test expectations rather than copy the old fallback; retain historical evidence. More accurate compact grouping can grow responses without adding mandatory tool calls.
- No production/test/configuration/grant/database changes, new build/full regression/model/token/performance claim or restart needed. Selected neighbors reveal no new P1/P2. [Assessment and evidence](docs/validation/v3.8/V3_8_2_SQLITE_DECLARED_TYPES_ASSESSMENT_2026_10_21_ZH.md). That assessment preceded the approved repair recorded above.

## v3.8.2 FTS catalog, cardinality sources and external-content rowid (October 21, 2026)

- Owner-approved DRR-137/138 plus adjacent DRR-139: replace the last shadowable internal PRAGMA TVF with actual-schema fixed statements; select true table/verified full-index statistics; resolve implicit content rowid to SQLite compile-time column identity. Keep direct grants, callbacks, guarded fallback and original SQL intact.
- Include index-order/index-only ANALYZE/WITHOUT ROWID, cold versus trusted-warm behavior, declared rowid names and continued direct-base/shadow refusals. Replace the regression that copied arbitrary first-stat output. No new AST layer, cache, dependency, switch, prompt or configured-database change.
- Additional bounded directory work is an accepted correctness cost, not a speed or token claim. Source/package checks and serial costs are recorded in the [repair record](docs/validation/v3.8/V3_8_2_FTS_CATALOG_STATISTICS_REPAIR_2026_10_21_ZH.md). After the owner restart, all 10 frozen existing-alias native checks pass: FTS MATCH/table calls agree, 6 tables/34 columns and estimates match independent SQLite truth, and shadow/function denials remain effective. All 77 disk resources, three private TOMLs and the configured SQLite file stay unchanged; 59 prior manifests/1998 file records remain intact. Special catalog/partial-index/cold-rowid fixtures retain source/package coverage. [Resident supplement](docs/validation/v3.8/v382_fts_catalog_statistics_repair_2026_10_21/resident_restart/README.md). Historical failures and prior scoped native/model evidence remain intact; no new model, build or full regression claim.

## v3.8.2 FTS catalog/statistics follow-up assessment (October 21, 2026)

- [Assessment] Confirm open P2s DRR-137/138: authorizer bootstrap still uses shadowable pragma_table_list; arbitrary first-index statistics mistake partial-index cardinality for table size. The former predates the adapter's four-PRAGMA repair; isolated 2c0a9e7 reproduces the latter. No production/configuration/grant/database change.
- [Evidence] Disposable source 284/existing-wheel 96/baseline 14 Client calls,16 component cases and 80 fixed-PRAGMA feasibility checks. Main/TEMP/aux tables/views, explicit schemas/quoting, exact/default metadata, index order, WITHOUT ROWID and partial-only ANALYZE are covered. A regression test currently mirrors the erroneous first-stat behavior and must change with the repair.
- [Scope] Recommend one small repair batch: actual-schema catalog statements with existing shadow checks/budgets, then verified statistics sources and guarded bounded fallback. No new AST/cache/switch. Prior 20/20 native acceptance retains its scope;55 earlier seals/1723 records stay intact. No new model, native, build, full regression or speed claim. [Assessment and recommendations](docs/validation/v3.8/V3_8_2_FTS_CATALOG_STATISTICS_ASSESSMENT_2026_10_21_ZH.md). These are not implemented fixes in the current commit draft.

## v3.8.2 Metadata PRAGMA identity repair (October 21, 2026)

- [Fixes] Owner-approved DRR-136 replaces shadowable metadata PRAGMA table-valued calls with four fixed main-bound PRAGMA statements. Preserve quoted business names, visible/generated columns, expression/sort/collation/partial/unique indexes and synthetic rowid primary keys.
- [Bounds] Keep 128 indexes, 2048 key parts, 64 KiB index JSON and the shared cooperative deadline. Fetch at most limit+1 rows and close results explicitly; raw PRAGMA row limits remain separate from public key-part counts, including WITHOUT ROWID auxiliary columns. Hold the existing connection lock across index collection; no partial-success metadata.
- [Tradeoffs] N real indexes now require N+2 catalog statements instead of two; column reads remain one per table. Measure serial warm A/B/A separately, without model/token or general speed claims. No new configuration, grants, parser layer, cache, dependency or Agent step.
- [Validation and Docs] Add 57 regressions and source/normal-wheel metadata plus DRR-135 matrices. Final regression, resource identity, application frame comparisons, preparation failures and costs are in the [repair report](docs/validation/v3.8/V3_8_2_METADATA_PRAGMA_REPAIR_2026_10_21_ZH.md). Preserve prior seals. The owner-requested combined restart is now verified: 20/20 frozen native checks pass, pages: 10 columns/complete indexes and compact/full: 6 tables / 34 columns match independent read-only SQLite metadata. 77 disk resources, three private TOMLs and the SQLite file remain unchanged; 53 prior seals/1706 records preserved. Special attached/collision fixtures retain source/package scope, with no new model, build or full regression claim. [Restart supplement](docs/validation/v3.8/v382_metadata_pragma_repair_2026_10_21/resident_restart/README.md).

## v3.8.2 Ordered attached JSON-name readiness (October 21, 2026)

- Owner-approved DRR-135 repair replaces TEMP-only absence with an immutable ordered two-name observation, successful schema prefix and completeness. Bound schema count/elapsed time; use fixed PRAGMA database_list, preserve explicit/resolved identities and unknown unqualified names, with no grants/authorizer/AST or configuration changes.
- Known default-scope Skills survive unrelated observation failure. Non-default stored identities remain unverified for readiness; actual authorization stays live and readiness-off adds no probes. The old adapter hook is replaced explicitly, without compatibility scaffolding.
- 67 new regression cases pass; final source/wheel each 332 application calls agree across the declared Client/stdio scope. Disk/package identity, final full regression, component costs and owner restart status are tracked in the [repair record](docs/validation/v3.8/V3_8_2_ATTACHED_JSON_REPAIR_2026_10_21_ZH.md). No new model/token claim.
- Continued assessment then confirmed independent old DRR-136: same-name business tables shadow metadata PRAGMA table-valued functions. Before/after each30 component and32 Client calls agree; column/schema reads failed for table_xinfo, while other tested names made indexes unavailable. [Historical assessment](docs/validation/v3.8/V3_8_2_METADATA_NAME_COLLISIONS_2026_10_21_ZH.md); subsequently approved repair is recorded above.

- DRR-135 and 136 now share the above 20/20 native supplement; default catalog checks pass, while attached-name/partial-observation cases retain source/package coverage. Earlier pending seals and initialization failures remain untouched.

## v3.8.2 Faithful read results and conditional dependencies (October 21, 2026)

- At the subsequent assessment checkpoint, DRR-135 was open: unqualified attached-only JSON-name FTS calls still appear builtin in readiness. A 332-call disposable source matrix/dynamic check preserves actual refusals and prior result repairs; no runtime/configuration changes or new package/native/model acceptance. Recommend ordered, complete, bounded two-name observations. [Findings](docs/validation/v3.8/V3_8_2_ATTACHED_JSON_READINESS_2026_10_21_ZH.md).
- DRR-131: detect duplicate actual row labels before dictionary conversion; return duplicate_result_columns with unique-AS recovery, preserving case-distinct labels. No automatic renaming or new ordered-result interface.
- DRR-132/133: query, Query Skills and sample share typed binary/base64 and non-finite-float encoding, explicit unsupported-value errors and encoded compact-JSON data limits. Oversized first rows may return zero rows with an actionable explanation; sample gains complete truncation fields. result_chars is zero or at least two. Keep write-outcome serialization independent.
- DRR-134: preserve builtin/stored/unverified JSON-name dependencies in fresh readiness, including aux/temp and unavailable metadata. One fixed SQLite TEMP catalog query per enabled snapshot prevents unqualified shadow misbinding; readiness-off adds no probes. Cache pure analysis only; no AST/authorizer changes, grants, switches or dependencies.
- Normal successful query payloads avoid an extra reason field; full Skill metadata discloses conditional state only when relevant. Binary expansion, encoding work, the TEMP query and alias-retry costs are accepted; no model/token or universal performance claim. [Contract and acceptance](docs/validation/v3.8/V3_8_2_READ_RESULTS_2026_10_21_ZH.md).
- Final full regression: 3126 passed/four optional skips; source/installed each 176 calls with identical application frames and 77 runtime resources. Types/prompt checks pass. After the owner restart, all 16 frozen native query checks pass with matching text/structured output; 77 runtime resources, three private TOMLs and the configured SQLite file remain unchanged, preserving 45 prior manifests/1329 file records. The old duplicate-label observation and parent pending checkpoint remain intact. Special Skill/sample cases retain source/package scope; no new model, speed or token claim. [Restart supplement](docs/validation/v3.8/v382_read_results_2026_10_21/resident_restart/README.md).

## v3.8.2 Relation-call identity and generated columns (October 20, 2026)

- Keep SQLite relation calls distinct from scalar aliases/arity in FROM, JOIN and table-form IN. Preserve decoded name components, quoting, source positions and arguments; still inspect true functions/subqueries and execute original SQL.
- Resolve JSON-name collisions against actual catalog/module identity and grants; authorized FTS5 roots use FTS abilities rather than builtin JSON abilities. Recompute Skill conditional dependencies from each current readiness snapshot.
- Cache immutable inferred SQLAnalysis only, using the private `_inferred_analysis` field; directory facts, grants and executable state are not cached. No new TOML switch, dependency or required Agent round trip.
- Use table_xinfo for visible ordinary and generated columns. Exclude hidden=1, expose virtual/stored generation_type and compact generated_columns, and include it in grouping signatures. Do not evaluate expressions or replace the separate primary-key lookup unnecessarily.
- DRR-129/130: 3062 regressions pass/four optional skips, source/wheel each complete 538 stdio calls; after the maintainer restart, all 12 frozen native checks pass. Generated status and compact/full counts agree, business results match independent truth, and restrictions remain. The database, private TOMLs and 77 runtime resources are unchanged; 40 earlier manifests/1129 file records are preserved. [Scoped acceptance](docs/validation/v3.8/V3_8_2_RELATION_CALLS_COLUMNS_2026_10_20_ZH.md). Earlier model and cost evidence retains its own source scope.

## v3.8.2 Complete Agent tasks, actual usage and configuration audit (October 20, 2026)

- Validation/documentation only on the same 77 runtime resources, with no new dependency, private TOML/grant or business write. Fifteen new actual Luna medium two-turn tasks cover telemetry, JSON/FTS, Sakila financial reconciliation and unconfirmed-preview/cancellation. Final business outcomes15/15; 60 extractable successful original SQL results match independent replay. Ten SQLite files, four complete Sakila table digests and three private TOML hashes are unchanged.
- Keep operational first-attempt availability15/18. Three same-thread close/resume recoveries restored tools but actual model/effort changed to parent Sol ultra; retain their results/costs separately, verify every turn and run three fresh Luna replacements. Do not assert a cache root cause or pool mixed models. Retain correct sqlite_master/FROM-subquery refusals and recovery, extra exploration/long answers, and the initial datetime comparison mismatch; fix only the verifier's typed ISO serialization.
- Nine actual same-model/effort/same-prompt historical business comparisons: MCP returns78→73, model responses89→85, input-6.42%, output+13.13%, total-6.30%; selected canaries included total-6.58%. The earlier mixed-model+7.10% is withdrawn, not erased. Six previously completed same-model comparisons show calls45→51/total+1.50%. Not randomized source A/B, billing, universal savings or added mandatory steps. Twenty-one prompt resources and ten common fixture tool definitions match older evidence.
- Three real preview/cancel trials correctly distinguish validation rejection, not_executed, estimates, prior observation/current unchecked state and no tool revocation. No guidance-off ablation or new committed/rolled_back/unknown model acceptance. Keep generic request analysis caching deferred; direct cold-inference analysis handoff remains optional.
- All eleven sample aliases were already added to private connections.toml and are visible among sixteen native targets; no duplicate addition. Earlier import report keeps its then-ungranted FTS scope; the later approved main.pages_fts root is present, without shadow grants. [Tasks, actual usage and limits](docs/validation/v3.8/V3_8_2_COMPLETE_AGENT_EVAL_2026_10_20_ZH.md).

## v3.8.2 Repair read comments/bindings and bound column work (October 20, 2026)

- Owner-approved DRR-124/125 repairs preserve original SQL and increase valid expression freedom: ignore only non-executable trailing AST nodes after complete comment checks; share execution transport's dialect/session-aware binding identity. Startup candidates must satisfy both shape and exact declared bindings; actual-target and consumed-token rechecks remain live. The pure classifier's 128-entry key now includes declared binding names, never values/grants/state.
- DRR-126: Query Skill startup stops at the first allowed candidate, retaining the first complete refusal if none allow. Full-schema columns are fetched only after authorization/truncation through the explicit get_columns_batch interface; MySQL uses at most 199 selected tables plus one schema binding per batch, retaining exact stored names, column order and whole-operation failure. SQLite composes existing per-table calls. Backend customizations must consider the new batch hook; no speculative compatibility shim.
- Full regression **3003 passed/four skipped**, followed by **two additional session-binding tests**; clean type/prompt checks, **84 source/84 installed stdio calls and six installed MySQL calls**, 77 matching resources. Five real MySQL catalogs match scalar/batch output; 16 actual sessions verify 32 literal comparisons and 32 non-executing plans with unchanged orders. After the owner restart, 34/34 scoped native checks pass: complete MySQL column payloads and a 20-row monthly report match independent truth, two previews remain unconfirmed, and seven refusals hold. SQLite file/full 80-order and MySQL full 60-order digests stay unchanged. Earlier model/native evidence is not reassigned; parent pending seals remain immutable.
- Matched child-stdio MySQL full-schema paired medians improve 81–85% for the fixed 16-table case; 22-Skill warm Runtime initialization improves about 43%. SQLite has mixed small changes, including a +3% group; warm managed cycles show no clear regression or speedup. Preserve samples, controls and scope.
- DRR-127: operation-local pure-read reuse was studied in 16 scenarios, not deployed. Cold dependency inference benefits; tested warm/raw/view/trigger-plan paths have no reusable duplicate. Prefer evaluating direct analysis handoff before a generic cache. No dependency, private config/grant, Agent-step or version change; temporary explicit sqlparse rollback retains its older syntax limits. [Implementation, decisions, costs and evidence](docs/validation/v3.8/V3_8_2_READ_PLAN_REPAIR_2026_10_20_ZH.md).

## v3.8.2 Audit remaining functional boundaries and performance candidates (October 20, 2026)

- Audit only: no runtime, dependency, private configuration/grant or configured business-data change. Record open DRR-124 (ordinary comments after a terminating semicolon look like a second read statement) and DRR-125 (managed-plan raw text binding discovery mistakes literal/comment/name colons for parameters). Complete HEAD and pre-comment package imports reproduce both; prior scoped acceptance retains its scope.
- Add 32 native-valid SQLite/shape inputs, 22 actual in-process Client calls, four current-Host constant calls, four independent MySQL reads and twelve managed binding comparisons. No new full-suite/installed/model acceptance claim; 77 runtime resources and README/dependency files remain identical.
- Measure unimplemented prototypes separately: 89 startup decisions remain identical (445→262 analyses); 20-template classifier batches 34.067→5.629ms. Selected MySQL 16-table/89-column metadata 209.764→16.482ms with 16→one column query and timeout setup; these are local warm-stage costs, not tool/model speedups.
- Recommend fixing the two functional issues before the startup and bounded-column optimizations; retain live authorization/target/token checks, current authorizer and statement-cache lifecycle. Update the current handoff, historical parser attribution and risk/configuration documentation. [Evidence and decisions](docs/validation/v3.8/V3_8_2_FINAL_AUDIT_2026_10_20_ZH.md).

## v3.8.2 Dialect comments, bounded MySQL plan hints and NOT precedence (October 20, 2026)

- Record three independent tasks under DRR-121/122/123: SQLite treats its ordinary block/hint-shaped comments and dash comments by native rules; MySQL checks every original comment span and accepts only named plan hints with flat name arguments; actual HIGH_NOT_PRECEDENCE changes prefix NOT grouping, while ! always binds tightly. Infix NOT grammar stays separate.
- Keep executable MySQL/MariaDB comments, SET_VAR, RESOURCE_GROUP, timeout overrides, unknown/incomplete hints and nested hint expressions unsupported. Hint-relative AST offsets are omitted from analysis only after complete lexical checking; original SQL/binds still execute. The explicit sqlparse rollback remains the original classifier, not an automatic fallback.
- Reuse one existing unary dispatch entry, with no new parser method override; the pinned private dispatch dependency and upgrade tests remain explicit. Startup managed candidates grow from nine to seventeen; warm classification caching and actual-session initialization remain. Version, dependencies, private config/grants and required tool steps are unchanged.
- Full regression: 2920 pass/four optional skips; a subsequently added Query Skill/readiness two-protocol check adds two passes. Type/prompt checks pass; 16 actual MySQL sessions verify 272 scalar results and 128 non-executing plans, with original order rows unchanged. Package/cost/native status and preserved test-fixture failures are in the [record](docs/validation/v3.8/V3_8_2_DIALECT_COMMENTS_NOT_2026_10_20_ZH.md).

- After the owner restart, **30/30 scoped native checks** pass: one routing catalog, 12 reads, four discovery/detail calls, three unconfirmed previews and ten expected refusals. SQLite file/full 80-order digest and MySQL order digest remain unchanged; 27 earlier manifests/681 file records are intact. No new model trial, configured write or full-mode native claim. [Separate resident evidence](docs/validation/v3.8/v382_dialect_comments_not_2026_10_20/resident_restart/README.md).

## v3.8.2 Reuse pure managed classification (October 20, 2026)

- At the DRR-120 checkpoint, the owner approved readiness-only dependency/schema checks and instance-local bounded classification reuse; hint-shaped comments and HIGH_NOT_PRECEDENCE compatibility were deferred. Their subsequent implementation is recorded separately in DRR-121–123 above. Version/dependencies, parser selector and tool steps remain unchanged.
- Discovery retains full availability policy; schema guards share only readiness evaluation. A 128-entry LRU retains immutable decisions keyed by verbatim SQL, complete frozen dialect/session context and parser. Connection resolution, grants, profiles, readiness, parameters, tokens and transaction evidence remain live; confirmation resolves context after token consumption. Pure denials may be reused; connection failures/exceptions are not cached. Close clears entries, including registry-cleanup failure. Concurrent misses may compute twice.
- A1 reduces the six-call workload from 11 to 7 classifications; final reuse and matched costs, source/package and resident status are separate in the [optimization record](docs/validation/v3.8/V3_8_2_MANAGED_CLASSIFICATION_REUSE_2026_10_20_ZH.md). Earlier sealed migration/performance measurements keep their original source attribution.

- Final **2815 passed/four skipped**, clean type/source-and-installed prompt checks; 77 matching runtime resources and 40 source/40 installed stdio calls. All 980 paired full-validator verdicts remain identical. Alternating paired six-call costs improve by median paired 13.06% modern / 7.51% legacy on this fixed warm SQLite workload; preserve all staged drift and 4800 timed/768 warmup calls. After the owner restart, **22/22 native checks** pass: repeated discovery/detail, three unconfirmed previews and six expected refusals. Two SQLite hashes and the full 80-order digest stay unchanged; 23 earlier manifests/580 files remain intact. No new complete-model trial or configured business write; native behavior does not attest LRU hits or in-memory source hashes.

## v3.8.2 Migrate managed-plan classification with explicit rollback (October 20, 2026)

- Later fixed-workload stdio A/B/A confirms a small end-to-end cost: six-call SQLite cycles +10.9% modern / +5.0% legacy, despite the faster startup validator. Preserve 1440 timed/288 warmup calls, 11 classifications per six-call cycle and 18 native EXPLAIN controls showing intentional engine-valid hint/HIGH_NOT_PRECEDENCE refusals. Those were proposals at that checkpoint; reuse and finer support are implemented separately in DRR-120 and DRR-121–123 above; [measurements and limits](docs/validation/v3.8/v382_managed_parser_2026_10_20/performance_followup/README.md).

- Freeze the actual two managed definitions and 98-case/10-context corpus before migration; compare both complete validators with identical fields/binds. Default to SQLGlot using existing dialect/session lexing and public AST parsing, with no new private parser override.
- Keep write rules independent: one direct INSERT/UPDATE/DELETE, original main verb, nested-write rejection, named-bind/value checks and original SQL execution. Share lexical directive-comment facts without applying read authorization to writes.
- Distinguish startup candidate screening from target availability/preview and consumed-confirmation rechecks. Reuse per-physical-MySQL-session mode initialization, not a probe of an unrelated connection; target failure before write remains not_executed and consumes the token.
- Owner decision: retain restart-scoped managed_plan_parser="sqlparse" and its dependency temporarily, default "sqlglot", no automatic fallback. Review removal after two or three release checkpoints and recorded acceptance; old classifier limitations and existing SQLGlot private-API risk remain explicit. No version bump, private configuration edit or configured business write.
- Final **2791 passed/four skipped**, clean type/prompt; 77 matching runtime resources, 40 source/40 final-installed calls, 980 paired comparisons and 64 MySQL non-executing plans. After the owner restart, 16 native calls satisfy the scoped contracts (two previews, four expected refusals); retain one corrected search expectation and unchanged SQLite hashes/full-order digest. No configured business write or new model trial. Source/package, costs and native limits are separated in the [migration record](docs/validation/v3.8/V3_8_2_MANAGED_PARSER_2026_10_20_ZH.md). Historical model trials are not reassigned to this source.

## v3.8.2 Check cached FTS content functions and qualified roots (October 20, 2026)

- Repair DRR-116 with shared restricted-function facts used by raw policy, SQLite callbacks and preparation of complete reachable view/trigger analyses. Trusted full FTS projection no longer makes guarded function checks depend on module cache state.
- Repair DRR-117 by applying builtin-only schema restrictions to builtin uses. Explicitly granted aux/temp FTS calls retain actual component grants and module checks; all-mode/default readiness and direct content/shadow restrictions remain separate.
- Deliberately check entire reachable view definitions, including unused output expressions; normal derived content views remain supported without granting direct base access. No dependency/config/grant/version change, raw-SQL rewriting or required Agent step. Trusted schema/UDF and generated-column boundaries remain explicit.
- Final **2737 passed/four skipped**, clean type/prompt; 76 matching runtime resources and **240 source/240 installed** child-stdio calls. Matched 24-case replay removes both guarded function evaluations and all 12 qualified-call refusals; direct-adapter timing/SQL traces retain drift and limits. No new complete-model trials; after the owner restart, 8/8 frozen native checks pass (five reads, three expected refusals), with unchanged database hash and independent SQLite truth. Exact trusted-warm view/aux FTS fixtures retain source/package coverage.
- Preserve before/after failures, source/package and cost attribution; the resident supplement completes the stated source/package/native scope without rewriting earlier seals. [Current repair and evidence](docs/validation/v3.8/V3_8_2_FTS_FOLLOWUPS_2026_10_20_ZH.md). Earlier open DRR-116/117 statements below describe their preceding checkpoints.

## v3.8.2 Bound metadata estimation work (October 20, 2026)

- Implement the three approved optimizations: project authorized returned tables before estimates, batch fresh SQLite statistics, and skip transport tokenization for SQL without colons. Retain complete guarded data reads, unknown/error semantics and MySQL catalog estimates.
- Add explicit adapter directory/enrichment methods; preserve get_tables as their full-directory composition. Real extensions implement the new directory interface; no legacy interface guessing, new config/dependency or model-facing tool step.
- Record first-statistic selection, partial-index limits, 200-bind/result batches, disappearing/malformed statistics, operation-local observations and deferred analysis/catalog caches. Source/package, measured costs and resident verification status are separate in the [optimization record](docs/validation/v3.8/V3_8_2_METADATA_OPTIMIZATION_2026_10_20_ZH.md). DRR-116/117 were open at this optimization checkpoint; their subsequent repair and scoped acceptance are recorded above.

- Final **2697 passed/four skipped**, clean type/prompt, 76 matching wheel resources; **134 source and 134 installed** two-protocol calls plus 12 read-only MySQL checks. Matched timing retains contrary staged samples and separate paired follow-ups; projection/statistics work drops as asserted. After the owner restart, 9/9 frozen native checks pass (seven reads, two expected refusals), with three unchanged SQLite file hashes and independent column/count truth. Earlier native/model checkpoints retain their attribution. DRR-118 completes this scoped acceptance.

## v3.8.2 Repair read capabilities and schema scope (October 19, 2026)

- Owner-approved independent repair: narrow SQLite table-role adaptation; restore derived views and known JSON relation calls while preserving the raw subset, original SQL and all real argument dependencies.
- Bind all-mode to the default schema; unify bare/default-qualified grants across early policy, Skill declarations, readiness, metadata and SQLite compilation. Cross-schema access uses existing structured allowlists. This is an explicit pre-release contract decision, not compatibility scaffolding.
- Verify FTS5 roots, shadow identities and external-content columns outside callbacks; grant operation-scoped internal abilities without granting direct shadow/content reads. Keep module cache/lifecycle limits and trusted schema/UDF boundaries explicit; do not expand FTS repair into a ban on ordinary scans of other modules.
- Reject executing locking reads, distinguish session assignment/positional binding/non-read commands, and use specific recovery messages. MySQL bound-name display and fixed diagnostics avoid trusted-session retirement; arbitrary trusted operations/writes still retire their sessions.
- Keep SQLite authorizer always enabled: no public TOML bypass. No new runtime dependency, version bump, required Agent step or automatic DB privilege change. Read policy metadata discloses default scope; replace only the all-mode scope phrase in prompts.
- Preserve baseline/red/intermediate/environment failures and earlier sealed evidence. Final regression, package, measured costs, native restart and complete Luna tasks have separate status in the [repair record](docs/validation/v3.8/V3_8_2_READ_CAPABILITIES_2026_10_19_ZH.md). DRR-111—115 are independent of scoped DRR-108/109/110 closures.
- Source/package checkpoint: **2667 passed/four skipped**, clean type/prompt; **108 source and 108 installed stdio calls**, 76 matching resources. Read-only Oracle MySQL event checks pass. Serial matched A/B/A retains measured drift and limits; after the owner restart, 30/30 native checks and 9/9 complete two-turn Luna outcomes pass. Retain one corrected analytical draft, nine oversized catalog outputs, repeated calls and actual provider usage; not a model-cost A/B.
- October 20 follow-up audit measures B33 with 312 real MySQL stdio calls and finds two additional FTS boundaries: trusted-precompiled content-view functions and qualified named calls. Record open DRR-116/117 without changing source/configuration or relabeling earlier scoped acceptance; [status, measurements and proposed fixes](docs/validation/v3.8/V3_8_2_POSTREPAIR_AUDIT_2026_10_20_ZH.md).
- Separate SQLite metadata audit confirms a different regression with 1,080 real stdio calls and four instrumented Client calls: bounded per-table analysis/catalog preparation, estimates before truncation, and repeated statistics/transport work. Retain controlled reads; propose projecting visible returned tables before estimates, batching statistics, then measuring bounded analysis reuse. No performance implementation, DB maintenance, dependency/config change or new model-cost claim; [measurements and trade-offs](docs/validation/v3.8/V3_8_2_SQLITE_METADATA_COST_2026_10_20_ZH.md).


## v3.8.2 Repair SQLite collation and predicate continuations (October 18, 2026)

- First adapt SQLite IS/IS NOT NULL/parameter and LIKE ESCAPE right operands to expression precedence; preserve raw SQL/parameters, all dependencies, grants and authorizer checks. Retain SQLGlot 30.22.0 and v3.8.2.
- The first operand checkpoint added 100 regressions: 2375 passed/four skipped, clean type/prompt checks; matched 40-call comparison restores 26 false refusals. Source stdio 96 and independently installed 490 calls pass with 75 matching resources; no new required Agent call or model-cost A/B claim.
- Preserve the IS-only checkpoint, two corrected error-layer test expectations, ESCAPE red tests and package-tool failures. Offline final build reuses the previously verified PyPA installer with RECORD checks; fresh wheel interpreter explicitly reuses frozen dependencies.
- Preserve four pre-restart parse refusals. After the maintainer restart, **25/25 native checks** meet the frozen expectations: 20 constant reads, three policy refusals and two unchanged full five-row/five-column snapshots. Seal the restart supplement separately; close DRR-109 within this documented scope, retaining DRR-108's scoped closure. [Repair, evidence and limits](docs/validation/v3.8/V3_8_2_COLLATE_REPAIR_2026_10_18_ZH.md).

- Preserve the [adjacent review](docs/validation/v3.8/V3_8_2_PREDICATE_COLLATE_REVIEW_2026_10_18_ZH.md), then repair DRR-110 after maintainer approval: resume complete-predicate COLLATE/arithmetic/concatenation/bitwise/JSON tails with explicit grouping, without moving collation or executing regenerated SQL. Add 190 regressions; final **2565 passed/four skipped**, clean type/prompt, 130 source stdio and **524 installed calls**. Restore all 114 matched reads and 480 additional valid analysis forms. Seven pre-existing SQL-generator grouping differences retain independent original-SQL controls. After the maintainer restart, **71/71 frozen native checks pass**: preflight plus 65 semantic constants, three refusals and two unchanged five-row/five-column snapshots. Independent SQLite recomputes all 66 constant reads; raw content and structured results agree. Close DRR-110 within documented source/package and native scope, preserving the 621 earlier sealed files. Correct a copied descriptive count through a separate metadata erratum without rewriting any native data. [Repair and evidence](docs/validation/v3.8/V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md).

## v3.8.2 Final committed-source review and COLLATE limitation (October 18, 2026)

- Verify e49cd0e with a clean initial worktree: 75 accepted runtime resources and 487 prior sealed files match; 22 changed Markdown documents have 757 valid local links with committed targets. Full regression passes 2275/four optional skips; type and prompt checks pass.
- Reproduce the independent P3 in eight native observations and matched private Client cases. SQLGlot 30.22.0 rejects NULL RHS COLLATE; baseline 3323f9c accepts all 16 inputs in both modes. Right-operand parentheses work; whole-predicate parentheses can change string semantics.
- At that read-only review stage, record open DRR-109 while retaining the scoped DRR-108 closure. Update evidence links and preserve historical source attribution. That stage changes no runtime code, dependencies, tests, configuration or data and needs no restart; the later repair and completed native checks are recorded above.
- [Findings, limits and sealed evidence](docs/validation/v3.8/V3_8_2_FINAL_REVIEW_2026_10_18_ZH.md).

## v3.8.2 Repair trigger WHEN roles and diagnose Host readiness (October 17, 2026; scoped resident verification passed)

- Parse the complete WHEN expression with the existing SQLite SQLGlot parser before requiring BEGIN, preserving begin columns/CTEs/functions and checking every original condition/body fragment. Keep original SQL/parameters, grants, callback isolation and budgets; no new dependency or required Agent step. One extra expression parse applies only to prepared trigger WHEN definitions.

- Add 79 regressions: 2275 passed/four optional MySQL skips, clean type/prompt checks; all 76 matched fixture/prefix cases meet expectations, restoring 12 false refusals. Source child stdio 254 calls and installed wheel 394 targeted calls pass across both protocols. The fresh wheel interpreter explicitly reuses frozen dependencies; all 75 package resources match. After the maintainer restart, scoped native acceptance passes 57/57 with three unchanged full snapshots. The exact WHEN fixture keeps regression/package attribution; no configured trigger/UDF/plan-Skill was added.

- Host structured logs show cached catalog advertisement without waiting for startup, then omission because no exact ready client existed. Successful children also used cached catalogs; stale content/initialization/binding root cause remains unproven. Closing/resuming the same failed child restores a real call; retain the original 2/3 business result and separate a new canary argument error/correction. Independent configured stdio passes 9/9 outside the sandbox; sandbox 10/60-second failures are not evidence of the native child root cause. No global Host configuration was changed.

- Three new actual-child canaries pass, followed in those same fresh Luna contexts by two business turns each: final sales outcomes pass 3/3, while one initial unsupported FROM query is refused and recovered with CTEs (2/3 trials without a rejection). Fifteen business MCP returns, six business inputs and costs are retained; prior 2/3 Host-failure evidence is unchanged. Canary-warmed trials are not a historical A/B. DRR-108 closes within the stated source/package/native scope; 469 older sealed files remain unchanged.
- [Findings, evidence and completed scoped restart checks](docs/validation/v3.8/V3_8_2_TRIGGER_WHEN_2026_10_17_ZH.md)。

## v3.8.2 Adjacent audit and current complete Agent trials (October 17, 2026)

- Review only; runtime/configuration/dependencies/data unchanged. Reopen DRR-108 for a begin column in trigger WHEN mistaken for the body delimiter: six forms/two prefixes give 12 false refusals, while all 24 same-input cases pass on frozen pre-repair source. Twenty-eight Client calls reproduce raw/Skill failures and quoted-definition controls. Repair this role boundary before final acceptance.

- Current 76 fixture/prefix combinations include 64 expectation matches and those 12 refusals. Generated-column evaluation retains the documented trusted-schema/UDF boundary; repeated outer CTE labels remain a separate conservative limit.

- Three fresh GPT-6 Luna medium two-turn sales trials on current source pass business/fixed checks 2/3; seven SQLite table fingerprints unchanged. Keep one correct-name Host tool-unavailable failure, later empty catalogs and both incomplete turns. No cache root-cause claim. Twelve successful MCP returns do not make three complete tasks pass; verify availability in each actual trial context. Prior source/package evidence keeps its scope.

- [Findings / 问题、证据、用量及建议](docs/validation/v3.8/V3_8_2_ADJACENT_AUDIT_2026_10_17_ZH.md)。

## v3.8.2 Restore trigger-local CTE explanations (October 17, 2026; scoped resident acceptance completed)

- Reopen DRR-108 for database-less CTE count READs. Prepare verified SELECT/DML sources outside the callback, retaining owner/fragment/scope identities. Check every physical dependency before accepting a scoped ephemeral event; keep real-DML, function and ambiguous-object refusals.
- Cover WHEN, select-only/nested triggers, recursive/materialized CTEs, repeated local names across fragments/scopes/triggers, schema collisions and catalog changes. Add 129 regressions: **2196 passed/four skipped**, clean type/prompt checks, 200 source stdio and 340 independently installed calls across both protocols; rows/total_changes unchanged and restricted functions uncalled.
- After the maintainer restart, 57 acceptance checks pass: 38 plans, 13 refusals and six controls; all five rows/columns match across three snapshots. Retain all 69 native calls: ten exploratory positive expectations used an ungranted qualified form, and two reproduce the existing repeated outer-CTE limit. Distinct-label recovery succeeds; independently restored old source confirms the limit predates this repair. No configured trigger/UDF/plan-Skill fixture was added.
- Preserve pre-repair failures, the first test's empty-plan assertion error, intermediate shared-name refusal and sandbox-limited runs. Also retain an invalid preliminary snapshot comparison caught by resource hashes; historical probes must verify the actual loaded package path. Serial A/B/A records extra catalog/compile work; no zero-cost/model-token claim. Version/dependencies/configuration/grants/approval/required Agent calls stay unchanged. [Decisions, evidence, costs and coverage](docs/validation/v3.8/V3_8_2_TRIGGER_CTE_2026_10_17_ZH.md); earlier native 42/42 retains its tested source, and 362 sealed files remain unchanged.

## v3.8.2 Complete trigger and dialect explanation plans (October 17, 2026; scoped resident acceptance completed)

- Reopen DRR-108 for authorized trigger READ, WITH REPLACE and UPDATE OR gaps. The latter regresses baseline all mode, while baseline allowlist already refused. SQLite statement dispatch and UPDATE-role parsing preserve original SQL/parameters and lexical identities.
- Verified non-executing plans check actual trigger read grants. Missing count bindings/view edges abort preparation; fixed catalog work runs outside the callback under one lock, deadline and cumulative budget. Shared analysis checks required trigger WHEN/body dependencies before accepting source-lost view counts, preventing direct bases from borrowing view grants. Ambiguous roles remain refused.
- Add 101 regressions: **2067 passed/four skipped**, clean type/prompt checks; 342 same-input Client observations, 140 current-source and 272 installed-wheel real stdio calls meet scoped expectations, with unchanged private data and zero restricted-function calls. Serial A/B/A separates ordinary reads from newly successful plans; no model-token/zero-overhead claim. Final wheel/native state and costs are in the [follow-up report](docs/validation/v3.8/V3_8_2_EXPLAIN_FOLLOWUP_2026_10_17_ZH.md). Preserve failures and source attribution. No version/dependency/configuration/approval/required Agent-step change.

- After the maintainer restart, **42/42 native checks** meet expectations: 26 plans, 12 refusals, preflight/metadata and two full snapshots. All five rows/five columns stay identical. Native trigger/UDF/plan-Skill fixtures were not added to configured databases; those cases retain matched-source regression/installed coverage. Append resident evidence separately, preserving the parent pending checkpoint and all earlier failures.

## v3.8.2 Guard view-backed metadata reads and restore explanation plans (October 17, 2026)

- Confirm two P2 review findings with independent fixtures. Sample, exact counts and SQLite data-based estimates now use controlled reads; fixed catalogs/statistics remain trusted. Denied estimates return null while columns/indexes stay usable. Check configured grants before estimating an object, including directory callers that filter after enumeration.
- Preserve ordinary view counts by checking every analyzed root before accepting a unique source-less count edge from the authorized view graph. Do not grant direct base access. Replace the unsupported estimate template with a bounded CTE/marker count; retain the 10000-row cap and avoid reserving the selected object's business name.
- Bind structured EXPLAIN payloads to original SQL/context. Admit only verified DML-plan compilation events, checking actual targets and restricted functions; keep real writes, ungranted trigger targets, PRAGMA/DDL/ATTACH and reused-plan contexts refused. Repair adjacent SQLite REPLACE-plan parsing without rewriting execution SQL.
- Seventy new regressions; final **1966 passed/four skipped**, clean type/prompt checks. Real child-stdio before/after checks, independently installed package checks, source hashes and 12 configured-MySQL read-only checks are recorded in the [repair report](docs/validation/v3.8/V3_8_2_READ_BOUNDARIES_2026_10_17_ZH.md). After the maintainer restart, 28/28 native checks meet expectations: nine DML/REPLACE plans, metadata/CTE counts and twelve refusal controls; five-row/five-column snapshots remain identical. This Host does not expose sample/table_summary, so their cross-entry fixtures retain installed/regression coverage. Retain intermediate parser/count failures and sandbox-limited runs; prior Luna/model/cost evidence keeps its tested-source attribution. No version, dependency, configuration, approval or required Agent-step change. DRR-2026-107/108.

## v3.8.2 Name semantics, SQLGlot and SQLite authorizer (October 16, 2026; approved-scope acceptance completed)

- The maintainer approved implementation from 3323f9c: contracts/matrix, connection semantics, separately validated AST and authorizer integration, then full acceptance. Target version is 3.8.2. Retain RelationReference, independent grants and original SQL/parameters; add structured declarations and role-specific name semantics. Existing real string declarations remain shorthand, without hypothetical legacy migration layers.
- The [design and decisions](docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md) cover complete MySQL session-mode initialization per physical connection, trusted-extension session ownership, SQLite exclusive use, view/CTE sources, caches and cleanup. A view grant does not authorize direct reads of its bases; incomplete analysis is not an empty dependency set.
- Pin SQLGlot 30.22.0; retain other locked versions. Adapt original-token ASCII vocabulary, contextual SQLite names and non-executing MySQL explanation forms. Preserve discovered parser limitations and intermediate failures; parsing success is not proof of database semantics.
- Separate identifier rendering from SQLAlchemy bind interpretation. Bind actual placeholders only; protect literal/name/comment colons while restoring original driver content. Metadata stays parameterized and schema-bound. Transaction outcomes, preview tokens, approval and auditing remain independent.
- Baseline: 1750 passes/four skips. Initial implementation: **1881 passed/four skipped**, clean type/prompt checks, 48 installed child-stdio semantic calls on both protocols plus generic wheel/CLI/resource checks (75 matching resources). Native SQLite matrices, eight MySQL mode combinations and two private pool lifecycle variants pass within the [reported scope](docs/validation/v3.8/V3_8_2_VALIDATION_2026_10_16_ZH.md). Retain intermediate parser, fixture and offline-explain failures. Serial costs are measured separately. After restart, Host canaries passed 10/10 and 12 fresh Luna trials completed 36 turns: 11/12 fixed checks, with one mismatch against the currency-precision tie reference retained (the task did not explicitly prescribe rounding before ranking). No configured data changed. Do not relabel this source or historical v3.8.1 evidence.
- The sales trial exposed a real materialized-CTE COUNT(*) false refusal: SQLite emits an empty-column/NULL-database READ for the CTE itself. Accept only unique declared labels absent from all attached catalogs, keep physical/function checks and ambiguity refusals, and retain the original recovered trial. Fifteen new regressions bring current full validation to **1896 passes/four skips**; type/prompt, 58 installed semantic calls and 75 resource hashes pass. The source adapter now returns all 11 independent-truth rows in one call. After the final maintainer restart, 5/5 native checks pass, including the exact original 11-row query and both refusal controls. Three fresh two-turn sales trials are retained: 2/3 meet the explicit business request; the strict numeric checker is 1/3 because one additional optional figure is absent. The remaining trial stopped on a misspelled function namespace, then recovered only the changed-scope task; this is not a client-binding failure. All 14 actual MCP calls succeeded, data stayed unchanged, and original failures are not replaced. DRR-2026-100–106 record scope and tradeoffs.

## v3.8.1 Group validation reports by version (October 15, 2026)

- Move all 18 V3_8*.md validation reports into docs/validation/v3.8/, following the existing v3.7 layout. Use git mv for the seven tracked files; move the eleven untracked reports without inventing history. Git detects all seven renames after link updates.
- Update incoming documentation references and rebase outgoing report links to sibling reports, raw evidence and other documentation; keep headings and report conclusions. Current entry points are the [validation index](docs/README.md#releases-and-validation) and the [v3.8 directory](docs/validation/v3.8/). Historical JSON/log/archive bytes and captured paths remain original records.
- Check local links and rename detection; 637 evidence files and 116 production/test hashes are unchanged. No runtime, dependency, configuration or version change; prior 1750-test/native-20/20 evidence retains its source attribution. No database/MCP restart or new test run is needed. git mv stages only its seven moves; new documents and link edits remain for the maintainer's complete commit.

## v3.8.1 Shared CTE structure, relation targets and readiness (October 15, 2026)

- Close the reproduced DRR-2026-098 functional gap using a bounded shared structure interface in core/structure.py. Original leaves identify names/columns, AS, materialization, balanced bodies and the main command; classification and scoped relation/dependency analysis reuse it. Do not rely on optional Identifier grouping or rewrite executed SQL. Preserve schema/name, target-specific case, declaration order and explicit recursion.
- Distinguish actual relation-name leaves from body/main DML and calls; declaration exclusions never include query bodies. Adjacent checks also repair like/regexp operator-labeled names, comma-target replace and WHERE groups split before Unicode IN operands. Raw reads, Skill loading/discovery/detail/execution and readiness now agree for the tested forms, including quoted column lists.
- Add 188 dedicated regressions and two write controls; update old classification/WHERE assertions. Final **1750 passed/four skipped**, clean type/prompt; 56 matching-input Client checks, 96 installed CLI/stdio checks with 70 resource hashes, and 24 real MySQL checks against independent native validity. The 300 valid functional matrix cases pass both scopes; 542 physical-name and 1000 relation-context cases show no scope misses or approved refusals; 576 harmless function fixtures remain denied.
- Record DRR-2026-099 and [scope, costs, failures and evidence](docs/validation/v3.8/V3_8_1_CTE_ANALYSIS_2026_10_15_ZH.md). Serial policy A/B/A p95 is 13.12/17.71/16.15 ms, with baseline drift and additional analysis work; no speedup, unchanged latency or model-token claim. Preserve interrupted sandbox and obsolete-expectation runs. Version stays 3.8.1; no configured database writes, configuration/dependency edits, complete production AST/authorizer, new tool step or commit. After the maintainer restart, 20/20 native checks pass with matching text/structured results: the first ten exact baseline inputs plus ten adjacent/refusal/MySQL/ordinary-Skill controls. Preserve the preceding refusal checkpoint and source/model attribution; CTE-specific Skill readiness remains private Client/installed evidence, not a new configured native Skill test.

## v3.8.1 Ambiguous WITH diagnostics and explicit CTE limits (October 15, 2026)

- Independently confirm native SQLite reads for seven unquoted keyword-like CTE names that sqlparse classifies UNKNOWN. Current Codex native results match pre-change source, and the maintainer clarified prior restart acceptance is complete; this is a shared existing functional limit, not evidence of stale MCP.
- Preserve denial for unclassified WITH and return sql_parse_failed with same-connection identifier-quoting/simplification guidance. Keep read_only_required and explicit write-approval guidance for known writes. Do not treat a WITH prefix as proof of a safe read or claim bare-name support is repaired.
- 43 new regressions; 1560 full passes/four skips, clean type/prompt, 76 matching-input Client calls per stage, 76 installed CLI/stdio and 12 current-source MySQL checks. Forty-seven source-attributed cases show no acceptance changes; 38 have independent native read truth. Two hash-verified earlier classifiers also reject these names under current dependencies.
- Record DRR-2026-098 and [findings, open functional scope and evidence](docs/validation/v3.8/V3_8_1_CTE_CLASSIFICATION_2026_10_15_ZH.md). Only sql.py changes in production; version remains 3.8.1, no configured database/configuration/dependency writes or commit. After the maintainer restart, all eight identical inputs and two controls match the new source, 10/10, with matching text/structured results; functional unquoted-CTE support remains open. Preserve previous source/model attribution and old native observations.
- Post-restart assessment adds 314 selected candidates/304 native-valid reads, 56 private Client observations and nine native impact observations without production/test changes. Ordinary data/summary/result/rollup CTE names, quoted declaration column lists, specific harmless comment positions and replace(n) declarations can fail. Quoted column lists also create false Skill readiness dependencies in all mode. Preserve ten expected tool errors in the Client observations and one initially overbroad comment expectation. Recommend a bounded shared-CTE-analysis repair soon, prioritizing business syntax/dependency consistency before optional materialization support; complete production AST/authorizer is not a prerequisite. This is a recommendation, not completed grammar support or a measured workload error rate.

## v3.8.1 Keep reserved calls visible inside CTE bodies (October 15, 2026)

- The preceding lexical patch passed 10/10 native checks after the maintainer restart. Further native-fixture review reproduces an omission: sqlparse can group a quoted CTE column list and AS/body into one Identifier, and the declaration exclusion masked its body from function checks.
- Hash-verified source reconstruction distinguishes origin: lock/delay calls already had this defect; the previous DRR-2026-096 scanner consolidation extended it to file/account calls. Fix the underlying exclusion boundary rather than relabeling all cases as old issues. Exclude original leaves only before the declaration-level AS, tracking parentheses.
- 132 new regressions; 1517 full passes/four skips, clean type/prompt checks, 80 identical-input Client calls per stage, 80 installed CLI/stdio and 12 real MySQL checks. The harmless-UDF matrix closes all 96 previously admitted combinations; 576 total cases stay denied with earlier shape refusals distinguished. Another 1000 relation-context cases and the repeated 542-case matrix show no further scope omission.
- Record DRR-2026-097 and [source attribution, remaining limits and evidence](docs/validation/v3.8/V3_8_1_CTE_HEADER_2026_10_15_ZH.md). Only policy.py changes in production relative to the accepted predecessor; retain version 3.8.1, previous native/model evidence and known conservative grammar/readiness limits. After the maintainer restart, identical native probes and positive controls passed 10/10; content and structured results agree. Earlier refusals remain recorded without a cache root-cause claim. No configured database write, dependency, tool step, production AST/authorizer or commit.

## v3.8.1 Lexical relation boundaries and quoted reserved calls (October 15, 2026)

- Close the preceding Unicode patch's native restart acceptance at 6/6. Further audit reproduces a P1 omission: contextual keyword table targets and Unicode lookalikes can disappear from the relation scan, admitting an unapproved read. Resolve target positions before clause boundaries and retain each structured relation.
- Compare SQL vocabulary from original token.value with ASCII-only folding; sqlparse normalized already performs Unicode uppercasing. Apply this to statement/CTE/read structure and the EXPLAIN expression. Reuse actual-call recognition for existing file/account reservations across identifier quoting, preserving literals, columns and CTE declarations.
- 107 new regressions; 1385 full passes/four skips, clean type/prompt checks, 68 identical-input Client calls per stage, 68 installed CLI/stdio calls and 12 current-source real MySQL checks. A bounded 97-name/542-case native audit finds no further unapproved-scope omission; 18 conservative unquoted refusals have verified quoted recovery. These are bounded results, not complete dialect coverage or measured model costs.
- Record DRR-2026-096 and [source-attributed evidence and remaining parser limits](docs/validation/v3.8/V3_8_1_LEXICAL_BOUNDARIES_2026_10_15_ZH.md). This patch changes only policy.py/sql.py in production; no configured database writes, dependencies, tool steps or production AST/authorizer. After the maintainer restart, all four identical native probes returned the expected policy refusals; Unicode/CTE, real MySQL and existing Skill controls also passed, 10/10 total. No cache root cause is inferred. Preserve the previous six passes and failed/intermediate test observations separately. Version remains 3.8.1; no commit created.

## v3.8.1 ASCII reserved-name comparisons and documentation navigation (October 15, 2026)

- Independently reproduce P2 PRAGMA false refusals for distinct pragma_locKing_mode/pragma_locking_mode through FROM and SQLite IN. Adjacent audit also reproduces current_uſer/current_user column conflation by Unicode uppercasing. Use the existing ASCII folding helper for PRAGMA names, account-name checks and four internal parser defaults; actual ASCII reservations stay denied before execution.
- Keep metadata identifier syntax, read grants, tool schemas, dependencies and prompts unchanged. Keyword/configuration-label/search normalization serves different purposes; avoid a mechanical project-wide replacement. No production AST/authorizer expansion.
- 56 new regressions, 1278 full passes/four skips, clean final type/prompt checks, 26 matching-input before/after Client calls per snapshot and 26 installed CLI/stdio calls across both modes. Preserve initial environment/type/stdio failures and the corrected constant-CTE probe. After the maintainer restart, the same three corrected native probes, two real ASCII-reservation controls and the existing report Skill passed 6/6. Earlier refusals remain recorded; no cache root cause is inferred.
- Remove four dated review notices from each root README and six from each documentation-index header. Put decisions/history in these logs, user-facing summaries in release/changelog sections and dated evidence under the validation index. Retain all prior evidence and its source attribution; earlier Luna usage is not remeasured for this patch.
- Record DRR-2026-095 and [findings, decisions and evidence](docs/validation/v3.8/V3_8_1_UNICODE_POLICY_2026_10_15_ZH.md). Only policy.py changes in production relative to the preceding accepted snapshot. Version stays 3.8.1; no configured database/configuration writes or commit.

## v3.8.1 Complete Agent business-task acceptance (October 15, 2026)

- Freeze four business scripts and independent truth before trials; use fresh GPT-6 Luna medium contexts with native SQL MCP, after a separate successful subagent preflight. Three trials per script complete 36 user turns and 110 observed MCP returns. Final business and scope checks pass 12/12; efficiency and wording are graded separately.
- Cover 720-row quarterly analysis and scope changes, 80-order/204-line financial reconciliation and join inflation, ambiguous/multi-connection reports with exact-alias correction, and rejected status recovery followed by preview and cancellation. Seven SQLite table fingerprints and MySQL aggregate checks remain unchanged; no actual writes.
- Retain floating-point self-corrections, seven empty Skill searches (including category/type confusion), three early additional reset previews, 38 local catalog calls and 13 catalog-output truncations. Preserve conservative wording that underuses existing readiness evidence. No runtime prompt/code repair is inferred from these observations.
- Record 161 Host model responses, input 5,647,244 (cached 5,272,320), output 37,072 and active-turn time 648.294 seconds. These include Host/tool-discovery overhead; no matched historical A/B, invoice-cost improvement, server-latency benchmark or general reliability claim. Actual write/rollback/conflict/expiry/MRTR and anomalous-money fixtures remain separate.
- Add reusable capture/check scripts, compressed public traces with bearer redaction, bilingual entry points and [acceptance evidence](docs/validation/v3.8/V3_8_1_AGENT_REAL_TASKS_2026_10_15_ZH.md). The accepted 69 production resource hashes remain unchanged; retain version 3.8.1 and prior dated evidence, without rerunning the already accepted production suite or creating a commit.

## v3.8.1 Literal SQLite prefix and dialect-specific guarantees (October 15, 2026)

- Confirmed two adjacent omissions: unescaped LIKE underscore filtered legitimate SQLite tables/views, and three current guide paragraphs overextended SQLite temporary-object isolation to MySQL. Both belong to this repair scope; version stays 3.8.1.
- Share a literal first-seven-character sqlite_ predicate with ASCII NOCASE across table and relation directories. Keep authorized sqliteXorders/SQLITEXorders and short sqlite; retain true internal-object exclusion and table-only discovery. No read grant, identifier grammar, tool parameter or runtime dependency change.
- Qualify README EN/ZH and configuration guidance: SQLite selects main without temp/attached replacement; MySQL binds the configured database but same-session temporary tables can still hide permanent objects. Session lifecycle/isolation remains separate.
- 12 new regressions, 101 focused passes/three skips, 1222 full passes/four skips, clean type/prompt checks, 72 matching-input before/after Client calls and 84 outside-repository installed CLI/stdio checks. After the maintainer restart, 16/16 configured-tool native checks passed; the special prefix fixture remains isolated-test evidence, and earlier 20/20 stays attributed to prior source. The unchanged 69 production/41 test resource hashes match the accepted snapshot; this is not loaded-code attestation. DRR-2026-094 and [evidence](docs/validation/v3.8/V3_8_1_SQLITE_PREFIX_2026_10_15_ZH.md).
- Compress the full commit draft from 25 to seven grouped bullets, retaining major correctness, validation and scope decisions; preserve the old draft and detailed evidence. No live database/config writes or commit.

## v3.8.1 Internal schema binding and relation readiness (October 15, 2026)

- Approved follow-up repairs retain version 3.8.1. Bind decoded metadata-tool names to one RelationReference; authorize and render the same schema/name for sample and exact counts. SQLite main remains selected despite temporary tables/views; absent main objects never fall back to attached schemas. MySQL metadata predicates bind the configured database rather than session DATABASE().
- Add ReadRelation and a table/view existence observation for readiness, separate from table-only discovery and row estimates. Authorized views work through discovery/detail/execution; dotted names stay distinct and other schemas remain unverified. New adapter implementations must provide the explicit scope/observation contract; no hypothetical old adapter compatibility layer.
- Share strict mutation validation-result checks across preview and imperative confirmation: bool valid, string-list errors, serializable business fields. Invalid returns use a fixed validation_failed/not_executed result; preview issues no token and confirmation still consumes/rejects replay. Trusted Python effects remain outside this guarantee.
- 48 new regressions and 1210 full passes/four skips, clean Pyright/prompt checks, 60 installed stdio calls and 18 read-only real MySQL calls; 20/20 configured-tool native checks passed after the maintainer restart. Record DRR-2026-091–093 and [evidence/limits](docs/validation/v3.8/V3_8_1_SCHEMA_BINDING_2026_10_15_ZH.md). Earlier batches and failures are preserved. AST/authorizer, session lifecycle isolation and old env/launcher/SDK/hypothetical-caller compatibility remain outside this patch; no new Agent step or measured model-cost claim.

## v3.8.1 Structured relation identity and mutation revalidation (October 15, 2026)

- Independently reproduced all three review findings in 38 isolated Client calls against the October 14 source. Preserve schema/name boundaries in RelationReference throughout policy, Skill inference and schema readiness; only render strings for disclosure. The first dot in configured/declarative strings separates schema/name; SQL uses lexical components. Do not silently grant a dotted single name through a qualified grant.
- Bind readiness/metadata to SQLite main or the configured MySQL database. Qualified grants can discover/describe the correct current-schema table; literal dotted tables cannot satisfy another dependency. Other schemas report unverified_tables instead of false missing_tables. Full entries expose readiness scope flags and both arrays; full return sizes can grow, with no new Agent calls or runtime dependencies.
- Convert adapter-sanitized execute-time validation errors to strings. Return validation_failed/not_executed with consumed-token metadata, reject replay, and never restore a consumed token automatically. Preview error conversion is also explicit.
- 48 new regressions; **1162 passed, 4 skipped, 40 logging-path warnings**, clean Pyright/prompt checks. Non-editable outside-repository wheel: 69 verified package files, 36 stdio calls in both Client modes. Real configured MySQL: 12 read-only/metadata calls with an isolated catalog/policy, no live writes/config edits. Failed harness/mock/sandbox trials are retained. After the maintainer restart, 18/18 primary native read-only checks passed; the changed refusal matches the repaired source and full Skill scope fields are present. Earlier old-policy evidence remains unchanged.
- [Acceptance, declaration examples, costs and evidence](docs/validation/v3.8/V3_8_1_RELATION_IDENTITY_2026_10_15_ZH.md); DRR-2026-088–090. Version remains 3.8.1; production AST/authorizer and hypothetical legacy migrations stay out of scope. Historical 1114-test/native/Luna evidence is unchanged; no new model-cost claim or confirmed cache root cause.

## v3.8.1 Complete pre-commit review and quoted identity follow-up (October 14, 2026)

- Reviewed the full pending patch against af3420f, including raw/Skill policy, typed read/metadata errors, mutation error adaptation and documentation. Reproduced two remaining object-identity defects: whole-string whitespace compression merged distinct quoted names, and decoding get_real_name() again conflated quoted delimiters or retained escaped delimiters incorrectly.
- Normalize whitespace/comment tokens with sqlparse formatting and decode original lexical identifier components exactly once. Preserve physical spelling and explicit qualification; CTE aliases use the same decoding. Native SQLite truth plus 25 new regressions cover repeated whitespace, tabs/newlines, embedded/doubled delimiters, exact grants and raw/discovery/readiness/Skill execution on both protocols.
- Documentation supplement: the distinct `" f "` / `"  f  "` physical-table reproduction is SQLite evidence. [MySQL's identifier rules](https://dev.mysql.com/doc/refman/8.0/en/identifiers.html) forbid database/table/column names ending in spaces; this is not a universal restriction on every identifier role. Record dialect-specific interpretation separately from project authorization and retain significant quoted contents. The [proposed architecture](docs/architecture/V3_8_IMPLEMENTATION_ZH.md#引用名方言边界与后续架构建议2026-10-14) is a future design, not an implemented dialect validator or approval to begin production AST/authorizer integration. This supplement changes documentation only, not prior source/test evidence.
- Final source: **1114 passed, 4 skipped, 17 existing-path logging warnings, 117.51 seconds**; MySQL opt-in disabled. Pyright/prompt contracts passed; current non-editable outside-repository sdist/wheel validation passed 22 stdio calls across both protocols. The 52-case SQLite/current-MySQL policy matrix remains unchanged; serial before/after/return sampling passes the prior exploratory p95 gate. No model cost or production AST/authorizer claim is added.
- The previous 1089-test/native-Luna snapshot is retained. Final identity-patch evidence is separately indexed in the [acceptance supplement](docs/validation/v3.8/V3_8_1_PHASE123_2026_10_14_ZH.md#提交前完整复核与补修2026-10-14). After the final maintainer restart, 11/11 primary Host native checks passed, including the changed whitespace refusal, quoted/escaped CTE successes, Unicode identity, function policy, MySQL case matching and ordinary Query Skill behavior. The earlier old-policy probe is retained. A sandbox-stalled focused test was stopped; the opt-in-disabled full run then passed in the approved environment.
- Update the local Git-ignored collaboration guide's actual prompt location and MCP preflight preference; mark historical adapter/Skill API snippets explicitly rather than rewriting their history. Split the three approved phase records, keep version 3.8.1 and DRR-2026-080–087, and retain deferred dialect/authorizer/AST boundaries. The maintainer first chose the report, then completed the final manual restart; source hashes still match the 1114-test/install snapshot.

## v3.8.1 CTE matrix, read-function limits and SQLGlot experiment (October 14, 2026)

Maintainer approved phases 2 → 4 → 3. Each task is recorded separately below; common validation belongs to this batch. Production AST/SQLite authorizer work remains a separate next phase. Version stays 3.8.1; prerelease compatibility scope is unchanged. [Acceptance and evidence](docs/validation/v3.8/V3_8_1_PHASE123_2026_10_14_ZH.md).

### CTE dialect matrix and cost baseline — completed

- Native SQLite 3.45.1 and Oracle MySQL 8.0.25/lower_case_table_names=1 matrix has 52 native/policy cases. SQLite forward/implicit recursion differences are recorded; current conservative production semantics remain. Other settings/MariaDB are untested as agreed. Only private SQLite fixtures were written; MySQL reads existing orders/constants/version settings.
- Frozen source and matched queries support serial A/B/A after the full regression completed. Each stage has 480 policy samples; each protocol's fixed Client sequence has 12 repeats. Policy p95 meets the exploratory gate. Fixed instructions/tool metadata remains 22681 characters per protocol; noisy Client drift and changed error outcomes do not prove end-to-end speed.
- Initial Luna tool failures are retained. Six required native CLI A/B tasks passed, three per stage and three MCP calls each. Uncached input/output grew despite lower total input, so no billing-savings or general no-regression claim. Recording scope and unavailable server variants are tracked in DRR-2026-087.

### Lock and expensive-function policy — implemented and accepted

- Actual GET_LOCK/RELEASE_LOCK/RELEASE_ALL_LOCKS calls return lock_function_denied; SLEEP/BENCHMARK calls return expensive_function_denied. Shared raw/Query Skill checks refuse them before capability/readiness/business I/O on both backends.
- Data, ordinary columns, quoted/Unicode identities and CTE column declarations are preserved. Startup quarantines unsafe templates; cached execution independently checks. There are 47 new regressions, including rejection before adapter I/O and legitimate same-name forms.
- This is a narrow reserved-call rule, including custom/schema-qualified calls with these names. No full function whitelist, bypass switch, new trusted operation or write behavior change; normal reads still take one MCP call. DRR-2026-085 records the remaining scope.

### SQLGlot feasibility validation — experiment completed

- SQLGlot 30.22.0 verified pure-Python wheel is isolated to the experiment. The 52-case matrix and 11 additional cases inform projection of scoped physical names, functions, CTEs and parameters; SQLite IN fields require project-specific handling. Opaque SQLite EXPLAIN and virtual relations require adapters.
- Five fresh processes measured median extra import about 119.87 ms and peak RSS +10292 KiB. Candidate projection is not full authorization; these figures do not establish production policy speed or complete MCP startup cost.
- Continue with a separate production-integration design; do not replace the current parser from this experiment alone. No runtime dependency/lock change, AST execution/SQL rewriting or production authorizer registration. DRR-2026-086 records the candidate and deferred production decision.

### Common validation and Host availability

- 1089 passed, 4 skipped, 14 warnings; Pyright/prompt contract and outside-repository installed wheel on both protocols passed (12 calls).
- After the maintainer restart, 13 primary Host native checks passed: seven structured refusals and six successful reads/discovery, including both CTE case queries and the ordinary SQLite Query Skill. Tested production source hashes remain unchanged.
- Subagent failures establish missing or non-callable tools at the observed time; they do not establish that visible tool names lacked a ready/bound MCP client. The same internal agent later acquired ten tools and queried successfully. Isolated startup measurements exceed the documented optional catalog grace, supporting a startup/snapshot hypothesis without proving the internal subagent path or a specific race. Task-local required=true/startup_timeout_sec=60 was verified in all six controlled trials; global configuration and Host implementation were not changed.
- DRR-2026-085–087 and bilingual docs are synchronized; prior failure records remain intact.

## v3.8.1 External review follow-up and typed query failures (October 13, 2026)

- The maintainer approved the repair plan, including structured policy decisions and typed query exceptions; version stays **3.8.1**. The project is unreleased: old dotenv, launch-entry and SDK migration compatibility, and hypothetical historical callers are outside this round. Report better designs with their benefits, affected interfaces and validation scope; test the Hosts and extensions actually in use.
- SQLite bare IN/NOT IN relations, qualified targets and identifiable membership virtual-table functions now participate in shared table/PRAGMA checks. Declaration-order and explicit-recursion CTE visibility remain authoritative. Authorized supported syntax is retained without SQL rewriting; unresolved shapes fail closed.
- `PolicyDecision` carries allowed/error_code/message/hint. Token checks avoid UNION/FROM literal false positives and distinguish statement refusals. Skill inferred dependencies reuse scoped extraction; discovery and execution share decisions, and execution checks policy before schema readiness. October 13 supplemental verification found a SQLite CTE case mismatch creating false Skill dependencies; the October 14 implementation below closes that reproduced boundary.
- Read adapters return row lists or raise `DatabaseQueryError`, classified using driver codes/SQLite prefixes into fixed public categories. Raw queries, Query Skills, sampling and exact counts are updated; internal metadata failures remain `MetadataQueryError`. Query Skill SQL/policy failures are structured `success=false` business results, rather than protocol ToolErrors. Parameter/target/Skill-scope/readiness failures still use operation errors. Mutation transaction outcomes remain separate; shared sanitizer results are converted to safe text for write handling.
- Live Oracle MySQL 8.0.25/lower_case_table_names=1 confirms the conservative F/f CTE refusal and correct physical-table checks for nonrecursive self/forward references. At the October 13 stage, exact CTE matching and a case hint were retained; October 14 replaces this fallback for measured ASCII rules. Other MySQL case settings and MariaDB remain unverified. An isolated SQLite authorizer prototype shows that denying only the underlying table misses PRAGMA virtual-table metadata; production integration requires a separate lifecycle/cache/internal-operation design.
- Frozen af3420f baseline: 941 passed, 4 skipped, 6 existing legacy logging warnings. Final checks: **1002 passed, 4 skipped, 7 warnings**, Pyright clean, sdist/wheel and installed-wheel stdio on both protocols passed. See [acceptance and evidence](docs/validation/v3.8/V3_8_1_FOLLOWUP_2026_10_13_ZH.md) for final checks and resident-Host restart status. Initial migration failures and three native GPT-6 Luna baseline trials are retained. Static character counts and nine-commit measurements are not this patch's billed-token savings.
- After the maintainer restart, native Host descriptions/results match the new contract. Nine host probes passed, including Query Skill business-policy refusal. Three identical-prompt GPT-6 Luna tasks passed, 4→3 MCP calls each; input-token mean +2.7% and median +5.4%, with differing discovery/batching, so no cost improvement or no-regression guarantee is claimed. Source hashes unchanged; only documentation/evidence changed after restart. No database writes or git commit.
- Later maintainer-authorized targeted checks: **4 passed, 0 skipped** live MySQL opt-in tests, including one committed and one rowcount-mismatch rollback in a conditional race. Only one unique new table was written and removed, with independent absence verification; existing business rows were untouched. Twenty Client calls across both protocols and read scopes reproduced the unresolved F/f CTE dependency defect: allowlist denial and all-mode missing-table readiness. This was then prioritized and fixed on October 14. Isolated authorizer cache/view/count probes and fixed-sequence costs are recorded; production candidates remain unimplemented. Keep existing JSON as agreed; index new evidence, store metadata once with hash references and retain compressed raw logs. Fixed metadata grew 352 characters and three structured responses grew a net 32 characters, not measured model tokens or billing. See the same [acceptance record](docs/validation/v3.8/V3_8_1_FOLLOWUP_2026_10_13_ZH.md#追加定点验证与待修边界2026-10-13).

- October 14 implements target-specific CTE dependencies: tables retains declarations; cached inference is selected per target and full Query Skills expose both origins, aligning table search/readiness/execution. MySQL measures ASCII comparison with a table-free constant duplicate-name probe only for authorized ambiguity; cache success, clear on close, and keep exact on unknown errors with a 30-second retry. Preserve physical/qualified/self/forward grants. SQLite ASCII identity, significant quoted whitespace and table declarations are aligned independently from tags. No legacy wrapper; DRR-2026-081 closes the reproduced boundary and 083/084 are added. Lock/delay policy remains advice; authorizer/AST unimplemented.
- New JSON records declare recording levels/omissions; compression and referenced snapshots preserve captured originals, while application results are not a full JSON-RPC capture. Model-cost trials must retain all actual model-visible discovery. Historical JSON/Luna usage remains unchanged and is not October 14 source evidence. Current automation/live/install/resident-Host status is in the same acceptance record; no git commit created.
- October 14 final acceptance: **1042 passed, 4 skipped**, four separate live MySQL tests passed, Pyright/prompt contracts and both-protocol installed-wheel checks passed. Current resident metadata and ten read-only native calls passed; retain the earlier old-Host observation. Resident MySQL uses all mode and existing Query Skills lack CTEs, so allowlist/CTE-Skill claims rely on the isolated live Client matrix. No new model trial or assistant restart.

## v3.8.1 Final acceptance after maintainer restart (October 12, 2026)

- The current Host's registered write description matches final source; malformed-field and missing-rowcount replays using that metadata passed 3/3 each. Production MRTR remains disabled; no native MRTR UI claim is added.
- Three GPT-6 Luna native tasks correctly read both databases' indexes and made previews without executes. Complete recovery routes were correct 2/3; one skipped confirmed, then acknowledged and corrected it on follow-up. The original failure is retained, and an actual pending-to-shipped preview returned validation_failed/not_executed. Category/type confusion added two empty searches to another run; calls/usage are recorded without a historical cost guarantee.
- Existing order checkpoints are unchanged. Source hashes still match the previously validated 941-test/wheel snapshot; this continuation changes evidence/docs only. All required checks ran with current permissions, without Full access. See [restart evidence](docs/validation/v3.8/V3_8_1_REVIEW_2026_10_12_ZH.md#手动重启后的最后检查已完成).

## v3.8.1 Five-commit review completion (October 12, 2026)

- Reviewed `f50b010` through `09c3b9a`, the four external reviews and the existing uncommitted fixes. Version remains 3.8.1. The later approved design keeps automatic indexes without a switch; it adds metadata work and disclosure within authorized table scope.
- Fixed quoted PRAGMA object checks while allowing ordinary business identifiers; CTE visibility follows declaration order and explicit recursion. Unsupported relation groups, single-quoted objects and ODBC/TABLE forms are rejected before database access. MySQL Skill readiness now uses the connection's exact table identity. These are conservative SQL-subset decisions, with limitations recorded in DRR-2026-075/076/078.
- Pinned SQLite metadata to main; preserved key direction/collation, MySQL prefix length and optimizer visibility. Whole-index collection is bounded to 128 indexes, 2048 key parts and 64 KiB UTF-8; unavailable indexes do not remove column metadata. Time limits are cooperative. MySQL 5.7 visibility fallback is mocked, while live comparison used 8.0.25 (DRR-2026-077/079).
- Both write tools independently render one packaged result-guidance resource. Final wording checks validity before outcome and explicitly reports missing row counts. Independent malformed-field replays improved from 0/3 to 3/3 for ordinary writes; simulated MRTR also passed 3/3. Earlier batch failures remain recorded. Descriptions are 3,546/2,642 characters; their added context cost is not represented by the historical +159-token measurement.
- Final validation: **941 passed, 4 skipped, 6 legacy logging warnings**; Pyright zero errors/warnings; explicit MySQL adapter subset 15 passed (including existing live checks); sdist/wheel build and installed-wheel stdio checks on both protocols. Live MySQL/SQLite index fixtures were cleaned up. Three GPT-6 Luna runs each verified native index, aggregate and preview-only recovery tasks without existing-row writes; usage is reported without an unmatched historical performance claim.
- At the pre-restart checkpoint, source/package acceptance and documentation were complete, while native prompt refresh/behavior was pending at the maintainer's request. That refresh check is now completed in the preceding restart entry. No new remote CI or native MRTR UI acceptance is claimed. See the [complete evidence and remaining limits](docs/validation/v3.8/V3_8_1_REVIEW_2026_10_12_ZH.md).

## v3.8.1 Server-state reads, MySQL table-name case and structured indexes (October 3, 2026)

- Fourth 3.8.1 update; version unchanged. Started from a proposal to allow limited raw SHOW in `query()`; the proposal was replaced by structured index metadata in `describe_table()`, and raw SHOW stays rejected. It will be evaluated separately only on a concrete compatibility need.
- The shared read policy rejects `@@` system variables, `USER`/`CURRENT_USER`/`SESSION_USER`/`SYSTEM_USER`/`CURRENT_ROLE` and SQLite `pragma_*` table-valued functions, by SQL token so literals and quoted identifiers are unaffected. Verified beforehand that the MySQL 8.0.25 test server exposed host name, data directory, file-privilege path and account through SELECT, and that SQLite `pragma_database_list` returns the file path under `read.mode="all"`. `VERSION()` stays allowed; other functions (including `SLEEP`, `BENCHMARK`, `GET_LOCK`) are left for separate review (DRR-2026-075).
- MySQL allowlists keep configured case and compare table references exactly (`ConnectionPolicy.case_sensitive_tables`, `allows_table()`), in queries, Query Skill checks, `describe_table()`, `list_tables()`, `get_full_schema()` and Query Skill availability; CTE names match exactly. SQLite unchanged. Fail-closed on case-insensitive servers: differently cased references are rejected (DRR-2026-076).
- Full suite **814 passed, 4 skipped**; Pyright 0 errors.
- `describe_table()` adds `indexes_status` and `indexes` (name, primary, unique, ordered key columns, `null` plus `has_expression` for expression parts, MySQL non-BTREE `type`, SQLite `partial` always present). New adapter method `get_indexes()`: MySQL reads `INFORMATION_SCHEMA.STATISTICS` without `CARDINALITY`; SQLite uses `pragma_index_list`/`pragma_index_xinfo`/`pragma_table_info` and synthesizes the implicit rowid primary key with `name: null`. Index-only failure keeps the call successful with `indexes_status="unavailable"` and `indexes=null`. No switch; `get_full_schema()` unchanged; comments, expressions, predicates and cardinality are not returned (DRR-2026-077).
- Baseline vs after (3 runs each, same prompts): MySQL 0/3 → 3/3, 2–3 calls → 1, 43.6k–59.4k → ~28.9k tokens; SQLite 0/3 → 3/3, 4–5 calls → 2–3, 59.2k–93.5k → 28.4k–43.4k tokens. A first version omitted `partial` when false and 2/3 runs reported it as unknown; it is now always present. Output matched native `SHOW INDEX` and PRAGMA. Fixed cost about +68 input tokens per request; routing and UNION-disabled regressions unchanged. SHOW, system-schema and PRAGMA rejections now point to `describe_table()` for indexes. The local rich SQLite fixture gained index fixtures.
- Live checks: `@@hostname`, `CURRENT_USER()` and `pragma_index_list` are rejected; `VERSION()` and SQLite case-insensitive names still work. Full suite **820 passed, 4 skipped**; Pyright 0 errors.

## v3.8.1 Per-connection read policy guidance and real-channel result checks (October 1, 2026)

- Third 3.8.1 update; version unchanged. Authorization, SQL validation, execution, output schemas and configuration format are unchanged.
- Server instructions list each connection's configured read policy, built at startup by `render.connection_policies()` from the loaded configuration: alias, database type, reads disabled or scope type (all, or an allowlist with a table count), UNION allowed/disabled. No database access and no table names, hosts or paths; at most 12 lines plus a count pointing to `list_connections()`. Aliases are restricted to `[a-z][a-z0-9_]{0,63}`, so no free text enters the instructions.
- A shared `prompts/read_policy.md` adds that this is configuration (not proof of connectivity or table existence), that FROM subqueries are rejected on every connection (use a CTE), that UNION-disabled targets should not try UNION, and that UNION allowed neither widens table scope nor permits cross-connection queries. The parameterless `sql_assistant` includes the same text.
- The UNION rejection keeps its `UNION queries disabled` prefix but no longer tells the model to combine separate results in its reply; it recommends one permitted query (scalar subqueries, EXISTS/NOT EXISTS, JOIN or a CTE) and SQL-side aggregation with truncation, duplicate and ordering checks.
- Design decision: adopted the proposal's intent (guidance derived from loaded configuration, no authorization change, no database access, UNION disabled does not mean single-table queries, correct the merge advice, per-connection wording) but not its delivery. The proposal added `sql_assistant(connection_id)` and kept server instructions connection-neutral; in Copilot, MCP Prompts are user-invoked slash commands that the model cannot fetch, so most measured gains would not appear. Server instructions were verified to reach the main Agent and subagents without extra calls. `list_connections()` already returned `allow_union`, but with a known target the routing rules lead the model to query directly, so it was not consulted. A parameterized Prompt is deferred until a Host lets models fetch Prompts.
- Measurements (GPT-5.6 Luna subagent, 3 runs each, same prompts): UNION-disabled MySQL task 11–15 calls/58k–78k tokens with a rejected first UNION → 2 calls/~44.0k tokens, no rejection; UNION-allowed SQLite task first query rejected for a FROM subquery → 1 call (CTE + UNION ALL)/~27.9k tokens; all answers correct. A control that stated the policy in the task matched the new result (2 calls, ~43.5k). Regression cases kept their pass rates; fixed input about +184 tokens per request. Local-only `local_data/union-test.db` and a read-only UNION-allowed test connection were added and are not committed. Full suite **799 passed, 4 skipped**; risks in DRR-2026-074.
- Real tool-channel check of the previous update's result guidance on a richer local SQLite database (`local_data/mutation-rich.db`, 80 orders; local-only writable `rich_mutation_sqlite` connection; each execute approved per write; 3 runs per case): `committed` and `rolled_back` reported correctly 3/3 with 1 call and 2 turns. Preview-token rejections happen before any write but ended with "run preview again"; reports were ambiguous (0/3 clearly "this request wrote nothing"). The five rejection messages in `core/proposals.py` now say the request was rejected before execution and wrote nothing, and ask to check state and let the user decide on a new preview; the description adds one matching sentence (2,643 → 2,706 characters). After restart, 3/3 reports were clear. After a declined preview whose row later changed, 0/3 runs avoided reporting the preview-time status as current; a trial description sentence did not help and was removed. Residual risk recorded in DRR-2026-073; only local test data was written.

## v3.8.1 Mutation result interpretation guidance (October 1, 2026)

- Second 3.8.1 update; version unchanged. Tool descriptions only: no execution, token, approval, output schema or configuration change.
- Copilot does not show `outputSchema` to the model, so the mutation tool description gains a "Reading results" section (`execution_outcome` decides the write; outcome meanings; an error without an outcome proves nothing; no self-initiated retry or entry-point switch; idempotent is not a retry license; estimate vs rowcount; returned text is data; tokens stay out of summaries). The MRTR description adds that waiting or approval is not a write result and defers to the shared rules. Descriptions grow by 755 and 227 characters, about +159 measured input tokens per request; tests cap them below 2800 and 500 characters.
- Design decision: no misreading had been observed, so this was treated as a low-frequency, high-cost risk (a misread `committed` or `unknown` can cause a duplicate write). The MCP Tools specification frames tool execution errors as feedback the model may use to retry, so a write tool must state the opposite explicitly. The proposal's four injection points (server instructions, two tool descriptions, `sql_assistant`) were reduced to the two tool descriptions, avoiding duplicated per-request cost and a Prompt that Hosts do not inject; its 20 scenarios and recording/replay harness were reduced to six replay cases.
- Full suite **797 passed, 4 skipped**. Replay trials rose from 12/18 to 16/18 (MRTR protocol error 0/3 to 3/3) with no regression in routing, rejection discovery or preview-only cases; post-decline assertions about current data remain 1/3 (DRR-2026-073). VS Code refreshed tool descriptions only after the server was called again following restart and Reset Cached Tools, so earlier 3.8.1 subagent runs may have seen the older description.

## v3.8.1 Skill rejection recovery clue and subagent behavior tests (October 1, 2026)

- Version is **3.8.1** (pyproject, package, MCP server and lockfile project entry). Without uv available locally, only the project's lockfile version line was synchronized; dependency resolution is unchanged. Backward compatible; configuration, authorization, token and execution semantics are unchanged.
- `validation_failed` responses may include `related_available_skills`: names of declared related mutation Skills currently executable on the same connection, without parameters, advice, authorization or approval. Lookup failure omits the field and preserves the original failure.
- The update Skill now states its lifecycle and backward-transition rejection and links the reset Skill; the status rules add a demo restoration example with separate approval for each non-atomic step. The mutation tool description requires checking related Skills after rejection and leaves token validity to execute.
- `preview_token_expires_in_seconds` was briefly reintroduced to address subagent misreports, then withdrawn with maintainer agreement: v3.7.1 removed it as duplicate, and a relative value becomes stale in conversation. Only the absolute expiry is returned.
- Full suite **796 passed, 4 skipped**; Pyright 0 errors. After a Host restart, three GPT-5.6 Luna runs per case gave: purpose-only target 3/3, recovery discovery after rejection 3/3, preview-only without approval 3/3; directly asking whether a token is still usable gave 0/3, then 1/3 after wording changes, with conservative misreports. No writes; orders 1–3 remain shipped. The local MCP Runner definition is ignored by Git. See the [acceptance record](docs/validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md).

## v3.8.0 pre-commit verification (October 1, 2026)

- Highlight the maintainer's approval-round explanation in both READMEs and this log, retaining the permission/execution checks, trusted-Host and legacy-entry-point qualifications. No version bump: package metadata, lockfile and runtime remain **3.8.0**.
- Review all pending runtime changes: per-connection Query Skill SQL preflight, the MRTR false-default form hint and complete indented review snapshots. Preserve the shared execution boundary; no additional runtime change was needed in this final review.
- A clean source copy, new environments and frozen dependencies passed **793 tests, 4 skipped, 3 existing legacy logging warnings (87.74 seconds)**; Pyright reported **0 errors, 0 warnings**. Source distribution/wheel build and non-editable wheel checks outside the repository passed, including packaged prompts and modern/legacy stdio queries.
- Four real-MySQL integration tests remain opt-in and skipped. Native UI gaps stay documented; no live database was accessed in this review. Private deployment files remain ignored. These are local pre-commit results, not a new remote CI pass; see the [complete verification record](docs/validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md).

## Default mutation workflow and acceptance audit (October 1, 2026)

- Retain preview/execute as the deployment default and MRTR as an explicit per-Host option, consistent with the current model, public template and private setting. The tested Codex IDE supports the main native interactions; the recorded Copilot session fails the protocol gate. Do not generalize these observations to every client or confuse the default choice with stronger human authentication.
- Reconcile the saved test conversation, implementation and tests in the [acceptance audit](docs/validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md). Native business-TTL, old-form restart and repeated-submission behavior remain distinct from automated coverage; post-reinstall Codex version and raw protocol evidence are incomplete. The Copilot legacy approval-tool response also does not prove visible human review.
- Clarify that MRTR is an input-request mechanism used for approval on this specific entry point. It does not authenticate a human or disable legacy writes. A dedicated preview/execute Host can enforce interaction in code; prompts alone are Agent behavior rules. Keep DRR-2026-050 and both language editions aligned, including the separate Copilot commits/restoration and preview-only trial.
- Focused revalidation: **131 passed, 1 existing logging deprecation warning, 35.84 seconds**. Documentation changes only in this follow-up; no deployment changes, live DB access or new native UI/full-suite/remote CI claims. Synchronize README, configuration examples, client/configuration guides, architecture, security and release notes without rewriting historical outcomes.

## Approval trust in preview/execute and MRTR (October 1, 2026)

**Maintainer-facing summary:** MRTR adds a server-enforced approval round to `request_mutation_approval`; human approval in preview/execute belongs to the Host workflow. The server enforces the preview-token protocol, permissions and execution checks, but cannot determine whether a person approved. MRTR still trusts the Host's decision and leaves legacy execution available; it is neither independent human authentication nor a global approval policy. This summary is also highlighted in both READMEs; version remains **3.8.0**.

- In the separate trial with preview expiry 20:44:01 UTC, MRTR's tool was absent while legacy preview succeeded with not_executed and unchanged independent reads. The Agent requested conversational confirmation; the user's subsequent question was not approval, so execute was not called. Only this trial was preview-only, not a complete write round trip.
- The earlier Copilot session recorded a committed shipped -> delivered update and three separately committed restoration steps, delivered -> pending -> confirmed -> shipped. Each execute affected one row; post-step reads verified the states. The final all-shipped result does not mean no writes occurred or constitute a transaction rollback.
- The client question tool recorded approval/cancellation choices, but complete previews were primarily in its message field. The user later reported missing review UI; tool responses alone do not prove visible review. Future writes in this interaction require a complete preview in the chat body and an explicit approval reply. This is a client rule, not a new server control; see the [separate trials and evidence limits](docs/validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md).
- Legacy execution requires confirm=true, a valid matching one-time token and policy checks. The token proves preview binding and consumable state, not human approval. A dedicated Host can enforce interaction in code; an Agent's conversational confirmation is a behavior rule.
- MRTR enforces a valid continuation and accept/strict true on its own path, but still trusts the Host to collect a human decision. Its registration switch does not disable the legacy mutation tool or enforce approval globally.
- Extend existing DRR-2026-050 in both languages and synchronize README, security, configuration/client guides and implementation decisions. Independently authenticated approval outside the Agent's control, enforced on every write path, remains a future design. This clarification changes documentation only.

## Overview

This actively maintained log records the project’s refactoring, design decisions, compatibility changes, trade-offs and validation. It began with `mcp_sql_server.py` and now also covers the installed `sql_safety_executor` package.

Dated entries preserve the interfaces, configuration and evidence from their own version. Old filenames, environment variables, test counts and failures remain historical; use the newest entry and linked current guides for deployment. Future implementation changes should update both language editions without rewriting earlier outcomes.

## v3.8.0 Copilot session and SDK evidence (October 1, 2026)

- Later direct inspection of the same Copilot session log records VS Code 1.140.0 / Copilot 0.68.0 in session_start and corroborates the earlier reported approval tool protocol-gate error. Earlier statements that versions were not captured remain historical.
- The local built-in Copilot bundle contains an MCP SDK whose latest protocol constant is 2025-11-25; its supported-version list omits 2026-07-28. This supports a client compatibility hypothesis, not proof that the session used that SDK path. The actual request protocol, capabilities and harness/backend remain unknown; do not generalize to every Copilot version or path.
- Update the [acceptance record](docs/validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md) and client guide to distinguish modern MRTR, legacy form elicitation and Agent Host Protocol. Further diagnosis needs actual request metadata. This documentation-only follow-up adds no database calls, approval retries, alternative writes or automated/UI acceptance results.

## v3.8.0 Copilot version evidence (October 1, 2026)

- Official Stable release notes and the update service report VS Code 1.140.0 (September 30). The local Server product manifest and active installation match commit `07f806f999227108933c2e30515b26eecc1fda74`; its built-in `GitHub.copilot-chat` manifest reports 0.68.0.
- Copilot Chat has shipped built-in since VS Code 1.116. Old standalone Marketplace listings must not be substituted for the bundled component version. The prior transcript's exact harness and negotiated MCP protocol remain unknown; do not rewrite it as a proven protocol/version combination.
- Sources and local manifest locations are in the [version supplement](docs/validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md). This was read-only verification and documentation work, without installing updates or repeating database/UI tests.

## v3.8.0 Copilot compatibility observation (October 1, 2026)

- The user supplied a native VS Code Copilot transcript: read live_test_sqlite, request one managed approval for order 2 shipped to delivered, then read again. The approval call was rejected with `MRTR requires MCP 2026-07-28; use preview/execute with trusted Host approval.` No form appeared; no automatic retry or alternative write was recorded, and both reads reported orders 1–3 shipped.
- Record expected protocol-gate rejection, not successful MRTR display/cancellation. The transcript provides neither a standalone error_code nor execution_outcome. The user reports “latest”; exact client/extension versions and negotiated protocol were not captured. Do not generalize this observation to all Copilot versions or infer form capability from the earlier protocol check.
- Evidence is user-supplied, not a direct Copilot run by this Agent; see the [acceptance record](docs/validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md). This update adds no runtime changes or automated-test claim.

## v3.8.0 native review rendering confirmed (October 1, 2026)

- After the user restarted Codex, the new screenshot shows indented JSON with the target, parameters, full SQL/bindings, expiry and Skill visible. The proposal targets order 2 on live_test_sqlite, shipped to delivered, with expiry `2026-09-30T19:59:37+00:00`.
- The close-button test returned `approval_cancelled` / `not_executed`; independent before/after queries showed orders 1–3 still shipped. The current Codex IDE's multiline presentation and cancellation path are accepted. This was a new proposal after restart, not resumption of a pre-restart approval.
- Earlier pending-rendering statements below describe their stage. Native business-TTL/restart continuation and other Hosts remain separate open items. The screenshot remains in the conversation; this documentation update adds no automated-test result or database write.

## v3.8.0 Codex review rendering and button diagnosis (October 1, 2026)

- Both inspected Codex-owned MCP processes started before the indentation patch; they do not hot-reload the module. A Host restart after the patch is required. The installed frontend uses `whitespace-pre-wrap`, supporting preserved newlines; native post-restart rendering remains to be observed.
- Extension 26.917.62051 maps Skip to `decline`, and the top-right close button/Escape to `cancel`. Correct the client guide's earlier conflation of Skip and close. The screenshot trial returned `approval_declined` without a database change, which is consistent with Skip; the user's combined “Skip/close” description does not establish which button was clicked.
- Preserve server action semantics and add explicit error-code assertions for decline, cancel and accept(false). Do not patch the third-party extension, silently remap actions or terminate the active service. See [diagnostic evidence](docs/validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md).

## v3.8.0 readable MRTR review payload (October 1, 2026)

- Replace compact review JSON with two-space indentation and readable Unicode, keeping the existing question line followed by valid JSON. The reference Host can still parse the entire payload after the first newline; no Markdown renderer is required. JSON string escaping is retained.
- First asks and missing-answer re-asks format the same saved review snapshot. Preserve every field, SQL, binding, target and expiry without truncation or new preview generation. Canonical storage, approval binding and execution rules are unchanged. The 64 KiB cap still applies to stored review JSON; indentation increases display payload size, so it is not a 64 KiB wire-message guarantee.
- Focused regression after this change: **131 passed, 1 existing logging deprecation warning, 27.54 seconds**. Assertions compare the parsed display with the saved snapshot and verify multiline formatting; existing re-ask, reference Host, strict-approval and restart cases passed. Actual rendering after restart remains unverified; a Host may collapse whitespace or use its own layout.
- Current acceptance is partial: native approval, cancellation, unchecked refusal and delayed framework rejection have evidence; separate real-process restart passes. Native business-TTL and restart UI cases and other Hosts remain pending. See the [current acceptance matrix](docs/validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md). No new native mutation was performed for this presentation change.

## v3.8.0 real-process MRTR restart regression (October 1, 2026)

- Added `tests/test_v38_mrtr_restart.py`: a reference Client starts the production package entry point over stdio, obtains a sealed proposal, closes and reaps the old process, then starts a different PID with the same configuration and temporary SQLite file. Both sessions negotiate MCP 2026-07-28. A minimal launcher records only the child PID; it does not change runtime behavior.
- The exact old request and approval are rejected with a requestState protocol error before the original proposal expires; an independent SQLite read remains pending. A fresh proposal in the new process then commits exactly one row. Both child processes are verified exited. This is real-process protocol acceptance, not native Codex UI acceptance; the connected Codex service and local live-test database are untouched.
- Focused validation: **131 passed, 1 warning** in 26.82 seconds across restart, stdio, MRTR, review-regression and manual-approval tests. The warning is the existing legacy logging-capability deprecation. Existing simulated-clock tests separately verify business expiry while the framework seal remains valid; they do not establish native UI business-TTL acceptance. The new POSIX test is discovered by the existing Ubuntu CI suite; no new remote CI run is claimed.
- See the [updated acceptance record](docs/validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md) for remaining native UI and cross-Host boundaries. No production-code or deployment-configuration change was needed.

## v3.8.0 native MRTR waiting and restart acceptance (October 1, 2026)

- Follow-up native tests committed orders 1 and 2 from confirmed to shipped. The first trial lacks expiry evidence; the second returned 4 minutes 11 seconds before the screenshot's expiry. Neither establishes expired-approval rejection.
- A shipped-to-confirmed proposal failed business validation without execution. A subsequent shipped-to-delivered proposal was approved by the user after more than ten minutes of waiting; the call returned after about 26 minutes with MCP `-32602`, `Invalid or expired requestState`, reason `invalid_request_state`. Independent reads showed no change. This verifies the observed framework rejection, not the business proposal TTL branch independently; the protocol error has no business `execution_outcome` field.
- The attempted restart scenario returned `approval_declined` / `not_executed`; no successful restart with an old approval was established. The current Agent has no callable Host reconnect control for the Codex-owned child. No process was terminated. A separately controlled real-process restart test is proposed, not yet executed, and would not replace native UI acceptance.
- Last observed orders 1, 2 and 3 are all shipped; no compensating write was performed. Earlier confirmed states below are historical. Full evidence and remaining boundaries: [native acceptance record (Chinese)](docs/validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md). This update changes documentation only and introduces no new automated-test result.

## v3.8.0 MRTR approval form default (October 1, 2026)

- Native Codex IDE testing and user screenshots confirmed human approval followed by a committed SQLite update, and cancellation without a write. The required checkbox without a default could not submit an unchecked value in that UI; explicit-false refusal was initially blocked by the form.
- Add `default=false` to the required boolean approval field as a client initialization hint only. Missing/invalid answers still re-ask; execution still requires `accept` with strict boolean true. No optional-field or enum migration is introduced.
- After the service restart, the user confirmed that leaving the field unchecked and clicking Continue no longer caused a required-field error. The server returned `approval_declined` / `not_executed`; before/after reads showed order 1 still confirmed and all three order statuses unchanged. Together with the earlier screenshots and user confirmation, native approval, cancellation and unchecked refusal are accepted for the tested Codex IDE (extension 26.917.62051 / embedded client 0.155.0-alpha.16.3). Expiry/restart UI acceptance remains pending; no compensating write was performed.
- Scope audit: `_ask` is the sole production elicitation-schema builder, shared by first asks and missing-answer re-asks. The reference Host initializes `self.approved = False` and returns explicit boolean decisions; legacy preview/execute uses `confirm=false` by default and a matching one-time token for execution. Neither is another checkbox schema requiring this patch; ordinary configuration booleans and AutoGen conversational approvals are not changed.
- Regression validation: 121 passed, 1 legacy logging deprecation warning across `test_v38_mrtr.py`, `test_v38_review_regressions.py` and `test_manual_mutation_approval.py`; `git diff --check` passed. The schema assertion preserves both false default and required presence, while existing tests cover false, cancellation, invalid values, missing answers and true execution. These results precede this documentation-only acceptance update.
- `default=false` is standard [MCP boolean schema metadata](https://modelcontextprotocol.io/specification/2026-07-28/client/elicitation#requested-schema), not a Codex-specific branch or a server-side fallback. Required means the field must be present, not true. The screenshots establish observed Host behavior, not its internal validation implementation. Other Host UIs, including Copilot and Codex Desktop, remain unverified; a client ignoring defaults must still fail closed.

## v3.8.0 follow-up review and Query Skill preflight (September 28, 2026)

- Independently confirmed remote run `36330541822` for `139d53a`: 786 passed,
  4 skipped; type checks, build and installed-wheel verification all passed.
  Closed the previous findings while preserving the failed `1be44b4` run.
- Reproduced the newly reported UNION discovery mismatch. Query availability
  now preflights cached SQL through the execution path's full static policy
  for the resolved target. Retain templates usable on other connections and
  avoid sharing authorization verdicts across targets. Execution still checks.
- Added six production-path regressions for modern/legacy UNION decisions,
  quoted table scope and a missing SQL snapshot. Discovery adds parsing CPU;
  dynamic readiness may still perform metadata I/O. Mutation policy is unchanged.
- Clean-copy local validation: 792 passed, 4 skipped, clean type checks, build
  and installed-wheel checks. This new patch still awaits a remote run; native
  MRTR UI and other deferred scopes remain separate. See the
  [follow-up evidence](docs/validation/v3.8/V3_8_REREVIEW_2026_09_28_ZH.md).

## v3.8.0 independent review fixes (September 27, 2026)

- Verified both external reviews against `1be44b4` and the failed Actions run.
  Its outdated tool-description assertion caused 1 failed / 743 passed / 4
  skipped; later CI steps were skipped. The earlier 744-pass local result
  preceded the final prompt edit. Updated the test to enforce all five write
  gates and equal treatment of the default target, preserving the prompt.
- Normalize excluded profiles after strict type validation; reject blank
  entries. Share read admission across discovery and execution, including
  tableless Query Skills. Preserve safe semantic configuration error codes
  without printing raw values or exception context.
- Attribute MRTR waiting/repeated rounds to the validated target and preserve
  decline/cancel phases. Unknown result identity remains null, never a guessed
  default. SDK rejection before middleware may produce no telemetry event.
- Share approval deadlines, displayed-review fingerprints and expiry rechecks
  between preview and MRTR reference Hosts. Late or altered approval fails
  closed; this is not isolation of malicious in-process providers.
- Added 42 production-loader/real-FastMCP/temporary-SQLite regressions. Full
  CI-equivalent checks and the pending remote rerun are recorded separately in
  [review validation](docs/validation/v3.8/V3_8_REVIEW_FIXES_2026_09_27_ZH.md).
  Clarified deferred trusted task-scope grants, catalog/readiness separation
  and cross-round tracing. No new native UI or live MySQL acceptance is claimed.
- Final documentation review clarified the profile array type and checked
  local links. After the user's restart, four native calls verified connection
  discovery, a constant SQLite query, Query Skill detail and unknown-target
  rejection. No mutation was invoked; native MRTR remains unverified.

## v3.8.0 native reconnection verification (September 26, 2026)

- After the user's restart, the current IDE conversation directly discovered
  10 tools. Completed 23 native calls, including reads/policy refusals and a
  controlled SQLite preview/execute/replay/compensation cycle; the fixture was
  restored. Three isolated GPT-6 Luna agents completed the same six-turn routing
  script: 18 rounds, 22 calls, no observed wrong-target access or agent mutations.
- Corrected another legacy statement in `list_connections`: default targets
  have no compatibility write grant; all five authorization gates apply.
  Runtime enforcement already refused the default target. Fresh reference
  discovery verified the corrected text; the native trials used the already
  running service and do not verify the new wording after reload.
- Native protocol/usage were not exposed; MRTR remains disabled. See the
  [reconnection evidence and limits](docs/validation/v3.8/V3_8_LIVE_REVIEW_2026_09_26_ZH.md#服务重连后的原生补测).
- Final documentation review reconciled both READMEs, release notes and the
  implementation record with the later native evidence: MySQL probes passed,
  while MySQL writes, native MRTR/human approval UI, Copilot and remote CI remain
  unverified. Historical failures and test-run scopes are preserved.

## v3.8.0 live review follow-up (September 26, 2026)

- Found and repaired a local Codex launch entry still referencing removed
  `start_server.py`; backed up the Host configuration and changed only this
  server's executable/arguments. Documented actual Host configuration migration
  and reconnection separately from editing repository templates.
- Corrected the `list_skills` description and parameter descriptions to name
  TOML discovery fields; corrected the loader's stale directory-trust comment.
  Routing, defaults, policy and execution logic are unchanged.
- Fresh stdio clients negotiated both protocol generations. Three local targets,
  including MySQL, passed connection/read probes. Two controlled SQLite
  preview/execute/replay/reset cycles restored the original fixture; no MySQL or
  demonstration-database mutation was invoked.
- Nine fresh GPT-6 Luna native Codex CLI trials completed scoped tasks or the
  required clarification/refusal, with 15 tool calls and no observed wrong-target
  access. One forbidden UNION attempt was rejected and corrected; retain it as
  an initial planning failure. Actual usage and complete extracted calls are
  recorded. The current IDE conversation still requires reconnection; CLI wire
  protocol was not captured and local MRTR remains disabled.
- Focused MRTR/stdio/disclosure regression: **66 passed, 1 warning**. This is not a
  rerun of the full suite or the full multi-turn Agent benchmark. See the
  [live review and evidence](docs/validation/v3.8/V3_8_LIVE_REVIEW_2026_09_26_ZH.md).

## Update v3.8.0 — FastMCP 4, TOML Configuration and Package Refactoring (September 26, 2026)

### Scope and baseline

Baseline `582822b` used Python 3.12.3, FastMCP 3.0.2 and MCP SDK 1.26.0;
its isolated default suite passed **676 tests, with 4 skipped**. This update
adopts FastMCP 4.0.10 with MCP SDK / mcp-types 2.2.0, explicit configuration,
instance-owned runtime state and optional managed MRTR. Python remains ≥3.12.
The repository version is 3.8.0; no release or tag is implied by this entry.

### Installed package, safety core and lifecycle

- Move runtime code into `src/sql_safety_executor/`, organized as `config`,
  `core`, `database`, `skills`, `mcp`, `prompts`, `observability` and the CLI.
  Whole-file moves use `git mv` before further splitting.
- Publish `load_config(path) -> AppConfig` and `create_server(config) -> FastMCP`.
  Configuration, adapters, Skill catalog, proposals and diagnostics belong to
  each service instance. Basic imports do not connect to a database, import
  business Skills or create log files. Explicit initialization loads enabled
  trusted definitions; adapters are lazy and lifespan closes owned resources.
- Move complete query policy and execution into the core. Remove the public
  `execute_sql()` helper that applied only part of the policy. Core results use
  `OperationResult`; MCP handlers handle protocol inputs/context and conversion.
  Core serialization checks preserve committed-write outcomes when later
  response processing fails.
- Move `skills/_lib` into the package and expose extension types/business
  exceptions from `sql_safety_executor.skills`. Remove `sys.path` injection;
  update bundled Skills and document custom-import migration. Root `skills/`
  remains the business definition directory. Explicit external directories are
  allowed when trusted; resolved path containment is not a Python sandbox.
- Package UTF-8 prompt resources with `importlib.resources`. Preserve existing
  routing/instructions first, then add MRTR guidance separately. Missing required
  resources fail startup. Parameter types/defaults and annotations stay in code.
- Consolidate dependencies, entry points and checks in `pyproject.toml`, commit
  `uv.lock`, and isolate AutoGen dependencies. The console command and
  `python -m sql_safety_executor` replace old root launch scripts.

### Explicit three-file TOML contract

`server.toml` references connections and optional Skills configuration;
`connections.toml` owns target identity/read/write policy; `skills.toml` owns
Skills discovery, mutation admission, proposals, MRTR and audit. Each declares
`schema_version = 1`. `tomllib` and strict Pydantic models reject unknown fields,
wrong types, invalid defaults/references and out-of-range settings.

Every launch requires `--config`. Paths resolve relative to the declaring file;
only query/connect timeouts inherit built-in → common → per-connection values.
Database identities and credentials never inherit from another connection.
`config check` and `config explain` use the same loader and resolve secrets
without database connections or business Skill imports. Explain output redacts
secrets and includes sources/disabled reasons.

Reads default to `deny`; an empty allowlist grants nothing and unrestricted
reads require explicit `all`. UNION requires explicit enablement and a valid
read scope. Mutation admission requires all five gates: Skills enabled, global
writes enabled, connection globally admitted, connection writes enabled and the
Skill allowlisted. Default-only compatibility grants are removed. Read table
scopes still do not universally constrain Mutation Skills.

Secrets choose exactly one `value`, `env` or `file` source, with no fallback.
Files are nonempty UTF-8, at most 64 KiB; whitespace/newlines are preserved.
Configuration and resolved secrets are immutable startup snapshots. Zero keeps
its documented unlimited-result/disabled-tool-timeout meaning; invalid negatives
or proposal bounds now fail startup instead of silently falling back.

Remove project dotenv loading and old environment configuration. Official entry
points disable FastMCP's automatic `.env` search before importing the framework;
explicit secret environment references remain supported. Existing private `.env`
files are preserved. Local TOMLs/secrets are ignored separately from four public
SQLite/MySQL/multi-target/mutation templates. Skills disabled means no business
imports, Skills tools or readiness probes.

### Managed MRTR pilot and retained approval flow

Optional `request_mutation_approval(skill_name, params, connection_id=None)` is
registered only when MRTR, Skills and mutations are enabled. It requires MCP
`2026-07-28`, client form elicitation and a managed single-statement Skill;
unsupported protocols/capabilities and imperative Skills are refused. Existing
`execute_mutation_skill` preview/execute remains available.

Both routes use one `MutationService` and token store. The first MRTR round
creates an immutable, server-held review of target, Skill, normalized params,
SQL, bindings and expiry, returning `InputRequiredResult` without executing the
managed write. Reviews exceeding 64 KiB are refused rather than truncated.
SDK-sealed `request_state` carries a continuation reference; it cannot replace
server-side binding/expiry/one-time validation. Per-instance ephemeral sealing
keys use the configured proposal TTL.

Missing answers resend the same review without a new preview or extended expiry.
Only `accept` with strict boolean `approve=true` reaches execution. Decline and
cancel close the proposal. Consumption remains atomic at the shared execution
boundary and is terminal after every later exception. Waiting holds no database
transaction or row lock. Lost responses, missing state and uncertain outcomes
never justify automatic retry.

The reference Host supports `--config` and `--flow preview|mrtr`, defaulting to
preview. It collects a trusted Host decision, not independently authenticated
human identity. Telemetry marks waiting as `phase=awaiting_approval` with
`success=null`. No response caching, Tasks, multi-user approval authentication,
shared distributed state or durable restart recovery is added; audit stays
best-effort and imperative whole-operation outcomes remain `unknown`.

### Validation and remaining limits

- Locked-environment suite: **744 passed, 4 skipped**, one legacy logging
  deprecation warning. The documented rerun took 62.77 seconds; the initial
  final run took 43.18 seconds. Pyright: **0 errors, 0 warnings**.
- Built sdist/wheel; a separately installed wheel loaded prompts and completed
  offline checks plus modern/legacy stdio queries outside the repository.
- Real stdio covered `2026-07-28` and `2025-11-25`, including reference MRTR and
  legacy preview/execute. Configuration rejection/privacy, authorization,
  replay/expiry/binding, concurrency, transaction outcomes, two-instance
  isolation and resource cleanup have automated coverage.
- Actual Codex CLI `0.155.0-alpha.16.3` negotiated `2025-06-18`; routing trials
  recorded no wrong-target access. Its approval policy blocked MRTR before
  dispatch, so native Codex MRTR did **not** pass. Copilot interactive approval
  was unavailable; no live MySQL integration was enabled in this v3.8 run.
- CI now contains locked tests, type checks and packaging/installed-wheel
  checks, but has not been pushed/run remotely. Local success is not a remote
  GitHub Actions result. Evidence and actual usage are in the
  [v3.8 validation record](docs/validation/v3.8/V3_8_VALIDATION_ZH.md).

### Documentation maintenance and cutover

Root bilingual READMEs retain the author's original structure, narrative,
examples and screenshots, with targeted v3.8 changes. This refactoring log is
an actively maintained root document, with a [Chinese edition](REFACTORING_LOG_ZH.md).
`docs/README.md` / `README_ZH.md` and `config/examples/README.md` / `README_ZH.md`
provide bilingual indexes and configuration instructions. All six guides formerly
under `docs/history/guides/` move with `git mv` to `docs/guides/`; versioned
applicability and historical failures/conclusions remain intact. Archived README
snapshots, legacy public env templates and dated evidence retain their roles.

Check TOML, stop the old process, then start the matching installed version with
explicit configuration. Rollback requires matching code, dependencies and
configuration together. Restart invalidates pending proposals; reconcile any
uncertain business write before considering another attempt. Detailed contracts
are in the [configuration guide](docs/guides/CONFIGURATION_ZH.md),
[implementation record](docs/architecture/V3_8_IMPLEMENTATION_ZH.md) and
[security boundaries](docs/security/V3_8_SECURITY.md).

## Unified Connection Diagnostics (September 22, 2026)

Unified default/named/all diagnostics under `check_connection`, with optional
connection_id and explicit `scope="single"|"all"`; removed the plural tool with
no compatibility alias. Both scopes reuse the existing independent diagnostic
runner and one required-scope report. A single selection has one result and
counts only that selection; scope is not inferred from configuration count.

Single checks no longer obtain a cached business adapter or query a database
name. They now share the 30-second/outer-timeout budget, process-wide busy gate
and cleanup-failure disable behavior. Result metadata resolves identity from
configuration only. Scope-aware telemetry replaces the old tool-name special
case while preserving completion versus success. After target validation succeeds,
later busy/stopped/disabled errors retain validated scope and, for single scope,
resolved identity. Validation failures that reach project middleware omit scope
and identity; requests rejected by SDK schema validation before that middleware
produce no project telemetry event.

This is a breaking tool/response migration without a repository version change,
release or tag. Updated current bilingual guidance, design and migration tables;
retained historical interfaces and scores under explicitly historical sections.
DRR-2026-066 remains Open because guidance and model-supplied scope do not enforce
per-request permission. Strict deployments still need trusted Host/app checks.

The staged validation compares baseline A, unified contract B, then wording-only
C; actual verification is separate from old test counts. Benefits and costs are
recorded in the [current design](docs/guides/V3_7_CONNECTION_DIAGNOSTICS_DESIGN.md#unified-contract-review-and-migration--september-22-2026),
including changed single-check availability and the absence of proven Agent/token
improvements before measurement. See the [September 22 staged record](docs/validation/v3.7/V3_7_3_LIVE_MCP_TEST_UNIFIED_CONNECTION_DIAGNOSTICS_2026_09_22_ZH.md)
for actual evidence and acceptance limits.

The C wording trial showed an unresolved-purpose default probe absent from the
initial three matching B samples. Under the frozen rule, restored B wording
without changing the unified implementation or schemas. Fresh B rechecks also
showed this failure, so it cannot be attributed uniquely to compression. All
failed traces are retained. No compression benefit or universal behavior
improvement is claimed. Earlier Host approval blocks remain historical evidence;
the user subsequently authorized completion in a new isolated workflow cohort.

Deterministic verification: targeted suite **123 passed**; default suite
**675 passed, 4 skipped**. Pyright covered the ten changed Python files,
including the evaluation bridge: **0 errors, 0 warnings**. The review rerun uses
the repository configuration and an explicit venv Python path; this is not a
whole-repository Pyright result. Compilation and local Markdown link checks
passed. Fresh stdio smoke checks passed; a subsequent connected-Host review also
observed the new signature, absence of the plural tool, successful default MySQL,
named SQLite and all-three diagnostics, and rejection of conflicting arguments.
The Host does not expose a remote source digest or server `_meta`; observable
contract validation is separate from build attestation and telemetry validation.
Agent workflow results are recorded separately in the staged report.

The authorized follow-up completed three fresh six-turn Luna workflows for each
of A, B and archived C: 54 user turns and 63 MCP calls. No new target-scope
violation appeared in this cohort; nine deliberate user-supplied alias typos were
rejected without fallback. Reply-language and percentage-prose issues are recorded
separately. Prior purpose/prohibition failures remain unchanged, and C stays
withdrawn. The observed native Host descriptions shrink by 3,405 characters from
A to B; actual model usage is unavailable, so this is not a billed-token claim.

## Managed Single-Statement Mutation Contract (September 16, 2026)

Assigned this safety-contract follow-up to the same v3.7.3 before its first
formal publication. It retains deliberate Skill-author compatibility changes;
the version assignment does not remove the migration requirements below.

Replaced the transitional built-in name/source/class exact-outcome registry with
an authorable `ManagedMutationPlan`. A managed Skill declares one immutable DML
statement, explicit params/binding/constants, an exact expected row count and
optional result fields. Discovery validates and caches the plan; confirmation
resolves it and performs one adapter call without instantiating or invoking
Skill Python.

This narrows the exact claim to the framework-owned database statement. Module
imports and preview callbacks remain trusted in-process Python and are not
covered by that evidence. Imperative `MutationBase` remains an experimental
escape hatch with whole-operation outcome `unknown`. The old
`exact_transaction_outcome` flag is rejected with migration guidance.

Also corrected a boundary that dates to the original v3.0 Skills commit
`04603e4`: with `SKILLS_ALLOW_MUTATIONS=0`, discovery no longer imports custom
mutation modules. The later sample-name/Git-ignore commits only made that old
behavior easier to notice; they did not introduce it. Metadata and source-path
validation remain available for listing while the mutation tool stays absent.

The two bundled mutation examples now declare managed plans. Targeted tests
cover disabled imports, invalid/multi-statement plans, final execution methods,
binding resolution before writes, confirmation without Skill callbacks,
transaction evidence, cancellation and imperative fallback. Current docs state
the compatibility cost and the limit of the exact claim; no durable receipt,
new MCP tool, background worker or API field was added.

Pre-commit review found that a Skill-authored preview could drift from the cached
plan. Managed SQL and bound values now come exclusively from that plan and the
final serialized binding, using the same resolver before token issuance and
confirmation. Missing SQL or result bindings never receive a token; declaring
reserved preview fields is rejected. Reserved result fields now include `error`
and `error_code` to prevent contradictory success audits. A non-bundled custom
Skill is tested through the real FastMCP Client with temporary SQLite databases,
including commit, rollback and no confirmation-time callbacks. Current guides,
diagrams and checklists now describe this contract; historical registry entries
remain historical. Error codes are explicitly extensible and the unsupported
Anthropic quotation is replaced with a sourced paraphrase. Verification counts
and scope are recorded in the [v3.7.3 managed-mutation verification record](docs/releases/RELEASE_NOTES_v3_7.md#verification--september-16-2026).

## Update v3.7.3 - Connection Routing and Tool Contract Clarity (September 15, 2026)

Assigned the current compatible routing/example corrections to v3.7.3 and
updated the bilingual README version badges and maintenance summaries. This is
repository version preparation; no tag or published release is created here.
Batch diagnostics and the earlier Skill-name migration remain part of v3.7.2.

The dated subsections below preserve each implementation/review stage, including
earlier candidate-version decisions and failed trials. Current behavior and known
limits are summarized in the [v3.7.3 notes](docs/releases/RELEASE_NOTES_v3_7.md#v373--connection-routing-and-tool-contract-clarity).
The [lessons and commit proposal](docs/guides/V3_7_3_CONNECTION_ROUTING_REMEDIATION_ZH.md#12-本轮工程与协作经验)
record reusable review practices. This version-only follow-up changes no Python;
the preceding 640 passed / 4 skipped and seven-file Pyright results still apply
to the same source. DRR-2026-066 remains Open.

### Follow-up: Versioned document names and Chinese design record (September 15, 2026)

Prefixed the v3.7.3 remediation guide and four dated connection-routing/boundary
reports with V3_7_3_, and updated repository links. The prefix identifies the
review's version scope, not the runtime version of every historical baseline.
All five files were still untracked, so they were renamed without staging them.
Raw evidence filenames, content and hashes are preserved.

Added a complete [Chinese batch-diagnostics design record](docs/guides/V3_7_CONNECTION_DIAGNOSTICS_DESIGN_ZH.md),
with reciprocal language links and Chinese README navigation. Both editions
include the current strict-deployment and closed-client response-model boundaries;
dated validation figures and historical grades are retained. No Python or
diagnostic implementation changed.

### Follow-up: Current evaluation rules and deployment requirements (September 15, 2026)

Aligned the reusable routing matrix with the current restriction rules, retaining
historical trial grades. Corrected both DRR summaries to the September 15 review
state and described the added list_connections hint accurately: input contracts
and existing output fields remain unchanged, while independent closed client
response models may need adaptation for the extra field.

Documented trusted per-action scope enforcement as a prerequisite for deployments
requiring hard restrictions. It must cover explicit aliases, implicit default
resolution and all batch targets, without a model-supplied confirmation shortcut.
No runtime authorization mechanism was added; trusted local use retains the
known limitation. See the [review follow-up](docs/guides/V3_7_3_CONNECTION_ROUTING_REMEDIATION_ZH.md#14-当前验收入口与部署边界复核2026-09-15).

### Follow-up: Restricted diagnostics and configuration interpretation (September 15, 2026)

Clarified the current diagnostic contract before new trials: an explicit
restriction to one resolved alias/default narrows a broad request; prohibitions
include connection checks, and rejected partial checks or irreconcilable
restrictions require waiting. Keep earlier conflict grades unchanged.

Added configuration-only guidance to list_connections and an additive result hint
distinguishing policy from table existence/completeness. Three new protocol cases verify discovery does not
connect/create files and that configured, visible and physical tables differ.
Final suite: 640 passed, 4 skipped; seven Python files: Pyright 0 errors/warnings.

Two phases of temporary SQLite / in-memory FastMCP Agent trials used 15 fresh Luna
contexts and 13 actual calls. Final interpretation cases passed 3/3; forbidden
target cases still failed in 2/3 contexts. DRR-2026-068 is implemented with local
acceptance, while 066 remains Open; native acceptance of the latest descriptions
is pending. This is guidance, not runtime per-request authorization. See the
[fixture evidence](docs/validation/v3.7/V3_7_3_LIVE_MCP_TEST_CONNECTION_BOUNDARIES_2026_09_15_ZH.md)
and [complete pending-change table](docs/guides/V3_7_3_CONNECTION_ROUTING_REMEDIATION_ZH.md#11-本次待提交修改的完整范围).

### Submission review: Routing and public parameter contracts (September 15, 2026)

Native Host discovery now includes the waiting rule. Twelve isolated Luna contexts
made 36 MCP attempts, including three six-turn workflows. Purpose/default/all
routing and correct first describe arguments passed; conflict clarification
remains open, and configuration being overstated as table existence is recorded
as DRR-2026-068. These are distinct from SQL authorization or write execution.

Aligned remaining current Skill examples with skill_name in sql_assistant and
bilingual README. Added two protocol cases comparing the
retrieved prompt with actual tool schemas under conditional mutation registration;
the describe example test now also reads prompt/initialize through MCP. No Skill
or preview runs in the new test. Final suite: 637 passed, 4 skipped; metadata file:
49 passed; six changed Python files: Pyright 0 errors, 0 warnings.

The [complete review](docs/validation/v3.7/V3_7_3_LIVE_MCP_TEST_CONNECTION_ROUTING_2026_09_15_ZH.md)
records behavior limits, timing corrections, prompt distribution cost and why
this is a compatible fix, not a new batch-diagnostics feature or API migration.

### Follow-up: Wait for unresolved target selection (September 14, 2026)

After the native review below, clarified target selection before database work.
Purpose-only unresolved targets, ambiguous references, non-unique type matches
and conflicting scopes allow optional configuration discovery, then require
asking and waiting. Generic connectivity defaults apply only without target clues
or a resolved conversational/application target. A default flag, alias name,
agent guess or successful probe is not user selection.

Updated shared routing, discovery/diagnostic descriptions, parameter help,
sql_assistant and bilingual documentation.
No tool signatures, diagnostic behavior, connection policies or version changed.
Adjusted two existing assertions that depended on old wording; default tests:
635 passed, 4 skipped. Six changed Python files: Pyright 0 errors, 0 warnings.
Fresh local MCP metadata and schema compatibility were verified. Native Host
metadata still precedes this follow-up; DRR-2026-066 remains open pending new
behavior trials. See the [implementation record](docs/guides/V3_7_3_CONNECTION_ROUTING_REMEDIATION_ZH.md#8-用途目标未确定时暂停数据库操作2026-09-14).

### Review follow-up: Native Host validation (September 14, 2026)

The restarted Host exposes the new routing and parameter descriptions; a live
list_tables result confirms table_name in the runtime hint. Nine isolated Luna
contexts made 36 tool attempts, including three full six-turn workflows. First
describe arguments were correct in all three workflows; purpose-based target
selection still caused one guessed query and one unsolicited default probe.
Conflicting-scope trials respected the narrower restriction without clarifying.
DRR-2026-067 is implemented; DRR-2026-066 remains open.

Corrected current bilingual README tool counts and aggregate metadata guidance;
historical entries retain their earlier counts. Moved only the uncommitted routing
release note to a provisional release section, with v3.7.3 proposed as a patch candidate. No production
Python, version badge or tag changed during this review. Related tests: 92 passed;
four Python files: Pyright 0 errors, 0 warnings. The
[native review record](docs/validation/v3.7/V3_7_3_LIVE_MCP_TEST_CONNECTION_ROUTING_2026_09_14_ZH.md)
contains methods, remaining risks and release-scope qualifications.

### Follow-up: Connection routing guidance and argument examples (September 13, 2026)

Aligned shared routing, diagnostic tool/parameter help, `sql_assistant` and
bilingual README sections. Unspecified
connectivity defaults to one connection; remembered aliases are explicit;
all-scope diagnostics require clear intent. Replaced six misleading
`describe_table(name...)` hints with `table_name` and added a JSON example.
Historical traces retain their original arguments and outcomes.

No connection implementation, API signature, schema validation policy or write
policy changed. Three new regressions cover advertised examples against the
actual schema, normal/truncated hints and accepted/rejected MCP arguments.
Validation: default suite `635 passed, 4 skipped`; affected metadata/contract
suite `47 passed`; four changed Python files passed Pyright with the project
virtualenv (`0 errors, 0 warnings`).

Fresh stdio clients loaded separate A/B source snapshots for isolated Luna
trials. This fixture Host is distinct from the IDE's previously connected
service. Observed behavior limitations remain in DRR-2026-066/067; test details
and pending native-Host acceptance are in the
[remediation record](docs/guides/V3_7_3_CONNECTION_ROUTING_REMEDIATION_ZH.md).

## Follow-up: Batch connection diagnostics (September 12, 2026)

Subsequent review tightened required output fields and documented the distinct
single/batch tools. Cleanup exceptions are now observable independently of
connectivity and latch batch diagnostics disabled until process restart; no
automatic recovery mechanism was added. The design record includes the cost /
benefit table, the successful three-alias black-box live check, and the limits
of that evidence. DRR-2026-034 now names the historical v3.6 Skill and its current
name explicitly instead of backdating the `sample-` prefix.

The final boundary review clarified that SQLite `mode=ro` is not a guarantee of
zero filesystem writes: a disposable WAL experiment observed sidecar creation
on a table read, while the actual `SELECT 1` probe did not create sidecars in
that case. Added a WAL transaction regression and an isolated child-process
test for delayed exit while a probe remains blocked. Network disruption and
supervisor termination drills remain deployment-specific follow-up work.
Final validation after these additions: `632 passed, 4 skipped`; targeted
diagnostics/telemetry `36 passed`; Pyright across all seven changed Python files
reported no errors or warnings. Added local documentation links and whitespace
checks passed.

Added no-argument `check_connections()` for all configured aliases, keeping
single-connection checking and configuration discovery unchanged. The report
preserves per-alias failures and explicit unknown states when the waiting budget
expires. Aggregate metadata/telemetry no longer attribute this operation to the
default alias. Agent instructions distinguish all-alias diagnostics from normal
read routing; the capability-aware agent advertises the tool only when exposed.

Connection reuse was considered first to keep the structure simple, then rejected
because SQLite's business `StaticPool` shares transaction state. A disposable
in-memory experiment on SQLAlchemy 2.0.46 reproduced an unrelated uncommitted row
being rolled back when a diagnostic checkout closed. The implementation reuses
adapter logic with fresh, uncached diagnostic instances and read-only SQLite
file access instead of expanding locks across all business operations.

A lifespan-managed four-worker executor admits one batch at a time. The internal
30-second waiting budget is shortened to 80% of a smaller MCP timeout. Workers
retain batch ownership through cleanup after timeout/cancellation, preventing
repeated requests from accumulating background database calls. Historical live
test records remain unchanged; the planning-time three-alias MCP baseline is
identified separately from new-tool validation in the
[design record](docs/guides/V3_7_CONNECTION_DIAGNOSTICS_DESIGN.md).

Validation: the default suite passed (`621 passed, 4 skipped`), followed by a
separate passing MCP protocol-cancellation regression. Pyright reported no
errors or warnings across the seven changed Python files. A fresh stdio process
confirmed mixed success/failure results using temporary SQLite configurations,
without creating a missing database or disclosing its path. Details and the
distinction from the older deployed-service baseline are in the design record.

## Follow-up: Sample Skill names and local files (September 12, 2026)

Renamed all four bundled Skill directories with `git mv` to the `sample-`
namespace, including `sample-reset-order-to-pending`. Frontmatter, related
Skills, exact-outcome registration, configuration templates, clients, tests,
and current documentation use the new identifiers. Old names are not aliases;
existing connection allowlists must migrate and clients must obtain fresh
previews after restart. Historical release and live-test records retain their
original identifiers with a link to the migration table.

The dated entries below this migration retain the names used at the time,
including historical source paths and recorded test calls. For current names,
see the [v3.7.2 migration table](docs/releases/RELEASE_NOTES_v3_7.md#sample-skill-names-and-local-files).

Non-sample directories under `skills/` are now ignored, with `_lib/` explicitly
retained as framework code. The generated catalog and default audit log were
removed from the index with local copies preserved. Shared example documentation
remains in README and the sample definitions. The prefix is only a naming and
Git convention; exact transaction attribution still requires the reviewed
source path, loaded class identity, declaration, and adapter evidence.

Validation: `600 passed, 4 skipped`; the renamed real in-memory MCP flows and
the additional custom `sample-` exact-declaration rejection passed. Ten
isolated Git-ignore cases passed, both generated files remained on disk after
index removal, and the local audit content was preserved. The default MySQL
opt-in tests remained skipped; no live database writes were performed for this
migration. `git diff --check` passed.

Final review repeated the full suite from a clean index export, without the
ignored runtime files: `600 passed, 4 skipped`. Two existing MCP regressions
gained explicit dict assertions before reading optional structured content;
their targeted rerun passed both tests. Pyright 1.1.411, using the project
virtualenv, then checked the 16 changed Python paths with `0 errors, 0 warnings`.
Changed Markdown relative-link targets were also checked against tracked files.

---

## Follow-up: Transaction Outcomes and Uncertain COMMIT (September 10, 2026)

v3.7.2 replaces the mutation write path's `engine.begin()` context-manager
boundary with an explicit `connect()` → immediate `begin()` → execute → optional
row-count invariant → `commit()` sequence. Unlike the historical buggy pattern,
no `SET` or other SQL precedes `begin()`, so SQLAlchemy autobegin does not
conflict. The explicit boundary is required to classify a statement failure plus
confirmed rollback separately from a COMMIT acknowledgement failure, which is
always unknown.

Both adapters now accept keyword-only `expected_rowcount`; the built-in status
and demo-reset Skills require exactly one affected row before COMMIT. Typed
adapter results/exceptions carry phase and transaction evidence, while the
successful dict interface remains compatible. MCP results add
`execution_outcome`; processable execute failures become structured business
failures with stable codes, and static setup/token rejection remains
`ToolError`. The host validates response identity before outcome and performs no
automatic follow-up after its one execute. Custom Skills are not given a false
whole-Skill rollback guarantee from one adapter statement, and no generic
multi-statement framework or durable operation ledger was added. Full rationale,
tests, public compatibility notes, sources, and remaining boundaries are in the
v3.7 release notes and DRR-2026-058 through DRR-2026-064.

The success-evidence hardening review removed a symmetric success-path overclaim:
MCP had still hard-coded `committed` after any custom `run_execute()` return.
Successful adapter results now carry internal COMMIT evidence through both
built-in Skills and `MutationBase`; MCP only forwards it. Ordinary custom success
is `success=true, unknown`, while malformed/self-reported failure results and an
exact Skill that drops its evidence become structured unknown failures. The host
accepts `success=true, unknown` as a valid terminal custom-Skill outcome rather
than as successful execution.

Both adapters now also convert `asyncio.CancelledError` raised specifically by
COMMIT into typed `commit_outcome_unknown` after cleanup. Pre-COMMIT cancellation
and unrelated process-control exceptions still propagate after cleanup, and a
transport that has already disappeared cannot receive a structured response.
These corrections and their trust/compatibility boundaries are recorded in
DRR-2026-062 and DRR-2026-063.

The subsequent review closed three additional gaps: SQLAlchemy may return from
rollback without calling the driver after connection invalidation; custom
`run_execute()` exceptions can bypass the base wrapper; and JSON arrays/objects
in `execution_outcome` must be classified rather than hashed. Rollback evidence
now requires an active transaction and a valid connection before rollback and
a still-valid connection afterward, without reconnecting. Custom execution
exceptions become sanitized, audited `unknown` results, and non-string host
outcomes are terminal unknown. Real SQLAlchemy transaction tests cover these
local no-op rollback paths for both adapter control flows.

Adjacent response paths were also hardened: fallback success/failure audit
exceptions cannot replace the write outcome, and serialization-error responses
discard the original custom result in favor of a scalar row-count summary.
This prevents the fallback from failing on the same unserializable value.

The September 11 diagnostic follow-up separates two `unknown` rollback reasons:
`rollback_failed` now requires an exception from the rollback call, while
`rollback_unconfirmed` means local cleanup returned but the original transaction
or connection could not provide sufficient database evidence. Both adapters and
the row-count-mismatch path use consistent classification rules; this diagnostic
distinction does not change host behavior or authorize a retry. Deferred
durable receipts remain in DRR-2026-061 rather than a separate speculative plan.
A versioned design/ADR is reserved for a concrete restart-query,
unattended-recovery, or measured manual-reconciliation requirement with an
owner and migration scope.

The September 12 extension-contract follow-up makes
`MutationBase.run_execute()` a framework-owned template method. Skill discovery
rejects both direct overrides and replacements inherited from an intermediate
custom base class, and points authors to `execute()` or
`execute_with_binding()`. `@final` documents the contract for type checkers;
`inspect.getattr_static()` identity comparison supplies runtime enforcement.
With the wrapper protected, MCP no longer duplicates its business-result and
COMMIT-evidence classification; it retains a narrow fail-closed typed-result
guard for base-level tampering or framework regressions. MCP invokes the base
method directly rather than dispatching through the custom instance, so a
post-load subclass replacement is ignored. The project is pre-release, so this
explicit migration is kept in v3.7.2 rather than preserving an unsafe, unshipped
extension point. Trusted in-process Python remains outside an untrusted plugin
sandbox.

The same P1 follow-up found that the public-looking
`exact_transaction_outcome=True` class flag could otherwise be copied by a
custom Skill. Discovery now reserves the declaration for the two registered
built-in single-statement Skills, and the base wrapper independently checks the
authoritative MCP Skill name *and the exact source-verified class identity*
before accepting exact evidence. The first implementation checked only the
name: configuring a different `SKILLS_DIR` with a same-named two-write custom
Skill could misreport a later statement rollback as a whole-Skill rollback
after an earlier COMMIT. The loader now checks the bundled `mutation.py` path,
rejects such a custom `exact_transaction_outcome=True` declaration, and
registers only the real loaded built-in classes; rediscovery replaces the
registry. Same-named custom Skills with the default flag remain `unknown`.
This closes the ordinary configuration self-upgrade path without introducing a
general custom transaction protocol or claiming protection from malicious
in-process code.
Custom row-count mismatch wording now also says that the whole Skill outcome
cannot be confirmed, instead of implying that earlier custom writes were not
committed when only the current statement's rollback was confirmed.

The same review deliberately did not add `AGENTS.md`. Codex automatically reads
applicable `AGENTS.md` files, so a stale preference could silently affect later
tasks. No collaboration-guide draft is included in the tracked v3.7.2 changes;
the Skill runtime and security contracts remain in the tracked design and
`skills/SAFETY.md` documents.

Earlier post-review validation: `583 passed, 4 skipped`; targeted Pyright reported
`0 errors` and 35 third-party-import resolution warnings. Live MySQL tests were
not enabled, and no live network-failure guarantee is inferred from that run.
After the September 11 follow-up, the default suite completed with
`584 passed, 4 skipped`; the four opt-in real-MySQL cases remained unexecuted,
and Python compilation plus `git diff --check` passed. Targeted Pyright for the
two changed Python paths reported `0 errors` and 16 unresolved third-party-import
warnings from the workspace resolver.
After the September 12 wrapper-contract follow-up, the default suite completed
with `592 passed, 4 skipped`; the same opt-in real-MySQL cases remained
unexecuted, so this run adds no live MySQL claim. Python compilation and
`git diff --check` passed; targeted Pyright reported `0 errors` and 21 existing
third-party-import resolution warnings from the workspace resolver.
After the September 12 source-identity follow-up for DRR-2026-065, the default
suite completed with `596 passed, 4 skipped`; the four opt-in real-MySQL cases
were not run. A real in-memory FastMCP Client regression used a disposable
SQLite database and a temporary in-project SKILLS_DIR to assert that a
same-named custom two-write Skill keeps its earlier COMMIT yet reports
`success=false, unknown` after the second statement rolls back. Both reserved
names fail discovery when their custom sources claim the exact flag; genuine
built-in registration and registry clearing on rediscovery are covered. This
does not establish any real MySQL integration or malicious-code sandbox claim.
The missing-evidence regression was subsequently restored for both genuinely
registered built-in classes. A plain `success=true` dict with no adapter COMMIT
evidence now has explicit tests for `missing_commit_evidence, unknown`, separate
from the unregistered same-name test. That default suite completed with
`598 passed, 4 skipped`; the four real-MySQL opt-in cases were not
executed. A further FastMCP Client regression now asserts that the registered
`update-order-status` returns a structured `missing_commit_evidence, unknown`
when its handler returns a plain success dict. The latest default suite is
`599 passed, 4 skipped`; the opt-in real-MySQL cases had not yet been run at
that point.
After the test-database opt-in on 2026-09-12, the three MySQL read-only checks
and one independent-connection InnoDB stale-state update race passed separately
(`4 passed`). The two race attempts yielded one COMMIT and one rowcount rollback;
the fixture now covers CREATE and preview failures with `try/finally` cleanup
and uses a full UUID table suffix. A read-only `information_schema` check found
zero remaining race-fixture tables. The default suite was rerun unchanged at
`599 passed, 4 skipped`; its opt-in skips are intentional, not a contradiction.
This does not test MySQL network disconnect or uncertain COMMIT acknowledgement.

---

## Follow-up: Strict Tool Contracts and Honest Row Estimates (September 3, 2026)

FastMCP now runs with `strict_input_validation=True`. MCP calls therefore
reject wrong-type scalar JSON such as string booleans and string integers
against the published `inputSchema` instead of applying FastMCP's default
compatible coercion. Handler validation remains necessary for direct Python
calls: `group_identical`, `exact_count`, `available_only`, and the
mutation-critical `confirm` flag now share an exact boolean check, while
omission retains each declared default.

The remaining Agent-facing tool contracts now describe their actual boundaries
instead of relying on prose outside the machine schema. `sample.limit` exposes
an inclusive `1..20` range through `Annotated[int, Field(ge=1, le=20)]`, so a
FastMCP/MCP call outside that range is rejected before the handler or SQL runs.
Valid values and the default of 5 are unchanged. The handler applies the same
explicit rejection to direct Python calls instead of silently clamping invalid
values. `get_table_summary.exact_count` tells the model at the parameter level
that `SELECT COUNT(*)` may require a full scan and may encounter MySQL
metadata-lock contention.

Finite projection values now use shared `Literal` aliases from configuration
parsing through handler validation. The startup-derived
`SKILLS_LIST_DEFAULT_DETAIL` therefore has a statically valid
`compact|summary|full` type as well as runtime fallback behavior. Deliberate
`None`/case/whitespace compatibility paths were removed from the non-null
projection and availability parameters, so MCP and direct Python calls now
share one exact contract. Omitted arguments still use their declared defaults.

Table discovery no longer converts an unavailable row estimate into zero.
SQLite tables outside the conservative generated-metadata identifier grammar
remain discoverable with `row_count=null`; MySQL preserves a nullable
`INFORMATION_SCHEMA.TABLES.TABLE_ROWS` value, and an absent single-table
metadata row is also unknown. Zero now means an actual zero estimate, while
null means unavailable. The same MySQL null semantics now flow
through `describe_table()` and the approximate path of
`get_table_summary()`: `row_count`, `row_count_approximate`, and `is_large` are
null rather than presenting an unknown estimate as a zero-row/small table.
Detailed schema projection still fails explicitly with
`unsupported_metadata_identifier` when it cannot safely inspect one of the
discovered names. SQLite also returns an unknown estimate when a table
disappears between discovery and bounded sampling, rather than classifying that
concurrent DDL race as an empty table.

Tool roles were also narrowed without adding tools or changing database logic:
`query` is the primary *free-form read-only SQL* path, metadata tools own schema
discovery, and reviewed Query Skills own defined workflows. `describe_table`
and related hints say “full adapter-visible column metadata” and explicitly do
not claim complete DDL. `list_connections` distinguishes discoverable aliases
from Mutation authorization: the default alias retains compatibility mode,
while non-default aliases require strict named-write authorization. The
no-argument `list_connections` description and `sql_assistant` prompt no longer
tell callers to omit a nonexistent `connection_id` parameter. The
`sql_assistant` guidance includes `connection_id` in the `list_skills` contract.

A final documentation audit corrected adjacent copies of the same contract.
The maintained AutoGen example now lists all six core tools, uses the compact
discovery path, treats exact counts as opt-in, and passes the returned
`preview_token` with the same params and connection to mutation execution.
README examples now distinguish pre-truncation `total_tables` from
`returned_table_count`, show adapter `default_value`, use internally consistent
`is_large` values, include the required mutation `source`, and document the
sanitized metadata-failure result for each affected schema tool.

This follows FastMCP's documented use of Python signatures, `Literal`, defaults,
and `Annotated` + Pydantic `Field` constraints to produce MCP `inputSchema`, as
well as MCP's requirement that tool descriptions and schemas define the
model-callable contract. The change is intentionally limited to validation,
metadata semantics, and disclosure; it adds no new tool, backend,
configuration, or database query.

Validation passed with `203 passed, 3 skipped` for the focused
adapter/schema/Skills/multi-connection contract suites and `521 passed, 3
skipped` for the default repository suite. Pyright 1.1.411, configured against
the project virtual environment, reported `0 errors, 0 warnings` across all
eight currently modified Python files, including the server, adapters, client,
and affected regression tests.
A disposable SQLite FastMCP Client confirmed the exact `minimum=1`,
`maximum=20`, and default 5 schema; MCP limits 0 and 21 were rejected before
the intercepted adapter executed SQL, while 1 and 20 succeeded. Direct-call
regressions likewise reject invalid limits and non-schema projection/filter
values before SQL. Adapter and core-tool tests distinguish unknown row
estimates from zero and verify that single-table tools do not emit a
large-table classification or recommendation when the estimate is unavailable;
the SQLite regression also simulates a table disappearing before bounded
sampling. A fresh FastMCP 3.0.2 stdio server exposed the non-null compact/full
schema and boolean grouping default, rejected `group_identical="false"`, and
returned the configured MySQL target as 8 tables, 272 columns, and 4 compact
groups without truncation. All MySQL operations were read-only.

The long-running VS Code Host initially exposed its old nullable/default-null
schema even while backend calls reached the new runtime. This was Host
registration cache evidence, not a server contract regression. After tool
rediscovery, the same Host exposed the compact and boolean defaults above and a
direct default call returned the same 8-table, 272-column, 4-group result.
Server restart and Host rediscovery remain separate release gates: inspect the
Host's own `tools/list` before Agent selection tests.

- [FastMCP tool parameter metadata](https://gofastmcp.com/servers/tools)
- [MCP Tools specification](https://modelcontextprotocol.io/specification/2025-06-18/server/tools)
- [Google Vertex AI function-calling guidance](https://docs.cloud.google.com/vertex-ai/generative-ai/docs/multimodal/function-calling)
- [Anthropic tool-definition guidance](https://platform.claude.com/docs/en/agents-and-tools/tool-use/define-tools)
- [MySQL `INFORMATION_SCHEMA.TABLES` reference](https://dev.mysql.com/doc/refman/8.4/en/information-schema-tables-table.html)

---

## Follow-up: Progressive Schema Projection (August 29, 2026)

`get_full_schema()` now supports a compact grouped projection for broad schema
explanations. Its machine-visible `detail_level` default is `"compact"`;
omission is equivalent to explicit compact with the default
`group_identical=true`, so the default envelope uses `schema_groups`. Callers
that need nullable/default/key metadata request full explicitly. Compact output uses structured
`[name, type]` pairs and keeps every returned table name, row estimate, column
count, and primary key. Optional grouping compares every column field currently
exposed by the adapter plus column order. That is stronger than comparing the
compact projection, but it is not complete DDL/index/constraint equivalence;
the response therefore records `grouping_basis`. `describe_table()` remains the
single-table detail path.

Metadata adapters now raise a sanitized `MetadataQueryError` when table,
column, statistics, or bounded row-sampling queries fail. Core schema tools
translate it into `success=false` / `error_code="metadata_query_failed"` and
do not return a partial projection. Legitimately empty databases, missing
tables, and invalid identifiers retain their prior distinct behavior. This also
fixes the optional `get_table_summary()` approximate path, which previously
could report a missing table as a successful zero-column table. A table name
discovered from the database but outside the conservative metadata identifier
grammar now returns the separate `unsupported_metadata_identifier` code rather
than being mislabeled as a query failure or projected with no columns.

The Skills readiness caller now distinguishes an intentionally disabled check,
a successful table snapshot, and unavailable metadata. When the check is
enabled, table-dependent Skills no longer remain `schema_ready=true` after a
metadata failure: discovery reports `schema_check_available=false` and
`schema_ready=false` without fabricating `missing_tables`, while execution
fails closed before query SQL, mutation preview, token issuance, or writes.
Only `MetadataQueryError` is converted to the unavailable state; unexpected
programming exceptions remain visible to tests and error handling.

On the configured MySQL fixture, 8 tables/272 columns measured 36,676 characters
/ 9,270 `o200k_base` tokens in the pre-change Host-rendered full result. A fresh
server process returned grouped compact output at 8,732 / 2,068 after the
guidance refinement, and a reloaded
direct MCP Host reproduced its projection and grouping semantics, reducing those
measures by 76.2% / 77.7%. The corresponding minified comparison was 18,404 /
5,314 to 3,728 / 1,128 (79.7% / 78.8%). Current full output, including adapter
defaults, measured 44,300 / 10,946, making its compact reduction 80.3% / 81.1%.
Ungrouped compact measured 20,125 / 4,660; grouping the five tables whose
adapter-visible column metadata and order were independently verified as equal
saved another 56.6% / 55.6%. A 41-column `describe_table()` measured about
1,094 tokens. The
optimization thus targets both the initial payload and Host-truncation-driven
duplicate calls; these measurements remain specific to the fixture, Host,
serialization, and tokenizer.

After the VS Code Host refreshed its tool registration, direct calls accepted
explicit full, grouped compact, and ungrouped compact parameters. One independent
low-context `MCP Runner` sample received only an exact alias and broad overview
goal; it chose `list_tables` followed by grouped compact, completed the task in
two calls, and made no full-schema, `describe_table`, or SQL call. Since compact
already returns table names and row estimates, this exposed one redundant
discovery call. Tool descriptions now route names/counts-only tasks to
`list_tables`, broad-column tasks directly to compact, one-table full
adapter-visible column metadata to `describe_table`, and the same metadata
across multiple tables to full. With current pretty
payloads, direct compact is 2,068 `o200k_base` tokens versus 2,436 for the same
two-call path. After the MCP service restart, three independent low-context
samples repeated the same broad overview task: `2/3` selected grouped compact
directly and `1/3` retained the leading `list_tables` call. All completed without
truncation, full schema, `describe_table`, or SQL, using four calls total (1.33
per sample). Their estimated pretty schema payload averaged 2,191 tokens, 5.9%
above the all-direct floor and 77.3% below the old approximately 9,638-token
`list_tables + pre-change full` path. This small non-randomized batch supports an
improvement in natural selection but is not a cross-model or cross-Host
guarantee.

Post-fix validation completed with `69 passed, 3 skipped` for the focused
adapter/schema suite. The Skills readiness follow-up completed with `83 passed`
for its focused disclosure/mutation suite. After the final default-contract
change, the focused schema/Skills suite passed `56` tests and the default
repository suite passed `485 passed, 3 skipped`. A fresh stdio registration
confirmed the non-null `compact|full` input enum with default `compact`; the
configured MySQL connectivity check then returned the sanitized database
failure and the smoke skipped before schema or SQL calls. The most recent
successful MySQL read-only projection was the 2026-09-01 run. The later
tool-contract smoke above passed against MySQL on 2026-09-02. No mutation or
database write was attempted.

Anthropic's programmatic tool-calling guidance supports filtering and
aggregation before results enter model context, but currently excludes MCP
connector tools. The portable implementation therefore projects on the server.
MCP `structuredContent` preserves machine-readable results; `outputSchema`
supports validation and documentation but does not automatically reduce result
size, so the follow-up does not add a large union-shaped output schema.

---

## Follow-up: Host-specific Prompt Budget and Routing Guidance (August 29, 2026)

A read-only review measured the current prompt surfaces instead of treating a
generic token cap as a design requirement. With the current FastMCP/VS Code
path, `InitializeResult.instructions` is returned as one server-level block;
the raw MCP tool schemas independently repeat the `connection_id` description
where that field is needed. A separate wrapper or Host may assemble these
surfaces differently, so the measurements are scoped to the named Host,
model, tokenizer, tool set, and feature flags.

The representative measurements used in that review were recorded with the
`o200k_base` tokenizer: the complete instructions were 1,128 characters/215
tokens, of which the routing block was 799 characters/156 tokens. The current
tool surface had nine copies of a 177-character/33-token `connection_id`
description, or about 297 tokens in total. A compact routing candidate was
about 90 tokens, saving about 66 tokens, while a representative historical
HMAC preview value measured roughly 335–350 tokens versus a median of about 29
tokens for the 43-character opaque handle. These are Host/model/tokenizer-
specific observations, not wire-size or client-facing length guarantees. The
current Codex wrapper view may display the routing prefix repeatedly even when
the raw MCP response and the tested VS Code prompt contain one server-level
instructions block.

The review retained the existing routing instructions and self-contained
`connection_id` parameter description. Compressing the routing block would
save only a small number of tokens relative to the safety and routing semantics
it carries, while the shorter opaque mutation handle provides a substantially
larger saving in the preview/execute flow. This is an intentional design
trade-off, not a claim that longer prompts are always preferable.

Future prompt-surface changes should use a frozen, single-variable A/B
comparison: change only the server instructions when testing that wording, and
hold the Host, model, sampling settings, tool schemas, fixture, and task
constant. Report routing correctness, unnecessary calls, input tokens, and
latency as Host/model-specific trends rather than universal guarantees.

No runtime change or new DRR was warranted by this review. The fixed token
limits formerly shown in `PROMPT_ENGINEERING_BEST_PRACTICES.md` were guidance
without a universal basis and have been replaced by baseline, relative-growth,
and behavior-regression guidance. The Agent behavior guide remains the
methodology reference for repeated samples and A/B attribution.

---

## Update v3.7.1 - Opaque Preview Handles and Agent Workflow Efficiency (August 28, 2026)

The mutation protocol keeps the public `preview_token` field but replaces the
self-describing HMAC envelope with a random 256-bit opaque bearer handle. The
bounded process-local Store now owns expiry, exact request binding, preview-time
execution state, and atomic conditional consumption. A mismatched execute
request does not consume the valid record; a matching execute consumes it once
before dynamic validation and writes.

Preview responses no longer duplicate `preview_token_expires_in_seconds`, an
execution hint, or the Skill's nested `requires_confirmation` value. The legacy
`MUTATION_PREVIEW_TOKEN_SECRET` input is ignored with a value-free warning.
Existing v3.6-v3.7 entries below remain historical records of the released HMAC
format rather than the current runtime contract.

`get_skill_detail()` now accepts `execution` and `full` projections through a
non-null enum whose default is full; the execution projection limits
Agent-facing output to invocation fields, resolved connection/DB type, any
disabled reason, and the next action. Catalog guidance no longer recommends a
detail call after `list_skills(detail_level="full")` or when parameters are
already known.

Connection guidance now distinguishes an exact alias, a uniquely matched DB
type, and a purpose/role that cannot be inferred safely. The global
`sql_assistant` prompt is target-neutral for UNION because it has no
`connection_id` argument: callers inspect `list_connections()` and the raw/query
Skill paths enforce the selected connection's policy. Module-load UNION logs
are explicitly labeled as the default-connection summary, and missing-allowlist
errors refer to the selected connection's policy. The standalone
`sql_safety_checker.execute_sql()` helper remains a compatibility statement-
shape gate, not the full MCP `ALLOW_UNION`/`ALLOWED_TABLES` policy.

After a handle has been consumed, a dynamic-validation exception before
mutation execution explicitly reports that no database write was attempted.
Once mutation execution starts, an exception may leave the write result unknown
and directs the caller to verify current database state before another preview
or mutation. This does not make memory-store consumption and database
commit/response delivery atomic. A durable operation ledger and reconnect
status API remain deferred until a real product workflow requires them.

The 2026-08-28 default suite passed with 468 tests and 3 skipped; the explicit
root legacy smoke passed 2 tests. A restarted configured MCP service also passed
a reversible v3.7.1 opaque-handle mutation flow on 2026-08-26. On 2026-08-28,
a fresh stdio subprocess completed the approval-host flow: literal `APPROVE`
returned exit code 0 with `rowcount=1`, while `NO` returned exit code 3 and did
not call execute. A separate fresh subprocess temporarily enabled UNION only
for `analytics_demo_sqlite`; both a raw query and a Query Skill harness returned
a real two-row UNION there while the default MySQL target remained denied by its
target policy. The configured MySQL was later checked successfully with
read-only `SELECT 1` and `COUNT(*)`; an earlier same-day timeout remains a
negative environment observation. Full timings, payload summaries, and evidence
boundaries are in `RELEASE_NOTES/LIVE_MCP_TSET/LIVE_MCP_TEST_V36-V37_ZH.md`.

## Update v3.7.0 - Scoped Skills, Approval Host, and SQL Hardening (August 22, 2026)

v3.7.0 is an incremental Skills release. It adds optional connection binding in
Skill metadata, a portable demo/test reset mutation, an explicit stdio approval
host, and supported-dialect SQL hardening without changing the
v3.6 preview-token format/store, general write protocol, environment-variable
schema, or routing behavior of documented-schema Skills that omit the
new field. Previously ignored unknown/duplicate frontmatter is the intentional
fail-closed compatibility tightening. Release details
are in `RELEASE_NOTES/RELEASE_NOTES_v3_7.md`.

### Optional `connection_ids` frontmatter

`SkillMetadata` now accepts an optional plural list:

```yaml
databases: [mysql]
connection_ids: [orders_primary, orders_reporting]
```

Unknown top-level fields and duplicate YAML mapping keys fail discovery so a
security-relevant typo such as `connections_ids` cannot silently turn a scoped
Skill into an unrestricted one. The singular `connection_id` field is therefore
rejected together with other unsupported fields so metadata is not
mistaken for the per-call routing argument. A declared value must be a non-empty
YAML list of non-empty strings matching `^[a-z][a-z0-9_]{0,63}$` after lowercase
normalization. Normalized duplicates, wildcards, DSNs, paths, and scalars fail
discovery. Values are sorted for deterministic output; order never implies a
default or failover sequence. The loader performs syntax-only validation and
does not add a direct dependency on `db_adapter`; it already reaches runtime
configuration indirectly through the SQL safety module. It therefore locally
mirrors the connection-id regex; future syntax changes
must update both definitions and their tests. Runtime availability uses the
startup connection registry, like the rest of current configuration, so alias
or DB-type changes require a server restart.

The known metadata vocabulary is strict in both name and value. Declared
`enabled`, `idempotent`, and `requires_confirmation` values must be YAML
booleans; `triggers` and `related_skills` must be lists of strings; and
`category` must be a non-empty string. Each parameter schema accepts only
`type`, `required`, `min`, `max`, `enum`, and `description`. Constraint values
must match the declared parameter type, enum must be a non-empty list, and
numeric bounds must be ordered. This completes the repository's lightweight
DSL rather than replacing it with JSON Schema.

Omission is represented by `None` and preserves the prior unrestricted-by-Skill
behavior. A list with one member provides direct binding; multiple members
support reuse. Runtime tool arguments remain singular. When a call omits
`connection_id`, the normal global default is resolved first and then checked;
the server never auto-routes to the only/first metadata member.

The MCP execution paths enforce the first two checks before adapter construction:

```text
target ∈ connection_ids (if declared)
AND target.db_type ∈ databases (if declared)
THEN every existing profile/schema/table/query/mutation policy passes before
query execution or database writes
```

Metadata only restricts—it never creates a connection or grants a read/write
permission. Unconfigured declared aliases remain portable metadata but are
reported unavailable with a startup warning. A configured alias whose DB type
conflicts with `databases` fails closed for that target and emits a startup
error; other valid aliases on the same reusable Skill remain available. This
per-target compromise is intentional: globally disabling the Skill would break
the intersection/reuse model without improving the rejected target's safety.

`list_skills()` and `get_skill_detail()` expose declared/configured/unconfigured
ids, per-target scope state, and type conflicts at summary/full detail. Search
includes declared aliases. `available_only` uses the scope state to reduce model
selection errors but is not authorization; both query and mutation execution
repeat the check. The query and mutation paths share the same resolver so scope
rejection occurs before `get_adapter()`. Mutation policy remains a separate,
additional deny-by-default layer, and preview tokens continue to bind exactly
one resolved connection.

Direct Python calls to `skill_loader` or a Mutation class bypass MCP routing and
must enforce equivalent target policy in the embedding application. Built-in
Skills contain commented alias examples only; v3.7 does not silently bind demo
Skills to deployment-specific names. Documentation recommends semantic aliases
such as `orders_primary`/`trade_analysis_mysql`/`analytics_demo_sqlite`;
`mysql` and `sqlite` remain legal but
are easy to confuse with `databases` type values.

### One-shot manual approval host

`examples/manual_mutation_approval.py` is deliberately outside the AutoGen demo
and adds no dependency. It launches `start_server.py` with `sys.executable`, so
the current venv is preserved, explicitly inherits the operator's complete
process environment so exported DB/policy configuration is not replaced by a
different `.env`, and keeps preview and execute in one stdio Client context and
server subprocess as required by the process-local store. A canonical finite-JSON
parameter snapshot is used for both calls. The workflow fingerprints the approval
view and fails closed if a custom provider changes displayed params or preview
data before returning its decision. If the original request omits a target, execute
is pinned to the resolved `connection_id` returned by preview rather than
resolving the default again.

The host strictly requires a successful preview with matching Skill, valid
resolved alias/DB type/business preview, boolean idempotency, non-empty token,
and timezone-aware expiry. It derives approval timeout from the smaller of the
CLI timeout and remaining token lifetime minus a safety margin, and the workflow
itself enforces that monotonic deadline instead of trusting the UI provider. A
custom provider must cooperate with async cancellation; hostile-provider hard
termination would require process isolation. The approval
view excludes the bearer token and displays the exact Skill, params, resolved
connection, DB type, preview, expiry, and idempotency. Only literal `APPROVE`
executes; denial, blank/other input, timeout, EOF, cancellation, malformed
preview, or UI error fails closed. A daemon input thread avoids leaving
`asyncio.run()` waiting for a non-cancellable `input()` executor task after a
timeout; this is intentionally a one-shot CLI and does not reuse stdin.

Execute is attempted once. Exceptions/timeouts are classified as an unknown
write outcome and never retried because token consumption and database commit
may already have occurred. Returned output removes the `preview_token` field and
redacts the exact bearer value if an abnormal server echoes it elsewhere.
`--params-file` avoids putting business params in shell history, but the file,
rendered params/preview, and printed execute result may contain sensitive
business data; operators
must protect the file, terminal, screen sharing, and terminal capture/history.

The example is not proof of an authenticated human approval. Any other MCP
client can bypass it. Denial does not revoke the server-side token record or
create a server denial audit; the record consumes one bounded entry until
expiry/lazy cleanup and only normal preview audit exists. Token bytes necessarily
pass through FastMCP/client memory, Python cannot guarantee secure erasure, and
external payload/debug logging can still disclose them. A real multi-user or
compliance workflow needs product-owned approver authentication, role policy,
durable audit, and possibly an explicit cancellation protocol. These are not
v3.7 HTTP capabilities. Passing `env=dict(os.environ)` is an intentional
trusted-local-host compromise: it preserves the exact operator database/policy
configuration but also places every exported secret and Python control variable
inside the child/Skill trust boundary. A productized host should forward a
maintained project-specific allowlist instead.

### SQL safety and portable demo reset mutation

The shared SQL gate accepts exactly one statement. The full MCP policy rejects
raw `SHOW` and directs metadata discovery to `list_tables()`/`describe_table()`;
adds `sys` to blocked system schemas; preserves schema qualification during
allowlist checks; and extracts comma joins, nested queries, CTEs, ordinary
comment-separated targets, and EXPLAIN child tables without treating keywords
as tables. Non-ANALYZE EXPLAIN/DESCRIBE/DESC of
`UPDATE`/`INSERT`/`REPLACE`/`DELETE` remains supported; restrictive allowlists
check the DML target, all read sources, CTE aliases, and multi-table
`DELETE ... USING` source tables. Ambiguous targets fail
closed under a
restrictive allowlist. MySQL executable comments (`/*! ... */`), optimizer hints
(`/*+ ... */`), MariaDB executable comments (`/*M! ... */`), non-whitespace
double-dash forms, executing ANALYZE explain, and nested write DML are rejected.
These are conservative statement-shape/application-policy guards, not a claim
of comprehensive SQL semantics or database authorization.

`reset-demo-order-to-pending` is a deliberately low-freedom mutation example.
It requires the caller to state the exact non-pending status expected after a
preceding test, while reviewed code fixes the target to `pending`. It performs a
second read for the visible preview, binds that displayed source state into the
one-time token, and repeats it in the optimistic-lock predicate. The portable
SQL supports `databases: [mysql, sqlite]`; optional `connection_ids` remains
commented so deployments can bind it to their own dedicated demo aliases.

This is both a mutation-path exercise and a compensating cleanup call, not a
transactional rollback or production order-reopening operation. Supported
schemas must enforce `orders.id` as `PRIMARY KEY` or `UNIQUE`; the Skill's
read-side cardinality check is diagnostic only. Because the reset deliberately
permits `pending -> X -> pending`, it makes the status-only ABA limitation in
DRR-2026-046 reachable through bundled demo Skills. Live scenarios should use
dedicated records, avoid overlapping previews, and preferably start a fresh
stdio process per scenario.

### Files and validation

| File | Change |
|------|--------|
| `skills/_lib/skill_loader.py` | Parses, normalizes, caches, and discloses optional `connection_ids` without adding a direct connection-module dependency |
| `mcp_sql_server.py` | Evaluates discovery availability on the resolved target and rechecks scope/type before adapter creation in query and mutation execution paths |
| `examples/manual_mutation_approval.py` | Adds the stdio-only explicit approval reference host |
| `sql_safety_checker.py`, `mcp_sql_server.py`, `tests/test_sql_policy.py` | Enforce one-statement/raw-SHOW/comment/system-schema boundaries and token-aware table scope, including EXPLAIN-family DML targets/read sources/CTE aliases and multi-table `DELETE ... USING` sources, while preserving ordinary comments/strings and non-ANALYZE plan inspection |
| `skills/reset-demo-order-to-pending/` | Adds the MySQL/SQLite demo reset with explicit expected source state and fixed `pending` target |
| `tests/test_skill_loader.py` | Covers omission, one/many normalization, malformed metadata rejection, and parser/runtime alias-grammar parity |
| `tests/test_multi_connection_v35.py` | Covers query scope, default behavior, disclosure, pre-adapter denial, and real-frontmatter per-target type-conflict isolation |
| `tests/test_mutation_multi_connection_v36_design.py` | Covers mutation scope, pre-adapter denial, policy intersection, target isolation, and token non-consumption before scope acceptance |
| `tests/test_manual_mutation_approval.py` | Covers approval state, enforced deadlines, expiry, malformed results, finite-JSON snapshots, approval-view mutation rejection, resolved-target pinning, environment propagation, non-retry, and token non-output/redaction |
| README/safety/design/guide/risk/release documents | Record v3.7 contracts, limits, compatibility, and best-practice rationale |

Validation results:

- Final default repository suite after adversarial SQL/Skill/mutation hardening:
  462 passed, 3 skipped.
- The August 22 portable reset follow-up retained 462 passed, 3 skipped; its
  focused mutation/token/discovery selection passed 94 tests and the explicit
  root regression smoke passed 2 tests. As of August 22, neither a real MySQL
  reset nor a reset-specific subprocess stdio live run had been performed. The
  v3.7.1 follow-up later validated SQLite reset in direct MCP and fresh-stdio
  flows; a real MySQL reset remains unclaimed.
- Focused SQL/query/SQLite suites: 115 passed.
- The root legacy smoke is outside default `pytest.ini` collection and was run
  explicitly: `test_bug_fixes.py` passed 2 tests.
- `git diff --check`, EN/ZH risk-register parity, and tracked Markdown
  relative-link checks passed.
- The approval workflow passed a real FastMCP `Client(module.mcp)` in-memory
  contract test and changed a disposable SQLite order exactly once.
- The 2026-08-13 and 2026-08-19/20 subprocess stdio attempts reached server
  startup but did not complete MCP initialize before the client timeout. They
  failed closed with no preview, audit, or DB write and remain historical
  environment observations. A 2026-08-21 follow-up subsequently completed the
  approval, denial, minimal-echo, `start_server.py`, and full-server subprocess
  stdio checks; details are recorded in
  `RELEASE_NOTES/LIVE_MCP_TSET/LIVE_MCP_TEST_V36-V37_ZH.md`.

---

## Update v3.6.1 - Preview-Token Store and Execution Hardening (August 10, 2026)

This v3.6.1 maintenance update belongs to the v3.6 release family and continues
to use `RELEASE_NOTES/RELEASE_NOTES_v3_6.md`. It closes DRR-2026-003,
DRR-2026-035, DRR-2026-037, DRR-2026-038, DRR-2026-039, DRR-2026-041,
DRR-2026-045, and DRR-2026-047.

The final architecture uses one bounded, locked, process-local memory store.
The recommended deployment is stdio, where preview and execute stay in the same
client-launched MCP process. Conditional HTTP mutation use is limited to one
mutation-enabled process in a trusted private boundary; multi-user authenticated
HTTP mutation is not a v3.6.1 deployment target. The application cannot enforce
worker/replica counts. Restart invalidates outstanding tokens even with a fixed
signing secret; callers must preview again.

A shared external token backend was evaluated because it could coordinate state
across workers. It is intentionally deferred: the repository primarily
documents stdio/single-process use and does not yet define or validate a
complete remote multi-replica profile. External services and persistence layers
move rather than eliminate transaction, cleanup, failure, and operational
complexity. The current design therefore requires no external token service,
token table, or token file.

The main token-store work and final-review follow-up were:

1. **DRR-2026-045 deployment scope:** retained the v3.6 bounded memory store,
   formalized a stdio-first same-process contract, and deferred shared external
   state until a concrete remote mutation requirement exists.
2. **DRR-2026-041 test signal:** completed signing-secret rotation with a real
   reload/rejection assertion, replaced the tautological sanitization check,
   and covered terminal token consumption after a database write exception.
3. **DRR-2026-038 preview provenance:** `update-order-status` now builds its
   binding from the status returned by the same query that produced the visible
   preview. A preview carrying an `error` or reporting `success=false` returns a
   failed result and receives no token, including empty/null error values.
4. **DRR-2026-037 one write path:** the public unbound `execute()` method now
   raises `ToolError`; all order-status writes go through
   `execute_with_binding()` and the preview-derived optimistic-lock value.
5. **DRR-2026-039 test isolation:** default pytest disables `.env` loading,
   installs a safe SQLite/config baseline before application imports, and
   requires explicit opt-in before the MySQL fixture can connect.
6. **DRR-2026-035 fixture cleanup:** reverified that `sample_data/demo.db`
   matches its tracked baseline and retained the rule that write tests use
   disposable databases.
7. **DRR-2026-003 dead helper cleanup:** removed two unreferenced availability
   wrappers so `_skill_availability_state()` remains the only policy source.
8. **Post-consume audit completeness:** dynamic validation rejection after
   atomic token consumption now attempts a best-effort execute audit and reports
   the actual `audit_logged` result without weakening terminal consumption. A
   response-stage failure after a committed write preserves the existing
   success audit instead of appending a contradictory execute failure.
9. **Configuration bounds and visibility:** capped process-local capacity at
   100000 entries, added generated/configured signing-key diagnostics without
   logging key material, and summarized candidate and policy-enabled mutation
   routing at startup without calling it final Skill/schema authorization.
10. **Dead named SQLite alias:** removed the unreachable
    `DB_<ID>_DATABASE_PATH` fallback; `DB_<ID>_SQLITE_DATABASE_PATH` remains the
    only named SQLite path setting.

The memory store preserves random `jti`, HMAC and execution-state binding,
bounded issuance, expiry cleanup, atomic one-time consume, sequential/concurrent
replay rejection, and terminal consumption. It does not support cross-worker
preview/execute, mutation horizontal scaling, restart-surviving token state, or
cross-process global capacity. Named database connections are unaffected;
read-only scaling requires a separate read-only endpoint, profile, or pool.

### Files and Configuration

| File | Change |
|------|--------|
| `preview_token_store.py` | Extracted the v3.6 bounded, locked memory-store behavior into a focused module with a minimal token record |
| `mcp_sql_server.py` | Registers/consumes preview tokens in one process, bounds TTL at 86400 seconds and capacity at 100000 entries, audits post-consume validation rejection, reports safe startup policy diagnostics, rejects every declared preview failure, and accurately describes optional mutation capability |
| `db_adapter.py` | Keeps `DB_<ID>_SQLITE_DATABASE_PATH` as the sole named SQLite path and removes an unreachable alias fallback |
| `skills/update-order-status/mutation.py` | Binds execution to the displayed preview read and disables direct unbound execution |
| `tests/test_preview_token_store.py` | Covers memory capacity, expiry, mismatch, and concurrent one-winner semantics |
| `tests/test_mutation_multi_connection_v36_design.py`, `tests/test_mutation_skills.py` | Cover DRR-2026-037/038/041/045, strict preview failures, TTL bounds, and tool-level concurrent replay with exactly one database write |
| `tests/conftest.py` | Makes default pytest independent of local `.env` and gates optional live MySQL integration behind explicit opt-in |
| `requirements.txt` | Requires `python-dotenv>=1.2.0`, the first release that implements the test suite's `.env` disable switch |

The retained token settings are:

```env
MUTATION_PREVIEW_TOKEN_TTL_SECONDS=300
# Valid range: 1-100000; invalid values fall back to 10000.
MUTATION_PREVIEW_TOKEN_STORE_MAX_ENTRIES=10000
# MUTATION_PREVIEW_TOKEN_SECRET=replace_with_at_least_32_random_bytes
```

### Validation

- Syntax checks passed for the store, MCP server, and focused test modules.
- Focused mutation/store regression:
  `.venv/bin/python -m pytest -q tests/test_preview_token_store.py tests/test_mutation_multi_connection_v36_design.py tests/test_mutation_skills.py`
  -> 67 passed.
- Full repository suite: `.venv/bin/python -m pytest -q` -> 289 passed,
  3 skipped.
- `git diff --check` passed. Runtime Python, environment examples, and base
  requirements contain no external token-store dependency or configuration.

---

## Post-v3.6 Test Isolation and Documentation Follow-up (August 2, 2026)

### Test Isolation

The local live `.env` intentionally enables the v3.6 strict named-write policy
with `SKILLS_ALLOW_MUTATION_CONNECTIONS=mysql,analytics`. The v3.5 regression
fixture instead registers `default,analytics`. Because `db_adapter.py` calls
`load_dotenv()` during module import, an unisolated test process could restore
the local allowlist and fail during `mcp_sql_server` import by looking for an
unconfigured `mysql` fixture connection.

`tests/test_multi_connection_v35.py::_reload_server()` now explicitly sets
`SKILLS_ALLOW_MUTATION_CONNECTIONS` to an empty value before re-importing the
server modules. Empty, rather than deleting the variable, is deliberate:
`load_dotenv()` does not override an existing empty environment value, so the
live `.env` cannot reintroduce the `mysql,analytics` allowlist. This is a test
fixture isolation fix; the live `.env` must not be changed to accommodate the
v3.5 test aliases.

### Documentation Follow-up

- Added `V3_5-V3_7_SKILLS_GUIDE_ZH.md` (originally the v3.5-v3.6 guide), an explanatory Chinese guide covering
    named connections, per-connection policy, Skill metadata, strict mutation
    routing, preview-token binding, state drift, and MutationBase contracts.
- Updated `skills/SAFETY.md` for the implemented v3.6 server-side
    preview-token model, corrected the concrete `Mutation.execute()` write
    constraint, and clarified that stdio/SSE is not itself a rate-limit boundary.
- Added Chinese explanations to the local `.env` for connection routing,
    timeout scope, token lifecycle, audit behavior, default limits, and the
    test-isolation boundary. No effective live configuration values were changed.

### Validation

- `.venv/bin/python -m pytest -q tests/test_multi_connection_v35.py` → 6 passed.
- `.venv/bin/python -m pytest -q tests/test_mutation_multi_connection_v36_design.py` → 27 passed.
- `git diff --check` for the changed test and documentation files produced no output.

## Project-wide Pylance Type-Safety Follow-up (August 2, 2026)

### Findings and Root Cause

A workspace-wide Pylance scan found five severity-1 diagnostics outside the
previously fixed v3.5/v3.6 regression files. They had the same underlying
pattern: optional or loosely typed values were allowed to cross a helper or
test-double boundary without an explicit contract or runtime narrowing.

- `test_mcp_client.py` passed `None` to a parameter declared as `str`.
- `tests/test_annotations_consistency.py` declared FastMCP tools as
    `object`, then accessed their `annotations` member; a second access path
    also used an optional annotation without checking it.
- `tests/test_db_adapter.py` assigned lightweight `DummyEngine` instances to
    the production `Engine | None` attribute without documenting the test-only
    structural substitution.
- `tests/test_skills_disclosure.py` accessed `openWorldHint` on an optional
    `ToolAnnotations` value.

### Remediation

- Marked the client helper's `note` parameter as `str | None`.
- Typed the annotation test's tool collection as `dict[str, Tool]` and added
    explicit `None` assertions before reading optional annotations.
- Used narrow `cast(Engine, ...)` expressions only at the three test-double
    assignments; production adapter typing remains unchanged.
- Added an explicit annotation-presence assertion before reading
    `openWorldHint` in the Skills disclosure test.
- Extended pytest environment isolation to include
    `SKILLS_ALLOW_MUTATION_CONNECTIONS`, and made the named-connection policy
    test explicitly disable MySQL mutations so local `.env` values cannot alter
    its expected baseline.

The preferred rule is to fix uncertainty at the producer or helper boundary,
then use a runtime assertion when the test is intentionally validating that
the value exists. Broad `Any` annotations and scattered `# type: ignore`
directives are not appropriate substitutes for these contracts.

### Validation

- Workspace Pylance diagnostics: no severity-1 findings remain. Severity-4
    unused-symbol notices are informational and were left outside this fix.
- `.venv/bin/python -m pytest -q tests/test_annotations_consistency.py
    tests/test_db_adapter.py tests/test_skills_disclosure.py` -> 70 passed,
    3 skipped.

---

## Update v3.6 (May 30, 2026) - Mutation Preview Tokens and Named Write Policy

### Overview

Closed the v3.5 compromise that kept mutation Skills on the default connection
only. v3.6 introduces one consistent high-impact write protocol: every
`execute_mutation_skill(confirm=true)` call must present the one-time
`preview_token` returned by the matching `confirm=false` preview, including on
the default connection. Named write targets are opt-in and require three
independent policy layers before a write is considered.

The token is HMAC-signed and bound to skill name, skill version, canonical
params hash, resolved `connection_id`, `db_type`, issue/expiry timestamps, a
random `jti`, and a hash of the minimal preview-time execution binding. It is
registered in a bounded process-local store and atomically consumed before
dynamic validation and the write, so replay fails closed. Consumption is
terminal: after a later validation, database, timeout, audit, or response
failure the caller must preview again rather than retry the old token.

### Changes

| File | Change Type | Description |
|------|-------------|-------------|
| `mcp_sql_server.py` | Modified | Added `PreviewTokenRecord`, `InMemoryPreviewTokenStore` (bounded, locked, lazy-expiring), token payload/signature/verify/consume helpers, `MUTATION_PREVIEW_TOKEN_*` configuration, `SKILLS_ALLOW_MUTATION_CONNECTIONS` strict-mode parsing with startup validation of each listed id, `_mutation_connection_policy_state()` shared by discovery and execution, and optional `connection_id` plus required `preview_token` on `execute_mutation_skill` |
| `mcp_sql_server.py` Skills paths | Modified | `list_skills` / `get_skill_detail` now report `mutation_connection_supported` and `mutation_policy_allowed`; unauthorized mutation Skills are non-executable in discovery and rejected at execution with the same policy result |
| `db_adapter.py` | Modified | Extended `ConnectionPolicy` with `allow_mutations` and `mutation_skills`; added `DB_<ID>_ALLOW_MUTATIONS` / `DB_<ID>_MUTATION_SKILLS` parsing with skill-name validation and explicit `*` wildcard; omitted per-target values deny writes |
| `skills/_lib/mutation_base.py` | Modified | Added `build_execution_binding()` and `execute_with_binding()`; `run_execute()` now routes through the binding path, forwards `client_id` / `connection_id` / `db_type` to audit, and returns the real `_audit_logged` outcome. A non-empty binding is rejected rather than silently ignored |
| `skills/update-order-status/mutation.py` | Modified | Captures `expected_status` during preview and applies the optimistic lock against that previewed value via `_execute_with_expected_status()` instead of re-binding to a later status |
| `skills/update-order-status/skill_def.md` | Modified | Documented the token workflow, one-time replay protection, preview-state binding, and best-effort audit semantics |
| `tests/test_mutation_multi_connection_v36_design.py` | Added | 27 tests covering routing, token binding/tampering/expiry, all three denial layers, one-time replay, concurrent consumption, capacity and lazy expiry, restart invalidation, static-rejection non-consumption, terminal failure semantics, preview-state drift, and full-token exclusion from meta/audit |
| `.env.example` | Modified | Documented `MUTATION_PREVIEW_TOKEN_TTL_SECONDS`, `MUTATION_PREVIEW_TOKEN_STORE_MAX_ENTRIES`, `MUTATION_PREVIEW_TOKEN_SECRET`, `SKILLS_ALLOW_MUTATION_CONNECTIONS`, and the per-connection write variables |
| `README.md`, `README_ZH.md`, `MCP_AGENTS_SKILLS_DESIGN.md`, `skills/SAFETY.md`, `DESIGN_RISK_REGISTER.md`, `DESIGN_RISK_REGISTER_ZH.md` | Modified | Documented the two-call migration requirement, the strict write policy layers, token lifecycle and limits, and DRR-2026-030 / DRR-2026-034 |
| `RELEASE_NOTES/RELEASE_NOTES_v3_6.md` | Added | Release notes for the preview-token core and named write policy |

### Write Authorization Layers

A mutation write is attempted only when all of the following hold. They are
independent switches, not alternatives:

1. `ENABLE_SKILLS=1`
2. `SKILLS_ALLOW_MUTATIONS=1`
3. Target `connection_id` listed in `SKILLS_ALLOW_MUTATION_CONNECTIONS`
   (omitting the variable keeps v3.5-compatible default-connection-only scope)
4. `DB_<ID>_ALLOW_MUTATIONS=1`
5. Skill listed in `DB_<ID>_MUTATION_SKILLS` (or the explicit `*` wildcard)
6. DB type compatibility and schema readiness for the resolved connection
7. Parameter schema validation plus the Skill's own `validate()`
8. A valid, unexpired, unconsumed `preview_token` matching this exact request

Query `ALLOWED_TABLES` is deliberately not reused as write authorization: a
readable table is not a writable table.

### Design Decisions

| Decision | Choice | Alternative | Rationale |
|----------|--------|-------------|-----------|
| Token scope | Required for every mutation execute, including the default connection | Require tokens only for non-default connections | One protocol avoids a weaker legacy path and makes preview/execute target binding explicit everywhere |
| Token binding fields | skill name, version, canonical params hash, `connection_id`, `db_type`, `iat`/`exp`, `jti`, execution-binding hash | Sign only skill name and params | Prevents preview-on-A/execute-on-B, param substitution, and executing v2 logic against a v1 preview |
| Replay protection | Bounded process-local store consumed atomically before validation/write | Rely on HMAC expiry alone, or consume only after successful commit | HMAC alone is replayable until expiry; consuming after commit reopens the race. Consuming first is conservative for uncertain write outcomes |
| Capacity behavior | Fail closed when the store is full; never evict valid tokens | LRU eviction | Eviction would silently invalidate a legitimate reviewed preview |
| Preview-state binding | Opt-in per Skill via `build_execution_binding()` / `execute_with_binding()`; non-empty bindings must be handled | Always re-read state during execute | Re-reading lets execute act on state the reviewer never saw; explicit opt-in avoids silently ignored bindings |
| Named write policy | Global target allowlist plus per-connection switch plus per-connection skill allowlist | Single global switch, or reuse read allowlists | Deny-by-default with separate operator-controlled layers; read policy and write authorization stay distinct |
| Discovery/execution parity | `_mutation_connection_policy_state()` used by both | Filter in discovery only | Keeps `available_only` an ergonomic filter while execution stays authoritative |

### Compatibility Notes

- **Breaking for direct execute callers.** Clients that previously called
    `execute_mutation_skill(confirm=true)` in one step must now call
    `confirm=false` first and pass the returned `preview_token`.
- Omitting `SKILLS_ALLOW_MUTATION_CONNECTIONS` preserves the v3.5
    default-connection-only mutation scope. Setting it enables strict mode and
    does not by itself grant write permission.
- The token store is process-local. Preview and execute must reach the same
    server process. Client-owned stdio is the recommended deployment. If an
    integrator conditionally exposes mutation over HTTP, it must use one process
    in a trusted private boundary; multi-user authenticated HTTP mutation is not
    supported. Restart invalidates outstanding tokens even when
    `MUTATION_PREVIEW_TOKEN_SECRET` is fixed, because store state is not
    persisted. The application does not enforce worker/replica counts. A future
    multi-worker design requires shared atomic state and must not fall back to
    stateless HMAC acceptance.
- `preview_token` is returned in the structured payload only. Applicable tool
    metadata carries a short `preview_token_id` correlation hint. Audit and
    telemetry persist neither the full token nor that short identifier.
- `destructiveHint` and `requires_confirmation` remain advisory client hints.
    `confirm=true` proves the client requested execution; it does not prove a
    human approved it. Deployments needing human approval require a separate
    client or external workflow.

### Validation

- `.venv/bin/python -m pytest -q tests/test_mutation_multi_connection_v36_design.py` → 27 passed.
- Full repository test suite after the v3.6 change set: `.venv/bin/python -m pytest -q` → 259 passed, 3 skipped.
- Live MCP stdio smoke on MySQL and SQLite fixtures verified preview token
    issuance, execute with the matching token, one-time replay rejection,
    cross-connection token rejection without consuming the valid token, and
    `pending -> confirmed` writes with `rowcount=1`. Details and cleanup
    evidence are in `RELEASE_NOTES/LIVE_MCP_TSET/LIVE_MCP_TEST_V36-V37_ZH.md`.

---

## Update v3.5 (May 30, 2026) - Named Multi-Connection Read Tools and Query Skills

### Overview

Implemented configured named database connections while preserving the legacy
single-default-connection path. The core invariant is now explicit in code and
docs: resolve the target `ConnectionContext` first, then run SQL policy, schema
readiness checks, dialect-specific helper SQL, execution, metadata, audit, and
telemetry against that same connection. Unknown connection ids fail closed and
never fall back to the default.

### Changes

| File | Change Type | Description |
|------|-------------|-------------|
| `db_adapter.py` | Modified | Added `ConnectionPolicy` and `DatabaseConfig`, named connection env parsing, `get_default_connection_id()`, `get_connection_config()`, `list_connection_configs()`, and an adapter cache keyed by `connection_id`; direct constructors and no-arg `get_adapter()` remain compatible with legacy callers; `DB_<ID>_*` and `DEFAULT_DB_CONNECTION` are ignored unless `DB_CONNECTIONS` is explicitly set |
| `sql_safety_checker.py` | Modified | Added optional `connection_id` to `execute_sql()` and now resolves the selected adapter/config before SQL safety policy or execution while preserving existing two-argument behavior |
| `mcp_sql_server.py` | Modified | Added `ConnectionContext`, `_resolve_connection_context()`, `list_connections()`, optional `connection_id` on read-only core tools, connection-aware policy/schema helpers, connection-aware ToolResult metadata/telemetry, quoted-identifier table allowlist extraction, and SQLite public database display aliases (`sqlite:<connection_id>`) |
| `mcp_sql_server.py` Skills paths | Modified | `list_skills`, `get_skill_detail`, and `execute_query_skill` now evaluate DB compatibility, schema readiness, allowlists, execution, metadata, optional query audit, and telemetry against the target connection; mutation Skills are marked non-executable on non-default connections in v3.5 |
| `skills/_lib/audit.py`, `skills/_lib/mutation_base.py` | Modified | Audit records can include safe `connection_id` and actual `db_type` without logging DSNs, credentials, SQL params, or returned rows |
| `start_server.py` | Modified | Startup validation imports server code only after environment validation and now validates the configured connection registry |
| `.env.example` | Modified | Added optional `DB_CONNECTIONS`, `DEFAULT_DB_CONNECTION`, and `DB_<ID>_*` examples, including the legacy-mode rule that per-connection variables and default selection are inactive until `DB_CONNECTIONS` is set |
| `README.md`, `README_ZH.md`, `MCP_AGENTS_SKILLS_DESIGN.md`, `SQLITE_ADAPTER_DESIGN.md`, `skills/SAFETY.md`, `TEST_MCP_CLIENT_GUIDE.md`, `DESIGN_RISK_REGISTER.md`, `DESIGN_RISK_REGISTER_ZH.md` | Modified | Documented v3.5 behavior, invariants, compatibility, compromises, telemetry/audit privacy, deferred multi-connection mutation risk, the `DB_CONNECTIONS` feature gate, runtime allowlist checks for quoted identifiers, SQLite path sanitization in public payloads, and the distinction between local pytest guardrails and actual CI enforcement |
| `tests/test_multi_connection_v35.py` | Added | Covers registry parsing, unknown connection fail-closed behavior, same-connection policy/execution, Skills availability/execution consistency, and mutation default-only scope |
| `tests/conftest.py`, `tests/test_db_adapter.py`, `tests/test_v342_meta_and_schema.py`, `tests/test_audit.py`, `tests/test_skills_disclosure.py`, `tests/test_annotations_consistency.py` | Modified | Expanded assertions for registry reset behavior, legacy-mode isolation from local named `.env` variables, connection metadata, audit fields, tool surface, and disclosure consistency |

### Design Decisions

| Decision | Choice | Alternative | Rationale |
|----------|--------|-------------|-----------|
| Connection identity | Server-configured `connection_id` aliases only | Allow tools/models to pass DSNs | Prevents credential disclosure and keeps routing under operator control |
| Resolve-first invariant | Resolve `ConnectionContext` before policy, readiness, helper SQL, execution, metadata, audit, and telemetry | Let each helper read global adapter/config state | Prevents cross-connection mismatches and fixes the historical quote-on-one-adapter/execute-on-default risk |
| Default compatibility | Omitted `connection_id` uses the default connection and legacy env vars still work when `DB_CONNECTIONS` is unset | Require all callers to pass connection ids | Preserves existing behavior and minimizes migration cost |
| Query Skill runtime policy | Startup validation checks read-only/structural safety; runtime enforces target connection policy | Validate every skill against every configured connection at startup | Per-connection allowlists differ by deployment, so runtime is the authoritative policy point |
| Table allowlist parsing | Normalize common quoted and schema-qualified identifiers before comparison | Continue matching only bare identifiers | Prevents `"table"`, `[table]`, and `schema."table"` forms from bypassing per-connection allowlists |
| Mutation scope | Default-connection only in v3.5 | Enable multi-connection writes immediately | Avoids preview/execute target drift and missing per-connection write permissions until a dedicated write policy exists |
| Metadata privacy | Include `connection_id` and `db_type`; exclude DSNs, hosts, users, passwords, SQLite paths, SQL params, and returned rows; display SQLite databases as `sqlite:<connection_id>` in public payloads | Include connection internals for debugging | Gives operators enough correlation without leaking sensitive connection material |

### Compatibility Notes

- Existing `.env` files that set only `DB_TYPE`, MySQL credentials, or
    `SQLITE_DATABASE_PATH` continue to work. `DB_CONNECTIONS` is optional.
- `DB_<ID>_*` variables are treated as named-connection config only when
    `DB_CONNECTIONS` is explicitly set. If `DB_CONNECTIONS` is unset or empty,
    legacy mode ignores those variables so local smoke configuration cannot
    silently override `DB_TYPE`/`SQLITE_DATABASE_PATH`.
- `DEFAULT_DB_CONNECTION` is also ignored in legacy mode; it only selects a
    default among ids listed in `DB_CONNECTIONS`.
- Existing MCP calls keep working when they omit `connection_id`; the default
    connection is selected.
- `SkillMetadata.databases` still describes DB type compatibility (`mysql`,
    `sqlite`, or omitted), not connection ids.
- Query Skills are now connection-scoped for listing, detail, and execution.
    Their visible executability should match the target connection used for
    execution.
- Mutation Skills intentionally remain default-connection only in v3.5. This is
    a documented compromise, not a missing parameter.
- Result-size caps (`MAX_RESULT_ROWS`, `MAX_RESULT_CHARS`, schema/table overview
    caps) remain process-wide; per-connection policy currently covers allowlist,
    UNION, query timeout, connect timeout, and SQLite progress interval.

### Validation

- Syntax check: `.venv/bin/python -m py_compile db_adapter.py sql_safety_checker.py mcp_sql_server.py start_server.py skills/_lib/audit.py skills/_lib/mutation_base.py tests/test_multi_connection_v35.py tests/test_db_adapter.py tests/test_v342_meta_and_schema.py tests/test_audit.py`
- Focused v3.5/regression suite after the latest follow-up: `.venv/bin/python -m pytest -q tests/test_sql_policy.py tests/test_multi_connection_v35.py tests/test_db_adapter.py::TestGlobalAdapter tests/test_v342_meta_and_schema.py tests/test_audit.py tests/test_skills_disclosure.py::test_mysql_database_hides_sqlite_skill_by_default tests/test_annotations_consistency.py` → 44 passed.
- Full repository test suite: `.venv/bin/python -m pytest -q` → 231 passed.
- Patch whitespace and syntax: `git --no-pager diff --check && .venv/bin/python -m py_compile db_adapter.py mcp_sql_server.py sql_safety_checker.py tests/test_sql_policy.py tests/test_db_adapter.py tests/test_multi_connection_v35.py` produced no output.
- VS Code diagnostics: no errors found for the changed Python files.
- Live MCP smoke on the local `.env` after adding `DB_CONNECTIONS=mysql,analytics`: `list_connections()` reported `mysql` (MySQL, selected as the default) and `analytics` (SQLite); `check_connection()` and `query(..., "SELECT 1 AS smoke_test")` succeeded on both connections. `list_tables(connection_id="analytics")` returned only `orders` under the analytics allowlist. `list_skills(connection_id="analytics", available_only=false)` showed `monthly-sales-report-sqlite` executable and `update-order-status` non-executable with `disabled_reason="Mutation skills are limited to the default connection in v3.5."`; `execute_query_skill(connection_id="analytics", skill_name="monthly-sales-report-sqlite", params={"year": 2024, "month": 1})` succeeded with zero rows and no truncation.

---

## Update v3.4.3 (May 24, 2026) - Bounded SQLite Estimates and Tool-Surface Wording

### Overview

Kept the release scope focused on removing an avoidable large-table scan and
making model-facing descriptions more conservative. The SQLite row-estimate
fallback no longer upgrades metadata discovery into a full `COUNT(*)`; when
`sqlite_stat1` is unavailable and a table reaches the 10,000-row sampling cap,
the adapter returns the cap as a lower-bound estimate. Exact counts remain
explicit through user SQL or `get_table_summary(exact_count=True)`.

### Changes

| File | Change Type | Description |
|------|-------------|-------------|
| `db_adapter.py` | Modified | `SQLiteAdapter.get_row_estimate()` now prefers `sqlite_stat1`, then uses bounded 10,000-row sampling without a full `COUNT(*)` fallback for larger tables; tightened typing around SQLAlchemy engines/results and classifies SQLAlchemy-wrapped SQLite `interrupted` errors as query timeouts |
| `tests/test_db_adapter.py` | Modified | Added regression coverage that large SQLite tables without `sqlite_stat1` return the sampling cap and do not execute full `COUNT(*)`; added coverage that `ANALYZE`/`sqlite_stat1` is still preferred; added SQLite timeout interruption coverage |
| `mcp_sql_server.py` | Modified | Clarified query/skill truncation notes: truncation limits returned payload only, while `WHERE`/`LIMIT`/`ORDER BY` must be used to limit database work and stabilize ordering; updated `list_tables()` / `get_full_schema()` descriptions to visible/truncated semantics |
| `test_mcp_client.py` | Modified | MCP smoke test now uses assertions, dict parameters for skill calls, `structured_content`-first result parsing, and an explicit skip only when the configured database is unavailable under pytest |
| `README.md`, `README_ZH.md`, `TEST_MCP_CLIENT_GUIDE.md`, `MCP_AGENTS_SKILLS_DESIGN.md`, `PROMPT_ENGINEERING_BEST_PRACTICES.md`, `SQLITE_ADAPTER_DESIGN.md`, `.env.example`, `GEMINI.md`, `agent_examples/` | Modified | Updated safety wording, SQLite estimate behavior, optional exact-count guidance, visible/truncated schema language, tool-count wording, SQLite write-lock wording, and prompt guidance so `get_table_summary()` is not treated as a default planning step |
| `DESIGN_RISK_REGISTER.md`, `DESIGN_RISK_REGISTER_ZH.md` | Added/Modified | Long-term design risk register records completed V343-001 through V343-005, closes V343-006 through V343-008 as documentation/operations guidance, and leaves V343-009 through V343-014 as accepted/deferred items |

### Design Decisions

| Decision | Choice | Alternative | Rationale |
|----------|--------|-------------|-----------|
| SQLite large-table estimates | Return the 10,000-row sample cap as a lower-bound estimate when `sqlite_stat1` is absent | Run full `COUNT(*)` after the sample cap | Keeps metadata tools bounded and consistent with their estimate contract; exact counts are still available when explicitly requested |
| Query truncation wording | Clarify payload-only truncation | Let users infer execution limits from `MAX_RESULT_ROWS` | Prevents agents from mistaking returned-row limits for database work limits |
| Generic SQL pagination | Keep pagination in user SQL | Add `limit`/`offset` or cursor-token params to `query()` | Arbitrary SQL result stability depends on query semantics and ordering; generic wrappers would be misleading |
| Tool/schema descriptions | Use visible/truncated wording | Say "all tables" / "complete schema" | FastMCP and function-calling guidance rewards precise descriptions because models choose tools from them |

### Compatibility Notes

- SQLite `row_count` for large tables without `ANALYZE` may now be lower than
    before because it is a bounded lower-bound estimate rather than an exact
    count. This affects metadata helpers only; explicit `COUNT(*)` queries are
    unchanged.
- `query()` and `execute_query_skill()` still execute through the existing
    adapter path and truncate after fetching. v3.4.3 only clarifies this
    contract; adapter-level streaming/fetch limiting remains a separate design
    decision.
- FastMCP client helpers should read `structured_content` before `data` because
    skill payloads themselves contain a `data` field. Skill tool params are MCP
    objects/dicts, not JSON strings.
- V343-006 through V343-008 are intentionally documented rather than implemented
    as new runtime controls in this release: raw SQL echo remains compatible,
    audit params are treated as business audit data rather than secrets, and
    JSONL rotation/retention is delegated to deployment tooling.

### Validation

- Full repository test suite: `.venv/bin/python -m pytest -q` → 183 passed.
- VS Code diagnostics: no errors found.
- Patch whitespace: `git --no-pager diff --check` produced no output.
- Direct MCP stdio verification covered `check_connection`, `list_tables`,
  safe/unsafe `query`, `get_full_schema`, `list_skills`, `get_skill_detail`,
  `execute_query_skill`, `execute_mutation_skill(confirm=false)`, and opt-in
  telemetry JSONL. Telemetry records contained only sanitized fields and no SQL,
  params, rows, or returned data.

---

## Update v3.4.2 (May 21, 2026) - Unified ToolResult, Output Schemas, and Optional Telemetry

### Overview

Closed the asymmetry from v3.4.1 by giving every MCP tool the same return
shape, declared MCP `outputSchema` on the two skill execution tools, and
introduced an opt-in middleware that records sanitized per-call telemetry.
Also formalized the pytest-level annotation-consistency check.

### Post-merge polish (same release, after code review)

- **B1 fix**: telemetry middleware now distinguishes transport-level outcome
    (`call_completed`, whether `call_next` returned without raising) from
    business-level outcome (`success`, which honors the tool's own
    `ToolResult.meta.success` when present). Previously a tool returning
    `meta.success=False` without raising (e.g. an unsafe-SQL veto by `query`)
    was mis-logged as `success=true`.
- **C1 schema refinement**: `execute_mutation_skill` `outputSchema` rewritten
    to reflect the real payload branches — `preview` object for preview mode,
    `result` object for execute mode, `validation` object for the
    validation-failure branch, `idempotent`/`hint` on the success branches.
    `mode` is now required and bound by the existing `preview`/`execute` enum.
- **3b sampling**: new `TOOL_TELEMETRY_SAMPLE_RATE` env var (float 0.0–1.0,
    default 1.0) gates JSONL writes for high-throughput deployments; values
    are clamped, invalid strings fall back to 1.0.
- **Test coverage** (`tests/test_v342_meta_and_schema.py`): direct meta
    assertions on every base tool, `outputSchema` registration check via real
    `Client.list_tools()`, and an end-to-end telemetry check that drives the
    middleware through `Client.call_tool()` covering both success and
    business-level-rejection branches.
- **Doc consistency**: removed v3.4.1-era "scope: only 2 skill tools" notes
    from `README.md`, `README_ZH.md`, `TEST_MCP_CLIENT_GUIDE.md`, and
    `MCP_AGENTS_SKILLS_DESIGN.md` that contradicted the v3.4.2 uniform
    `ToolResult` rollout.
- **Review follow-up**: `_skill_tool_result()` now includes the same common
    `tool_name` and `success` metadata fields as base tools. The `success`
    value is derived from the stable structured payload, so a mutation
    validation failure that returns normally with `structuredContent.success=false`
    is logged as business-failed telemetry instead of being mistaken for
    success merely because no exception escaped `call_next()`.
- **Telemetry parser hardening**: `TOOL_TELEMETRY_SAMPLE_RATE` now rejects
    non-finite floats (`nan`, `inf`, `-inf`) by falling back to 1.0. Finite
    out-of-range values remain clamped to the nearest bound. This keeps a typo
    from silently disabling all telemetry records.
- **Configuration/docs parity**: `.env.example` now documents the telemetry
    feature flags, including the security compromise that tool usage timing is
    sanitized but still operationally sensitive. Client response examples were
    corrected to show `mode="query"`, real mutation preview/execute payload
    keys, and the uniform `_meta.tool_name` / `_meta.success` fields.

### Changes

| File | Change Type | Description |
|------|-------------|-------------|
| `mcp_sql_server.py` | Modified | Added module-level `_tool_result()` helper; converted `query`, `check_connection`, `list_tables`, `describe_table`, `get_full_schema`, `get_table_summary`, `sample`, `list_skills`, `get_skill_detail` to return `ToolResult` with runtime metadata; added uniform `tool_name`/`success` meta to Skills execution results; added `output_schema` to `execute_query_skill` and `execute_mutation_skill`; added opt-in `_ToolTelemetryMiddleware` (env `ENABLE_TOOL_TELEMETRY` / `TOOL_TELEMETRY_LOG_PATH` / `TOOL_TELEMETRY_SAMPLE_RATE`) |
| `tests/test_annotations_consistency.py` | Added | Pytest lint that fails local/default test runs if any registered tool's `ToolAnnotations` drift from the documented closed-world / read-only intent; add a CI workflow before describing this as CI enforcement |
| `tests/test_tool_telemetry.py` | Added/Modified | Verifies the telemetry middleware writes sanitized JSONL records on success, exception, and business-failure paths; covers sample-rate clamping including non-finite values; never logs SQL/params/rows |
| `tests/test_v342_meta_and_schema.py` | Added | Verifies base and skill tool meta contracts, outputSchema registration, and end-to-end telemetry via real FastMCP `Client.call_tool()` |
| `.env.example` | Modified | Documents opt-in tool telemetry configuration and sampling controls |
| `README.md`, `README_ZH.md`, `TEST_MCP_CLIENT_GUIDE.md`, `MCP_AGENTS_SKILLS_DESIGN.md` | Modified | New v3.4.2 changelog entry, version badge bumped, scope/visibility notes updated, examples aligned with actual payload/meta contract |

### Design Decisions

| Decision | Choice | Alternative | Rationale |
|----------|--------|-------------|-----------|
| Unify return type across all tools | Wrap every tool in `ToolResult` | Keep skill tools special-cased | Removes the v3.4.1 direct-call asymmetry and makes observability symmetric across the whole tool surface; existing clients still read `structuredContent` unchanged |
| Telemetry transport | FastMCP middleware writing local JSONL | Always-on logging or external sink | Opt-in (`ENABLE_TOOL_TELEMETRY=1`) keeps default behavior unchanged; local JSONL avoids new dependencies and remains greppable for operators |
| Telemetry payload | `timestamp`, `tool_name`, `execution_ms`, `call_completed`, `success`, `error_class`, `db_type` only | Include SQL, params, rows for richer analytics | Honors SAFETY constraints (no SQL/params/rows/credentials) and the spirit of `mask_error_details=True`; separates transport completion from business success so validation/safety rejections are not misclassified |
| Telemetry aggregation | Local JSONL plus optional sampling only | In-process p50/p95 stats tool/resource | Keeps the MCP server stateless and dependency-free; avoids exposing sensitive usage patterns to model-visible tools. Operators can compute percentiles externally over JSONL if needed |
| Output schema strictness | Object with required success/skill_name and `additionalProperties: true` | Strict closed schema | Tolerates incremental payload evolution (preview vs execute mode in mutations) while still giving clients a usable validation contract |
| Annotation consistency | Pytest test rather than startup assertion | Fail server startup if drift detected | Keeps server resilient to local edits while catching drift in local/default test runs; add repository CI before calling it CI enforcement |

### Compatibility Notes

- The `structuredContent` payload of every tool is byte-for-byte identical to
    v3.4.1. Adding `ToolResult.meta` and `outputSchema` is additive only.
- Direct Python callers should use
    `getattr(result, "structured_content", result)` to unwrap. The pattern is
    already in `tests/test_skills_disclosure.py::run_tool`.
- The telemetry feature is **disabled by default**. When enabled it writes to
    `logs/tool_calls.jsonl` (configurable via `TOOL_TELEMETRY_LOG_PATH`). The
    middleware never reads tool arguments, SQL, params, rows, or result data —
    it inspects tool name, timing, exception class, and the non-sensitive
    `ToolResult.meta.success` bit. The resulting log still reveals tool usage
    patterns and timings, so keep it on trusted local storage.
- Per MCP spec `_meta` remains OPTIONAL; clients MAY ignore it. The VS Code
    MCP UI still does not display `_meta`, so treat it as a server-side
    observability channel.

---

## Update v3.4.1 (May 19, 2026) - ToolResult Metadata and Closed-World Annotations

### Overview

Implemented the previously deferred runtime metadata decision for Skills
execution tools and normalized MCP tool safety annotations. The change keeps
the existing structured payload contract intact while adding FastMCP
`ToolResult.meta` for non-sensitive diagnostics.

### Changes

| File | Change Type | Description |
|------|-------------|-------------|
| `mcp_sql_server.py` | Modified | Added `ToolResult` wrappers for `execute_query_skill` and `execute_mutation_skill`; attached runtime metadata such as `execution_ms`, row counts, truncation state, mode, db type, idempotency, and skill version; set `openWorldHint=false` on all MCP tool annotations |
| `tests/test_skills_disclosure.py` | Modified | Added coverage for `ToolResult.meta` on query skills and verified every listed MCP tool exposes `openWorldHint=false` |
| `README.md`, `README_ZH.md` | Modified | Documented closed-world tool hints and Skills runtime metadata conventions |
| `MCP_AGENTS_SKILLS_DESIGN.md` | Modified | Updated ToolAnnotations matrix, moved ToolResult metadata from deferred/future work to implemented design, and documented metadata exclusions |
| `TEST_MCP_CLIENT_GUIDE.md` | Modified | Added client-facing note that Skills execution payloads remain structured while runtime diagnostics live in `meta` |

### Design Decisions

| Decision | Choice | Alternative | Rationale |
|----------|--------|-------------|-----------|
| Skills execution response wrapper | Return `ToolResult(structured_content=payload, meta=...)` | Add diagnostic fields directly into the existing payload | Keeps business results stable and separates diagnostics from model-facing data |
| Metadata scope | Include timing/count/version/mode/truncation/audit flags | Include SQL, params, or returned data | Improves observability without expanding sensitive data exposure |
| Tool world hint | Set `openWorldHint=false` on all MCP tools | Leave FastMCP default/open hint | Tools operate against configured database/server boundaries, not arbitrary external entities; hints are advisory only |

### Compatibility Notes

- Existing MCP clients that read structured payloads continue to receive the
    same result object via `structuredContent` / client `.data`.
- `ToolResult.meta` is additional runtime metadata. It is not an authorization
    boundary and should not be treated as an audit log.
- **Historical v3.4.1 scope**: In v3.4.1, `ToolResult` was used only by
    `execute_query_skill` and `execute_mutation_skill`; the remaining nine MCP
    tools still returned plain `dict`. That mixed direct-call shape was an
    intentional narrow rollout at the time. v3.4.2 resolves it by making all 11
    tools return `ToolResult` with uniform common `meta` fields — see the latest
    section above.
- **Client visibility caveat**: Per MCP spec the `_meta` field is OPTIONAL and
    clients MAY ignore it. Verified during v3.4.1 testing: server-side
    middleware and MCP Inspector can read `_meta`, but VS Code's MCP UI does
    not currently surface it. Treat `ToolResult.meta` primarily as a
    server-side observability hook and an opt-in client signal.
- Query skill audit behavior is unchanged: `SKILLS_AUDIT_QUERIES=0` remains the
    default to avoid surprising parameter logs.

---

## Update v3.4 (May 14, 2026) - MCP Hardening and Skills Profile Policy

### Overview

Reviewed ten proposed hardening items and implemented the
low-risk changes that improve security or test signal without changing the
default Skills execution model. Runtime SQL/Python source loading remains
unchanged: executable skill artifacts are still validated and cached at startup.

### Changes

| File | Change Type | Description |
|------|-------------|-------------|
| `mcp_sql_server.py` | Modified | Enabled FastMCP `mask_error_details=True`; added configurable MCP tool timeouts; added `MAX_SQL_LENGTH` schema/runtime guard for raw `query(sql)`; added `SKILLS_EXCLUDE_PROFILES`; added optional query skill audit logging |
| `skills/_lib/audit.py` | Modified | Generalized audit wording from mutation-only to skill operations and records optional query metadata such as `total_rows` and `truncated` without logging returned data |
| `test_bug_fixes.py` | Modified | Refactored source-based checks so pytest tests assert instead of returning booleans |
| `tests/test_skills_disclosure.py` | Modified | Added coverage for profile exclusion, direct execution blocking, query skill audit, raw query MCP schema length metadata, and runtime raw SQL length rejection |
| `.env.example` | Modified | Documented `MCP_TOOL_TIMEOUT_SECONDS`, `MAX_SQL_LENGTH`, `SKILLS_EXCLUDE_PROFILES`, and `SKILLS_AUDIT_QUERIES` |
| `README.md` | Modified | Documented the new hardening controls and deferred decisions |
| `MCP_AGENTS_SKILLS_DESIGN.md` | Modified | Recorded the profile policy, optional query audit, tool timeout, raw SQL length decision, and deferred v3.4.B3/v3.4.B4/v3.4.C1 choices |

### Design Decisions

| Decision | Choice | Alternative | Rationale |
|----------|--------|-------------|-----------|
| Pytest warnings | Convert boolean-returning tests to assert wrappers | Leave source-verification script unchanged | Removes noisy pytest warnings while preserving direct script execution |
| Error masking | `mask_error_details=True` | Depend only on local sanitization | Masks unexpected exceptions while explicit `ToolError` messages continue to expose sanitized guidance |
| Raw SQL length | `MAX_SQL_LENGTH=20000` for `query(sql)` | Apply length caps to skill SQL templates | Free-form Agent SQL is untrusted input; reviewed skill templates are code artifacts validated at startup |
| Profile policy | `SKILLS_EXCLUDE_PROFILES` marks matching skills non-executable | Delete bundled demo skills from production branches | Keeps examples useful but gives production deployments an explicit guardrail |
| Query audit | `SKILLS_AUDIT_QUERIES=0` opt-in | Audit all query skills by default | Avoids surprising parameter logs; compliance-oriented deployments can enable it |
| Tool timeout | FastMCP `timeout` via `MCP_TOOL_TIMEOUT_SECONDS` | Only DB-level timeout | Covers non-DB stalls and foreground request hangs; default is conservative for schema tools |
| v3.4.B3 ToolResult metadata | Deferred decision | Wrap current dict returns in `ToolResult` | Would alter client-facing response contracts without a current need |
| v3.4.B4 Session schema cache | Deferred decision | Cache table names in `ctx.set_state()` | Reduces repeated metadata reads but can stale after DDL; table-readiness checks are lightweight |
| v3.4.C1 Schema resource | Deferred decision | Add `db://schema` MCP resource | Existing schema tool is explicit and broadly supported; resource path can be added later without blocking current workflows |

### Compatibility Notes

- All new runtime behavior is controlled by environment variables or preserves old defaults.
- `SKILLS_EXCLUDE_PROFILES` defaults to empty, so existing Skills catalogs are unchanged unless explicitly configured.
- `SKILLS_AUDIT_QUERIES` defaults to `0`; mutation auditing behavior is unchanged.
- `MAX_SQL_LENGTH` affects only raw `query(sql)` input, not reviewed query skill templates.
- `ToolError` messages remain visible by design under FastMCP error masking.

### Testing

- `.venv/bin/python -m pytest test_bug_fixes.py tests/test_skills_disclosure.py tests/test_skill_loader.py tests/test_query_skills.py tests/test_mutation_skills.py -q` - 99 passed
- `.venv/bin/python -m pytest -q -k 'not test_mcp_server'` - 160 passed, 1 deselected

---

## Update v3.3 (May 14, 2026) - Skills Availability Filtering and SQLite Example

### Overview

Added Agent-facing availability filtering for Skills discovery and introduced a
SQLite-specific monthly sales report example. The availability check now includes
DB compatibility, mutation switch state, and optional table-level schema
readiness. This change keeps startup discovery, SQL validation, mutation class
loading, and execution-time checks eager and unchanged as the security boundary.
`available_only` only changes which cached skill metadata is returned by
`list_skills()`.

### Changes

| File | Change Type | Description |
|------|-------------|-------------|
| `mcp_sql_server.py` | Modified | Added `SKILLS_LIST_AVAILABLE_ONLY_DEFAULT` and `SKILLS_CHECK_SCHEMA_ON_LIST`; added `list_skills(..., available_only)`; included current `DB_TYPE`, mutation switch, and schema readiness in skill executability metadata; default Agent-facing catalog hides currently non-executable skills |
| `skills/monthly-sales-report-sqlite/` | Added | Added SQLite query skill using the sample SQLite schema (`orders.order_date`, `orders.total_amount`) |
| `skills/_lib/skill_loader.py` | Modified | Added `profiles` and declarative `tables` frontmatter support; query tables are merged from reviewed SQL extraction and declared tables |
| `skills/monthly-sales-report/skill_def.md` | Modified | Linked to the SQLite counterpart via `related_skills`, kept `databases: [mysql]`, and marked the bundled example as `profiles: [demo]` |
| `skills/update-order-status/skill_def.md` | Modified | Linked to both monthly report examples, marked the skill as `profiles: [demo]`, and declared `tables: [orders]` |
| `skills/SKILLS.md` | Modified | Regenerated/updated catalog to include databases, profiles, and table dependencies |
| `tests/test_skills_disclosure.py` | Modified | Added coverage for default availability filtering, schema readiness, explicit full catalog listing, env default override, DB-specific visibility, and MCP `list_tools()` schemas |
| `.env.example` | Modified | Documented `SKILLS_LIST_AVAILABLE_ONLY_DEFAULT=1` and `SKILLS_CHECK_SCHEMA_ON_LIST=1` |
| `README.md` / `README_ZH.md` | Modified | Documented `available_only`, schema readiness, demo profiles, the new default behavior, full catalog override, and SQLite skill example |
| `MCP_AGENTS_SKILLS_DESIGN.md` | Modified | Documented conditional availability filtering, related design decisions, and external practice references |
| `TEST_MCP_CLIENT_GUIDE.md` | Modified | Updated Skills smoke examples and config hints |

### Design Decisions

| Decision | Choice | Alternative | Rationale |
|----------|--------|-------------|-----------|
| Availability filtering | `available_only` on `list_skills()` | Separate developer/admin listing tool | Keeps the MCP surface small and matches existing discovery workflow; developers can pass `available_only=false` |
| Default availability | `SKILLS_LIST_AVAILABLE_ONLY_DEFAULT=1` | Preserve full catalog as no-arg default | The tool is Agent-facing, so default discovery should not suggest skills that will fail under the current `DB_TYPE` or mutation switch |
| Schema readiness | `SKILLS_CHECK_SCHEMA_ON_LIST=1` table-existence check | Do no live schema check, or validate every column/type | Catches wrong-schema demo/production mismatches with low overhead while leaving precise validation to execution |
| Security boundary | Keep execution-time compatibility checks | Treat filtering as enforcement | Tool filtering is advisory/ergonomic; callers can still name hidden skills, so execution must remain authoritative |
| SQLite example | Separate `monthly-sales-report-sqlite` skill | One SQL template with dialect branches | Separate skills keep SQL review, startup validation, and Agent selection deterministic |
| Demo profiles | Mark bundled examples with `profiles: [demo]` | Disable examples by default | Keeps examples discoverable for sample databases while making their intended schema explicit |
| Missing `databases` | Keep meaning as all supported DBs | Require every skill to declare databases | Preserves compatibility for portable skills such as `update-order-status` |

### Compatibility Notes

- `ENABLE_SKILLS=0` still registers no Skills tools.
- `list_skills(available_only=false)` restores the full discovered catalog.
- `get_skill_detail(skill_name)` remains available for hidden incompatible or schema-unready skills and includes `executable=false` plus a `disabled_reason`.
- Execution checks still reject database-incompatible or schema-unready skills even if a caller bypasses discovery and directly calls an execution tool.

### External Practice Review

- OpenAI Tool Search supports deferred/client-executed discovery when available tools depend on project or system state; `available_only` is this project's in-MCP analog.
- Anthropic Agent Skills and MCP code-execution guidance emphasize progressive disclosure and loading only relevant definitions.
- Google Gemini function calling best practices recommend keeping the provided tool set relevant and small to reduce selection errors.
- FastMCP annotations and visibility features are useful for presentation and tool surfaces, but annotations are advisory.
- Microsoft function calling guidance emphasizes validating function calls and not relying only on omitted tool definitions as a security control.

### Testing

- `.venv/bin/python -m pytest tests/test_skills_disclosure.py -q` - 19 passed
- `.venv/bin/python -m pytest tests/test_skill_loader.py tests/test_query_skills.py tests/test_mutation_skills.py tests/test_skills_disclosure.py -q` - 92 passed
- `.venv/bin/python -m pytest tests/test_skills_disclosure.py tests/test_skill_loader.py -q` - 74 passed
- `.venv/bin/python -m pytest -q -k 'not test_mcp_server'` - 156 passed, 1 deselected; warning cleanup was completed in v3.4

---

## Update v3.2 (May 12, 2026) - Skills Metadata On-Demand Disclosure

### Overview

Added MCP-level on-demand metadata disclosure for the Skills layer. This change
does **not** lazy-load executable artifacts: `discover()` still validates SQL and
pre-loads mutation classes at startup, and runtime execution still uses the
in-memory cache. Only the Agent-facing metadata projection changed.

### Changes

| File | Change Type | Description |
|------|-------------|-------------|
| `mcp_sql_server.py` | Modified | Added `SKILLS_LIST_DEFAULT_DETAIL`; extended `list_skills(search, category, detail_level)`; added `get_skill_detail(skill_name)`; added compact/summary/full metadata projections and category aggregation |
| `skills/_lib/skill_loader.py` | Modified | Added optional `databases` metadata parsing/validation and included supported database types in generated `SKILLS.md` |
| `skills/monthly-sales-report/skill_def.md` | Modified | Declared `databases: [mysql]` because the example SQL uses MySQL-specific date functions |
| `tests/test_skills_disclosure.py` | Added | Tests for default summary disclosure, compact/full projections, search, category filtering, categories aggregation, overlong search rejection, and `get_skill_detail` errors |
| `tests/test_skill_loader.py` | Modified | Added coverage for omitted, scalar, multiple, case-insensitive, empty, and invalid `databases` values |
| `tests/conftest.py` | Modified | Added an engine assertion for SQLite fixture typing/analysis safety |
| `.env.example` | Modified | Added `SKILLS_LIST_DEFAULT_DETAIL=summary` documentation |
| `README.md` / `README_ZH.md` | Modified | Documented `get_skill_detail`, list projection levels, search/category filters, and the new workflow |
| `MCP_AGENTS_SKILLS_DESIGN.md` | Modified | Documented metadata disclosure levels and clarified that executable artifacts remain eager-loaded for TOCTOU protection |
| `agent_examples/autogen_sql_agent_new.py` | Modified | Added `get_skill_detail` capability detection and prompt guidance |
| `TEST_MCP_CLIENT_GUIDE.md` | Modified | Updated Skills tool list and configuration example |

### Design Decisions

| Decision | Choice | Alternative | Rationale |
|----------|--------|-------------|-----------|
| Disclosure levels | `compact`, `summary`, `full` | `names` alias or custom field lists | Three stable levels cover discovery, compatibility-oriented metadata, and execution planning without exposing raw source |
| Default detail | `summary` via `SKILLS_LIST_DEFAULT_DETAIL` | Default `full` | Keeps the default useful while reducing unnecessary parameter-schema disclosure; per-call `detail_level` can override |
| Search | Case-insensitive substring | Regex/BM25 | Deterministic, dependency-free, avoids ReDoS and model-generated regex fragility |
| Category handling | Missing category maps to `uncategorized` | Omit category | Gives Agents a stable grouping key and supports category aggregation |
| Detail tool | Add `get_skill_detail(skill_name)` | Add `search_skills` or per-skill tools | One extra read-only tool enables on-demand params without tool explosion |
| Artifact loading | Keep startup eager validation/cache | Runtime disk reads | Preserves TOCTOU protection and existing security model |
| Database compatibility | Optional `databases` field | No DB type declaration | Prevents execution of DB-specific skills on incompatible adapters; omitted field means all supported DB types |

### Compatibility Notes

- `ENABLE_SKILLS=0` remains zero-overhead: no Skills tools are registered.
- Existing execution tools are unchanged.
- `list_skills()` now returns additive metadata fields such as `detail_level`,
  `matched_skills`, `categories`, and `hint`. Clients that need maximum detail
  can call `list_skills(detail_level="full")` or `get_skill_detail(skill_name)`.

### Testing

- `pytest tests/test_skills_disclosure.py -q` - 13 passed
- `pytest tests/test_skill_loader.py tests/test_query_skills.py tests/test_mutation_skills.py tests/test_skills_disclosure.py -q` - 85 passed

---

## Update v3.1 (March 17, 2026) - Explicit Source Declaration

### Overview

Added a mandatory `source` field to `skill_def.md` YAML frontmatter. Each skill must now explicitly declare its execution file (e.g. `source: query.sql`, `source: mutation.py`), replacing the previous convention-based implicit file association (hardcoded `query.sql` and `mutation.py` filenames).

This follows the **Explicit Configuration** principle — the same approach used by GitHub Actions (`action.yml` `main` field), npm (`package.json` `main` field), and Python (`pyproject.toml` entry points).

### Changes

| File | Change Type | Description |
|------|-------------|-------------|
| `skills/_lib/skill_loader.py` | Modified | Added `source: str` field to `SkillMetadata`; new `_validate_source_filename()` function with security checks (path traversal, hidden files, suffix enforcement); `_parse_skill_md()` extracts and validates `source`; `discover()` uses `metadata.source` instead of hardcoded filenames |
| `skills/monthly-sales-report/skill_def.md` | Modified | Added `source: query.sql` to YAML frontmatter |
| `skills/update-order-status/skill_def.md` | Modified | Added `source: mutation.py` to YAML frontmatter |
| `tests/test_skill_loader.py` | Modified | All fixtures updated with `source` field; 9 new tests added (TestSourceField class): missing source, path traversal, backslash traversal, wrong suffix, mutation wrong suffix, hidden file, custom filename, source stored in metadata |
| `MCP_AGENTS_SKILLS_DESIGN.md` | Modified | Section 4: added `source` to YAML schema example; added 5th design rationale (Explicit Configuration principle with industry comparison table); Section 10: added design decision entry |
| `README.md` | Modified | Updated skill_def.md examples and "Adding Custom Skills" section |
| `README_ZH.md` | Modified | Updated skill_def.md examples and "如何添加自定义 Skill" section |
| `REFACTORING_LOG.md` | Modified | This entry |
| `skills/SAFETY.md` | Modified | Updated item #1 to reference explicit `source` field |

### Key Design Decisions

| Decision | Choice | Alternative | Rationale |
|----------|--------|-------------|-----------|
| Field name | `source` | `main`, `entry_point`, `file` | Consistent with web conventions; short and descriptive |
| Mandatory | Required, no default | Optional with convention fallback | User's explicit requirement; prevents ambiguity about file association |
| Suffix enforcement | query→.sql, mutation→.py | No enforcement | Prevents misconfiguration; catches type/file mismatch early |
| Filename validation | Regex + path traversal + hidden file checks | Path-only check | Defense-in-depth: `_validate_source_filename()` enforces safe character set, no path separators, no leading dots |
| Custom filenames | Allowed (e.g. `daily-revenue.sql`) | Fixed names only | Enables descriptive naming while maintaining security through validation |

### Source Filename Validation (`_validate_source_filename()`)

Security checks performed on the `source` field value:
1. Must not be empty
2. Max 128 characters
3. No path separators (`/` or `\\`) — prevents directory traversal
4. Must not start with `.` — prevents hidden files and `..` traversal
5. Must match regex `^[a-zA-Z0-9][a-zA-Z0-9._-]*$` — safe character set
6. Suffix must match skill type: `query` → `.sql`, `mutation` → `.py`
7. Resolved path must stay within skill directory — prevents symlink escape

### Testing

- **125 total tests, 0 failures** — all internal examples and tests migrated; external custom skills require adding `source` field (schema-breaking change)
- 9 new tests in `TestSourceField` class covering all validation paths
- All existing 38 skill_loader tests updated with `source` field and passing

---

## Update v3.0 (March 1, 2026) - Skills Extension Layer

### Overview

Added an optional Skills extension layer for pre-defined, parameterized SQL operations. Skills provide structured Agent interactions with query and mutation support, following Anthropic Agent Skills best practices for progressive disclosure.

**Backward Compatible**: `ENABLE_SKILLS=0` (default) — zero overhead, no tools registered.

### System Architecture (v3.0)

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                          LLM / MCP Client (Agent)                            │
└────────────────────────────────┬──────────────────────────────────────────────┘
                                 │  MCP Protocol (stdio / SSE)
                                 ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│                          mcp_sql_server.py                                   │
│                          (FastMCP v3.0 Server)                               │
│                                                                              │
│   ┌─────── Core Tools (always on) ──────┐  ┌── Skills Tools (opt-in) ──────┐ │
│   │ query()           list_tables()     │  │ list_skills()               │ │
│   │ describe_table()  get_full_schema() │  │ execute_query_skill()       │ │
│   │ check_connection()                  │  │ execute_mutation_skill()    │ │
│   │ [sample()]  [get_table_summary()]   │  │                             │ │
│   │  ↑ ENABLE_SCHEMA_TOOLS opt-in      │  │  ↑ ENABLE_SKILLS opt-in     │ │
│   └──────────────┬──────────────────────┘  └──────────┬─────────────────┘ │
│                  │                                    │                    │
│   ┌──────────────▼────────────────┐    ┌──────────────▼──────────────────┐ │
│   │   sql_safety_checker.py      │    │       skills/_lib/              │ │
│   │   ─────────────────────      │    │   ┌──────────────────────────┐  │ │
│   │   is_sql_safe()  (allowlist) │    │   │ skill_loader.py          │  │ │
│   │   execute_sql()  (runtime)   │    │   │  discover() / load_*()   │  │ │
│   │                              │    │   ├──────────────────────────┤  │ │
│   │   + _is_query_safe_extended()│    │   │ mutation_base.py         │  │ │
│   │   + _check_table_allowlist() │    │   │  MutationBase (ABC)      │  │ │
│   │     (in mcp_sql_server.py)   │    │   ├──────────────────────────┤  │ │
│   └──────────────┬───────────────┘    │   │ audit.py                 │  │ │
│                  │                    │   │  AuditLogger → JSONL     │  │ │
│                  │                    │   └──────────┬───────────────┘  │ │
│                  │                    └──────────────┼──────────────────┘ │
│                  │                                   │                    │
│   ┌──────────────▼───────────────────────────────────▼──────────────────┐ │
│   │                       db_adapter.py                                │ │
│   │                    DatabaseAdapter (ABC)                           │ │
│   │   ┌────────────────────────┐  ┌────────────────────────┐          │ │
│   │   │    MySQLAdapter        │  │    SQLiteAdapter       │          │ │
│   │   │  execute() / execute   │  │  execute() / execute   │          │ │
│   │   │  _write() / get_*()   │  │  _write() / get_*()   │          │ │
│   │   └───────────┬────────────┘  └───────────┬────────────┘          │ │
│   └───────────────┼───────────────────────────┼────────────────────────┘ │
└───────────────────┼───────────────────────────┼──────────────────────────┘
                    │                           │
                    ▼                           ▼
              ┌──────────┐               ┌──────────────┐
              │  MySQL   │               │   SQLite     │
              │ (remote) │               │  (local file)│
              └──────────┘               └──────────────┘
```

### Skills Execution Flow

```
                          ┌─────────────────────────┐
                          │  Server Startup          │
                          └────────────┬─────────────┘
                                       ▼
                          ┌─────────────────────────┐
                          │  discover(_skills_dir)   │
                          │  - Scan skill_def.md     │
                          │  - Parse YAML frontmatter│
                          │  - Validate SQL safety   │
                          │  - Cache SkillMetadata   │
                          └────────────┬─────────────┘
                                       ▼
         ┌────────────────────────────────────────────────────────┐
         │                                                        │
  ┌──────▼──────┐       ┌──────────────────┐       ┌─────────────▼─────────────┐
  │ list_skills │       │execute_query_skill│       │  execute_mutation_skill   │
  │             │       │                  │       │                           │
  │ Return:     │       │ 1. validate_name │       │ confirm=false (preview):  │
  │  metadata   │       │ 2. load_query    │       │  1. validate_name         │
  │  (cached)   │       │ 3. validate_params│      │  2. load_mutation         │
  │             │       │ 4. adapter       │       │  3. validate_params       │
  │             │       │    .execute(     │       │  4. mutation.validate()   │
  │             │       │      sql, params)│       │  5. mutation.preview()    │
  └─────────────┘       └──────────────────┘       │  6. audit.log()          │
                                                   │                           │
                                                   │ confirm=true (execute):   │
                                                   │  1-3. (same as above)     │
                                                   │  4. mutation.validate()   │
                                                   │  5. mutation.run_execute()│
                                                   │     → adapter.execute     │
                                                   │       _write(sql, params) │
                                                   │  6. audit.log()          │
                                                   └───────────────────────────┘
```

### Architecture: Skills Directory Convention

```
skills/
├── SAFETY.md                          # Security governance
├── SKILLS.md                          # Auto-generated overview (by discover())
├── _lib/                              # Shared infrastructure
│   ├── __init__.py
│   ├── skill_loader.py                # Discovery, loading, validation (~550 lines)
│   ├── mutation_base.py               # ABC for write operations (~170 lines)
│   └── audit.py                       # JSONL audit logger (~120 lines)
├── monthly-sales-report/              # Example query skill
│   ├── skill_def.md                   # YAML frontmatter + documentation
│   └── query.sql                      # Parameterized SQL template
└── update-order-status/               # Example mutation skill
    ├── skill_def.md                   # YAML frontmatter + documentation
    ├── mutation.py                    # validate/preview/execute logic
    └── references/
        └── status-transitions.md      # State machine documentation
```

### Naming: `skill_def.md` (not `SKILL.md`)

Skill definition files are named `skill_def.md` instead of `SKILL.md` to avoid conflicts with GitHub Copilot / FastMCP's built-in `SKILL.md` skill file format. VS Code's Copilot extension validates `SKILL.md` files against its own schema (expecting attributes like `argument-hint`, `compatibility`, `user-invokable` etc.), which produces false lint errors on our custom YAML frontmatter attributes (`type`, `risk`, `params`, `triggers` etc.).

### New Files

| File | Lines | Description |
|------|-------|-------------|
| `skills/_lib/skill_loader.py` | ~550 | Skill discovery, YAML parsing, SQL safety validation at startup, in-memory caching |
| `skills/_lib/mutation_base.py` | ~170 | ABC for mutations: validate → preview → execute pattern with audit logging |
| `skills/_lib/audit.py` | ~120 | Thread-safe JSONL audit logger with parameter sanitization |
| `skills/SAFETY.md` | — | 16-item security governance document for skill authors |
| `skills/monthly-sales-report/` | — | Example query skill (parameterized SQL) |
| `skills/update-order-status/` | — | Example mutation skill (state machine with optimistic locking) |
| `MCP_AGENTS_SKILLS_DESIGN.md` | ~270 | Design document: architecture, security model, decisions |
| `tests/test_skill_loader.py` | 30 tests | Discovery, parsing, validation, name checks, edge cases |
| `tests/test_query_skills.py` | 8 tests | Parameterized read, write, injection safety |
| `tests/test_mutation_skills.py` | 8 tests | Dry-run, confirm, idempotent, error sanitization |
| `tests/test_audit.py` | 7 tests | JSONL logging, sanitization, directory creation |
| `pyrightconfig.json` | — | Pyright/Pylance config: adds `skills/_lib` to `extraPaths` for import resolution, sets `reportMissingImports` to warning |

### Modified Files

| File | Change Type | Description |
|------|-------------|-------------|
| `mcp_sql_server.py` | Modified | v3.0 header, `ToolError` import, Skills config, 3 new MCP tools (`list_skills`, `execute_query_skill`, `execute_mutation_skill`), updated `sql_assistant` prompt |
| `db_adapter.py` | Modified | `execute()` accepts optional `params`, new `execute_write()` for transactions, unified `_handle_error(self, e, timeout=None)` |
| `start_server.py` | Modified | `validate_environment()` is now DB_TYPE-aware (MySQL vs SQLite) |
| `requirements.txt` | Modified | Added `pyyaml`, changed `SQLAlchemy` to `SQLAlchemy>=2.0` |
| `.env.example` | Modified | Added `ENABLE_SKILLS`, `SKILLS_ALLOW_MUTATIONS`, `SKILLS_DIR`, `SKILLS_AUDIT_LOG` |
| `README.md` | Modified | Version badge 3.0, v3.0 changelog, roadmap updated |
| `README_ZH.md` | Modified | Same updates in Chinese |

### Key Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Tool architecture | 2-3 unified tools (list/query/mutation) | Prevents tool explosion (Google Gemini 10-20 rule) |
| Metadata format | `skill_def.md` YAML frontmatter | Anthropic Skills spec alignment, avoids VS Code conflict |
| SQL caching | discover() caches at startup | Eliminates TOCTOU (time-of-check-time-of-use) risks |
| Write safety | 3-stage validate/preview/execute | Anthropic "verifiable intermediate outputs" pattern |
| Error handling | ToolError propagation | FastMCP ToolError bypasses `mask_error_details` |
| Audit storage | JSONL file | Minimal dependency for MVP |

### Security Model (SAFETY.md)

1. Template = Whitelist — only pre-defined SQL/Python in `skills/` is executed
2. Parameterized queries via SQLAlchemy `text()` + named parameters
3. Dual switch: `ENABLE_SKILLS` (master) + `SKILLS_ALLOW_MUTATIONS` (second)
4. Startup SQL safety validation via `is_sql_safe()` (defense-in-depth)
5. Skill name regex `^[a-z0-9][a-z0-9-]*$` prevents path traversal
6. SKILLS_DIR constrained to project root
7. Error sanitization through `ToolError` (no internal detail leaks)

### Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `ENABLE_SKILLS` | `0` | Master switch for skills extension |
| `SKILLS_ALLOW_MUTATIONS` | `0` | Enable mutation skills (requires `ENABLE_SKILLS=1`) |
| `SKILLS_DIR` | `skills/` | Skills directory path (must be under project root) |
| `SKILLS_AUDIT_LOG` | `skills/_audit.jsonl` | Audit log file path |

### Testing

- **64 new tests** across 4 files (all pass)
- **53 existing tests** unchanged (all pass)
- **117 total tests, 0 failures** — backward compatibility confirmed
- All tests use SQLite in-memory databases for speed and isolation
- Key finding: SQLAlchemy Row objects use attribute access (`.column_name`) not dict access (`["column_name"]`)

> **Design Documentation:** See [MCP_AGENTS_SKILLS_DESIGN.md](docs/architecture/MCP_AGENTS_SKILLS_DESIGN.md) for full architecture details.

### Post-Implementation Audit (March 1, 2026)

Code review following MCP Spec §7, Anthropic, Google Gemini, and Microsoft best practices.

#### Issues Found & Fixed

| # | Severity | Issue | Fix |
|---|----------|-------|-----|
| 1 | P0 Security | `_is_query_safe_extended` leaked regex pattern in error message (`f"SHOW command not allowed for security: {pattern}"`) | Replaced with generic message: `"This SHOW command is not allowed for security reasons"` |
| 2 | P0 Security | `INFORMATION_SCHEMA` bypass: `query("SELECT * FROM INFORMATION_SCHEMA.TABLES")` could bypass `ALLOWED_TABLES` controls, exposing restricted table names | Added `information_schema` to blocked system databases pattern |
| 3 | P1 Logic | `sample()` tool used MySQL-specific backtick quoting (`\`table\``) — would fail on SQLite | Dynamic quoting: backtick for MySQL, double-quote for SQLite via `adapter.db_type` |
| 4 | P1 Logic | `get_table_summary()` bypassed adapter layer, used MySQL-only `INFORMATION_SCHEMA` SQL directly | Refactored to use `adapter.get_row_estimate()` and `adapter.get_columns()` |
| 5 | P2 Quality | `import json` inside `_truncate_result()` function body | Moved to module-level imports |
| 6 | P2 Quality | `ALLOWED_SHOW_COMMANDS` set was dead code (defined but never referenced) | Removed |
| 7 | P2 Quality | `_is_valid_identifier` had redundant `dangerous_patterns` check | Added comment noting it's defense-in-depth (kept) |
| 8 | P0 Type | Pylance reported `_project_root`/`_skills_dir`/`Field` possibly unbound in Skills conditional blocks | Moved `sys`, `Path`, `Annotated`, `Field` imports to module level; pre-initialized path variables |
| 9 | P1 Type | `DatabaseAdapter` ABC missing `_handle_error()` method — Pylance couldn't resolve calls on abstract type | Added `_handle_error()` as a concrete method in `DatabaseAdapter` (default: returns generic error string) |
| 10 | P1 Type | `skill_loader.py`: `importlib.util.spec_from_file_location()` returns `Optional[ModuleSpec]`, but `spec` and `spec.loader` used without None check | Added explicit `None` guard with clear `ImportError` message |
| 11 | P2 Type | `mutation.py`: SQLAlchemy `Row.status` attribute access unrecognized by Pylance (dynamic attribute) | Added `# type: ignore[union-attr]` annotations (3 locations) |
| 12 | P2 Type | `test_query_skills.py` / `test_mutation_skills.py`: `adapter._engine` could be `None` before `connect()` | Added `assert adapter._engine is not None` after `connect()` |
| 13 | P0 Bug | `execute_write()` fails on MySQL: `connection.begin()` conflicts with SQLAlchemy 2.0 autobegin — `SET SESSION MAX_EXECUTION_TIME` triggers autobegin, then explicit `begin()` raises `InvalidRequestError` | Replaced `engine.connect()` + `connection.begin()` with `engine.begin()` context manager (both MySQL and SQLite adapters) |
| 14 | P2 Perf | `load_mutation()` re-executes `exec_module()` on every call — disk I/O + module compilation per mutation invocation | Pre-load mutation module class in `discover()` at startup, cache in `SkillMetadata._mutation_class`; `load_mutation()` now only instantiates from cache |
| 15 | P2 Security | `validate_params()` silently ignores extra parameters not defined in schema — defense-in-depth gap | Added `unexpected = set(params) - set(schema)` check at start; raises `ValueError` listing unexpected keys |
| 16 | P3 Robustness | `AuditLogger.__init__` calls `mkdir()` without error handling — `PermissionError` crashes entire Skills initialization | Wrapped `mkdir()` in try-except `OSError`; logs warning but allows AuditLogger to construct |
| 17 | P1 Logic | `mutation.py execute()` returns `{"success": False}` on failure instead of raising exception — bypasses `run_execute()` error handling chain, causes semantic contradiction (`{"success": True, "result": {"success": False}}`) in MCP tool response, and `run_execute()` `except ToolError` path lacked audit logging | Changed `execute()` to `raise ToolError(...)` on order-not-found and optimistic lock failure; added audit logging to `run_execute()` `except ToolError` path before re-raising |
| 18 | P2 Type | `SkillMetadata._mutation_class: type \| None` — Pylance reports "Variable not allowed in type expression". Python 3.12 introduced `type` as a soft keyword for type alias statements (`type X = ...`), causing Pylance to misparse the built-in `type` in annotation context within a `@dataclass` | Added `from __future__ import annotations` (PEP 563) to `skill_loader.py` — defers all annotation evaluation to string form, bypassing the `type` soft keyword parsing conflict |
| 19 | P1 Semantics | MySQL `execute_write()` used `MAX_EXECUTION_TIME`, but MySQL documents that mechanism as SELECT/read-query oriented and live validation showed `UPDATE ... SLEEP(2)` still succeeded under `timeout=1` | Removed write-path `MAX_EXECUTION_TIME`; `execute_write()` now sets session `innodb_lock_wait_timeout` for InnoDB row-lock waits and fails closed if that guard cannot be configured. Remaining DML CPU/IO runtime limits are documented as driver/deployment scope. |

#### Noted (Not Fixed — Design Decisions)

| # | Topic | Note |
|---|-------|------|
| A | Error pattern inconsistency | Core tools return `{"success": False, "error": ...}`, Skills tools raise `ToolError`. MCP Spec §6 favors `isError: true` (which ToolError maps to), but changing core tools would break backward compatibility. |
| B | Rate limiting | Not implemented — acceptable for the current trusted single-operator/stdin-first mutation boundary. Any future remote or multi-user design must add ingress and/or per-principal limits rather than treating an HTTP transport as the control. |
| C | CTE/WITH bypass | `_is_query_safe_extended` blocks `FROM (subquery)` but not `WITH ... AS` (CTE). Low risk since `is_sql_safe()` already restricts statement types to SELECT. |
| D | Lifespan cleanup | `lifespan()` context manager doesn't call `reset_adapter()` on shutdown. Minor — Python process exit cleans up resources. |
| E | `query.sql` MySQL-only functions | `monthly-sales-report/query.sql` uses `YEAR()`/`MONTH()` — MySQL-specific, not supported by SQLite. Acceptable as an example skill for a MySQL-primary project. `skill_def.md` Notes already marks it MySQL-only. Cross-database compatibility is the skill author's responsibility. |
| F | `_extract_table_names()` ignores `schema.table` | `skill_loader.py`'s `_extract_table_names()` regex doesn't handle `schema.table` format, but this function is only used for generating the `SKILLS.md` overview document — not involved in security validation. The core security path `_extract_tables_from_sql()` in `mcp_sql_server.py` already handles `schema.table` correctly (fixed in Bug Fix 1). |
| G | Mutation `execute()` duplicate SELECT | Superseded in v3.6.1: the bundled state-sensitive Skill's unbound `execute()` fails closed. Preview displays and binds one state read; `execute_with_binding()` applies the optimistic lock to that bound value. |
| H | Mutation read-write transaction gap | Superseded by the v3.6 preview-state binding contract for the bundled Skill. The preview read and later write remain separate operations by design, while the final `WHERE status = :expected_status` rejects execute-time drift from the displayed state. The narrower external-writer ABA boundary is tracked in DRR-2026-046. |
| I | `execute_mutation_skill` double audit risk | Resolved in v3.6.1: `run_execute()` owns execution success/failure audit. After it returns successfully, the MCP layer marks the write complete; a later context/response failure no longer appends a contradictory execute-failure audit and instead tells the caller to verify current database state. |
| J | `_sanitize_params()` flat-only | `audit.py`'s `_sanitize_params()` only truncates top-level `str` values >500 chars, does not recurse into nested `dict`/`list`. No impact — current skill frontmatter schema only defines atomic types (`int`/`float`/`str`/`bool`). If future skills add complex parameter types, this should be revisited. |
| K | `_coerce_type()` bool conversion | Resolved: bool parameters accept native booleans and explicit `"true"`/`"false"` strings; other values fail validation instead of using Python truthiness. Regression coverage is tracked under DRR-2026-020. |

### Live Integration Test Report (March 1, 2026)

End-to-end functional verification against production MySQL database (`trade_data_analysis` on `192.168.1.113`).  
All 10 MCP tools tested via VS Code MCP Client → FastMCP 3.0.2 stdio transport.

#### Test Environment

| Item | Value |
|------|-------|
| Database | MySQL 8.x, `trade_data_analysis` |
| Production tables | 6 tables, largest `trade_data_analysis_log` (~138K rows, 57 columns, Chinese A-stock data) |
| Test tables | `orders` (5 rows), `test_users` (2 rows) — created for testing, cleaned up after |
| Skills config | `ENABLE_SKILLS=1`, `SKILLS_ALLOW_MUTATIONS=1` |
| Sample skills | `monthly-sales-report` (query), `update-order-status` (mutation) |

#### Phase 1: Core Tools — All Pass

| # | Tool | Test | Result |
|---|------|------|--------|
| 1 | `check_connection` | Connect to MySQL | ✅ `"MySQL connection successful"` |
| 2 | `list_tables` | List all tables | ✅ 7 tables returned (6 production + 1 test) with estimated row counts |
| 3 | `describe_table` | `test_users` (small table) | ✅ 2 columns (id, name), 2 rows |
| 4 | `describe_table` | `trade_data_analysis_log` (large table) | ✅ 57 columns, ~135K rows, `is_large=true` |
| 5 | `query` | `SELECT * FROM test_users` | ✅ Returns Alice, Bob |
| 6 | `query` | Aggregation: `COUNT(*)`, `COUNT(DISTINCT ...)`, `GROUP BY` on 138K rows | ✅ 138K records, 6408 stocks, 87 industries |
| 7 | `query` | `GROUP BY industry ORDER BY cnt DESC LIMIT 10` | ✅ Top 10 industries by stock count |
| 8 | `query` | **Security**: `DROP TABLE test_users` | ✅ **Blocked**: `"Only read-only queries allowed"` |
| 9 | `get_full_schema` | Full database schema dump | ✅ All 7 tables with columns, ~35KB response |

#### Phase 2: Skills Discovery — Pass

| # | Tool | Test | Result |
|---|------|------|--------|
| 10 | `list_skills` | Discover available skills | ✅ 2 skills found: `monthly-sales-report` (query/low), `update-order-status` (mutation/high) |

#### Phase 3: Query Skill — All Pass

| # | Tool | Test | Result |
|---|------|------|--------|
| 11 | `execute_query_skill` | `monthly-sales-report` (before test data) | ✅ Error correctly: `"Table or column not found"` (orders table didn't exist yet) |
| 12 | `execute_query_skill` | `monthly-sales-report` with `{year:2026, month:1}` (after creating orders) | ✅ **Success**: 5 daily rows with `order_count`, `revenue`, `avg_order_value` |
| 13 | `execute_query_skill` | `nonexistent-skill` | ✅ Error correctly: `"Skill not found"` |

#### Phase 4: Mutation Skill — Bug Found & Fixed

| # | Tool | Test | Result |
|---|------|------|--------|
| 14 | `execute_mutation_skill` | Dry-run (`confirm=false`): `{order_id:1, new_status:"confirmed"}` | ✅ Preview returned UPDATE SQL with optimistic locking |
| 15 | `execute_mutation_skill` | Execute (`confirm=true`) — **BEFORE FIX** | ❌ **FAILED**: `"Database query failed"` |
| 16 | (diagnosis) | Root cause analysis | 🔍 `InvalidRequestError: This connection has already initialized a Transaction() object via begin() or autobegin; can't call begin() here` |
| 17 | `execute_mutation_skill` | Execute (`confirm=true`) — **AFTER FIX** | ✅ **Success**: `pending` → `confirmed`, `rowcount: 1` |
| 18 | `execute_mutation_skill` | Chained transition: `confirmed` → `shipped` | ✅ **Success**: `rowcount: 1` |
| 19 | `execute_mutation_skill` | **Security**: illegal transition `shipped` → `pending` | ✅ **Blocked**: `"Transition from 'shipped' to 'pending' is not allowed. Allowed: ['delivered', 'returned']"` |

#### Bug #13: `execute_write()` SQLAlchemy autobegin conflict

**Symptom**: `execute_mutation_skill(confirm=true)` returns `"Error: Database query failed"` on MySQL.  
Dry-run (preview) works; confirm (execute) fails. Data unchanged.

**Root Cause**: In `MySQLAdapter.execute_write()`:

```python
# BEFORE (buggy)
with self._engine.connect() as connection:
    connection.execute(text(f"SET SESSION MAX_EXECUTION_TIME = {timeout_ms}"))
    # ↑ This triggers SQLAlchemy 2.0 autobegin (implicit transaction)
    
    with connection.begin():  # ← FAILS: autobegin already active
        result = connection.execute(text(sql), params)
```

SQLAlchemy 2.0 uses "autobegin" — any `execute()` call on a connection implicitly starts a transaction. The `SET SESSION MAX_EXECUTION_TIME` call activated autobegin, then the explicit `connection.begin()` raised `InvalidRequestError` because a transaction was already in progress.

**Why unit tests didn't catch it**: All 111 tests use SQLite in-memory with `StaticPool` (shared single connection), where the connection lifecycle differs. The timeout mechanism uses `set_progress_handler()` instead of `SET SESSION`, so the autobegin trigger path doesn't exist in SQLite tests.

**Historical fix**: Replace the then-buggy `engine.connect()` + SQL-before-
`connection.begin()` sequence with `engine.begin()`:

> v3.7.2 supersedes this implementation, but not the lesson: it again uses
> `connect()` + `begin()` only with `begin()` called immediately before any SQL,
> then tracks COMMIT explicitly to preserve uncertain-outcome evidence.

```python
# AFTER (fixed) — both MySQL and SQLite adapters
with self._engine.begin() as connection:  # explicit transaction from the start
    connection.execute(text(f"SET SESSION MAX_EXECUTION_TIME = {timeout_ms}"))
    result = connection.execute(text(sql), params)
    # auto-commit on context exit, auto-rollback on exception
```

`engine.begin()` creates a connection with an explicit transaction from the start, avoiding the autobegin conflict. All subsequent `execute()` calls within this context operate within the same transaction.

**Verification**: After fix, mutation skill confirmed working (tests #17-19 above). 111 unit tests remain green.

#### Phase 5: Cleanup

| Action | Result |
|--------|--------|
| Drop `orders` table | ✅ Removed from production DB |
| Drop `test_users` table | ✅ Removed from production DB |
| Verify table count | ✅ 6 original tables remain |

#### Summary

| Category | Tests | Pass | Fail | Notes |
|----------|-------|------|------|-------|
| Core tools | 9 | 9 | 0 | Including security block |
| Skills discovery | 1 | 1 | 0 | |
| Query skill | 3 | 3 | 0 | Including error cases |
| Mutation skill | 6 | 5 | 1 | 1 failure → bug found → fixed → re-verified |
| **Total** | **19** | **18** | **1** | **Bug #13 found, fixed, verified** |

All 10 MCP tools verified functional. One P0 bug discovered and fixed during testing.  
111 unit tests pass after fix. Test environment cleaned up — no residual test data in production.

---

## Update (January 13, 2026) - GitHub Repository Rename

This update records a repository-level rename (no functional code changes).

- **Old repo name:** `vibe-coding-gemini-llm-execute-sql-tools`
- **New repo name:** `llm-sql-safety-executor-mcp`
- **New URL:** https://github.com/Firstmeridian/llm-sql-safety-executor-mcp

### Local Git Update

After renaming on GitHub, update your local `origin` remote to avoid relying on redirects:

```bash
git remote -v
git remote set-url origin https://github.com/Firstmeridian/llm-sql-safety-executor-mcp.git
git remote -v

# optional verification
git fetch origin --prune
```

---

## Update v2.2 (January 15, 2026) - SQLite Database Support

### Overview

Added SQLite database support while maintaining full backward compatibility with MySQL. This enables the MCP server to work with lightweight SQLite databases for development, testing, and embedded use cases.

### Architecture: Database Adapter Pattern

Introduced `db_adapter.py` implementing the Abstract Base Class (ABC) pattern:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         DATABASE ADAPTER ARCHITECTURE                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│                          ┌─────────────────────┐                            │
│                          │  DatabaseAdapter    │ (ABC)                      │
│                          │  ─────────────────  │                            │
│                          │  + connect()        │                            │
│                          │  + execute()        │                            │
│                          │  + get_tables()     │                            │
│                          │  + get_columns()    │                            │
│                          │  + get_row_estimate()│                           │
│                          │  + check_connection()│                           │
│                          │  + get_database_name()│                          │
│                          │  + close()          │                            │
│                          │  + db_type (property)│                           │
│                          └─────────┬───────────┘                            │
│                                    │                                        │
│                    ┌───────────────┴───────────────┐                        │
│                    │                               │                        │
│           ┌────────▼────────┐             ┌───────▼────────┐                │
│           │   MySQLAdapter  │             │  SQLiteAdapter │                │
│           │  ─────────────  │             │  ────────────  │                │
│           │  - SQLAlchemy   │             │  - SQLAlchemy  │                │
│           │  - PyMySQL      │             │  - sqlite3     │                │
│           │  - QueuePool    │             │  - StaticPool  │                │
│           │  - MAX_EXEC_TIME│             │  - progress_   │                │
│           │                 │             │    handler     │                │
│           └─────────────────┘             └────────────────┘                │
│                                                                             │
│                          ┌─────────────────────┐                            │
│                          │  create_adapter()   │ (Factory)                  │
│                          │  ─────────────────  │                            │
│                          │  DB_TYPE → Adapter  │                            │
│                          └─────────────────────┘                            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Files Changed

| File | Change Type | Description |
|------|-------------|-------------|
| `db_adapter.py` | **NEW** (749 lines) | Database adapter abstraction layer |
| `sql_safety_checker.py` | Modified | Now uses adapter; removed MySQL-specific code |
| `mcp_sql_server.py` | Modified | Uses adapter methods; adds `db_type` to responses |
| `.env.example` | Modified | Added SQLite configuration section |
| `.env` | Modified | Added SQLite configuration section |
| `README.md` | Modified | v2.2 changelog, SQLite config docs |
| `README_ZH.md` | Modified | v2.2 changelog, SQLite config docs |
| `tests/conftest.py` | **NEW** (318 lines) | Pytest fixtures for SQLite/MySQL tests |
| `tests/test_db_adapter.py` | **NEW** | Unit tests for adapters |
| `tests/test_sqlite_integration.py` | **NEW** | SQLite integration tests |
| `requirements.txt` | Modified | Added `pytest` dependency |

> **Detailed Design Documentation:** See [SQLITE_ADAPTER_DESIGN.md](docs/architecture/SQLITE_ADAPTER_DESIGN.md) for design decisions, conventions, compromises, potential issues, and implementation details.

---

## Update v2.1 (January 4, 2026) - Tool Optimization & Field Naming

### Major Changes

#### 1. `get_table_summary` Now Optional (Default: Disabled)

**Rationale:** The `describe_table()` tool already provides estimated row counts from INFORMATION_SCHEMA. The `get_table_summary()` tool with its optional `COUNT(*)` feature is only needed when exact counts are required.

**Configuration:**
```env
# Default: disabled (describe_table provides estimates)
ENABLE_TABLE_SUMMARY=0

# Enable when exact counts via COUNT(*) are needed
ENABLE_TABLE_SUMMARY=1
```

**New Parameters:**
- `exact_count` (bool, default: False): When True, runs COUNT(*) for precise count (slow on large tables)

#### 2. `describe_table` Enhanced with Row Count and Hints

**New Output Fields:**
```json
{
  "row_count": 1500,
  "row_count_approximate": true,
  "is_large": true,
  "recommendation": "Large table (~1500 rows). Use LIMIT or aggregation (COUNT/GROUP BY)."
}
```

**Benefits:**
- Eliminates need for separate `get_table_summary()` call in most cases
- Provides query planning hints based on `LARGE_TABLE_THRESHOLD`

#### 3. `list_tables` Output Restructured

**Before:**
```json
{
  "success": true,
  "data": [...],
  "table_count": 2
}
```

**After:**
```json
{
  "success": true,
  "database_name": "mydb",
  "returned_table_count": 2,
  "total_tables": 2,
  "tables": [...],
  "row_count_approximate": true,
  "truncated": false,
  "truncation_note": null
}
```

**Field Naming Convention:**
- `returned_table_count`: Number of tables in response (after truncation)
- `total_tables`: Visible tables (after allowlist filtering, before truncation)
- `tables`: Renamed from `data` for clarity

#### 4. `get_full_schema` Output Aligned

Same field naming convention applied:
- `returned_table_count` instead of `table_count`
- `total_tables` field added
- `truncated` and `truncation_note` always present

#### 5. New Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `ENABLE_TABLE_SUMMARY` | 0 | Enable `get_table_summary()` tool |
| `LARGE_TABLE_THRESHOLD` | 1000 | Rows threshold for `is_large` flag |
| `MAX_OVERVIEW_TABLES` | 100 | Max tables in `list_tables()` |

#### 6. AutoGen Agent Prompts Updated

Removed `get_table_summary()` references from agent prompts since:
- Tool is disabled by default
- `describe_table()` now provides equivalent functionality

Updated workflow guidance:
```
- For unknown tables: list_tables() → describe_table()
- For multi-table JOINs: get_full_schema()
- Check is_large flag in describe_table response
```

### Files Changed

| File | Changes |
|------|---------|
| `mcp_sql_server.py` | Tool restructuring, field naming, new env vars |
| `.env.example` | New environment variable documentation |
| `autogen_sql_agent.py` | Updated prompts, removed get_table_summary refs |
| `test_mcp_client.py` | Validate new field structure |
| `test_bug_fixes.py` | Updated tests for new fields |

---

## Previous Update (December 29, 2025) - Bug Fixes

### Bug Fix 1: Schema.table Regex Extraction (P1)

**Problem:** `_extract_tables_from_sql()` incorrectly extracted schema name instead of table name when using `schema.table` syntax (e.g., `SELECT * FROM mydb.users` extracted "mydb" instead of "users").

**Impact:** Table allowlist validation could incorrectly block/allow queries when using schema-qualified table names.

**Root Cause:****
```python
# Old regex - captures first identifier (schema)
from_join_pattern = r'(?:FROM|JOIN)\s+`?([a-zA-Z_\u4e00-\u9fff][a-zA-Z0-9_\u4e00-\u9fff]*)`?'
```

**Fix:** Updated regex to handle optional schema prefix and capture only the table name:
```python
# Fixed regex - skips optional schema., captures table name
from_join_pattern = r'(?:FROM|JOIN)\s+(?:`?[a-zA-Z_\u4e00-\u9fff][a-zA-Z0-9_\u4e00-\u9fff]*`?\s*\.\s*)?`?([a-zA-Z_\u4e00-\u9fff][a-zA-Z0-9_\u4e00-\u9fff]*)`?'
```

**Test Cases Verified:**
- `SELECT * FROM mydb.users` → extracts "users" ✅
- `SELECT * FROM \`mydb\`.\`users\`` → extracts "users" ✅
- `DESCRIBE mydb.products` → extracts "products" ✅

### Bug Fix 2: sql_assistant Prompt Display for ALLOWED_TABLES=* (P2)

**Problem:** When `ALLOWED_TABLES=*` was set, the prompt displayed "UNION enabled (tables: *)" which was unclear to LLMs.

**Fix:** Added special handling to display "all tables" instead of "*":
```python
# Before
cross_table = f"UNION enabled (tables: {', '.join(sorted(ALLOWED_TABLES))})"
# Output: "UNION enabled (tables: *)"

# After
if "*" in ALLOWED_TABLES:
    tables_desc = "all tables"
else:
    tables_desc = ', '.join(sorted(ALLOWED_TABLES))
cross_table = f"UNION enabled ({tables_desc})"
# Output: "UNION enabled (all tables)"
```

### Bug Fix 3: get_full_schema Truncation Protection (P0)

**Problem:** `get_full_schema()` could return extremely large responses for databases with many tables (100+ tables with 30+ columns each could exceed 200K+ characters), causing LLM context overflow.

**Fix:** Added truncation protection with `MAX_SCHEMA_TABLES = 50`:
```python
MAX_SCHEMA_TABLES = 50  # Reasonable limit for most LLM contexts
total_tables = len(tables_data)
truncated = False

if total_tables > MAX_SCHEMA_TABLES:
    tables_data = tables_data[:MAX_SCHEMA_TABLES]
    truncated = True
    await ctx.warning(f"Schema truncated: showing {MAX_SCHEMA_TABLES}/{total_tables} tables")

# ... (build schema) ...

if truncated:
    result["truncated"] = True
    result["truncation_note"] = f"Showing {MAX_SCHEMA_TABLES}/{total_tables} tables. Use describe_table(table_name) for specific tables not shown."
```

**Size Estimates:**
| Database Size | Tables | Estimated Chars | Truncated? |
|--------------|--------|-----------------|------------|
| Small | 10 | ~9K | No |
| Medium | 50 | ~88K | At limit |
| Large | 100 | ~260K | Yes → 50 |
| Very Large | 200 | ~860K | Yes → 50 |

---

### Previous Fix: ALLOWED_TABLES=* Filtering Issue

**Problem:** When `ALLOWED_TABLES=*` was set, `list_tables()` and `get_full_schema()` returned empty results because the filter logic checked if table names were literally in the set `{"*"}`.

**Root Cause:**
```python
# Buggy code
if ALLOWED_TABLES is not None:
    data = [t for t in data if t["table_name"].lower() in ALLOWED_TABLES]
    # ALLOWED_TABLES = {"*"}, no table name equals "*", so all filtered out!
```

**Fix:** Added check to skip filtering when `"*"` is in the allowlist:
```python
# Fixed code
if ALLOWED_TABLES is not None and "*" not in ALLOWED_TABLES:
    data = [t for t in data if t["table_name"].lower() in ALLOWED_TABLES]
```

**Affected Functions:**
- `list_tables()` - Line ~552
- `get_full_schema()` - Line ~683

### Configuration Improvements & Truncation Optimization

This update relaxes default truncation limits, adds `ALLOWED_TABLES=*` support, and simplifies error messages.

#### 1. Relaxed Default Truncation Limits

| Setting | Before | After | Reason |
|---------|--------|-------|--------|
| `MAX_RESULT_ROWS` | 50 | 100 | More practical for analysis tasks |
| `MAX_RESULT_CHARS` | 8000 | 16000 | Reduces premature truncation |

#### 2. Disable Truncation Support

Set `MAX_RESULT_ROWS=0` or `MAX_RESULT_CHARS=0` to disable respective limits:

```env
# Disable all truncation (for data export scenarios)
MAX_RESULT_ROWS=0
MAX_RESULT_CHARS=0
```

#### 3. ALLOWED_TABLES=* Support

Added special value `*` to explicitly allow all tables (required for UNION with unrestricted access):

```env
# Enable UNION and allow all tables
ALLOW_UNION=1
ALLOWED_TABLES=*
```

**Behavior:**
- `ALLOWED_TABLES=` (empty): Allow all tables for normal queries, but UNION still blocked
- `ALLOWED_TABLES=*`: Explicitly allow all tables, enables UNION when `ALLOW_UNION=1`
- `ALLOWED_TABLES=t1,t2`: Only allow specified tables

#### 4. Simplified Truncation Messages

Reduced truncation note length to minimize token consumption:

| Before | After |
|--------|-------|
| `"Results truncated to 50 rows. Use 'SELECT ... LIMIT n' for precise control. Total available: 200 rows."` | `"Showing 100/200 rows. Use LIMIT clause for full control."` |

#### 5. Simplified UNION Error Message

| Before | After |
|--------|-------|
| `"UNION queries require ALLOWED_TABLES to be configured. Set ALLOWED_TABLES environment variable or use separate queries."` | `"UNION requires ALLOWED_TABLES. Set ALLOWED_TABLES=table1,table2 or ALLOWED_TABLES=* to enable."` |

#### Files Changed

| File | Change |
|------|--------|
| `mcp_sql_server.py` | Relaxed defaults, added `*` support, simplified messages |
| `.env.example` | Updated documentation and default values |

---

## Update (December 23, 2025)

### Security & Token Optimization

This update adds configurable UNION query policy, startup logging, and significant prompt optimization following OpenAI/Google best practices.

#### 1. ALLOW_UNION Configuration (P2 Security)

Added configurable UNION query handling for flexible security vs efficiency trade-off:

| Setting | Behavior | Use Case |
|---------|----------|----------|
| `ALLOW_UNION=0` (default) | Block UNION, guide LLM to multiple queries | Maximum security |
| `ALLOW_UNION=1` + `ALLOWED_TABLES` | Allow UNION with table validation | Efficiency mode |
| `ALLOW_UNION=1` without allowlist | Block UNION (requires allowlist) | Defense-in-depth |

**Configuration Example (.env):**
```env
# P2: UNION Query Policy (0=disabled/safer, 1=enabled with table allowlist)
ALLOW_UNION=0

# Required when ALLOW_UNION=1
ALLOWED_TABLES=customers,orders,products
```

#### 2. Startup Logging for Security Configuration

Added logging at module load to confirm security settings:

```python
# Log security configuration at module load
if ALLOW_UNION:
    if ALLOWED_TABLES:
        logger.info(f"UNION queries enabled with table allowlist: {sorted(ALLOWED_TABLES)}")
    else:
        logger.warning("ALLOW_UNION=1 but no ALLOWED_TABLES configured - UNION will be blocked")
else:
    logger.info("UNION queries disabled (default safe mode)")
```

#### 3. Prompt Token Optimization (69% Reduction)

Significantly reduced `sql_assistant` prompt size following OpenAI/Google best practices:

> **Google**: "Token limits: function descriptions and parameters count toward input token limits"
> **OpenAI**: "If you run into token limits, we suggest limiting the number of functions or the length of the descriptions"

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Characters | 1,224 | 376 | -69% |
| Tokens (approx) | ~306 | ~94 | -69% |

**Before (verbose):**
```python
"""Database query assistant with READ-ONLY access.

TOOLS:
1. query(sql) - PRIMARY. Execute SELECT, SHOW, DESCRIBE, or non-ANALYZE EXPLAIN. (Historical v2 wording; v3.7 full MCP policy rejects raw SHOW.)
2. list_tables() - List available tables (use if structure unknown)
3. describe_table(name) - Get single table columns
4. get_full_schema() - Get ALL tables and columns in ONE call (recommended first)
5. get_table_summary(name) - Get table statistics without raw data
6. sample(table, limit) - Preview table data

QUERY GUIDELINES:
- Use JOINs for combining related tables (INNER JOIN, LEFT JOIN)
- Use aggregation (COUNT, SUM, GROUP BY) instead of fetching all rows
- Always include LIMIT for large result sets

UNION QUERIES:
- UNION is enabled for combining results from multiple tables
- All tables in UNION must be in allowlist: customers, orders, products
- Example: SELECT id, name FROM products UNION SELECT id, title FROM categories

WORKFLOW (Token Optimized):
- Start with: get_full_schema() to understand database structure
- For large tables: get_table_summary() first, then query with LIMIT
- Prefer aggregation over raw data retrieval

Always show executed SQL in response. Format results as readable tables."""
```

**After (optimized):**
```python
"""READ-ONLY SQL assistant. Tools: query (primary), get_full_schema, list_tables, describe_table, get_table_summary, sample.

Workflow: get_full_schema() first → query with LIMIT for large tables.
Guidelines: Use aggregation (COUNT/GROUP BY) over raw data. UNION enabled (tables: customers, orders, products). Use JOINs for related data.
Always show SQL in response."""
```

**Key optimization principles applied:**
- Remove redundant tool descriptions (already in docstrings)
- Combine related guidelines into single sentences
- Remove examples (LLM can infer from context)
- Dynamic UNION guidance based on configuration

#### Files Changed

| File | Change |
|------|--------|
| `mcp_sql_server.py` | Added ALLOW_UNION config, startup logging, optimized prompt |
| `.env.example` | Added ALLOW_UNION=0 documentation |

#### References

- [OpenAI Function Calling Best Practices](https://platform.openai.com/docs/guides/function-calling)
- [Google Gemini Function Calling](https://ai.google.dev/gemini-api/docs/function-calling)
- [FastMCP Prompts Documentation](https://github.com/jlowin/fastmcp)

---

## Update (December 15, 2025)

### Extended SQL Statement Support

Added support for additional read-only SQL statement types beyond SELECT:

| Statement | Purpose | Example |
|-----------|---------|---------|
| `SELECT` | Data retrieval | `SELECT * FROM users` |
| `SHOW` | Database metadata | `SHOW TABLES`, `SHOW COLUMNS FROM users` |
| `DESCRIBE` | Table structure | `DESCRIBE users` |
| `EXPLAIN` | Query plan analysis | `EXPLAIN SELECT * FROM users` |

**Files Changed:**
- `sql_safety_checker.py`: Added `SAFE_SQL_TYPES` constant and updated `is_sql_safe()` function
- `mcp_sql_server.py`: Updated instructions, tool descriptions, and prompts
- `README.md`: Updated documentation to reflect new capabilities

**Server Instructions Updated:**
```python
instructions="""You are a database query assistant with READ-ONLY access.
Use the query tool for most operations. Safe statements: SELECT, SHOW,
DESCRIBE, and non-ANALYZE EXPLAIN. (Historical v2 wording; v3.7 full MCP policy rejects raw SHOW.)
Use list_tables first if you don't know the database structure.
If first time querying or unsure about columns: list_tables() -> describe_table() -> query()
If you already know the table structure: query directly"""
```

---

## Changes Summary (v2.0 vs. v1.0)

### 1. Code Reduction
- **Before:** ~460 lines
- **After:** ~280 lines
- **Reduction:** ~40% less code while maintaining functionality

### 2. Tool Consolidation

| Old Tools | New Tools | Reason |
|-----------|-----------|--------|
| `validate_sql_query` | *(removed)* | Validation is now automatic inside `query()` |
| `execute_safe_sql` | `query` | Renamed for clarity and brevity |
| `check_database_connection` | `check_connection` | Renamed, kept for backward compatibility |
| `get_table_schema` | `describe_table` | Matches SQL `DESCRIBE` command |
| `get_sample_data` | `sample` | Shorter, more intuitive name |
| `get_server_info` | *(removed)* | Rarely used, low value |
| *(new)* | `list_tables` | Essential for database discovery |
| *(new - Dec 23)* | `get_full_schema` | Token optimization: Get all tables/columns in ONE call |
| *(new - Dec 23)* | `get_table_summary` | Token optimization: Get table stats without raw data |

**Summary:**
- Original: 6 tools → Now: 7 tools
- 2 removed (`validate_sql_query`, `get_server_info`)
- 3 added (`list_tables`, `get_full_schema`, `get_table_summary`)
- 4 renamed

### Tool Migration Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         TOOL MIGRATION MAP                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   OLD TOOLS (6)                              NEW TOOLS (7)                  │
│   ═══════════                                ════════════                   │
│                                                                             │
│   ┌──────────────────────┐                                                  │
│   │  validate_sql_query  │ ──────┐                                          │
│   └──────────────────────┘       │  (merged)   ┌─────────────┐              │
│                                  ├───────────► │    query    │              │
│   ┌──────────────────────┐       │             └─────────────┘              │
│   │   execute_safe_sql   │ ──────┘                                          │
│   └──────────────────────┘                                                  │
│                                                                             │
│   ┌──────────────────────┐   (renamed)   ┌──────────────────┐               │
│   │check_database_connection│ ─────────► │  check_connection │               │
│   └──────────────────────┘               └──────────────────┘               │
│                                                                             │
│   ┌──────────────────────┐   (renamed)   ┌──────────────────┐               │
│   │   get_table_schema   │ ─────────────►│  describe_table  │               │
│   └──────────────────────┘               └──────────────────┘               │
│                                                                             │
│   ┌──────────────────────┐   (renamed)   ┌──────────────────┐               │
│   │    get_sample_data   │ ─────────────►│      sample      │ [OPTIONAL]    │
│   └──────────────────────┘               └──────────────────┘               │
│                                          (requires ENABLE_SCHEMA_TOOLS=1)   │
│                                                                             │
│   ┌──────────────────────┐                                                  │
│   │    get_server_info   │ ─────────────► ✗ REMOVED                         │
│   └──────────────────────┘                                                  │
│                                                                             │
│                              (new)       ┌──────────────────┐               │
│                          ★ ─────────────►│   list_tables    │               │
│                                          └──────────────────┘               │
│                                                                             │
│                          ★ (new Dec 23)  ┌──────────────────┐               │
│                            ─────────────►│  get_full_schema │               │
│                                          └──────────────────┘               │
│                                                                             │
│                          ★ (new Dec 23)  ┌──────────────────┐               │
│                            ─────────────►│ get_table_summary│               │
│                                          └──────────────────┘               │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

Legend:
  ─────────►  Renamed (1:1 mapping)
  ──┬──────►  Merged (N:1 mapping)  
  ✗ REMOVED   Tool no longer exists
  ★           Newly added tool
```

### 3. Tool Count Optimization
- **Before:** 6 tools called per simple query
- **After:** 1-2 tools for most queries

---

## Detailed Changes (v2.0)

### A. Added Lifespan Management

```python
@asynccontextmanager
async def lifespan(mcp_server: FastMCP) -> AsyncIterator[dict[str, Any]]:
    """Server lifespan context manager."""
    logger.info("SQL Safety Checker MCP Server starting...")
    yield {"initialized": True}
    logger.info("SQL Safety Checker MCP Server shutting down...")
```

**Reason:** FastMCP best practice for managing server lifecycle and resources (e.g., database connection pools).

### B. Added ToolAnnotations

```python
@mcp.tool(
    annotations=ToolAnnotations(
        title="Execute SQL Query",
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=False,
    )
)
```

**Reason:** Provides metadata to LLM clients about tool behavior:
- `readOnlyHint`: Indicates the tool doesn't modify data
- `destructiveHint`: Indicates the tool doesn't delete data
- `idempotentHint`: Indicates repeated calls have the same effect

### C. Added Context Injection

```python
async def query(sql: str, ctx: Context) -> dict[str, Any]:
    await ctx.info(f"Executing query: {sql}")
    # ...
    await ctx.warning(f"Rejected unsafe query: {sql}")
```

**Reason:** 
- Structured logging through MCP protocol
- Client can receive real-time progress updates
- Better debugging and monitoring capabilities

### D. Improved Server Instructions (Updated December 2025)

The server instructions were optimized following prompt engineering best practices to reduce LLM's "exploratory behavior" (making unnecessary tool calls).

**Original Instructions:**
```python
instructions="""You are a database query assistant with READ-ONLY access.
Use the query tool for most operations. Only SELECT statements are allowed.
Use list_tables first if you don't know the database structure."""
```

**Optimized Instructions (Updated December 15, 2025):**
```python
instructions="""Database query assistant with READ-ONLY access.

Tools: query (primary), list_tables, describe_table, check_connection

Workflow:
- Known table structure: query directly
- Unknown structure: list_tables first, then query

Safe statements: SELECT, SHOW, DESCRIBE, and non-ANALYZE EXPLAIN.
(Historical v2 wording; v3.7 full MCP policy rejects raw SHOW.)"""
```

**Design Rationale:**
- **Concise**: Reduced token count while preserving all essential information
- **Flexible**: Allows LLM to choose exploration when needed (per MCP design philosophy)
- **Clear priority**: `query (primary)` indicates main tool without being restrictive
- **Workflow guidance**: Provides both paths (known/unknown structure) without forcing either
- **Aligned with MCP spec**: Tools are "model-controlled" - LLM decides based on context

See [PROMPT_ENGINEERING_BEST_PRACTICES.md](docs/guides/PROMPT_ENGINEERING_BEST_PRACTICES.md) for detailed guidelines.

### E. Added SQL Injection Prevention

```python
def _is_valid_identifier(name: str) -> bool:
    """Validate table/column name to prevent SQL injection."""
    return bool(re.match(r'^[\w\u4e00-\u9fff][\w\u4e00-\u9fff]*$', name))
```

**Reason:** Prevents SQL injection through table names while supporting Chinese characters.

### F. Conditional Tool Registration

```python
SCHEMA_TOOLS_ENABLED = os.getenv("ENABLE_SCHEMA_TOOLS", "1") == "1"

if SCHEMA_TOOLS_ENABLED:
    @mcp.tool(...)
    async def sample(...):
        ...
```

**Reason:** Allows disabling optional tools via environment variables for production deployments.

---

## Tool Usage Guide (After Refactoring, v2.0)

### Primary Workflow
```
query("SELECT * FROM users LIMIT 10")  # Direct query - most common
```

### Discovery Workflow
```
list_tables()                          # Step 1: Find tables
describe_table("users")                # Step 2: Understand structure
query("SELECT name FROM users")        # Step 3: Execute query
```

### Utility Tools
```
check_connection()                     # Verify database connection
sample("users", limit=5)               # Preview table data
```

---

## Best Practices Applied

1. **Single Responsibility:** Each tool does one thing well
2. **Clear Naming:** Tool names match their purpose (e.g., `describe_table` ≈ SQL `DESCRIBE`)
3. **Consistent Return Format:** All tools return `{"success": bool, "data": ..., "error": ...}`
4. **Proper Async:** All tools are async with proper Context usage
5. **Defensive Programming:** Input validation, SQL injection prevention
6. **Graceful Degradation:** Clear error messages with context

---

## Backward Compatibility Notes

- `check_connection` (previously `check_database_connection`) was kept for compatibility
- Old tool names are no longer available - clients need to update their calls
- The functionality remains the same, only the interface has improved

---

## Files Modified (After Refactoring, v2.0)

| File | Change Type |
|------|-------------|
| `mcp_sql_server.py` | Complete rewrite |
| `test_mcp_client.py` | Updated tool names to match new API |
| `test_mcp_functions.py` | Removed mcp_sql_server imports, use raw SQL |
| `REFACTORING_LOG.md` | Created (this file) |

### test_mcp_client.py Changes

Updated all tool calls to use new names:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    test_mcp_client.py TOOL CALL UPDATES                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   OLD TOOL CALLS                             NEW TOOL CALLS                 │
│   ══════════════                             ══════════════                 │
│                                                                             │
│   ┌──────────────────────────┐               ┌──────────────────────────┐   │
│   │ check_database_connection│ ─────────────►│    check_connection      │   │
│   └──────────────────────────┘   (renamed)   └──────────────────────────┘   │
│                                                                             │
│   ┌──────────────────────────┐               ┌──────────────────────────┐   │
│   │    get_table_schema      │ ─────────────►│    describe_table        │   │
│   └──────────────────────────┘   (renamed)   └──────────────────────────┘   │
│                                                                             │
│   ┌──────────────────────────┐               ┌──────────────────────────┐   │
│   │     get_sample_data      │ ─────────────►│        sample            │   │
│   └──────────────────────────┘   (renamed)   └──────────────────────────┘   │
│                                                                             │
│   ┌──────────────────────────┐                                              │
│   │    validate_sql_query    │ ─────────────► ✗ REMOVED (merged into query) │
│   └──────────────────────────┘                                              │
│                                                                             │
│   ┌──────────────────────────┐               ┌──────────────────────────┐   │
│   │     execute_safe_sql     │ ─────────────►│        query             │   │
│   └──────────────────────────┘   (renamed)   └──────────────────────────┘   │
│                                                                             │
│   ┌──────────────────────────┐                                              │
│   │     get_server_info      │ ─────────────► ✗ REMOVED (low value)         │
│   └──────────────────────────┘                                              │
│                                                                             │
│                                  (new)       ┌──────────────────────────┐   │
│                              ★ ─────────────►│      list_tables         │   │
│                                              └──────────────────────────┘   │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│  REASON: Align test script with refactored mcp_sql_server.py API            │
│  IMPACT: Test logic unchanged - only tool names updated                     │
└─────────────────────────────────────────────────────────────────────────────┘

Legend:
  ─────────►  Tool name updated (1:1 mapping)
  ✗ REMOVED   Test case removed (tool no longer exists)
  ★           New test case added
```

### test_mcp_functions.py Changes

Removed dependency on `mcp_sql_server.py`, now uses raw SQL for schema tests:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                   test_mcp_functions.py IMPORT UPDATES                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   BEFORE                                     AFTER                          │
│   ══════                                     ═════                          │
│                                                                             │
│   ┌──────────────────────────────────┐                                      │
│   │ from mcp_sql_server import       │                                      │
│   │     get_sample_data,             │ ─────────────► ✗ REMOVED             │
│   │     get_table_schema             │                                      │
│   └──────────────────────────────────┘                                      │
│                                                                             │
│   ┌──────────────────────────────────┐       ┌──────────────────────────┐   │
│   │ get_table_schema(table_name)     │ ─────►│ execute_safe_sql(        │   │
│   └──────────────────────────────────┘       │   "SELECT ... FROM       │   │
│                                              │   INFORMATION_SCHEMA..." │   │
│                                              │ )                        │   │
│                                              └──────────────────────────┘   │
│                                                                             │
│   ┌──────────────────────────────────┐       ┌──────────────────────────┐   │
│   │ get_sample_data(table, limit)    │ ─────►│ execute_safe_sql(        │   │
│   └──────────────────────────────────┘       │   "SELECT * FROM table   │   │
│                                              │    LIMIT n"              │   │
│                                              │ )                        │   │
│                                              └──────────────────────────┘   │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│  REASON: mcp_sql_server.py no longer exports these functions after refactor │
│  IMPACT: Test logic unchanged - only data retrieval method changed          │
│  BENEFIT: test_mcp_functions.py now only depends on sql_safety_checker.py   │
└─────────────────────────────────────────────────────────────────────────────┘

Legend:
  ─────────►  Implementation changed
  ✗ REMOVED   Import removed
```

---

## Why This Refactoring Follows Best Practices (v2.0)

### 1. Tool Design Simplification

| Aspect | Before | After | Why Better |
|--------|--------|-------|------------|
| Query execution | `validate_sql_query` + `execute_safe_sql` (2 calls) | `query()` with automatic validation (1 call) | MCP best practice: fewer tools = easier for LLM to choose correctly |
| Tool count | 6 tools | 5 tools with clearer responsibilities | Reduces cognitive load for LLM clients |

### 2. ToolAnnotations Usage

```python
@mcp.tool(
    annotations=ToolAnnotations(
        readOnlyHint=True,      # Tells LLM this is a read-only operation
        destructiveHint=False,  # Tells LLM this is safe
        idempotentHint=True,    # Tells LLM this can be retried safely
    )
)
```

These annotations help LLM clients understand tool behavior without reading documentation, leading to better tool selection.

### 3. Async + Context Pattern

```python
# Before (synchronous, basic logging)
def execute_safe_sql(sql_query: str) -> Dict[str, Any]:
    logger.info(...)

# After (async, structured logging via Context)
async def query(sql: str, ctx: Context) -> dict[str, Any]:
    await ctx.info(f"Executing query: {sql}")
```

Using `Context` is the FastMCP recommended approach:
- Provides structured logging through MCP protocol
- Enables real-time progress reporting to clients
- Better observability and debugging

### 4. Lifespan Management

```python
@asynccontextmanager
async def lifespan(mcp_server: FastMCP) -> AsyncIterator[dict[str, Any]]:
    # Initialize resources on startup
    yield {"initialized": True}
    # Cleanup resources on shutdown
```

Proper resource lifecycle management:
- Prepares for future connection pooling
- Follows Python async best practices
- Enables graceful shutdown

### 5. Enhanced SQL Injection Protection

```python
def _is_valid_identifier(name: str) -> bool:
    """Validate table/column name to prevent SQL injection."""
    return bool(re.match(r'^[\w\u4e00-\u9fff][\w\u4e00-\u9fff]*$', name))
```

New version explicitly validates dynamic table names, adding defense-in-depth security.

### 6. Simplified Prompts

| Before | After |
|--------|-------|
| Verbose `system_orchestration` prompt | Clean `sql_assistant` prompt |
| Complex `generate_select_sql` prompt | Removed (unnecessary) |

Simpler prompts are easier to maintain and less likely to confuse LLM clients.

### 7. Code Quality Metrics

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Lines of code | ~460 | ~280 | -40% |
| Cognitive complexity | High | Low | Easier to maintain |
| Test surface area | Large | Small | Easier to test |
| Type hints | Partial | Complete | Better IDE support |
