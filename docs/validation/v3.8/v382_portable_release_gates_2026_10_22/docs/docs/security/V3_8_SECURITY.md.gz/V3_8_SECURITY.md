# v3.8 security boundary / 安全边界

MySQL is the server/dialect acceptance target; MariaDB is not required. Native SQLite and actual MySQL version/session scopes remain explicit. The [DRR-141 actual channel checkpoint](../validation/v3.8/v382_primary_key_metadata_repair_2026_10_21/resident_restart/README.md) retains the earlier native7/12 versus fresh CLI12/12 mismatch; latest owner restart passes all12 scoped native checks. The earlier runtime/client binding cause remains unconfirmed.

DRR-141 separates actual PRIMARY identity/order from native display flags in metadata. SQLite reuses native positions; MySQL joins configured-schema PRIMARY facts in existing bounded column queries with exact component residuals. Compact grouping uses positions but does not prove full DDL/index equivalence. No grants, read analysis, authorizer rules, original SQL or configuration are relaxed. [Contract and current acceptance scope](../validation/v3.8/V3_8_2_PRIMARY_KEY_METADATA_REPAIR_2026_10_21_ZH.md).

Owner-approved DRR-137/138 repairs use actual-schema fixed FTS catalog PRAGMAs and true table/verified nonpartial-index statistics. Adjacent DRR-139 maps implicit external-content rowid spellings to SQLite compile-time column identity, preserving declared names and INTEGER PK DESC/WITHOUT ROWID distinctions. All work remains outside callbacks on the owned connection, within query/fetch/lookup budgets; direct grants and guarded data reads remain live. After the owner restart, all10 frozen existing-alias native checks pass, including FTS reads, metadata and continued shadow/function refusals. Special collision, partial-index and cold-rowid fixtures retain source/package coverage. [Repair and scoped evidence](../validation/v3.8/V3_8_2_FTS_CATALOG_STATISTICS_REPAIR_2026_10_21_ZH.md).

October 21 result boundary: query/Query Skills/sample reject duplicate returned-row labels before dict projection, encode binary/non-finite values explicitly, reject unsupported representations without exception details, and apply the same encoded-data limits including a zero-row oversized-first-row response. These are representation guarantees, independent of database authorization and write-outcome evidence. JSON conditional dependencies retain unresolved identity; DRR-135 now uses ordered two-name catalog observations with completeness, schema-count/time budgets and fixed PRAGMA database_list. Incomplete absence is unverified, never builtin; readiness-off performs no probes. Actual object/module/grant checks and the authorizer remain unchanged. Data limits do not cap protocol envelopes, SQL echo, database work/fetch or provider tokens. [Result contract](../validation/v3.8/V3_8_2_READ_RESULTS_2026_10_21_ZH.md), [ordered readiness repair](../validation/v3.8/V3_8_2_ATTACHED_JSON_REPAIR_2026_10_21_ZH.md). DRR-136 metadata-name shadows are now repaired with fixed main-bound PRAGMA statements, bounded raw-row fetch and the existing whole-index count/key/byte/deadline limits. This does not grant arbitrary user PRAGMA access or change read authorizers. N real indexes require N+2 catalog statements; the combined owner restart now passes 20/20 scoped native checks; special collision/attached fixtures retain source/package coverage. [Metadata repair and limits](../validation/v3.8/V3_8_2_METADATA_PRAGMA_REPAIR_2026_10_21_ZH.md).


October 20 read/binding follow-up: ignore only verified non-executable trailing nodes after checking every original comment; real second statements, restricted functions and unauthorized targets remain refused. Managed loading and target rechecks share execution transport's actual session-aware binding identity. Pure classifier reuse includes declared parameter names, never values, grants or readiness; consumed confirmation still resolves current context. MySQL column batches contain only authorized returned names with bounded bindings and exact-name projection, and fail as one metadata operation. Operation-local read-analysis reuse was studied but no generic production cache was added; connection/authorizer/cache lifecycles and trusted-code limits remain. Source/package checks pass; after owner restart, 34/34 scoped native checks pass with unchanged data and no confirmed writes. Exact temporary-template/mode cases retain source/package coverage; no new model/native performance claim. [Evidence and limits](../validation/v3.8/V3_8_2_READ_PLAN_REPAIR_2026_10_20_ZH.md).

October 20 metadata optimization projects authorized returned tables before data-based estimates and batches fixed statistics only. Missing statistics retain complete guarded reads; no-colon transport preparation does not authorize SQL. No cross-request authorization/catalog cache, authorizer bypass or automatic ANALYZE is introduced. Directory/statistics metadata and data evaluation remain separate boundaries. [Implementation, costs and acceptance status](../validation/v3.8/V3_8_2_METADATA_OPTIMIZATION_2026_10_20_ZH.md).

October 19 read-capability follow-up: all-mode covers the configured default schema; bare grants identify default objects. Cross-schema access uses explicit allowlists. FTS5 internal abilities are derived from verified roots and never become direct shadow/content grants; callback provenance alone cannot distinguish internal PRAGMA. Keep complete analysis, per-request authorization and lifecycle checks; no public authorizer-off TOML option. Ordinary lock-taking reads are refused; DB permissions, MySQL DEFINER views/routines and trusted UDF/extension boundaries remain independent. [Scope, costs and current validation status](../validation/v3.8/V3_8_2_READ_CAPABILITIES_2026_10_19_ZH.md).


October 20 FTS follow-up implements DRR-116/117: check shared restricted-function facts of complete reachable view/trigger definitions before execution, including after trusted full FTS prewarming; limit builtin-only qualification rules to builtin uses so explicitly granted named FTS calls retain actual schema/module checks. Definition-wide checks conservatively refuse unused restricted expressions too; normal derived views remain supported. Source/package checks pass; after the owner restart, 8/8 existing-fixture native checks pass with unchanged data and independent SQLite truth. Exact trusted-warm view/aux FTS cases retain source/package coverage, not a claim of identical native replay. [Repair and limits](../validation/v3.8/V3_8_2_FTS_FOLLOWUPS_2026_10_20_ZH.md). The [earlier audit](../validation/v3.8/V3_8_2_POSTREPAIR_AUDIT_2026_10_20_ZH.md) retains its original findings.

Current follow-up: the [WHEN repair](../validation/v3.8/V3_8_2_TRIGGER_WHEN_2026_10_17_ZH.md) consumes the real condition expression before requiring the body marker, restoring the confirmed begin-column regression. Every original condition/body dependency and function remains checked. Source/package validation passes; after the maintainer restart, 57/57 scoped native checks pass with unchanged data. Three new canary-conditioned complete sales trials reach correct outcomes, retaining one initial unsupported-query refusal and recovery. Exact WHEN trigger fixtures retain source/package coverage, and prior Host failures remain unchanged. Separate Host logs confirm cached metadata without an exact ready client, with close/resume recovery observed; they do not prove stale cache or an underlying startup/binding root cause.

The supported deployment is a trusted local Host and a single server process. MCP annotations describe tools; they are not authorization. The server does not authenticate a human approver, provide remote multi-user identity isolation, or sandbox Python Skills.

本轮沿用可信 Host 审批模式 A。Host 负责可靠呈现审阅内容并收集人的决定；服务端负责目标、Skill、参数、提案绑定及单次消费。恶意或被攻陷的 Host 能伪造批准，不能宣称 MRTR 提供了独立人类认证。

## October 17 read-boundary supplement

The subsequent [plan follow-up](../validation/v3.8/V3_8_2_EXPLAIN_FOLLOWUP_2026_10_17_ZH.md) reopened DRR-108 for trigger READ, WITH REPLACE and UPDATE OR gaps; scoped repair acceptance now includes the completed 42/42 native restart checks. Source/package and native fixture coverage remain distinct. Verified non-executing plans check direct reads by actual schema/name even when the source is a trigger. Unresolved count/view reads first abort preparation, then receive fixed catalog work outside the callback under one lock, deadline and cumulative budget. Trigger WHEN/body dependencies must be analyzed before accepting source-lost view-count edges, so direct base reads cannot borrow a view grant. Ambiguous source roles and incomplete definitions refuse; real DML gains no exemption. The observations below retain their previous-source scope.

A subsequent trigger-local CTE boundary reopened DRR-108 and is now repaired with scoped resident acceptance: verified SELECT/DML sources and owner/fragment/scope declarations are prepared outside callbacks before database-less CTE count events are accepted. Real physical dependencies, writes, restricted functions and ambiguous source/catalog identities remain checked. Same local spellings in separately validated triggers do not share physical grants. See the [current supplement](../validation/v3.8/V3_8_2_TRIGGER_CTE_2026_10_17_ZH.md) for 2196 passes/four skips, installed coverage, 57 passing native acceptance checks and 12 retained exploratory mismatches. Repeated outer-query CTE labels remain a known conservative refusal; trigger-local support is not a general scope exception.

View-evaluating sample/count/estimate operations now use controlled reads; guarded estimates can be unavailable while columns/indexes remain usable. Every analyzed physical root is checked before accepting an extra source-less COUNT event from an authorized view's dependency graph. That graph does not grant direct base access. Verified non-executing SQLite DML plans admit only the required INSERT/UPDATE/DELETE compilation events, with actual target and function checks intact. Bind the analysis to the original SQL/context; do not disable authorizers or exempt PRAGMA/DDL/ATTACH based on an EXPLAIN prefix. These checks also cover REPLACE plans. See [scope, evidence and completed native checks](../validation/v3.8/V3_8_2_READ_BOUNDARIES_2026_10_17_ZH.md). Earlier evidence retains its tested-source attribution.

## v3.8.2 read execution contract (October 16, 2026)

Raw queries, Query Skills and readiness now use shared SQLGlot analysis with explicit SQLite/MySQL session semantics. Relations retain schema/name components, lexical spelling and scopes; project grants stay independent. Structured declarations do not widen grants, and incomplete analysis is never treated as no dependencies. Original SQL and parameters reach the driver; literal/name/comment colons are protected from SQLAlchemy binding without AST rewriting. The earlier dated sections below describe their original source states.

SQLite adds a per-physical-connection authorizer under exclusive adapter ownership, with DBAPI statement caching disabled. Checks last through result consumption/recompilation and deny actual reads of unauthorized temp/attached objects, reserved operations/calls and unsupported source edges. Authorized views may read through a verified view/CTE dependency chain while direct base access remains denied. A schema change after preparation cannot inherit stale edges. Certain empty-column READ events omit the database; only an unambiguous current catalog or verified virtual-relation binding is accepted. Ambiguous labels, unsupported virtual view dependencies and over-budget preparation are refused. Fixed catalog/statistics metadata and complete managed writes are trusted separate contexts; sample, exact counts and SQLite data-based estimates activate the read guard; callbacks never execute SQL and never substitute NULL through IGNORE.

Every MySQL physical connection initializes/verifies a complete SQL-mode contract before SQLAlchemy dialect detection, including reconnect/pool rebuild. No added per-request mode probe. Arbitrary trusted operations/full writes retire their sessions after determining the outcome, preventing their state from returning to the ordinary read pool. Private engine/DBAPI extensions must maintain this ownership contract. Database-qualified SQL alone still does not prevent same-session temporary-table shadowing. MySQL does not gain a SQLite-style authorizer or proof that stored routines/UDFs have no side effects.

Schema, UDFs and Python Skills remain trusted deployment content. Authorizer events occur at compilation/recompilation, not necessarily every evaluation of functions embedded in an already-loaded schema (including generated columns). Connection locking, statement-cache removal, view preparation and reconnects have costs; outer cancellation does not forcibly interrupt all synchronous work. Existing approval/token/audit and mutation outcome semantics are unchanged. See [design, supported subset and limits](../architecture/V3_8_2_SQL_SEMANTICS_ZH.md), [current-source acceptance](../validation/v3.8/V3_8_2_VALIDATION_2026_10_16_ZH.md), DRR-2026-100–106. Materialized CTE counts can report empty-column READ events without a database. The narrow exception requires a unique declared CTE label absent from every attached catalog; it does not grant physical objects or skip function/operation checks. Catalog-name collisions remain conservatively refused.

## Where approval is enforced

MRTR is a protocol pattern for requesting more input, not inherently a human-approval system. This project's `request_mutation_approval` uses it to require a bound approving response before executing that proposal; the Host remains responsible for obtaining the person's decision.

**MRTR 给 `request_mutation_approval` 这个入口增加了服务端强制的“批准轮次”；而 preview/execute 的“人工批准”属于 Host 工作流，Server 强制 preview-token 协议、权限与执行检查，但并不知道是否真的有人批准。** 此处“批准轮次”指服务端必须收到有效绑定的 `accept` 与严格布尔 `approve=true`，不证明真人在场或点击，也不改变旧入口仍可用的事实。

| Boundary | Legacy preview/execute | MRTR |
|---|---|---|
| Human interaction | The Host implements it; the server does not request an approval form. An Agent may ask in conversation, or the reference Host may require literal `APPROVE`. | The server returns a protocol input request; the Host renders it and supplies a decision. Window rendering and human interaction depend on that Host. |
| Server execution gate | `confirm=true`, a valid matching one-time preview token, configuration grants and execution checks. | A valid bound continuation, `accept` with strict boolean `approve=true`, and the shared proposal/grant/execution checks. |
| Independent evidence of a human | None: a client with both tool access and the token can submit execute without asking a person. | None: an automated or compromised Host can supply an accepting response. Sealing binds continuation state; it does not authenticate the approver. |

`skills.mutation.mrtr.enabled` controls registration of the optional MRTR tool. Enabling it does **not** disable `execute_mutation_skill` or require every mutation to use MRTR; disabling it does **not** disable otherwise authorized legacy mutations. Client tool-call permissions are another Host control, not a server-verifiable approval of the exact SQL.

Trusted-Host mode A is the accepted boundary (DRR-2026-050). A conversation-only instruction to ask permission is an Agent behavior rule, not a server authorization gate. The reference Host enforces its own decision/deadline checks in code, so legacy approval need not rely solely on an Agent following instructions; other authorized clients can still call the service directly. Both flows continue enforcing target, parameter, expiry, replay and database policies even though they do not prove human approval.

If the requirement changes to preventing an Agent/client from approving its own writes, a separate authenticated approval authority must issue authorization unavailable to that Agent and bound to the exact proposal, with every write entry point enforcing it. An unbypassable trusted gateway is another possible deployment boundary. These are future designs, not properties of current tokens, MRTR, tool annotations or UI prompts; hiding a tool only from the model is not sufficient server-side enforcement. See the [DRR follow-up](DESIGN_RISK_REGISTER.md#drr-2026-050-approval-boundary-follow-up-october-1-2026).

## Authorization

The October 1 deployment decision retains preview/execute as the default, with MRTR disabled unless explicitly enabled for a verified Host. Native Codex IDE evidence and the tested Copilot protocol rejection justify this compatibility choice only for the observed scope; see the [acceptance audit](../validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md). This does not strengthen either flow's human-identity guarantee. A client must not automatically switch write entry points after an approval refusal, cancellation, timeout or uncertain outcome. This is a Host workflow requirement, not a cross-entry-point server lock; reconcile uncertain writes first.

Read access defaults to deny. An explicit allowlist (nonempty) or `all` grants read scope; structural checks still block writes, unsupported syntax, system schemas, file operations, unsafe comments and unauthorized UNION. Raw SQL and Query Skills share the complete policy. Metadata tools obey read scope. Unknown targets never fall back.

Writes require all five configuration gates: Skills, global mutation enablement, admitted target, target mutation enablement, and target Skill allowlist. Skill connection/type/profile restrictions and execution checks remain conjunctive. Read allowlists are not universal mutation allowlists. Authorized previews/readiness checks may inspect mutation business tables even if general reads are denied.

Profile exclusions are normalized once in the TOML loader (trim, lowercase, deduplicate); blank entries fail startup. Query Skill availability uses the same read-admission predicate as execution, including tableless SQL. These checks do not grant mutation access.

Query Skill discovery also preflights the cached SQL with the execution path's full static policy for the resolved connection, including UNION and parsed table scope. A denied template remains in the catalog for other authorized targets; verdicts are not shared across connections. This adds parsing work to discovery, not database SQL execution. Enabled schema readiness can still perform metadata I/O, and execution repeats the authoritative checks. Availability does not guarantee valid parameters, dialect compatibility, database availability or successful execution.

Explicit target binding and deployment permissions do not authenticate the user's natural-language task scope. `OperationContext` carries operational callbacks, not a trusted per-request authorization grant. A Host-authenticated task-scope boundary remains deferred; an Agent can request any operation that the deployment otherwise authorizes.

## Proposals and MRTR

- `execute_mutation_skill` retains preview/execute and its opaque 256-bit random bearer handle. Only a digest is used as the token-store key; possession still represents a capability.
- MRTR supports only cached, framework-managed, single-statement plans. Legacy imperative callbacks retain their earlier weaker guarantee and are rejected by MRTR.
- First round validates protocol/form capability, Skill mode and authorization before preparing a proposal. It does not execute the managed write. Custom preview Python is trusted code; the server cannot sandbox a malicious preview callback.
- Review includes resolved target, Skill, normalized parameters, SQL/bound values and expiry. One server-side review is capped at 64 KiB UTF-8; over-limit proposals are revoked and rejected, never truncated for approval. The existing execution binding cap remains 4096 bytes.
- FastMCP/SDK seals request state. The sealed reference is not a replacement for server-side proposal validation. The raw bearer token is omitted from displayed MRTR review and telemetry. Sealed state should also be treated as sensitive.
- Missing answers resend the same review without extending TTL. Only `accept` plus strict boolean `approve=true` executes. False, decline and cancel consume the pending proposal without executing. Invalid responses never approve.
- The required boolean `approve` field advertises `default=false` as a form initialization hint. It does not supply missing response data or authorize execution. Explicit false uses the refusal path. On October 1, the tested Codex IDE accepted an unchecked submission after this hint was added; the user confirmed the UI action and the server returned `approval_declined` without a database change. This is standard MCP schema metadata, not a Host-specific bypass. Other Host/version combinations still require UI verification; see the [dated acceptance and scope audit](../../REFACTORING_LOG.md#v380-mrtr-approval-form-default-october-1-2026).
- The SDK's sealed-state TTL explicitly follows the configured preview TTL, using an ephemeral key per service instance. Resealing a missing-answer continuation never extends the original server-side proposal expiry.
- Continuations must match the same target, Skill/version and normalized parameters. Execution uses the cached plan and preview binding; it does not rerun preview under an old approval.
- Consumption remains atomic at the execution boundary. Any failure after consumption leaves the token spent. Missing records, concurrent continuations and replay are not evidence that an earlier write did not happen.
- Waiting holds no transaction or row lock. An optimistic precondition may fail between review and execution; row-count mismatch rolls back the managed transaction.

Token state, diagnostics, connections and catalog are instance-owned and in-memory. Shutdown clears pending proposals. Restart cannot recover approvals. There is no distributed or durable completion ledger. Capacity is count-based; with the configured review/binding maxima, administrators should size `max_entries` for memory use rather than blindly choosing the maximum.

Native October 1 testing observed a user-approved continuation after a long wait rejected with `invalid_request_state`; independent reads showed no change. This framework protocol error carries no business `execution_outcome` and does not independently exercise the business TTL branch. A separate real-process stdio regression now verifies old-state rejection before expiry and successful fresh approval after restart; native restart UI behavior remains unverified; see the [acceptance record](../validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md). No cross-client guarantee follows from this one Host's result.

The reference Host's preview and MRTR flows share an outer approval deadline, a fingerprint of the displayed review (including nested values), and a post-decision expiry check. Late approval, altered review, invalid decisions or provider errors fail closed. Host approval timeout is independent of server token TTL. Cooperative providers are cancelled; a blocking provider or one suppressing cancellation is rejected when it returns, but this is not a hard termination or isolation guarantee against hostile Python. MRTR sends cancellation for these failures; external task/transport cancellation can leave a proposal pending until TTL. No automatic write retry is introduced.

## Outcome and observability

October22 SQLite repair (DRR-142/143): logical SQLAlchemy begin is not physical-BEGIN evidence under legacy sqlite3 control. Writes now establish a physical transaction before original DML, complete/close RETURNING before direct-row checks, and use same-connection changes() only for unknown-count DML. A confirmed rollback requires valid pre/post physical state; unresolved cursor/handler/transaction cleanup retires the connection. Auto-rollback and COMMIT uncertainty remain unknown, never an automatic retry license. Read authorizers and MySQL's transactional evidence scope are unchanged. Source/package private fixtures and owner-restarted12/12 scoped native checks pass; actual write proof remains private, without a configured confirmed write. Preserve the [original contract/costs](../validation/v3.8/V3_8_2_SQLITE_WRITE_TRANSACTIONS_2026_10_22_ZH.md) and [restart/contract-gap assessment](../validation/v3.8/V3_8_2_WRITE_RESTART_AND_STABILIZATION_2026_10_22_ZH.md). DRR-144 is an internal MySQL analysis/source-SQL consistency recommendation; no current MCP failure is reproduced, and no implementation is claimed.

`success` reports handler completion. `execution_outcome` reports transaction evidence: `not_executed`, `rolled_back`, `committed`, `unknown`. A committed write can have `success=false` when notification/serialization fails. Core result construction validates serializability inside the outcome boundary. Later network loss remains uncertain to the caller. Never automatically retry an uncertain write.

Audit remains **best-effort**. It may fail after a write and is not an authorization ledger. Audit may contain business parameters (bounded strings, not universal content redaction); restrict access. Metadata-only tool telemetry omits SQL, params, rows, credentials and token identifiers. An MRTR input-required round has `phase=awaiting_approval` and `success=null`, not business success. Diagnostic busy/draining/cleanup-failed protection is retained. No application result cache is enabled for previews, executes or MRTR.

Waiting and missing-answer MRTR rounds carry the validated target in result metadata; FastMCP stores it under `InputRequiredToolResult.input_required.meta`. Decline/cancel phases are `approval_declined` / `approval_cancelled`. Ordinary results use validated result metadata too; without it, `connection_id` and `db_type` remain null, including early rejections. Telemetry never guesses the default or echoes an unvalidated target. Diagnostics retain their separately validated scope behavior. Sealed-state rejection may occur before middleware and produce no tool telemetry event. These records are not a complete request ledger or a cross-round operation trace.

Database least privilege remains necessary. SQL parsing is a conservative safety filter, not a complete proof of all DB-specific side effects. Read-shaped functions and database-specific behavior retain the existing risk scope. Response truncation is not a database work or peak-memory limit. Synchronous backend work can outlast an outer timeout; reconcile state before retrying.

## Configuration and trusted code

Secrets use exactly one explicit source, have no fallback, and preserve whitespace/newlines. Offline errors and explanation redact secrets. File-based secret size is bounded at 64 KiB. Existing `.env` files and unrelated DB environment variables have no configuration effect through supported entry points. Embedders that import FastMCP beforehand own that import's settings.

Only trusted operators should edit TOML or Skill directories. Source and definition containment prevents accidental directory escapes, including symlinks; Python code can still import files, open connections, or mutate process state. Loading a class is not a sandbox. Definition snapshots mean file edits require restart, not that arbitrary trusted Python becomes immutable or harmless.

Configuration check does not load business code. Service initialization discovers Skills and can reject individual invalid definitions while leaving valid Skills available. Readiness is an availability observation, never an authorization grant. `agent_id` / Host-provided client labels are not authenticated identities.

## Accepted limits / 暂缓项

Tasks, remote multi-user auth, independently authenticated approvals, durable/distributed recovery, providers, CodeMode, generic result caching and OTel export are outside this release. Native Host version and observed protocol must be recorded separately from reference Client tests. A legacy client rejection is a compatibility result, not an MRTR approval pass.

### Review presentation

MRTR formats the saved review snapshot as indented Unicode JSON without removing fields or truncating SQL/bindings. The first-line question plus JSON contract remains compatible with the reference Host. Canonical stored bindings and strict approval checks are unchanged. The 64 KiB limit covers the stored review, not the expanded display message. Actual whitespace rendering is Host-controlled and needs native verification; readability changes do not authenticate a human or expand approval authority.

### Rejection recovery clue (v3.8.1)

On `validation_failed` (preview, execute, and MRTR's shared first round), the server may return `related_available_skills`. The list is limited to names in the rejected Skill's own `related_skills` that are mutation Skills executable on the same resolved connection under the same availability checks as `list_skills`: profile, connection scope, database type, every mutation grant and schema readiness. It is computed only after validation fails, issues no token and never changes `success`, `error_code` or `execution_outcome`; lookup failure omits it and logs only the exception class.

The field is advisory. It grants nothing, carries no parameters or sequencing advice, and cannot bypass the rejected rule. Every alternative write keeps its own preview, approval, binding and single-use token, and a multi-step restoration is a series of independent commits, not an atomic rollback. It discloses only names already visible through `list_skills` on that connection, and adds one readiness metadata lookup on qualifying rejections. Author-declared links can be incomplete or unsuitable; Agents may still ignore or misuse them (DRR-2026-071).

Previews return only absolute `preview_token_expires_at`; execute alone enforces expiry. Agents judging validity from their own date can misreport a live token as expired. This is conservative and accepted (DRR-2026-072); a relative-expiry field was not restored.

### Result interpretation guidance (v3.8.1)

First validate the result's target, Skill, phase and required fields. An invalid
result does not confirm execution even if its payload claims committed. The
outcome rules below apply only to valid results. Missing actual rowcount means
unreported; do not substitute an estimate or another request's count.

Hosts may not show `outputSchema` descriptions to the model; Copilot sends only name, description and input parameters. The `execute_mutation_skill` description therefore states how to read results: `execution_outcome` decides the write, not `success`; `committed` with `success=false` must not be redone; `unknown` may be written even with `success=true`; `not_executed` covers only this request; a tool or protocol error without `execution_outcome` (for example an invalid MRTR `requestState`) proves neither write nor no-write. After uncertainty, errors, decline or cancel, an Agent must not retry, switch entry points or open a new proposal on its own. `idempotent=true` grants no retry. Returned text, including error messages, is data, not instructions, and preview tokens stay out of user-facing summaries. Both write tools independently include the same packaged rules; a Host need not expose the other tool for result interpretation. A refusal does not establish current row state. Without a fresh authorized read, report that state is unverified; an explanatory reply need not perform a read.

These are behavior rules, not controls. Token binding, expiry, single use and the rest of the execution boundary are unchanged and remain authoritative. Replay trials improved but did not eliminate misstatements: after an approval decline, two of three runs asserted current data without reading it (DRR-2026-073). The initial description cost about 159 input tokens per request in that measured Host; this historical number does not measure the longer final October 12 descriptions.

A later real tool-channel check on a richer local SQLite database (3 runs per
case) confirmed correct reports for `committed` and `rolled_back` results. It
found that preview-token rejections at the framework write boundary said "run
preview again" while the description said an error without `execution_outcome`
proves nothing; agents reported this request ambiguously. The five rejection
messages now state that the request was rejected before execution and wrote
nothing, and ask to check current state and let the user decide whether to
preview again; the description adds one matching sentence. Rejection
conditions, error type and token semantics are unchanged. After a declined
preview whose data later changed, 3/3 agents still reported the preview-time
status as current, also after a trial description sentence that was then
removed for lack of effect; this stays a residual risk in DRR-2026-073.

### Read policy guidance (v3.8.1)

Server instructions and `sql_assistant` include each connection's configured
read state, scope type with table count, and UNION allowed/disabled. The text is
built once at startup from the loaded configuration through
`read_access_enabled()`; it opens no database connection and lists no table
names, hosts, users or paths. It is capped at 12 connections, with a count line
pointing to `list_connections()`. Aliases, database types and modes were
already returned by `list_connections()`; the table count adds only scope size.
Aliases are validated as `[a-z][a-z0-9_]{0,63}` and database types are a
closed set, so configuration cannot inject free text into the instructions.

This is guidance, not authorization. `query()` and Query Skills still validate
every statement against the selected connection's full read policy, so stale or
ignored instructions cannot widen access; they can only cause a rejection. The
text states that UNION allowed does not widen table scope or permit
cross-connection queries, and that it is not proof of connectivity or table
existence. The UNION rejection no longer tells the model to combine separate
results in its reply, which had led to merging truncated rows; it now recommends
one permitted query, or SQL-side aggregation with truncation, duplicate and
ordering checks. See DRR-2026-074.

### Server-state reads and table-name case (v3.8.1)

Table scope authorizes table data only. SELECT-shaped reads of server,
account and file-path state are therefore rejected by the shared read policy:
`@@` system variables, `USER`, `CURRENT_USER`, `SESSION_USER`, `SYSTEM_USER`,
`CURRENT_ROLE` and built-in SQLite PRAGMA objects in relation position, including
quoted object names. Ordinary `pragma_` columns, aliases and nonreserved business
table names remain allowed. The check walks SQL tokens so ordinary literals and
quoted business identifiers are not misread as account or variable references. It is a
denylist. Since the October 14 follow-up, GET_LOCK, RELEASE_LOCK, RELEASE_ALL_LOCKS,
SLEEP and BENCHMARK calls are refused by the shared read policy (DRR-2026-085).
The earlier allowed-function state remains in dated evidence. Other function
costs are not generally bounded; database account privileges stay the primary control.

MySQL allowlists match table names exactly because, with
`lower_case_table_names=0`, names that differ only by case are different
tables. Lowercasing both sides had authorized and listed such tables. SQLite
identifiers remain case-insensitive. On case-insensitive MySQL servers the
exact match can reject a differently cased but equivalent reference; this
fail-closed trade-off is recorded in DRR-2026-076.

### Index metadata (v3.8.1)

`describe_table()` returns index names, primary/unique flags, ordered key
columns, non-BTREE type (MySQL) and partial/expression flags. Reads happen
only after the existing read-access, identifier and allowlist checks, inside
the adapter with bound parameters (MySQL `INFORMATION_SCHEMA.STATISTICS`,
SQLite `pragma_*`). Agents still cannot run these queries through `query()`.
Comments, expression text, partial-index predicates and cardinality are not
returned; returned names are data, not instructions. The approved design collects
indexes by default within the existing authorized table scope, adding metadata
work and disclosure without a switch. Deployments that consider index names
sensitive should not allowlist those tables. Raw SHOW remains rejected.
See DRR-2026-077.


## October 3–12 read-policy, metadata and result-guidance review

Quoted PRAGMA relations are checked as object references.
Built-in PRAGMA names are conservatively reserved on all
backends; ordinary `pragma_` columns, aliases and other table names are allowed.
CTE authorization follows declaration order and explicit `WITH RECURSIVE`.
SQLite-specific forward references or implicit recursion may be rejected under
an allowlist. This is a conservative cross-dialect policy, not a complete parser.

Relation groups, single-quoted object names, ODBC relation wrappers and TABLE expressions are rejected rather than partially authorized. STRAIGHT_JOIN and comma relations after ON/USING enter the same table checks. MySQL readiness also uses the connection's exact table identity; readiness is still an observation, not an execution grant.

SQLite metadata is pinned to main. This does not sandbox trusted Python code or
remove the session-shadowing implications of arbitrary temporary objects in
ordinary SQL. Index collection has its own 128-index/2048-key-part/64-KiB budget
and cooperative query deadline; it does not bound every field of a schema reply.
Unavailable metadata is never an empty-index assertion. Index visibility is
optimizer visibility, not a promise of index use. Prefix-length units follow
MySQL SUB_PART and the underlying data type.

The later approved design accepts automatic index collection without a switch. It adds metadata work and disclosure within already-authorized table scope. MySQL first probes visibility capability; a missing column means unknown visibility, while a probe error is not silently downgraded. SQLite performs two bounded queries. Neither the byte limit nor query deadline is a whole-tool memory or hard termination guarantee (DRR-2026-077/079).

Each write description independently renders the common result rules. Validity of target, Skill, phase and required fields comes before interpreting outcome; malformed success types do not confirm a write. A missing rowcount is unreported, never filled from an estimate or another request. Legal boolean false+committed and true+unknown remain valid. Server-confirmed token rejection covers this request at the framework write boundary; imperative Skill construction, Adapter acquisition or readiness can precede validation, and trusted Python is not sandboxed.

Final independent malformed-field replays passed 3/3 for ordinary writes and 3/3 with a simulated MRTR-only description; earlier batch misstatements remain in the evidence. Descriptions now occupy 3,546/2,642 characters and duplicate the common text when both are loaded. This is behavioral guidance with explicit context cost, not a new authorization or durable completion control. After maintainer restart, the resident Host description matched source and malformed-field/missing-rowcount replays using current metadata passed 3/3 each. Native index/preview tasks passed 3/3 without executes. Complete recovery routes were correct 2/3: one omitted confirmed and was corrected later; the actual preview rejected that jump. This remains an advisory limitation (DRR-2026-071/073), not a new execution grant or native MRTR UI pass.

See the [initial review](../validation/v3.8/V3_8_1_REVIEW_2026_10_03_ZH.md) and [final evidence](../validation/v3.8/V3_8_1_REVIEW_2026_10_12_ZH.md) for reproduced CTE omissions, fixes, live database comparisons, installed-wheel checks and remaining Agent/Host limits. No existing database rows were written in this final review.

## Structured read failures and membership relations (v3.8.1, October 13)

Bare SQLite IN/NOT IN right-hand relations participate in the same scope and built-in PRAGMA checks as FROM/JOIN. Qualified references require qualified allowlist entries; unsupported targets fail closed. Literals and ordinary identifiers containing UNION/FROM are not operators. CTE declaration-order/explicit-recursion checks remain; MySQL CTE names still match exactly pending a vendor/case-setting matrix.

`PolicyDecision` owns stable refusal codes and optional recovery hints. Read adapters raise fixed-category `DatabaseQueryError`; raw queries and Query Skill SQL/policy failures return structured success=false results. Metadata exceptions retain their independent unavailable behavior; parameter/target/scope/readiness failures may remain ToolErrors. Hints do not grant access, permit switching connections or authorize writes. Database messages, extracted identifiers and SQLAlchemy parameter strings are not copied to public errors. Connection loss is distinguished from a query timeout; read categories do not establish mutation outcomes.

The unreleased project excludes hypothetical old dotenv/entry-point/SDK compatibility from this repair. Better internal designs are reported and validated against actual callers. Production SQLite authorizer integration remains deferred after an isolated prototype, and a full SQL parser/semantic guarantee is not claimed. See [implementation and evidence](../validation/v3.8/V3_8_1_FOLLOWUP_2026_10_13_ZH.md), DRR-2026-080 through 082.

October 13 supplemental verification reproduced a then-unresolved false refusal (repaired October 14 below): SQLite raw SQL recognizes F/f as one CTE, while Skill catalog inference adds f as a physical dependency. Allowlist Skills are denied, and all-mode Skills can fail readiness because f is absent. This is a functional correctness defect in DRR-2026-081, not a new grant. Separate inferred/declared dependencies and CTE/table identity semantics before relaxing it. Authorizer probes also show that changing callback state does not reauthorize an already-cached statement; a naive base-table allowlist can reject an otherwise permitted view. Production integration must define cache, concurrency and view semantics; it should not introduce extra Agent tool steps. The authorized MySQL race test wrote only a unique new fixture table, then removed it and independently verified absence; earlier no-write statements refer to the preceding Host checks.

The October 14 implementation closes that reproduced Skill boundary: declarations remain separate from target-dependent inference; discovery, table search, readiness and execution share the target's required dependencies. Full Query Skill results expose their declared/inferred origins. SQLite identity uses ASCII case mapping, and decoded quoted names and declared physical names retain significant whitespace. This prevents K/K and f/" f " from being conflated with a grant or CTE alias (DRR-2026-084).

MySQL CTE comparison is measured with constant-only duplicate-name definitions and no FROM clause. This probe cannot read a physical table. It runs only for a genuine case ambiguity after definitely unauthorized dependencies and structural refusals have been excluded; successful capability is cached per adapter and cleared on close. Unknown failures keep exact matching with a 30-second retry backoff. Thus a cold ambiguous decision can perform trusted constant I/O before the final verdict; rejected business SQL is never executed. Physical MySQL grants remain exact, qualified/self/forward references remain checked, and non-ASCII case compatibility and independent MySQL 0/2/MariaDB live matrices remain limited (DRR-2026-083).

At the earlier October 14 CTE batch, lock/delay restrictions were recommendations; the later implementation below activates them. Evidence records declare their recording profile: compressed captured originals and referenced metadata preserve collected information, while application-level results do not reconstruct every JSON-RPC frame/notification. Future model-cost records must retain all actually model-visible discovery, even for unused tools. See the dated [latest implementation and checks](../validation/v3.8/V3_8_1_FOLLOWUP_2026_10_13_ZH.md#cte-依赖与实际名称规则修复2026-10-14); the October 13 Host/model evidence is a distinct snapshot.

## October 14 matrix and function policy

Real GET_LOCK/RELEASE_LOCK/RELEASE_ALL_LOCKS/SLEEP/BENCHMARK calls are now denied in raw reads and Query Skills before capability/readiness/business I/O. Use fixed lock_function_denied/expensive_function_denied business errors; startup skips unsafe templates, and cached execution independently checks. ASCII name comparison distinguishes Unicode names; literal data, ordinary columns and CTE column declarations remain valid. Quoted/schema calls with these reserved names and EXPLAIN are restricted too. No broad function whitelist or cost guarantee, no new trusted lock operation or mutation approval change.

SQLGlot is experimental, not a runtime dependency; SQLite authorizer remains uninstalled. Native matrix exposes SQLite forward/implicit-recursion semantics still conservatively handled by production. Candidate scope/IN projection does not settle opaque commands, virtual objects, schema resolution or all dialect semantics. Other MySQL configurations/MariaDB remain untested; six required native CLI model tasks passed, with uncached input/output growth and no full-IDE or billing guarantee. See [decisions, measured costs and acceptance](../validation/v3.8/V3_8_1_PHASE123_2026_10_14_ZH.md), DRR-2026-085–087.

## Final identifier identity follow-up (October 14, 2026)

DRR-2026-084 now also covers repeated quoted whitespace and repeated quote decoding: policy normalizes token whitespace and decodes original lexical components once, preserving physical grants, CTE identity and escaped delimiters. Twenty-five new native-informed regressions and 22 installed stdio calls passed, with full regression at 1114 passed/four skips. Final primary Host acceptance passed 11/11 native checks after the maintainer restart. This does not introduce a complete semantic parser or authorizer. See [current acceptance](../validation/v3.8/V3_8_1_PHASE123_2026_10_14_ZH.md#提交前完整复核与补修2026-10-14).


## October 15 relation scope and mutation outcome repairs

DRR-2026-088–090 close the reproduced dotted-name, post-token exception and qualified-readiness code boundaries. RelationReference preserves schema/name through grants, dependency inference and scoped snapshots; diagnostic strings never grant access. Declaration strings split at the first dot while SQL names come from lexical tokens. Current-schema metadata accepts the correct qualified grant; literal dotted names cannot satisfy it. Unknown snapshot schemas are unverified, not falsely missing.

Execute-time validation errors are converted from fixed adapter-sanitized exceptions to strings. Return validation_failed/not_executed and consumed-token metadata; replay stays rejected. This is a framework outcome fix, not arbitrary trusted-Python transaction isolation. 48 new regressions, 1162 full passes/four skips, 36 outside-repository installed stdio calls and 12 configured MySQL read-only checks passed. After the maintainer restart, final resident acceptance passed 18/18 native read-only checks, with source hashes unchanged; earlier old-policy evidence remains separate. Default-only readiness, AST/authorizer deferral, no new model-cost measurement and source attribution remain explicit in [the dated acceptance](../validation/v3.8/V3_8_1_RELATION_IDENTITY_2026_10_15_ZH.md).

## October 15 internal schema binding and callback result follow-up

DRR-2026-091–093 add schema-bound sample/exact reads, table/view readiness observations and strict callback-result validation. Authorization and SQL rendering share one RelationReference; SQLite main cannot be shadowed by temp tables/views or fall back to attached schemas. MySQL metadata queries bind the configured database. Raw SQL still uses its original text and engine name resolution. MySQL temporary-object lifecycle/session reset is not solved by this change.

Readiness now observes tables and views in the configured schema, without per-table estimates, but does not authorize view sources for direct reads or prove writability/full semantics. Invalid validate returns become fixed validation_failed/not_executed results before a token is issued or an imperative execution callback runs; consumed tokens stay consumed. This is trusted-extension robustness, not a Python sandbox. 48 new regressions, 1210 full passes/four skips, 60 installed stdio and 18 real MySQL read-only calls passed; 20/20 native checks on existing configured read paths passed after the maintainer restart. See [current evidence](../validation/v3.8/V3_8_1_SCHEMA_BINDING_2026_10_15_ZH.md); earlier 18/18 native acceptance belongs to earlier source.

## October 15 literal-prefix and guide-scope correction

DRR-2026-094 repairs a functional false refusal: LIKE sqlite_% interpreted underscore as any character, hiding authorized sqliteX... tables/views. Both SQLite directories now compare the literal sqlite_ prefix; internal objects remain excluded. No read grant or raw SQL policy is widened. Current sampling guides explicitly limit temp/attached replacement prevention to SQLite main; configured MySQL database binding does not prevent same-session temporary-table shadowing. Session lifecycle/isolation remains separate. 1222 full passes/four skips and 84 installed CLI/stdio calls passed; after the maintainer restart, 16/16 configured-tool native checks passed. The special prefix fixture was checked in isolated source-matched tests, not the current aliases; native smoke is not loaded-code attestation. [Evidence](../validation/v3.8/V3_8_1_SQLITE_PREFIX_2026_10_15_ZH.md); preceding 20/20 native checks remain dated.

## October 15 complete Agent task evidence

Twelve fresh native Luna business trials completed 36 user turns with 110 observable MCP returns. Business and connection-scope checks passed for complex reads and preview/cancellation; actual writes were outside the Agent permission scope. The retained category/type confusion, extra previews, tool-discovery overhead and conservative readiness wording show why a final correct answer is insufficient evidence of an optimal or universally reliable workflow. No new production-policy change is inferred; approval, transaction, concurrency, expiry/MRTR and special-name boundaries retain their separate acceptance requirements. See [task evidence, measured usage and limitations](../validation/v3.8/V3_8_1_AGENT_REAL_TASKS_2026_10_15_ZH.md).

## October 15 ASCII reserved-name comparisons

DRR-2026-095 corrects functional false refusals: Unicode lower()/upper() confused distinct Kelvin-sign PRAGMA-like tables and long-s account-like columns with ASCII reservations. Both PRAGMA object branches and account-name comparisons now share the existing ASCII fold; parser defaults follow the same rule. Genuine ASCII PRAGMA/account names remain reserved, including when table grants would otherwise allow them. This does not widen metadata identifier syntax, authorize other relations or guarantee arbitrary functions have no side effects. Source/package checks passed; after the maintainer restart the same corrected probes and controls passed 6/6 natively. The preceding refusal remains recorded without assigning a cache root cause. [Evidence and current status](../validation/v3.8/V3_8_1_UNICODE_POLICY_2026_10_15_ZH.md). Earlier business-task usage remains prior-source evidence.

## October 15 lexical relation-boundary follow-up

DRR-2026-096 fixes an authorization omission: contextual keyword names and Unicode lookalikes could be discarded before a relation was checked. Relation positions now precede clause-boundary classification, with each component retained for authorization. SQL vocabulary comparisons use original token.value with ASCII-only conversion; normalized parser keywords may already have Unicode-folded business names. Existing file/account call reservations share quote-aware actual-call recognition, preserving strings, columns and CTE headers.

107 new regressions, 1385 full passes/four skips, 68 installed stdio and 12 real MySQL checks passed. The bounded 97-name/542-case native audit found no further unapproved scope omission. Eighteen approved unquoted forms remain conservatively rejected and have verified standard-quote recovery; this is not a full SQL semantic model. AST/authorizer, view-source expansion and connection lifecycle remain separate. After the maintainer restart, the same four native probes and positive controls passed 10/10. This verifies the observed behavior without establishing a cache root cause. Earlier 6/6 native acceptance belongs to the preceding patch. [Evidence and remaining limits](../validation/v3.8/V3_8_1_LEXICAL_BOUNDARIES_2026_10_15_ZH.md).

## October 15 CTE declaration/body exclusion follow-up

DRR-2026-097 corrects an actual-call omission: a quoted CTE column list could share an Identifier with AS/body, and masking all its leaves hid body calls. Hash-verified source reconstruction distinguishes the pre-existing lock/delay omission from the file/account regression introduced by the preceding scanner consolidation. The exclusion now stops at the declaration-level AS, using original leaves and parenthesis depth; body calls remain subject to existing reservations. This does not expand the conservative relation/readiness grammar.

132 new regressions, 1517 full passes/four skips, 80 installed CLI/stdio and 12 real MySQL checks passed. The harmless native-UDF matrix closes all 96 prior allowances; earlier shape denials are separately retained. Another 1000 valid relation-context cases and the repeated 542-case matrix show no further scope omission. No real lock/delay/file/account side effects were executed. Current native allowlist probes previously stopped at relation scope; private source/package all-scope coverage is kept distinct. After the maintainer restart, identical probes and controls passed 10/10 natively; previous 10/10 acceptance stays attributed to the preceding source. Historical refusals are retained without assigning a cache root cause. [Evidence and source attribution](../validation/v3.8/V3_8_1_CTE_HEADER_2026_10_15_ZH.md).

## October 15 ambiguous WITH diagnostics and open support gap

DRR-2026-098 records an existing availability/recovery limitation: some legal SQLite CTE names produce UNKNOWN in the conservative classifier. Unclassified WITH stays denied and now receives sql_parse_failed with read-query recovery guidance. The preceding conditional mutation hint did not authorize writes, but was unsuitable for this ambiguous read recovery. Known writes keep their original rejection/approval contract; a WITH prefix never proves read safety.

43 new regressions, 1560 full passes/four skips, 76 installed stdio and 12 current-source MySQL checks passed. Forty-seven cases show no change to acceptance. Bare-name support remains open for shared analysis/AST; no table/function grant or grammar scope is widened. After the maintainer restart, eight identical inputs and two controls match the diagnostic change, 10/10; preceding native/model evidence remains separate. A further bounded assessment confirms common business-name, quoted declaration-column-list/readiness and specific comment/declaration false refusals: 314 candidates/304 native-valid reads, 56 private Client observations and nine native impact observations, retaining observed tool errors. All four private unauthorized-table controls stay denied; this is not complete parser coverage or a measured workload failure rate. Recommend shared CTE analysis as a near-term functional repair without requiring complete production AST/authorizer integration. This assessment changes no production code. [Assessment, source comparison and known limits](../validation/v3.8/V3_8_1_CTE_CLASSIFICATION_2026_10_15_ZH.md).

## October 15 shared CTE analysis implementation

DRR-2026-099 implements the maintainer-authorized repair following the preceding assessment. Original-leaf WITH structure now serves statement classification and scoped relation/dependency analysis; shared relation-target selection distinguishes contextual names from DML commands. Declaration exclusions contain only name/column leaves, never entire query bodies or function arguments. Quoted column lists no longer invent physical readiness dependencies. Optional WHERE grouping cannot discard a Unicode IN operand. Exact schema/name, original quoting, target case rules, declaration order and explicit-recursion boundaries remain authoritative.

The 300 native-valid functional cases pass both scopes, while all four unauthorized-table controls stay denied. Adjacent checks include 542 physical-name cases and 1000 relation-context cases with no observed scope misses/approved refusals, plus 576 harmless reserved-call fixtures denied by their function checks. These are bounded results, not complete dialect semantics or general SQL execution safety. The classifier still refuses actual main/body writes; all-mode does not bypass system-state/function/shape rules. No complete production AST/authorizer or cross-request policy-result cache is added.

1750 full passes/four skips, clean type/prompt, 56 matching-input Client checks, 96 installed stdio checks and 24 real MySQL checks passed. MySQL native syntax failures stay typed database errors instead of inheriting SQLite validity claims. Pure-policy p95 A/B/A is 13.12/17.71/16.15 ms; additional analysis has a cost and baseline drift limits attribution. No model-cost or unchanged-latency claim. After the maintainer restart, 20/20 native checks pass for this source, with matching text/structured results: ten exact baseline inputs and ten adjacent/refusal/MySQL/ordinary-Skill controls. Write-shaped and unapproved-relation controls remain refused; no configured write occurred. Preserve the old refusal checkpoint and prior native/model evidence. Complete CTE Skill readiness remains private Client/installed evidence, not a new configured native Skill test. [Repair, evidence and remaining scope](../validation/v3.8/V3_8_1_CTE_ANALYSIS_2026_10_15_ZH.md).

## October 20 managed-plan parser observation (DRR-119)

Managed write classification defaults to SQLGlot with explicit dialect/session context, independently from read authorization. The startup candidate check is not an execution authorization: target availability/preview and consumed confirmation recheck actual semantics, with the existing per-physical-MySQL-session initialization contract enforced on execution. Original SQL/parameters and exact named-bind checks remain; nested writes, bare REPLACE and unsupported directive comments refuse on the new path. Parse success is not native syntax, catalog or side-effect proof.

The owner explicitly retains `[skills.mutation] managed_plan_parser="sqlparse"` and its dependency for a temporary observation window. It is a deliberate restart-scoped rollback, never an automatic fallback; it preserves old dialect-neutral classification limits rather than claiming equivalent syntax/comment safeguards. Approval, grants, token consumption, transaction evidence and the always-enabled SQLite read authorizer do not depend on this selector. A target-context failure before the adapter write returns not_executed; missing evidence after an actual write remains unknown. Trusted Python/import/preview effects stay outside this classifier. After the owner restart, 16 current-Host calls satisfy the scoped contracts, including two unconfirmed previews and four expected refusals; two SQLite file hashes/full-order digest remain unchanged. Preserve one corrected catalog-search expectation. Preview handles are redacted and naturally expire; no public revocation or observed expiry is claimed. Special confirmation/rollback combinations remain isolated source/package coverage. [Differences, costs, removal criteria and acceptance](../validation/v3.8/V3_8_2_MANAGED_PARSER_2026_10_20_ZH.md).

## October 20 classification reuse boundary (DRR-120)

Readiness guards use dependency/schema checks without invoking full execution policy. Discovery/detail retain all availability gates. Each GatewayRuntime owns a 128-entry LRU over exact SQL, complete immutable DialectContext and selected parser; values are frozen PolicyDecision instances, including deterministic classification refusals. No AST, authorization, token, database state or connection-resolution result is cached. A parse failure converted to a fixed pure denial may be reused; exceptions that escape classification are not retained.

Target context is still resolved for each applicable check, including after token consumption and before a managed write. Independent grants, profiles, parameters, readiness, approval, physical-session initialization and commit evidence remain live. Cached classification cannot authorize a request. Runtime close clears entries even on registry cleanup failure; concurrent misses may duplicate pure work. Capacity bounds entries, not SQL byte size; trusted Skill templates remain the input boundary. This adds no public switch or dependency. Hint/HIGH_NOT_PRECEDENCE support was deferred at DRR-120; later support is recorded below. The temporary explicit sqlparse rollback remains. [Tests, costs and resident status](../validation/v3.8/V3_8_2_MANAGED_CLASSIFICATION_REUSE_2026_10_20_ZH.md).

DRR-120 scoped acceptance now includes 22/22 current-Host calls after the owner restart: repeated availability/detail, three unconfirmed previews and six expected refusals. Original SQL/binds and same-target recovery remain; two SQLite files and the full 80-order digest are unchanged. No configured write, new model trial, resident cache-hit attestation or in-memory source-hash claim is made. Keep the parent source/package checkpoint and its pending label immutable; [separate resident evidence](../validation/v3.8/v382_managed_classification_reuse_2026_10_20/resident_restart/README.md).

## October 20 dialect comments and NOT support (DRR-121/122/123)

Comment semantics follow the actual target. SQLite ignores standard block/dash comments, including hint/directive-shaped text. MySQL checks all original trivia and hint spans before accepting only known plan-hint names with flat name arguments; executable/MariaDB comments, SET_VAR, RESOURCE_GROUP, MAX_EXECUTION_TIME, unknown/incomplete bodies and nested expressions remain unsupported. Literals/quoted names are never scanned as comments. Validated hint tokens are omitted from analysis only, preserving all actual SQL token offsets and executing original SQL/binds; hints grant no relation access and cannot hide real restricted functions.

HIGH_NOT_PRECEDENCE is now interpreted by the existing unary dispatch: ! always binds tightly, prefix NOT follows actual session mode, and infix NOT forms remain separate. No new parser method override, package dependency, public toggle or Agent step. The dispatch table/private parser-method dependency is pinned and requires upgrade tests; native parsing/constraints and trusted schema/UDF limits remain. Startup candidates increase from 9 to 17; cached decisions remain keyed by full actual context, with independent admission and post-token target verification. Explicit sqlparse rollback retains its old classifier, including its weaker comment checks; no automatic fallback or newly equivalent safeguards are claimed.

Keep historical refusals, matrix/test-fixture corrections, source/package costs and owner-restart evidence separately attributed. [Scope and current validation](../validation/v3.8/V3_8_2_DIALECT_COMMENTS_NOT_2026_10_20_ZH.md).

DRR-121/122/123 scoped resident acceptance passes 30/30 after the owner restart: 12 successful reads, four discovery/detail calls, three unconfirmed previews, ten expected refusals and one routing catalog. Independent SQLite and MySQL order truth remains unchanged; no configured write, new model trial, all-mode native or resident source-hash claim. [Separate evidence](../validation/v3.8/v382_dialect_comments_not_2026_10_20/resident_restart/README.md) preserves the parent pending checkpoint.
October 20 relation-call/column follow-up: SQLite relation heads retain original
semantic name components instead of scalar aliases or arity. Arguments retain
independent function/relation checks. JSON spellings bind to the actual catalog
object before FTS module abilities are established; ordinary or unauthorized
same-name objects receive no builtin abilities. Skill conditional dependencies
use fresh schema snapshots; only immutable analysis is cached. table_xinfo
metadata includes visible generated columns without evaluating expressions;
hidden columns and existing trusted-schema/UDF execution limits stay explicit.
[Contract and current acceptance](../validation/v3.8/V3_8_2_RELATION_CALLS_COLUMNS_2026_10_20_ZH.md).


Latest complete-task acceptance distinguishes execution safety from interpretation quality: fifteen paired Luna business tasks pass and65 successful SQL results match native replay, but three natural-cancel probes include an unsupported current-state claim and ambiguous cancellation language. All previews remain unconfirmed and no write or post-cancel MCP call occurs. Correct database boundaries do not guarantee a model will accurately explain an old observation; no result-guidance causal efficacy is claimed. Keep the [actual failures, costs and limits](../validation/v3.8/V3_8_2_COMPLETE_AGENT_EVAL_2026_10_21_ZH.md) separate from latest native12/12 PRIMARY closure.

October22 follow-up DRR-144/145: MySQL now checks exact original-SQL binding as SQLite already did; old consistent MCP callers were not a reproduced bypass. Source/package real InnoDB gates verify business/trigger/cascade truth, actual errors and own-session loss, separately labelled client faults, unknown before/after commit, one attempt and consumed-token rejection. Test-only observers exclude non-rollback AUTO_INCREMENT allocation, with no production full-database comparison. [Confirmed contracts and source/package evidence](../validation/v3.8/V3_8_2_MYSQL_WRITE_CONTRACTS_2026_10_22_ZH.md) retain their original pending checkpoint. After the owner restart, [six limited native checks pass](../validation/v3.8/v382_mysql_write_contracts_2026_10_22/resident_restart/README.md); they do not expose the internal mismatch argument or add confirmed-write proof. The [bounded stabilization plan](../validation/v3.8/V3_8_2_STABILIZATION_PLAN_2026_10_22_ZH.md) records16 contract families, remaining execution order and stop conditions. The subsequent [finite16-family acceptance](../validation/v3.8/V3_8_2_STABILIZATION_2026_10_22_ZH.md) completes those scoped gates with independent current source/package checks, reused real-write truth and target-detecting sentinels. No broader engine/fault-profile or defect-free guarantee.

October22 engineering follow-up: [portable contracts and dependency-aware release acceptance](../validation/v3.8/V3_8_2_PORTABLE_RELEASE_GATES_2026_10_22_ZH.md) add ordinary target-detecting pytest cases, explicit unverified live status, actual JUnit/matrix/cleanup checks and runtime/dependency identity. This changes validation infrastructure only; it adds no production enforcement or Agent call and never automatically reuses prior results.
