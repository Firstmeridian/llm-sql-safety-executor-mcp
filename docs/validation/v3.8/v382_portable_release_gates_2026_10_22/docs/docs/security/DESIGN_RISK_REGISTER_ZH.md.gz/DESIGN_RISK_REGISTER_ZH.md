> 2026-10-21范围决议：MySQL方言／服务端以MySQL为验收基准，MariaDB不作验收要求，旧条目中的可选MariaDB后续不阻塞本轮；SQLite原生验证保持。DRR-141源码／安装及最新原生12/12通过；此前原生7/12、新CLI12/12差异及未确认根因保留。见[实际检查点](../validation/v3.8/v382_primary_key_metadata_repair_2026_10_21/resident_restart/README.md)。

> 2026-10-17：DRR-2026-107、108 补齐视图数据读取入口与 SQLite 非执行型 EXPLAIN；旧完成结论保留当时范围，[本批证据与重启状态](../validation/v3.8/V3_8_2_READ_BOUNDARIES_2026_10_17_ZH.md)。

> 10 月 15 日：DRR-2026-088–090 记录结构化关系、令牌消费后的安全失败与默认 schema readiness；见[当前源码与已完成的原生验收](../validation/v3.8/V3_8_1_RELATION_IDENTITY_2026_10_15_ZH.md)。

> 最新前三阶段：DRR-2026-085–087 记录函数限制、试验与成本边界；见[验收](../validation/v3.8/V3_8_1_PHASE123_2026_10_14_ZH.md)。

> **10 月 14 日更新：** DRR-2026-080–084 记录读取整改、依赖修复、CTE 能力与身份语义；新源码本地验收与原生重启状态见[验收记录](../validation/v3.8/V3_8_1_FOLLOWUP_2026_10_13_ZH.md)。版本仍为 3.8.1。

> **v3.8 更新（2026-09-26）：** 当前边界见 [安全说明](V3_8_SECURITY.md)。下方历史条目保留原版本语境。
> 已移除旧 `.env` 配置加载和 default-only 隐式写入授权；用户现有私有 `.env` 文件保留。
> 新增接受的限制：可信 Host 审批（不独立认证人类）、仅托管写入且默认关闭的 MRTR、重启失效的进程内提案、无持久完成记录、按条数限制的审阅内存。
> Python Skill 仍是受信任代码，审计仍为 best-effort；未知写入结果不得自动重试。
> FastMCP 密封续接状态，精确提案绑定和原子令牌消费仍由服务端验证。
> 真实 Host 按实际版本和协议记录兼容性，不能以参考 Client 通过代替。
> DRR-2026-056 在 v3.8 中通过删除仅部分校验的 `execute_sql()` 入口解决；直接查询集成使用共享完整策略服务。见 [迁移指南](../guides/CONFIGURATION_ZH.md) 和 [验收记录](../validation/v3.8/V3_8_VALIDATION_ZH.md)。

> **评审补充（2026-09-27）：** 已修复 profile 规范化、无表 Query Skill 可用性、MRTR 遥测归属及参考 Host 的期限/审阅内容检查；配置语义错误保留安全原因码。见[问题与验证](../validation/v3.8/V3_8_REVIEW_FIXES_2026_09_27_ZH.md)。
> 接受的限制继续明示：部署授权不是经认证的每请求任务 grant（D01）；目录/readiness 分层（D04）及完整跨轮追踪（D07）暂缓。遥测身份未知时为 null；SDK 在中间件前拒绝可能不留事件。共享 Host 保护不隔离恶意 Python。保留原 CI 失败，本地通过不代表远端运行或原生 MRTR UI 通过。

> **复评补充（2026-09-28）：** `139d53a` 已通过远端 CI，上一轮问题关闭。Query Skill 发现现按目标连接的完整静态执行策略预检缓存 SQL，补齐新增 UNION 不一致。代价是解析开销，不引入策略结果缓存，也不代替执行检查。动态 readiness 和原生 MRTR UI 保留既有边界，见[证据](../validation/v3.8/V3_8_REREVIEW_2026_09_28_ZH.md)。

> **验收补充（2026-10-01）：** 原生批准/拒绝/取消及长等待框架拒绝已有证据，真实进程重启另有协议覆盖。当前 Codex IDE 已有重启后多行排版截图及关闭按钮取消无写入的证据；原生业务 TTL/重启 UI、其他 Host 仍待验收。排版完整保留快照值，展示空白不计入保存快照的大小上限。见[当前验收矩阵](../validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md)。

> **v3.8.1（2026-10-01）：** DRR-2026-071 增加仅作线索的拒绝恢复提示；DRR-2026-072 接受 Agent 对令牌到期的偏保守误判，不恢复相对期限字段；DRR-2026-073 在工具说明中加入结果解读规则，并接受其残余误述（后经真实工具通道复测，并澄清了预览令牌拒绝文本）；DRR-2026-074 在服务说明中加入按连接的读取策略指导；DRR-2026-075 拒绝以 SELECT 读取服务器、账号与文件路径状态；DRR-2026-076 使 MySQL 白名单按表名大小写精确匹配；DRR-2026-077 以 `describe_table()` 结构化索引取代原始 SHOW。见[v3.8.1 条目](#v381-拒绝恢复与令牌到期报告2026-10-01)。

> **复核收尾（2026-10-12）：** DRR-2026-073 记录独立写入描述与有效性前提，075/076 补对象位置／readiness 身份，连续新增 078/079 记录 CTE／关系范围和元数据属性／资源。源码、安装包及真实数据库检查通过，维护者重启后的常驻 Host 刷新核验完成，恢复路线初始误述另记 071。见[证据](../validation/v3.8/V3_8_1_REVIEW_2026_10_12_ZH.md)。

# 设计风险登记表

[English](DESIGN_RISK_REGISTER.md) | 中文

创建日期：2026-05-24
最近评审：2026-10-21（附加名称有序补修及独立元数据名称评估；历史条目保留原评审日期）

文档状态：长期维护的设计与运维风险登记表。  
初始评审批次：v3.4.3。

本文档记录本 MCP SQL 安全网关中的设计风险、取舍、拒绝方案和后续决策。它不是单一版本文档：历史 ID 会保留以便追踪，未来条目可以继续使用版本前缀，也可以使用 `DRR-YYYY-NNN` 格式。

## 范围

以下主题适合进入本登记表：工具行为、模型可见界面、数据库负载、安全声明、日志、缓存、遥测、资源、Schema、运维可靠性等相关风险和设计取舍。

本文档不能替代测试、发布日志或漏洞公告。任何条目如果改变运行时行为，都应补充测试，并在“当前结果”字段记录对应测试文件。

## 状态说明

| 状态 | 含义 |
|---|---|
| 待修复 | 已观察到问题；修复或行为/部署验收仍有未完成项。 |
| 已实现 | 代码或文档修改已完成并记录。 |
| 已接受 | 当前行为是有意识的取舍，暂不计划修改。 |
| 需要策略决策 | 修改前需要先决定兼容性、隐私或审计策略。 |
| 运维决策 | 当前更适合通过部署/运维说明处理，而不是加入服务器逻辑。 |
| 暂缓 | 方向有效，但当前版本没有足够需求或设计清晰度。 |
| 不计划 | 在当前架构下明确不做，除非需求发生变化。 |

## 风险等级说明

| 风险等级 | 含义 |
|---|---|
| 高 | 安全边界、敏感日志/审计、live database 或写入路径风险，可能影响生产安全、隐私或合规。 |
| 中 | 可靠性、运维、治理、可维护性或误导性声明风险，影响明确但范围相对可控。 |
| 低 | 兼容性、命名、文档精度或低影响清理风险，对运行时和安全边界影响有限。 |

`首次登记日期` 记录该行首次进入本登记表或对应评审批次的最早已知日期。

## 评审节奏

- 每个小版本发布前、任何工具界面变化后，复查未关闭条目。
- 涉及日志、缓存、遥测、原始 SQL、模型可见资源的条目，在安全评审后重新检查。
- 只要登记表发生实质修改，就更新“最近评审”。

## 外部最佳实践锚点

| 来源 | 本文档采用的相关指导 |
|---|---|
| [FastMCP Tools 文档](https://gofastmcp.com/servers/tools) | `ToolResult.meta` 是运行期元数据；`output_schema` 必须匹配结构化输出；tool annotations 是提示而非安全边界；清晰的 schema 和描述有助于客户端选择工具。 |
| [FastMCP Middleware 文档](https://gofastmcp.com/servers/middleware) | Middleware 可通过 `on_call_tool` 记录或转换工具调用；响应限制可能破坏结构化输出一致性；缓存 key 默认不包含用户/session 身份，除非显式设计。 |
| [Model Context Protocol 文档](https://modelcontextprotocol.io/docs) / [Claude Code MCP 文档](https://docs.anthropic.com/en/docs/claude-code/mcp) | MCP 工具输出可能挤占上下文；resources 和 tools 都是模型可见界面；更小、更清晰的界面能降低上下文和工具选择风险。 |
| [Python importlib 文档](https://docs.python.org/3/library/importlib.html) / [abc 文档](https://docs.python.org/3/library/abc.html) | `exec_module()` 会在动态导入时执行模块代码；ABC 与 `issubclass()` 适合作为 mutation plugin 具体子类契约的结构性检查。 |
| [Google Gemini Function Calling 文档](https://ai.google.dev/gemini-api/docs/function-calling) | 使用清晰的函数/参数描述、强类型/枚举、相关且有限的工具集、稳健错误处理，并避免通过函数调用暴露敏感数据。 |
| [Microsoft Azure OpenAI Structured Outputs 文档](https://learn.microsoft.com/en-us/azure/ai-services/openai/how-to/structured-outputs) | 严格 schema 很有用但受约束；任意 SQL 行结构不适合强行声明严格输出 schema。 |
| [OWASP Logging Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html) | 不应直接记录 secret、access token、密码、连接串或敏感个人数据；日志需要访问控制、保留/轮转策略和磁盘耗尽防护。 |
| [OWASP SQL Injection Prevention](https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html) | 应用校验需要配合参数绑定和最小权限数据库账号；table/view/object grant 仍是权威边界。 |
| [MySQL stored program restrictions](https://dev.mysql.com/doc/refman/8.4/en/stored-program-restrictions.html) / [locking functions](https://dev.mysql.com/doc/refman/8.4/en/locking-functions.html) | SELECT 形状的 stored-function 与 named-lock 调用可能产生外层 statement type 看不出的效果；语法过滤不能替代账号权限。 |

## 当前快照

项目当前没有实现通用 SQL 分页工具或 cursor-token 机制，也没有实现进程内遥测百分位聚合、模型可见 stats 工具/资源、session schema cache 或 `db://schema` resource。

v3.4.3 的运行时修复已让 SQLite 行数估算保持有界：当没有 `sqlite_stat1` 且 10,000 行采样达到上限时，`SQLiteAdapter.get_row_estimate()` 返回该上限作为下界估算，而不是继续执行完整 `COUNT(*)`。精确计数仍需通过用户 SQL 或 `get_table_summary(exact_count=True)` 显式触发。

V343-006 至 V343-008 已在 2026-05-26 再次评审。当前策略是文档声明和部署约束，而不是新增运行时控制：原始 SQL echo 为了兼容性和排障透明度继续保留；Skill audit params 被视为业务审计数据而不是 secret 存储；JSONL 轮转/保留交由部署环境处理。

2026-05-26 的实现层过度设计复审没有发现已落地的通用分页、stats tool/resource、session schema cache、`db://schema` resource、raw SQL echo 开关、audit 脱敏策略引擎或进程内日志管理器。主要实现清理候选是启动期生成面向人工审阅的 `skills/SKILLS.md`；其它低优先级清理候选记录在下表。以下条目目前只记录风险和后续决策点，尚未修改运行时代码。

随后对非 AutoGen 模块的复审发现，导入期副作用、导入期配置冻结、adapter metadata 标识符处理，以及 manual smoke 脚本被普通 pytest 收集，是更值得持续跟踪的维护/安全边界风险。这些先作为设计风险记录；除非有明确清理计划，不应贸然引入大 settings object 或大规模测试目录重排。

后续安全边界复审又发现 MCP 扩展 SQL 检查和本地错误日志中存在窄范围 hardening gap。以下条目仅记录风险；当前改动不修改运行时行为。

2026-05-27 又做了一次只读、怀疑式复核：重新运行直接安全判断探针，但没有把危险 SQL 发往 live database 执行。复核确认 DRR-2026-011、DRR-2026-012 和 DRR-2026-015 基本准确；将 DRR-2026-013 收窄为方言/检查范围声明过宽，而不是已经证实的 MySQL/SQLite 写入路径；并补充下方 workflow/SQLAlchemy hygiene 方面遗漏的风险。

随后在 2026-05-27 继续只读复查了 Skills loader/audit 层、配置/启动界面、adapter 写入语义和默认测试收集边界。结果显示，部分此前风险被低估：本地 Skills 代码和元数据仍需要自己的边界校验；query skills 尚未共享自由 `query(sql)` 工具的扩展 SQL 检查；默认 pytest 可通过根目录 smoke test 触达 live database；依赖安装不可复现；MySQL mutation timeout 文档/注释当前依赖的是偏 SELECT 的机制，缺少写入路径证明。

2026-05-28 的聚焦加固批次先实现最高优先级 SQL policy 和日志卫生修复，尚未启动多数据库实现。自由查询与 query skills 已共享同一读查询策略；MySQL 文件操作和 quoted/comment-separated 系统元数据绕过形式被拒绝；Skills 目录 containment 改用路径边界判断；adapter 日志和 SQLAlchemy engine 配置避免暴露 SQL 参数值。

同一 2026-05-28 加固批次也关闭了 DRR-2026-008 和 DRR-2026-014 记录的 adapter metadata 标识符边界。Adapter metadata 方法现在只接受简单未限定表名；能作为数据值处理的 table-name 谓词使用参数绑定；SQLite 中必须作为 identifier 的位置会先校验再引用。

随后在 2026-05-28，DRR-2026-023 也通过明确默认 pytest 契约关闭：`pytest.ini` 将默认收集范围限定为 `tests/`；根目录 MCP smoke 脚本继续作为 manual/live 检查，通过脚本入口在安全的开发库或 fixture 库上显式运行。

2026-05-29，DRR-2026-020 通过收紧轻量 Skills 参数 schema 关闭，而不是替换成完整 JSON Schema。未知参数类型现在会在 discovery 和 validation 阶段 fail closed；bool 参数只接受 JSON boolean 以及显式 `true`/`false` 字符串字面量。

同样在 2026-05-29，一次多数据库就绪度复核认为，之前“先修再做设计”的前置计划已经足够支撑设计阶段：DRR-2026-011、DRR-2026-012、DRR-2026-015、DRR-2026-017、DRR-2026-018、DRR-2026-019、DRR-2026-023、DRR-2026-025 已实现，adapter 边界相关的 DRR-2026-008 与 DRR-2026-014 也已落地。DRR-2026-024 仍保持暂缓，但不视为阻断项，因为当前观察到的冲突面位于 optional AutoGen 示例依赖，而不是核心 server runtime。由此，多数据库工作可以进入 design-only 阶段，但还不适合直接在当前 process-global adapter 与 `DB_TYPE` 地基上进入运行时实现。

2026-05-30，v3.5 已实现第一段运行时多数据库能力：配置化命名连接、connection-aware 只读核心工具、connection-scoped 查询 Skills，以及安全的 `connection_id` 元数据/审计/遥测。实现有意把 mutation Skills 保持为仅默认连接。先解析连接的不变量现在成为运行时设计的一部分：工具必须先解析 `ConnectionContext`，再做 SQL policy、schema readiness、内部辅助 SQL、执行、metadata、audit 和 telemetry。未知连接 id fail closed，不会回退到默认连接。

同日结合官方文档和最佳实践做的 follow-up review 又关闭了几个边界缺口：table allowlist 现在会规范化 quoted 与 schema-qualified identifiers；公开 SQLite payload 使用 `sqlite:<connection_id>` 而不是文件路径；legacy 模式只有在显式设置 `DB_CONNECTIONS` 后才会启用 `DB_<ID>_*` 与 `DEFAULT_DB_CONNECTION`；独立兼容 helper `execute_sql()` 也会先解析目标连接，再做 SQL policy。

同一次复核也收窄了 v3.6 mutation 多连接设计方向：写操作应采用一致的高影响操作协议。目前 preview-token core 和严格 per-connection mutation policy 均已实现。只读 policy 与写授权保持分离；未设置新的全局 mutation 目标 allowlist 时，仍保持仅默认连接路由。

2026-08-04，对合并后的 v3.5/v3.6 改动集做了一次提交前复审：运行默认测试套件（259 passed、3 skipped），在不执行破坏性 SQL 的前提下重新探测 SQL policy，并对照 FastMCP 3.0.2 与 MCP 2025-06-18 tools 规范核对实现。复审确认了已实现的边界，同时新增下表十条记录。其中当时影响最大的三条是：真实 mutation 联调在被跟踪的示例数据库中留下的数据漂移（DRR-2026-035）、server 级 `instructions` 仍宣称只读但 mutation 工具可写（DRR-2026-036），以及默认 pytest 环境隔离不完整、部分重新打开 DRR-2026-023（DRR-2026-039）。复审同时确认没有运行时行为与已实现的 v3.5/v3.6 条目矛盾，文档漂移仅限于 DRR-2026-042 记录的 v3.5 时期遗留措辞。

2026-08-06，v3.6.1 维护更新关闭了 DRR-2026-037、DRR-2026-038 与
DRR-2026-041，并扩展了 DRR-2026-034 记录的 replay 防护。该版本仍属于
v3.6 release family。

2026-08-08 的范围评审以有界进程内 memory store 和 stdio-first 部署关闭了
DRR-2026-045。条件性 HTTP mutation 仅限受信任私有边界中的单进程；多用户认证
HTTP 和跨主机副本不是 v3.6.1 基线。只读容量只能通过独立 endpoint/profile/pool
扩展。

2026-08-10 的 follow-up 关闭了 DRR-2026-036、DRR-2026-040 与 DRR-2026-042，
记录 DRR-2026-043 的已接受不对称默认值，将 preview TTL 限制为最多 86400 秒，
收紧 preview 失败契约，并用完整工具层并发 replay 回归替换重复的 store 并发测试。

2026-08-20 的 v3.7 对抗复核发现，只读 statement shape 不足以实施 table scope：
comma join、comment-separated keyword、qualified name、过宽 SHOW 与多 statement
都可能绕过或误导 regex 时代的 extractor。因此 v3.7 选择收窄可接受 raw grammar，
而不是引入一个声称完整的跨方言 AST policy。同一轮复核还补齐了严格 Skill
metadata value 校验，并增加明确仅供测试的跨数据库 reset mutation。数据库
最小权限和 schema 强制的订单 id 唯一性仍是权威边界，因为 SELECT 形状的
stored function 与
locking function 可能产生 outer-statement checker 无法证明不存在的副作用。

### DRR-2026-050 审批信任边界补充（2026-10-01）

**状态：已接受；风险：中，限可信本地 Host 模式 A。** 本项沿用已有 ID，不重复建号；下方 v3.7 历史条目保留当时的方案和取舍。

- 原有 preview/execute 不主动请求协议审批窗口。服务端校验 `confirm=true`、匹配的一次性令牌、授权及执行策略，不能证明客户端问过真人。能调用 preview 与 execute 的 Agent 可以自行取得并回传令牌。专用参考 Host 可用代码强制收集用户决定、检查期限，但其他获准客户端不必使用该 Host。
- MRTR 将输入请求和批准响应纳入协议；该路径执行必须有有效密封续接、`accept` 和严格布尔 `approve=true`。这验证的是响应与提案绑定，不是独立的人类身份认证；自动化或被攻陷的 Host 仍能提交同样的响应。
- MRTR 开关仅增减该工具；Skills/写入配置允许时，旧 `execute_mutation_skill` 仍可用。启用 MRTR 不等于全局强制人工窗口，关闭 MRTR 也不等于禁写。客户端的一般工具调用许可同样不是服务端可验证的精确 SQL 审阅证据。
- 当前决策：继续默认 preview/execute，MRTR 由已验证的 Host 显式选用，保留两条流程及目标/参数绑定、期限、单次消费保护。依据限于所测 Codex/Copilot 路径的支持不一致，不概括全部客户端；两条流程均不保证获准客户端无法自行批准。只有到期时间为 20:44:01 UTC 的独立场次仅完成 preview；Copilot 另一场次实际提交了一次变更和三次恢复，且用户报告未看到审阅窗口，批准选项记录不能证明可见审阅通过。本次澄清没有增加新的安全控制。
- 若以后要求认证批准人、职责分离或抵抗不可信 Agent，应重新评审：由 Agent 无法自行取得凭据的独立批准方签发精确绑定提案的授权，并在**所有写入入口**验证，或由不可绕过的可信网关把守。仅提示 Agent、启用 MRTR 或从模型目录隐藏工具均不满足此要求。该设计尚未实现。详见[流程对比](V3_8_SECURITY.md#where-approval-is-enforced)及[实测记录](../validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md)。

## 登记表

| ID | 状态 | 风险等级 | 首次登记日期 | 领域 | 风险或关注点 | 是否计划修改 | 修改逻辑 | 当前结果 | 下一步 |
|---|---|---|---|---|---|---|---|---|---|
| V343-001 | 已实现 | 中 | 2026-05-24 | SQLite 行数估算 | 元数据发现此前会从 10,000 行采样升级为大表完整 `COUNT(*)`。 | 是 | 优先使用 `sqlite_stat1`；采样达到上限时返回下界估算；精确计数保持显式触发。 | 2026-05-24 已完成：修改 `db_adapter.py`，在 `tests/test_db_adapter.py` 增加测试，并更新文档。 | 观察用户是否误解下界估算；需要精确值时建议运行 `ANALYZE` 或显式计数。 |
| V343-002 | 已实现 | 中 | 2026-05-24 | 查询结果截断 | `query()` 和 `execute_query_skill()` 在截断返回 payload 前仍会获取完整 adapter 结果。 | v3.4.3 仅改文档 | 澄清截断只限制返回 payload；用户应使用 `WHERE`/`LIMIT`/`ORDER BY` 限制数据库工作量并稳定顺序。 | 工具消息和文档已更新；adapter 级流式/分批获取仍暂缓。 | 只有在兼容性测试充分时再评估 `fetchmany()` 或 streaming。 |
| V343-003 | 已实现 | 低 | 2026-05-24 | 工具描述 | `list_tables()` 和 `get_full_schema()` 的 all/complete 表述会忽略 allowlist 和截断。 | 是 | 改为 visible/truncated 语义，并澄清 returned/visible counts。 | 面向工具和文档的描述已更新。 | 后续新增工具描述继续保持精确和保守。 |
| V343-004 | 已实现 | 中 | 2026-05-24 | 安全文档措辞 | 部分文档过度声明 comprehensive SQL analysis 或所有调用都经 `validate_name()`/`validate_params()`。 | 是 | 将 sqlparse 描述为语句类型 allowlist 加 MCP 层扩展检查；区分 Skills 参数校验和基础 SQL/table 校验。 | README 和设计文档已更新。 | 不在缺少对应 enforcement 的情况下扩展安全声明。 |
| V343-005 | 已实现 | 低 | 2026-05-24 | Prompt 指南 | `get_table_summary()` 曾被当成默认规划步骤，但该工具默认禁用，精确计数也是显式 opt-in。 | 是 | 默认优先 `describe_table()` 估算；只有需要精确计数时才使用显式 `COUNT(*)` 或 `get_table_summary(exact_count=True)`。 | Prompt guide 已更新；无需运行时测试。 | Prompt 示例要和默认启用工具保持一致。 |
| V343-006 | 已接受 | 高 | 2026-05-26 | 原始 SQL echo/log 可见性 | `query(sql)` 会把完整 SQL 记录到上下文并返回在结构化 payload 中；SQL literal 可能包含敏感值。 | 仅文档声明 | 为兼容性和排障透明度保留当前 echo 行为。不要在原始 SQL literal 中放 secret、token 或敏感个人数据；重复且敏感的工作流优先用低敏谓词、视图或经过 review 的 Skill。 | 2026-05-26 已在 README 和本登记表中声明；不新增运行时开关，避免过早造成兼容性 churn。 | 只有隐私敏感部署明确需要时，再评估 echo/log opt-out 开关。 |
| V343-007 | 已接受 | 高 | 2026-05-26 | Skills audit 参数日志 | Audit 仅截断长参数，不按 key/value 脱敏。 | 仅文档声明 | 将 skill params 视为业务审计数据，而不是 secret 存储。`SKILLS_AUDIT_QUERIES=0` 继续作为默认；mutation audit 为了可追踪性保持自动尝试记录，完整性边界见 DRR-2026-022。 | 2026-05-26 已在 README、`skills/SAFETY.md`、`.env.example` 和本登记表中声明；不新增运行时脱敏层。 | 如果未来 Skill 确实需要敏感参数，再评估 key-based redaction 或 per-skill redaction metadata。 |
| V343-008 | 运维决策 | 中 | 2026-05-26 | Append-only JSONL 日志 | Audit、telemetry 和 server logs 是本地文件，没有内置轮转或保留策略。 | 文档/部署指导 | 优先使用外部日志轮转、保留、访问控制和磁盘监控，而不是进程内日志管理。Audit/telemetry 每次写入都会重新打开文件，适合 rename/create 式外部轮转。 | 2026-05-26 已在 README、`skills/SAFETY.md`、`.env.example` 和本登记表中声明。 | 生产环境使用 `logrotate`、平台日志、cron cleanup 或托管日志 sink；只有受限单文件部署明确需要时再改代码。 |
| V343-009 | 已接受 | 低 | 2026-05-24 | `ToolResult.meta` 可见性 | `_meta` 包含运行期统计，某些客户端可能展示。 | 不改行为 | 保持 metadata 非敏感；不加入 SQL、params、rows、凭据或用户身份。 | 接受当前取舍。 | 新增 meta 字段时重新审查。 |
| V343-010 | 暂缓 | 低 | 2026-05-24 | 基础工具 output schema | 任意 SQL 行结构不适合统一声明严格 schema，容易误导。 | 不做 blanket 修改 | 只给稳定 envelope 的工具考虑 schema。 | 有意暂缓。 | 如有需要，逐个稳定工具评估。 |
| V343-011 | 不计划 | 低 | 2026-05-24 | 通用 SQL 分页参数 | 对任意 SQL 添加 `limit`、`offset`、`page` 或 cursor token 会重复 SQL 语义，且无稳定排序时结果不可靠。 | 否 | 分页留给用户 SQL；如需封装，使用有明确排序键的领域 skill。 | 未实现。 | 未经新设计评审，不添加通用 `query(limit, offset)`。 |
| V343-012 | 暂缓 | 中 | 2026-05-24 | 遥测 stats 工具 | 进程内 p50/p95 聚合或模型可见 stats 工具可能暴露操作模式，并需要有界状态设计。 | v3.4.3 之后继续暂缓 | 保持 opt-in JSONL；聚合交给外部日志处理。 | 有意暂缓。 | 只有出现有界且非模型可见的设计时再评估。 |
| V343-013 | 暂缓 | 中 | 2026-05-24 | Session schema cache | Schema cache 在 DDL 后可能过期，并影响安全/可执行性判断。 | v3.4.3 之后继续暂缓 | 继续以执行时检查为准。 | 有意暂缓。 | 只有存在明确失效策略时再评估。 |
| V343-014 | 暂缓 | 中 | 2026-05-24 | `db://schema` resource | Schema resource 会增加第二条 schema 访问路径，也会扩大模型可见上下文界面。 | v3.4.3 之后继续暂缓 | 继续使用显式 `get_full_schema()`。 | 有意暂缓。 | 只有客户端 resource 支持成为明确需求时再评估。 |
| DRR-2026-001 | 暂缓 | 中 | 2026-05-26 | 启动期副作用 | 启用 Skills 时，server import/startup 当前会 discover skills 并写入面向人工审阅的 `skills/SKILLS.md`。除日志/审计文件外，运行时启动路径理想上应保持只读。 | 候选代码清理，尚未实现 | 保留启动期 eager discovery/cache 作为 TOCTOU 防护；如果修改，应把人工总览生成移到显式维护命令或脚本。 | 2026-05-26 已记录到本登记表；尚未改运行时代码。 | 修改代码前先决定 `skills/SKILLS.md` 是否继续作为 tracked generated artifact，并为显式生成路径补测试/文档。 |
| DRR-2026-002 | 已接受 | 低 | 2026-05-26 | 展示型环境默认值 | `SKILLS_LIST_DEFAULT_DETAIL` 和 `SKILLS_LIST_AVAILABLE_ONLY_DEFAULT` 是展示默认值，而 `list_skills()` 已支持单次调用传入 `detail_level` 和 `available_only`。额外 env 默认值会扩大配置矩阵和测试重新 import 成本。 | 保留启动配置，但把解析后的值作为 MCP 输入 schema 中具体、非空的 enum/boolean 默认值暴露。 | 将这些变量视为展示默认值，而不是安全控制；单次调用参数仍是主接口，同时保证省略参数的行为与机器可见默认值一致。 | 已接受；默认配置与非默认启动配置的 schema/运行时一致性均有测试覆盖。 | 只有确认没有具体客户端需要环境级列表默认值，或进入破坏性版本时，再评估移除/收敛。 |
| DRR-2026-003 | 已实现 | 低 | 2026-05-26 | Skills 可用性 helper | `_skill_executable_state()` 和 `_skill_is_executable()` 只包装 `_skill_availability_state()`，且没有真实调用者。这些额外名称会让 availability policy 看起来不像集中在一个入口。 | 是 | 删除两个 wrapper，保留 `_skill_availability_state()` 作为唯一判断来源。 | 2026-08-10 已在 `mcp_sql_server.py` 实现；Skills disclosure 与多连接回归在删除后通过。 | Availability 决策继续集中到 `_skill_availability_state()`；不要为没有消费者的 convenience wrapper 增加入口。 |
| DRR-2026-004 | 已接受 | 低 | 2026-05-26 | 旧 feature switch 命名 | `ENABLE_SCHEMA_TOOLS` 是历史名称，但当前实际只 gate `sample()`，不是全部 schema tools。重命名更清晰，但会带来兼容性 churn。 | 仅文档/兼容处理 | 不把该开关扩展成控制无关 schema tools。如果将来确实需要澄清，可增加兼容别名如 `ENABLE_SAMPLE_TOOL`，不要改变旧变量语义。 | 作为历史命名妥协接受。 | 文档继续精确说明当前该开关只控制 `sample()`。 |
| DRR-2026-005 | 已接受 | 低 | 2026-05-26 | 低层 SQLite 调优面 | `SQLITE_PROGRESS_HANDLER_INTERVAL` 暴露 SQLite VM progress handler 频率。timeout 机制本身合理，但 interval 比多数部署需要的控制面更底层。 | 暂不改行为 | 把 `QUERY_TIMEOUT_SECONDS` 作为用户主要 timeout 控制；没有实测部署需求时，不再新增类似低层 DB 调优 env var。 | 为兼容性接受当前取舍。 | 只有该 interval 导致实测 CPU/延迟问题，或进入可破坏兼容的清理版本时，再评估移除低频调优旋钮。 |
| DRR-2026-006 | 暂缓 | 中 | 2026-05-26 | import/startup 副作用 | `start_server.py` 在模块 import 时就导入 server、加载 `.env`、创建 `logs/` 并安装带时间戳的 `FileHandler`，而这些发生在环境校验之前。单纯 import 或工具探测也可能创建文件并提前冻结 server 配置。 | 候选代码清理，尚未实现 | import 路径理想上保持只读。只有在做聚焦的启动流程清理时，才把 logging setup 和 `mcp_sql_server` import 移入 `main()` 或显式 startup factory。 | 2026-05-26 已记录到本登记表；尚未改运行时代码。 | 重新评估时补测试：import `start_server.py` 不创建日志文件，同时保持 FastMCP `Client(str(start_server.py))` 可启动。 |
| DRR-2026-007 | 暂缓 | 中 | 2026-05-26 | 导入期配置冻结 | `db_adapter.py` 在 import 时把 DB 配置读成模块常量，`sql_safety_checker.py` 直接 import `QUERY_TIMEOUT_SECONDS`，adapter 又全局缓存。测试为了切换配置必须 reload module 或清 `sys.modules`。 | 暂不做大 settings 重构 | 没有具体需求时，不引入大 settings object。若清理，应优先选择窄 factory/config injection 路径，并保留现有公开 API。 | 2026-05-26 已记录到本登记表；尚未改运行时代码。2026-05-29 结合多数据库前置修复计划复核后确认：前面的安全/加固项已基本完成，因此该项已成为运行时多数据库支持前最主要的地基风险。 | 多数据库工作现在可以进入 design-only 阶段，但真正实现前应先选定窄范围的 connection-aware adapter/config 方案（例如按调用选择 `connection_id` registry），而不是继续扩展当前 process-global `DB_TYPE` 与 singleton adapter 路径。若之后需要清理启动/import 路径，再与 DRR-2026-006 一并评估。 |
| DRR-2026-008 | 已实现 | 高 | 2026-05-26 | Adapter metadata 标识符处理 | MySQL 和 SQLite 的 adapter metadata 方法曾把 `table_name` 拼进 SQL/PRAGMA。MCP tools 调用前多数会校验标识符，但 adapter 也是测试和脚本会直接使用的公共内部边界。 | 是 | 在 adapter metadata 边界集中校验简单未限定标识符。MySQL `INFORMATION_SCHEMA` table-name 谓词改用参数绑定；SQLite metadata 路径在 `PRAGMA` 或 bounded sample SQL 前先校验并引用 identifier。 | 2026-05-28 已在 `db_adapter.py` 实现；`tests/test_db_adapter.py` 覆盖非法表名、schema-qualified 名称、quoted identifiers、MySQL 绑定和 SQLite bounded-sample 引用。 | 如果未来 DB 支持需要 schema-qualified 名称，新增结构化 `(schema, table)` API，而不是接受 dotted 或预先 quoted 的字符串。 |
| DRR-2026-009 | 暂缓 | 中 | 2026-05-26 | Smoke/manual 测试边界 | 根目录 `test_mcp_client.py`、`test_mcp_functions.py`、源码读取型 `test_bug_fixes.py` 混合了手动集成检查和 pytest 自动收集；部分依赖真实 DB/server 或检查源码字符串而非行为。 | 候选测试清理 | 行为回归测试应放在 `tests/`；manual smoke flow 应移动到显式脚本或标记为 integration/manual。替换成行为测试前，不删除仍有价值的覆盖。 | v3.7 部分清理：等价行为覆盖落入 `tests/test_sql_policy.py` 后，已从 `test_bug_fixes.py` 删除过时 table-regex 源码字符串断言。其它 legacy source/manual smoke 仍保留，因此本条继续暂缓。 | 只有已有等价行为覆盖时才继续替换源码形状断言。决定 CI/manual integration 边界后，再整理剩余脚本归属。 |
| DRR-2026-010 | 已接受 | 低 | 2026-05-26 | 运行模块中的 demo 写入 | `sql_safety_checker.py` 的 `__main__` demo 会创建并 seed `test_users` 表。它不是导入期副作用，但把写入型 demo setup 放在 safety module 中会增加心智负担。 | 暂不改行为 | 写入示例优先放在显式 demo/setup 脚本中；不要继续向 runtime library module 添加写入 demo。 | 作为历史 demo 代码接受。 | 清理示例时，将该 demo 移到 `scripts/` 或文档，让 `sql_safety_checker.py` 聚焦 validation/execution helper。 |
| DRR-2026-011 | 已实现 | 高 | 2026-05-26 | MySQL SELECT 文件操作 | 基础和扩展 SQL 安全检查曾把 MySQL `SELECT ... INTO OUTFILE`、`SELECT ... INTO DUMPFILE`、`LOAD_FILE(...)` 当作安全 SELECT 形式。如果 DB 账号有 `FILE` 权限，这些语法可读写 server-side 文件；`DUMPFILE`/`LOAD_FILE` 还可能不包含表名，因此 table allowlist 无法覆盖该风险。 | 是 | 在 MCP 层、注释规范化后显式拒绝 MySQL server-side 文件操作。保持窄 denylist，不引入大 SQL parser 重写。 | 2026-05-28 已在 `mcp_sql_server.py` 实现；`tests/test_sql_policy.py` 覆盖 OUTFILE、DUMPFILE、LOAD_FILE 和 comment-separated 形式。 | 继续依赖无 `FILE` 权限的最小权限 DB 账号；新增 SQL backend 时补方言相关测试。 |
| DRR-2026-012 | 已实现 | 高 | 2026-05-26 | SHOW/system schema 绕过形式 | 扩展检查曾阻断普通 `SHOW VARIABLES` 和 `information_schema.tables`，但 regex 不拦截 comment-separated SHOW 形式，以及 `` `information_schema`.`tables` ``、`` `mysql`.`user` `` 这类反引号引用系统 schema。 | 是 | 在 denylist 检查前做注释剥离/空白规范化，并扩展系统 schema 匹配以覆盖 quoted schema identifier。table allowlist 仍只是纵深防御，不是唯一系统 schema 屏障。 | 2026-05-28 已在 `mcp_sql_server.py` 实现；`tests/test_sql_policy.py` 覆盖 comment-separated SHOW 和 quoted `mysql`/`performance_schema`/`information_schema` 引用。 | 后续元数据访问变更继续走共享 policy；避免新增分叉且更弱的 SQL 检查。 |
| DRR-2026-013 | 已实现 | 高 | 2026-05-26 | SQL 方言/parser 语义与会执行的形式 | `is_sql_safe()` 曾主要依赖 `sqlparse` 顶层类型，接受会执行的 `EXPLAIN ANALYZE`、SELECT 形状的嵌套写 DML，并在 policy 检查前使用通用注释剥离。MySQL 会执行 `/*! ... */` 内容，且仅把后接空白/控制字符的 `--` 视为注释；optimizer hint 与 MariaDB executable comment 也是服务端 directive，不是普通注释。错误剥离会隐藏或改变服务器实际执行的内容。 | 是 | 把声明的 runtime 契约限于 Oracle MySQL/SQLite 行为。普通注释规范化前拒绝 ANALYZE explain、嵌套写 DML、`/*! ... */`、`/*+ ... */`、`/*M! ... */` 与非空白 `--`；保留普通注释、注释样字符串和非 ANALYZE plan。不得声称全面 SQL 语义分析或独立 MariaDB 方言支持。 | v3.7.0 于 2026-08-20 在 `sql_safety_checker.py` 与共享 MCP policy 实现。测试覆盖 ANALYZE/CTE、executable/optimizer/MariaDB comment、dash-comment 方言差异、被隐藏的 OUTFILE/system-schema、普通注释/字符串和普通 `EXPLAIN`。依据 [MySQL EXPLAIN](https://dev.mysql.com/doc/refman/8.4/en/explain.html)、[MySQL comments](https://dev.mysql.com/doc/refman/8.4/en/comments.html)、[MySQL 双横线规则](https://dev.mysql.com/doc/refman/8.4/en/ansi-diff-comments.html)与 [SQLite EXPLAIN](https://www.sqlite.org/lang_explain.html)。 | 该行保留v3.7检查点；后续按方言细化的注释／hint见DRR-121／122。新方言在声明支持前必须评审 EXPLAIN、CTE 与注释语义。保持窄而 fail closed；没有明确语法需求和方言测试时不引入通用 parser。 |
| DRR-2026-014 | 已实现 | 中 | 2026-05-26 | Adapter metadata 语义注入 | 直接调用 SQLite adapter 时，`get_row_estimate("users) --")` 这类 table name 曾可改变 metadata SQL 语义，包括注释掉 bounded sample 的 `LIMIT` 并退化为完整 count。MCP tools 会拒绝这些标识符，但 adapter 方法仍是公共内部边界。 | 是 | 与 DRR-2026-008 相同：adapter metadata 方法现在先校验，并在 SQLite bounded sampling 中引用 identifier。MCP 上游校验仍只是纵深防御，不是唯一防线。 | 2026-05-28 已在 `db_adapter.py` 实现；`tests/test_db_adapter.py` 证明非法 identifier 不会进入 `execute()`，且有效 sampling 使用 quoted SQLite identifier。 | exact-count 路径和未来 metadata helper 继续沿用同一 adapter identifier policy。 |
| DRR-2026-015 | 已实现 | 高 | 2026-05-26 | 错误日志参数暴露 | Adapter `_handle_error()` 曾记录 `str(e)[:200]`。SQLAlchemy 异常字符串可能包含 SQL 文本和 bound parameter values，然后才返回 sanitized client error。这是本地日志暴露，不是客户端响应暴露。 | 是 | 保持客户端错误 sanitized，同时把 adapter 本地异常日志收敛为 exception class，并在 engine 创建处配置 SQLAlchemy `hide_parameters=True`。 | 2026-05-28 已在 `db_adapter.py` 实现；`tests/test_db_adapter.py` 验证 adapter 日志不包含 SQL 文本或参数值。 | Audit payload 和 tool telemetry 继续按各自文档策略处理；adapter 路径不要重新引入 raw exception logging。 |
| DRR-2026-016 | 已实现 | 中 | 2026-05-27 | CI guardrail 声明过强 | README/REFACTORING_LOG 中曾有 annotation consistency regression 会在 CI 中失败的表述，但仓库当前只有 pytest guardrail，没有配套 CI workflow/config。这会让 reviewer 误以为仓库已经有自动化 CI enforcement。 | 文档清理 | 在真正加入 CI 前，把文档改为 pytest/local/default test guardrail，避免安全/流程声明超过实际 enforcement。 | 2026-05-30 已更新 README、README_ZH、MCP_AGENTS_SKILLS_DESIGN、REFACTORING_LOG 和本登记表；未新增 workflow。 | 如果后续新增 CI，再回头更新这些文档并记录 workflow 文件。 |
| DRR-2026-017 | 已实现 | 中 | 2026-05-27 | SQLAlchemy URL 构造 hygiene | MySQL 连接初始化曾用 f-string 拼接包含用户名、密码、host、database 的 URL。凭据中若包含 `@`、`:`、`/` 等特殊字符，可能导致解析错误或难排查的连接失败；该问题也靠近已有参数日志风险。 | 是 | 改用 SQLAlchemy `URL.create` 结构化构造连接 URL，并在创建 engine 时配合 `hide_parameters=True` 和明确 logging name。范围比大 settings 重构更窄。 | 2026-05-28 已在 `db_adapter.py` 实现；`tests/test_db_adapter.py` 覆盖包含 `@`、`:`、`/` 的凭据构造。 | 未来加入多数据库 registry 时，再评估多 URL builder 和每连接 logging identifier。 |
| DRR-2026-018 | 已实现 | 高 | 2026-05-27 | Skills 目录 containment | Skills 启动时曾对绝对 `SKILLS_DIR` 使用字符串前缀与项目根目录比较。路径字符串以项目根目录开头的 sibling 路径可能通过该检查，而 mutation skills 会在 discovery 阶段通过 `exec_module()` 导入执行。本地可信 repo 内 Skill 执行是预期行为，但 containment check 不应弱于后续 loader 层的路径检查。 | 是 | 在 discovery/import 前，用 `Path.resolve().relative_to()` 替换字符串前缀判断。继续明确 mutation skill code 是可信本地代码，不把 `SKILLS_DIR` 宣称为 sandbox。 | 2026-05-28 已在 `mcp_sql_server.py` 实现；`tests/test_sql_policy.py` 覆盖 sibling-prefix 路径拒绝。 | 如果未来再次调整 Skills 路径策略，补 symlink-specific containment 测试。 |
| DRR-2026-019 | 已实现 | 高 | 2026-05-27 | Query skill 安全一致性 | Query skill discovery 曾只用基础 `is_sql_safe()` 预审 SQL 模板，没有应用自由 `query(sql)` 工具的 MCP 扩展检查或 table allowlist。因此 query skills 可在启动时接受 DRR-2026-011 和 DRR-2026-012 中的同类 SQL 形状，而 `execute_query_skill()` 后续又跳过运行时 SQL safety check，依赖 discovery-time trust。 | 是 | 增加共享 read-query policy 函数并注入 query skill discovery；`execute_query_skill()` 在执行前也会重新检查缓存的 SQL 模板。 | 2026-05-28 已在 `mcp_sql_server.py` 和 `skills/_lib/skill_loader.py` 实现；测试覆盖 policy 注入和共享 deny checks。 | 后续新增多数据库 `connection_id` 支持时，保持 raw query 与 query skill 使用同一 validation helper。 |
| DRR-2026-020 | 已实现 | 中 | 2026-05-27 | Skills metadata 与参数 schema 声明 | `validate_params()` 使用小型自定义 schema 语言，而不是 JSON Schema。它已拒绝额外调用参数，但未知 type 曾直接通过，bool coercion 曾把 `"false"` 当真值。v3.7 复核又发现，拼错的嵌套 constraint、标量 `enum`、字符串数值边界和字符串形式的顶层 boolean 可能通过 discovery，随后削弱校验或披露准确性。 | 是 | 保留轻量 DSL，但严格校验已声明 vocabulary 与值。顶层 boolean 必须是 YAML boolean，列表/字符串 metadata 必须符合文档形状。每个参数只接受 `type`、`required`、`min`、`max`、`enum`、`description`；constraint 必须与类型兼容，enum 必须是非空列表，边界必须有序。运行时 bool 仍只解析原生布尔值和显式 `"true"`/`"false"` 字符串。它仍不是完整 JSON Schema。 | 第一阶段 type/bool 加固于 2026-05-29 落地。v3.7.0 在 `skills/_lib/skill_loader.py` 补齐 discovery-time metadata 值和嵌套 constraint 校验；`tests/test_skill_loader.py` 覆盖畸形 metadata、constraint 形状/类型、边界、enum、未知 key 和既有 runtime coercion。 | 未来新增字段、constraint 或参数类型前，必须显式加入 vocabulary 并测试。没有定义 namespace 与兼容规则时，不得静默接受扩展 metadata。 |
| DRR-2026-021 | 已实现 | 中 | 2026-05-27 | Mutation skill 类型完整性 | Mutation discovery 过去只检查模块中有 `Mutation` 属性；frontmatter `name` 也可能与目录身份不一致。由于 `mutation.py` 会在 discovery 阶段通过 `exec_module()` 动态导入执行，畸形的可信本地插件应在运行时 tool 路径缓存或实例化前 fail closed。 | 是 | Discovery 现在要求 frontmatter `name` 必填、符合命名规则，并与 skill 目录名完全一致。Mutation source 必须导出名为 `Mutation` 的 class，且必须是具体的 `MutationBase` 子类。mutation 代码体安全仍依赖人工 review；这不是面向不可信插件的 sandbox。 | 2026-05-29 已在 `skills/_lib/skill_loader.py`、`README.md`、`README_ZH.md`、`MCP_AGENTS_SKILLS_DESIGN.md` 和 `skills/SAFETY.md` 实现；`tests/test_skill_loader.py` 覆盖缺失/不匹配/非法 name，以及缺少、非 class、非 subclass、抽象 `Mutation` 导出。 | 如果未来需要支持不可信第三方插件，应单独设计进程隔离或 sandbox，而不是继续扩展该 loader invariant。 |
| DRR-2026-022 | 已实现 | 高 | 2026-05-27 | Skills audit 完整性声明过强 | `AuditLogger.log()` 仍是 best-effort；审计写入失败以及 token 前的参数/validation 拒绝仍可能没有 JSONL 记录。旧文档/config 曾过度暗示完整记录和 fail-closed audit 行为。 | 是 | 保持 audit 为 best-effort observability，而不是事务控制；正常结果 metadata 报告实际审计状态。v3.6.1 follow-up 让 post-consume 动态 validation 拒绝尝试 execute 失败审计；已提交写入后的响应阶段失败则保留既有 success audit，不追加矛盾的 failure。 | 已在 `skills/_lib/audit.py`、`skills/_lib/mutation_base.py`、`mcp_sql_server.py`、文档和回归中实现。2026-08-10 follow-up 覆盖动态 validation 返回 invalid 或抛 `ToolError`、诚实 `audit_logged`、无写入/replay 行为，以及 post-write response failure 只有一条成功 execute audit。 | 如果合规要求 guaranteed audit，应设计 transactional outbox 或数据库审计机制。不要把 JSONL 文件当成 fail-closed 证据，审计失败也不得弱化 mutation 拒绝。 |
| DRR-2026-023 | 已实现 | 高 | 2026-05-27 | 默认 pytest live database 边界 | `test_mcp_client.py::test_mcp_server` 曾被默认 pytest 收集。只要当前配置的数据库可连接，它会用当前 `.env` 启动 MCP server、list tables、count 第一张表、describe 第一张表、sample rows，并可能执行 query skill。这可能触达 live/类生产数据库，并把 sample data 打印到 pytest captured output 或失败日志中。 | 是 | 将默认收集限定到 `tests/`，保留根目录 MCP smoke 检查为显式脚本，并说明其 live-data 边界。DRR-2026-039 follow-up 还在 pytest 中禁用 `.env`、设置安全 SQLite/process 默认值，并把 MySQL 集成测试改为显式 opt-in。 | 已在 `pytest.ini`、`tests/conftest.py`、`README.md`、`README_ZH.md` 和 `TEST_MCP_CLIENT_GUIDE.md` 实现；默认 pytest 不收集根目录 smoke 脚本，也不能继承开发者 `.env`。 | 后续 live DB smoke 检查继续留在默认收集之外，除非具备显式 opt-in gate 和非敏感输出策略。 |
| DRR-2026-024 | 暂缓 | 中 | 2026-05-27 | 依赖可复现性 | `requirements.txt` 大多是不固定版本或只有下限的依赖，其中 FastMCP 和 SQLAlchemy API 被项目直接使用。没有 lockfile、constraints file 或 CI matrix 时，未来安装可能静默选择行为/兼容性变化的版本，从而削弱“本地/default tests 代表 release 行为”的声明。dry-run 证据也显示，当前冲突面主要来自 optional AutoGen 依赖链，而不是核心 server runtime 路径。 | Packaging/workflow 清理候选，尚未实现。AutoGen 示例不是本程序主线 runtime。 | 后续若修复，优先拆分 runtime/dev/optional AutoGen dependencies，再为实际支持的安装路径增加 constraints 或 documented tested version set。不要把无约束安装描述成可复现 release input。 | 2026-05-27 配置/依赖复审后记录。2026-05-29 验证：当前 `.venv` 的 `pip check` 报告 `autogen-core 0.7.5` 要求 `protobuf~=5.29.3`，但已安装 `protobuf 6.33.5`；干净 requirements dry-run 会解析到 `protobuf 5.29.6`，仅核心 runtime 解析不会引入 `protobuf`。v3.6.1 只增加 `PYTHON_DOTENV_DISABLED` 所需的窄约束 `python-dotenv>=1.2.0`；这不会让更广泛的依赖集合变得可复现。 | 更广泛的问题继续暂缓。不要让 optional AutoGen 示例依赖定义核心 runtime 的可复现性声明，也不要把当前未锁定集合描述为可复现 release input。 |
| DRR-2026-025 | 已实现 | 高 | 2026-05-27 | MySQL mutation timeout 语义 | `MySQLAdapter.execute_write()` 曾使用 `MAX_EXECUTION_TIME`，但 MySQL 文档将该机制描述为偏 SELECT/read-query。受控 MySQL 验证确认了缺口：`timeout=1` 下 `SELECT SLEEP(2)` 约 1.079s 停止，而 `UPDATE ... SLEEP(2)` 仍在约 2.171s 后提交成功。 | 是 | 移除写入路径的 `MAX_EXECUTION_TIME`。MySQL `execute_write()` 现在会在 mutation 前设置 session `innodb_lock_wait_timeout = max(1, timeout_seconds)`，若该防护无法配置则 fail closed。文档已区分只读查询 timeout、InnoDB 行锁等待 timeout、PyMySQL socket timeout 和部署侧 DML 控制。 | 2026-05-29 已在 `db_adapter.py`、`tests/test_db_adapter.py`、README/docs 和 Skills safety 文档中实现。受控证明使用数据库 `trade_data_analysis`：旧写入路径忽略 `timeout=1`；另一个 lock-wait 场景在 `innodb_lock_wait_timeout=2` 下约 3.236s 抛出 OperationalError 1205。 | 剩余边界：这不是覆盖所有 MySQL DML CPU/IO 工作的完整 wall-clock statement timeout。如果生产需要硬性的 mutation 执行上限，仍需把 driver read/write timeout 和部署侧 statement controls 纳入方案。 |
| DRR-2026-026 | 已实现 | 高 | 2026-05-30 | 多连接 policy/execution 串线 | 运行时多数据库支持如果让 policy、identifier quoting/schema helper、adapter execution、metadata、audit 或 telemetry 从不同连接读取，就可能出现“展示/校验针对数据库 A，执行却打到数据库 B”的串线风险。 | 是 | 引入 `ConnectionContext`，并在 policy、schema readiness、方言相关 helper SQL、执行、metadata、audit 和 telemetry 之前解析目标连接。`sample()` 和精确表计数中的内部 helper SQL 直接在选中的 adapter 上执行，不再绕回 legacy 默认执行包装。 | 2026-05-30 已在 `db_adapter.py`、`sql_safety_checker.py` 和 `mcp_sql_server.py` 实现；`tests/test_multi_connection_v35.py` 覆盖同连接 policy/execution 和未知 id fail-closed。 | 后续新增工具继续沿用 resolve-first 模式；任何会 quote identifier 或执行内部 SQL 的 helper 路径都要补回归测试。 |
| DRR-2026-027 | 已实现 | 高 | 2026-05-30 | Skills 展示与执行不一致 | 命名连接和 per-connection allowlist 出现后，Skills discovery 可能把某个 skill 展示为在一个数据库类型/schema 下可执行，但实际执行使用另一 adapter。 | 是 | 让 `list_skills`、`get_skill_detail`、`execute_query_skill` 接受可选 `connection_id`，并在同一个目标连接上评估 DB 兼容性、schema readiness、allowlist、metadata、可选 audit 和 telemetry。`SkillMetadata.databases` 仍是 DB 类型兼容字段，不是 connection-id allowlist。 | 2026-05-30 已在 `mcp_sql_server.py` 实现；`tests/test_multi_connection_v35.py`、`tests/test_skills_disclosure.py` 和文档覆盖目标连接的 availability/execution 一致性。 | 继续把 `available_only` 说明为发现层过滤，不是授权边界；执行期检查仍必须保留。 |
| DRR-2026-028 | 已实现 | 中 | 2026-05-30 | Adapter registry 生命周期与资源边界 | 多个命名连接意味着多个长期存在的 SQLAlchemy Engine。如果 registry/reset/lifecycle 不清楚，会泄漏资源，也会让需要切换环境的测试更复杂。 | 是 | 新增按配置化 `connection_id` 懒加载的进程内 adapter cache，并提供 `reset_adapter(connection_id=None)` 关闭单个或全部 adapter，用于测试/重配置。连接定义仍由服务器端配置并在 import 时解析，不引入动态 per-request DSN。 | 2026-05-30 已在 `db_adapter.py` 实现；`tests/test_db_adapter.py` 和 `tests/test_multi_connection_v35.py` 覆盖 registry 行为。 | 暂缓 LRU/上限/凭据刷新。若部署配置大量连接或需要运行时配置 reload，再重新设计。 |
| DRR-2026-029 | 已实现 | 中 | 2026-05-30 | 日志和元数据中的连接身份 | 运维需要知道一次 tool call 打到了哪个配置化连接，但如果在 `ToolResult.meta`、telemetry、audit 或结构化 payload 展示字段中暴露连接内部信息，会泄漏敏感 DB 细节。 | 是 | 在结果 metadata、可选 telemetry 和 Skills audit 中加入安全别名 `connection_id` 与实际 `db_type`；`list_connections()` 只返回别名和 policy 摘要。公开 SQLite `database_name` 展示字段使用 `sqlite:<connection_id>`，不暴露文件路径。仍排除 DSN、host、用户名、密码、SQLite 路径、SQL params 和返回行。 | 2026-05-30 已在 `mcp_sql_server.py`、`skills/_lib/audit.py`、`skills/_lib/mutation_base.py`、文档和测试中实现；follow-up 测试覆盖 `check_connection()` / `list_tables()` 不暴露 SQLite 路径。 | 新增 metadata/audit/payload 字段时重新审查；未经隐私评审不要加入连接内部信息。 |
| DRR-2026-030 | 已实现 | 高 | 2026-05-30 | 多连接 mutation 写入 | 允许 mutation Skills 选择任意配置化连接，需要 per-connection 写权限、preview/execute 目标绑定、audit 语义，以及针对 SQLite 文件锁和 MySQL 写超时的更强运维说明。 | 是 | 要求全局 mutation 目标 allowlist、per-connection 写开关、per-connection Skill allowlist，以及绑定 skill/version/params/connection/DB type/expiry 的一次性 preview 值。v3.6 使用 HMAC envelope + Store 实现；省略全局路由策略时保持仅默认连接。 | v3.6 已在 `db_adapter.py` 和 `mcp_sql_server.py` 实现，discovery 与 execution 共享 policy 检查。v3.7.1 只把客户端可见 envelope 换成 opaque handle，目标/请求绑定继续保存在 Store（DRR-2026-054）。当前测试覆盖路由、目标隔离、拒绝层、精确过期、未知/变更 handle、版本变化、重启和不暴露。 | Replay 与 preview-state hardening 已在 DRR-2026-034 实现。每个授权写目标仍需持续说明 SQLite lock 和 MySQL DML timeout 边界。 |
| DRR-2026-031 | 已实现 | 高 | 2026-05-30 | Quoted identifier allowlist 绕过 | MCP table extractor 曾没有一致处理常见 quoted identifiers。`FROM "forbidden"`、`FROM [forbidden]` 或 `FROM main."forbidden"` 这类形式可能绕过或误导 table allowlist 比较，即使实际引用的是不允许访问的表。 | 是 | 在和目标连接 allowlist 比较前，规范化反引号、双引号、方括号和 schema-qualified 引用。保持为聚焦的 extractor 加固，不引入完整 SQL parser。 | 2026-05-30 已在 `mcp_sql_server.py` 实现；`tests/test_sql_policy.py` 覆盖 quoted/schema-qualified deny case 和允许的 quoted 表。 | 后续 table-reference 解析继续走共享 policy 路径；扩展语法支持前先补方言示例测试。 |
| DRR-2026-032 | 已实现 | 中 | 2026-05-30 | Legacy named-env 泄漏 | 本地多连接 `.env` 中的 `DB_DEFAULT_*` 和 `DEFAULT_DB_CONNECTION` 可能在 `DB_CONNECTIONS` 未设置或为空时影响 legacy 单连接模式，破坏向后兼容，或因为 named default 不存在导致 legacy 启动失败。 | 是 | 将 `DB_CONNECTIONS` 作为命名连接唯一 feature gate。legacy 模式忽略 `DB_<ID>_*` 和 `DEFAULT_DB_CONNECTION`；`DB_TYPE` / `SQLITE_DATABASE_PATH` 继续作为权威配置。 | 2026-05-30 已在 `db_adapter.py`、`.env.example`、README/docs 和测试中实现；`tests/test_db_adapter.py` 覆盖 legacy 模式忽略 `DB_DEFAULT_*` 和默认连接选择。 | 后续新增 per-connection setting 时保留该 gate；未经显式迁移决策，不让 named 变量影响 legacy 模式。 |
| DRR-2026-033 | 已实现 | 中 | 2026-05-30 | 兼容 helper 解析顺序 | 独立 helper `sql_safety_checker.execute_sql(..., connection_id=...)` 曾可能先做 SQL safety，再解析目标连接。未知 id 应先 fail closed，再考虑任何目标相关 policy 或执行路径。 | 是 | 在 `is_sql_safe()` 和 adapter execution 前先用 `get_connection_config()` 解析 `connection_id`，保持和 MCP 工具的 resolve-first 不变量一致。 | 2026-05-30 已在 `sql_safety_checker.py` 实现；`tests/test_multi_connection_v35.py` 覆盖未知 `connection_id` 会先返回连接错误而不是 SQL policy 错误。 | 后续扩展 connection-aware policy 时，保持兼容 helper 与 MCP tool 顺序一致。 |
| DRR-2026-034 | 已实现 | 高 | 2026-05-30 | Preview-token replay 与审阅状态漂移 | 有效 HMAC token 曾可在过期前 replay；内置 mutation 还会在 execute 时重新读取当前状态，而不是锁定 preview 展示的状态。单靠乐观锁不是通用 replay 或“所见即所写”边界。 | 是 | v3.6 新增随机 `jti`、有界 execution-state hash 和加锁的进程内 Store，在动态 validation/write 前消费；后续结果保持 terminal，并禁止 stateless HMAC acceptance。 | v3.6/v3.6.1 已在 `mcp_sql_server.py`、`preview_token_store.py`、`MutationBase` 和 `sample-update-order-status` 实现。v3.7.1 将 Store 操作改为 opaque handle 的精确 request-binding 比较与原子消费，保留 mismatch record 和原有 replay/state 边界。测试覆盖唯一签发、mismatch preservation、顺序/并发 replay、容量、过期、重启、terminal 结果、状态漂移和无绑定执行拒绝。 | Preview 与 execute 必须进入同一进程。推荐客户端自有 stdio。条件性 HTTP mutation 仅限受信任私有边界中的单进程；多用户认证 HTTP 不属于当前设计。重启或跨进程请求会使未消费值失效。禁止 stateless fallback。 |
| DRR-2026-035 | 已实现 | 低 | 2026-08-04 | 示例数据库 fixture 漂移已解决 | Mutation live smoke 曾让被跟踪的示例数据库看起来包含未提交的状态变化；当前已经不存在该工作树漂移。 | 是 | 让 `sample_data/demo.db` 保持 tracked baseline；任何会执行写入的测试都使用一次性数据库。 | 2026-08-10 复核：`git diff -- sample_data/demo.db` 为空，`HEAD` 和工作区中的订单 `id=4` 都是 `confirmed`。 | 后续 live write 检查不得把 tracked sample database 当作 mutation fixture；应创建临时副本或临时数据库。 |
| DRR-2026-036 | 已实现 | 中 | 2026-08-04 | Server instructions 曾错误声称全局只读 | FastMCP server 级 `instructions` 曾写成 “Database query assistant with READ-ONLY access”，但可选 Mutation Skill 能执行受控写入；模型可见能力说明与实际界面不一致。 | 是 | 简洁说明只读核心 SQL 工具、配置化连接路由、可选 Skills，以及由 preview 和一次性 token 保护的受控 mutation。 | 2026-08-10 已在 `mcp_sql_server.py` 实现。回归测试断言 instructions 不再声称全局只读，并明确提到受控 mutation 和一次性 token。 | 后续工具面变化时同步 instructions；不得暗示 `confirm=true` 能证明人类批准。 |
| DRR-2026-037 | 已实现 | 中 | 2026-08-04 | Mutation 双执行路径 | `MutationBase` 要求实现具体的 `execute()`，因此 `sample-update-order-status` 曾同时保留 `execute()` 和 `execute_with_binding()`；公开的 `execute()` 会重新读状态并在没有 preview binding 时写入，若在 MCP 外调用会重新引入 DRR-2026-034 的 TOCTOU。 | 是 | 保留满足抽象接口的 `execute()`，但让它直接抛出 `ToolError`。唯一权威写路径为 `_execute_with_expected_status()`，只能通过携带服务端 preview state 的 `execute_with_binding()` 到达。 | 2026-08-06 已在 `skills/sample-update-order-status/mutation.py` 实现；`test_update_order_status_rejects_direct_unbound_execute` 验证直调失败且数据不变。 | 只有一个 binding-only Skill 时保留 ABC，使畸形 Skill 继续在 discovery 阶段失败。若多个 binding-only Skills 证明需要重构，移除 abstract method 前必须增加 loader invariant，要求至少覆写 `execute()` 或 `execute_with_binding()` 之一。 |
| DRR-2026-038 | 已实现 | 中 | 2026-08-04 | Preview 绑定来源与预览失败仍签发 token | `sample-update-order-status` 的 binding 曾来自 validation 第一次读取，而展示内容来自 preview 的第二次读取；两次读取之间的变化会导致展示与绑定不一致，第二次读取失败时仍可能报告成功并签发 token。 | 是 | Preview 返回自身读取的 `current_status`，binding 只从该字段构建。任何包含 `error`、声明 `success=false`，或提供非布尔/非 true `success` 值的 preview 都失败、不签发 token。 | 已在 `mcp_sql_server.py` 和 `skills/sample-update-order-status/mutation.py` 实现。回归覆盖状态插入变化、非空/空/null `error`、布尔 false 与 malformed non-true success 值；所有失败 preview 后 store 都为空。 | 自定义 mutation Skill 成功时应省略 `success` 或把它设为布尔 true；失败时应返回 `error`、返回布尔 `success=false` 或抛出 `ToolError`。只有 Skills 增多且字典契约难以维护时才引入 typed result。 |
| DRR-2026-039 | 已实现 | 高 | 2026-08-04 | 默认 pytest 环境隔离缺口 | `tests/conftest.py` 此前只清空两个路由变量，而 `db_adapter.py` 会加载开发者 `.env`。legacy 数据库凭据、读 policy、Skills 和 telemetry 配置因此可能改变默认测试；可选 MySQL fixture 甚至可能连接 live database。 | 是 | 在应用导入前设置 `PYTHON_DOTENV_DISABLED=1`，为默认 pytest 建立明确的安全 SQLite/config 基线；除非显式请求 live integration，否则清空 legacy MySQL 凭据，并要求 `RUN_MYSQL_INTEGRATION_TESTS=1` 后 MySQL fixture 才能连接。 | 2026-08-10 已在 `tests/conftest.py` 实现；README/testing guidance 明确 `.env` 会被忽略，live MySQL 需要 shell 显式 opt-in 与导出的凭据。完整 pytest 仍以三个 MySQL integration skip 通过。 | 默认 pytest 必须继续禁用 `.env`。未来任何 live service/database fixture 都必须有自己的显式 opt-in gate，且不得意外进入默认收集。 |
| DRR-2026-040 | 已实现 | 低 | 2026-08-04 | 不可达的配置 helper | `mcp_sql_server.py` 中的 `_parse_table_allowlist()` 从未调用；实时 allowlist 解析已经归属 `db_adapter.py`，保留两条路径会诱导后续改错函数。 | 是 | 删除死 helper 及其分歧日志，使 allowlist 解析只有一个归属；补上 `pytest.ini` 文件末尾换行。 | 2026-08-10 已实现。运行时 `ALLOWED_TABLES` 继续来自已解析的连接 policy。 | 保持 allowlist 解析集中在 `db_adapter.py`。 |
| DRR-2026-041 | 已实现 | 中 | 2026-08-04 | Mutation 回归断言偏弱 | v3.6 signing-secret 轮换测试曾在轮换/断言前结束，一处脱敏断言恒真，也没有端到端覆盖 `adapter.execute_write()` 抛错后的 terminal token 消费。这些弱点降低了 replay 边界的可信度。 | 仅测试加固 | v3.6.1 完成 secret rotation、直接 non-disclosure 和数据库失败断言；v3.7.1 移除 envelope 后，用 opaque-handle 契约和 legacy-secret 无效断言替代过时的 secret 行为测试，同时保留 terminal failure/concurrency 证据。 | 已在 `tests/test_mutation_multi_connection_v36_design.py` 与 `tests/test_mutation_skills.py` 实现。当前证据包括 256-bit opaque 签发、legacy secret 不影响行为、non-disclosure、数据库失败后的 terminal consumption、Store 原子条件消费，以及两个并发完整 execute 只产生一次数据库写入。 | 后续 preview-token Store 或执行路径变更必须保留这些回归；替换过时机制测试时仍需保留发布历史。 |
| DRR-2026-042 | 已实现 | 低 | 2026-08-04 | v3.6 之后遗留的 v3.5 时期措辞 | 多份文档在 v3.6 已引入命名写 policy 后，仍把 v3.5 的仅默认连接妥协描述为当前状态。 | 是 | 为 default-only 行为补上“省略 `SKILLS_ALLOW_MUTATION_CONNECTIONS` 时”的限定，并分开记录 v3.5→v3.6 与 v3.6→v3.6.1。 | 2026-08-10 已在客户端指南、README、Skills 指南、Agent 指南、设计文档和发布说明中完成；最后一处无条件 “limited to the default connection in v3.5” 已修正。 | 后续维护版本继续把基线能力与补丁修复分开记录。 |
| DRR-2026-043 | 已接受 | 中 | 2026-08-04 | 读 allowlist fail-open 与写 allowlist fail-closed 不对称 | `DB_<ID>_ALLOWED_TABLES` 为空或省略表示所有可见表都可读，而 `DB_<ID>_MUTATION_SKILLS` 为空或省略表示拒绝所有写入。两个默认值有意不同。 | 仅文档声明 | 保留读侧兼容默认值和写侧 deny-by-default；集中说明不对称并建议生产环境配置具体读表 allowlist。 | 2026-08-10 已在中英文 env example 与 README 配置/安全说明中记录；行为本身仍是已接受的兼容取舍。 | 保持警告靠近两类 policy 示例；仅在破坏性版本中重新考虑读侧默认值。 |
| DRR-2026-044 | 已接受 | 低 | 2026-08-04 | Preview-token store 容量自我拒绝 | `MUTATION_PREVIEW_TOKEN_STORE_MAX_ENTRIES` 限制每进程未过期 token，容量满时 fail closed。反复 preview 不 execute 会在过期前填满 store；惰性清理会在锁内扫描有界字典。 | 部分加固 | 保留 fail-closed 容量和惰性清理；把 TTL 限制为 `1-86400` 秒、容量限制为 `1-100000`；无效值分别回退到 `300` 和 `10000`。没有实测负载前不增加 heap/后台清理服务。 | 默认 TTL 300、容量 10000 不变；测试覆盖不驱逐、过期释放和两类配置上限。容量上限只是防误配置护栏，不是经验证的吞吐声明；仍无 per-client 限流。 | v3.6.1 不支持不可信或多用户 HTTP mutation。只有明确远程/高吞吐需求时才重新评估 quota、限流和索引化 expiry。 |
| DRR-2026-045 | 已实现 | 中 | 2026-08-08 | 共享 token backend 与实际部署范围 | 共享 backend 能协调 worker/副本，但生产级远程服务还需要认证、传输安全、可观测性、副本配置一致性和数据库治理；只增加 token store 会夸大部署成熟度。 | 是 | 保留有界进程内 Store，并推荐客户端自有 stdio。条件性 HTTP mutation 仅限受信任私有边界中的单进程；多用户认证 HTTP 和共享 mutation 副本不属于当前设计。读扩展只能使用独立 read-only endpoint/profile/pool。 | 已实现：活动文档说明同进程边界、连续性损失、程序不强制 worker 数，以及当前没有多用户 HTTP 安全设计。 | 只有出现明确远程 mutation 需求时，才连同完整部署 profile 重新设计共享状态。禁止 stateless token 校验。 |
| DRR-2026-046 | 已接受 | 低 | 2026-08-10 | 仅比较 status 的乐观锁与 ABA 变化 | `sample-update-order-status` 和 v3.7 `sample-reset-order-to-pending` 示例都会绑定并比较展示的 `status`。外部写入者或 demo reset 自身可在另一个 token 有效期内形成 `pending -> X -> pending`，导致 execute 时 status 相同而中间变化未被发现。 | 不新增通用 schema | reset 明确仅供 demo/test，且调用方必须声明准确的非 pending 来源状态。加入 revision/`updated_at` 条件需要真实业务 schema 契约和 migration；在 portable framework demo 中虚构一列属于过度设计。建议使用专用 fixture、不为同一订单保留重叠 preview，并为每个 live-test 场景启动新的 stdio 进程。 | 接受为有界的 demo/外部写入者局限。只要 execute 时状态与 preview 展示值不同，现有保护仍会拒绝；但仅绑定 status 无法发现已经循环回原值的变化。 | 真实目标表提供稳定 revision/version，或生产流程可恢复旧状态时，再把版本字段加入 binding 与 `WHERE`。不得把 demo reset 作为生产订单重开 API，也不要在框架中虚构通用 timestamp 契约。 |
| DRR-2026-047 | 已实现 | 低 | 2026-08-10 | 不可达的命名 SQLite 路径别名 | 命名 SQLite 分支含有未文档化 `DB_<ID>_DATABASE_PATH` fallback，但前面的 canonical `DB_<ID>_SQLITE_DATABASE_PATH` lookup 总会提供字符串默认值，因此 `None` guard 与别名读取不可达。把它转为支持配置只会新增重复配置面和优先级规则，没有兼容收益。 | 是 | 删除死 fallback。继续把 `DB_<ID>_SQLITE_DATABASE_PATH` 作为唯一命名 SQLite 路径配置；不为不可达别名补文档、激活逻辑或测试 fixture 清理。 | 2026-08-10 已在 `db_adapter.py` 实现。现有命名 SQLite 与 legacy 隔离测试通过，运行时行为不变。 | 保持命名连接配置显式且唯一。若测试环境 suffix 漂移成为真实问题，应隔离项目自有 `DB_*` 命名空间，而不是让死别名转正。 |
| DRR-2026-048 | 已接受 | 低 | 2026-08-13 | Preview-token 交付记账边缘 | Preview 成功后会先登记 handle，再执行 best-effort audit、`ctx.info()` 和 `ToolResult` 构造。若服务器能观察到的异常发生在登记之后、结果返回之前，客户端拿不到可用 handle，但对应 record 会占用一个有界 Store 槽位直到过期/惰性清理；audit 可能已经记录 preview success，通用 adapter sanitizer 还可能把响应或日志失败误报为数据库查询失败。由于执行仍要求未交付的高熵 handle，这不会允许 mutation 或 replay。 | 部分加固 | 保持 fail-closed、短 TTL、有界容量和同进程原子消费。v3.7.1 `consume_if_matches()` 通过同一锁内比较/消费消除了旧的 request-binding mismatch pop 后边缘；它不会让 handle 交付或之后的结果信号原子化。服务端生成的 execution-binding JSON 仍在消费后解析，这是签发路径内部不变量，不是独立的攻击者可控授权检查。若有运维证据，再增加按 digest 的 best-effort `discard()` 并区分响应与 DB 错误。 | 剩余交付/记账局限影响低：不引入未授权写、replay 或乐观锁绕过；孤儿 record 受容量和过期约束。Store 测试覆盖 mismatch preservation 和原子 one-winner consumption。 | 若观察到 preview 响应失败、HTTP 成为主要 transport，或 token storage 出现第二个 producer，则重评。清理不得暗示服务端能判断 transport handoff 后丢失的响应是否到达客户端。 |
| DRR-2026-049 | 已实现 | 中 | 2026-08-19 | 可选 Skill 连接范围与授权/路由歧义 | 可复用 Skill 需要表达预期连接；复用 `databases`、接受自动路由 metadata、把 metadata 当权限，或静默忽略范围字段拼写错误，都可能打错数据库或取消预期限制。多值还需定义别名缺失/DB 不兼容行为。 | 是 | 新增严格限制性的复数 `connection_ids`。省略保持旧行为；运行时省略仍用全局默认。拒绝未知 frontmatter 字段和重复 YAML key，使安全相关 typo 在 discovery fail closed。adapter 前校验 scope/type，其余 policy 在查询执行或写入前继续生效；冲突按目标拒绝，其它有效成员可复用。 | 已在 loader/server 实现；测试覆盖语法、未知/重复字段、grammar 对齐、规范化、不自动路由、policy 交集、目标隔离和 token 前拒绝。真实 fixture 独立覆盖有效、未配置与 DB 冲突 alias。 | Metadata 只收窄；直接 Python 调用绕过 MCP 路由。严格未知字段意味着自定义 metadata 以后需要显式扩展 namespace。建议语义别名；只有具体全成员需求才重审全局禁用。 |
| DRR-2026-050 | 已接受 | 中 | 2026-08-19 | 人工批准 host 不是服务端可验证的人类授权 | preview token 能证明匹配 preview 并阻止 replay，但客户端可自动回传。console host 增加批准体验，服务端仍不认证批准人，其他客户端可绕过，deny 不上报，外部 payload 日志也可能泄漏 token。 | 实现示例并明确局限 | 在同一 stdio Client/server 中运行；规范化有限 JSON 参数，拒绝 provider 修改批准视图，由 workflow 强制截止时间，固定 preview 目标，不重试不确定执行。完整环境继承避免可信本地 host 静默换用另一 `.env`，但也把全部导出 secret/control variable 纳入子进程信任边界。没有产品需求时不增加 Elicitation/HTTP auth/cancel/持久服务。 | 测试覆盖各决定状态、迟到批准、畸形/过期 preview、请求快照、批准视图修改拒绝、目标固定、环境传递、token 脱敏和不重试。文档明确它不是身份/合规证明，并说明 params/preview/execute 输出可能敏感。 | deny token 占容量至 TTL；Python 不能保证内存擦除；恶意 provider 需进程隔离。产品化 host 应选择性转发项目配置。若要求身份、职责分离、持久 deny 或远程多用户 mutation，应设计认证批准/审计服务。 |
| DRR-2026-051 | 已实现 | 高 | 2026-08-20 | Raw read grammar 与 table allowlist 完整性 | regex 时代的表提取器会漏掉 comma join 或 comment-separated 表、丢弃 schema qualifier，并把 EXPLAIN 关键字误当表。过宽 SHOW、跨 session EXPLAIN 和允许多条 statement 也使 metadata/system scope 校验不完整，并让行为依赖未来 driver。 | 是 | 保持 raw query/Query Skill 共用一个保守 policy。只接受单条 statement；规范化普通注释但不剥离 executable directive；拒绝 raw SHOW 与跨 session EXPLAIN/DESCRIBE；把 `sys` 纳入 system schema；保留 qualifier；限制性 allowlist 下无法完整提取 table scope 时 fail closed。非 ANALYZE 的 EXPLAIN-family DML 仍有用途，但其写 target 与全部 read/USING source 都必须在 scope 内。不得声称完整跨方言 parser。 | v3.7.0 已在 `mcp_sql_server.py`/`sql_safety_checker.py` 实现；`tests/test_sql_policy.py` 覆盖 comma join、comment separator、qualified name、nested/CTE table、EXPLAIN 误报/跨 session 形式、EXPLAIN/DESCRIBE/DESC `UPDATE`/`INSERT`/`REPLACE`/`DELETE` target、CTE alias、multi-table `DELETE ... USING` source、SHOW 变体、无字符串字面量误报的 system schema、ambiguous target 与多 statement。Query Skill 依据 DRR-2026-019 复用相同 runtime helper。低层 `is_sql_safe()` 为兼容仍识别 SHOW，但完整 MCP policy 从不执行。 | 只有出现具体受支持方言需求并补正反测试时才扩展 grammar。schema discovery 使用 `list_tables`/`describe_table`，数据库 grant 继续作为权威边界。 |
| DRR-2026-052 | 运维决策 | 高 | 2026-08-20 | SELECT 形状的副作用与数据库授权 | Statement-shape gate 无法证明所有外层 `SELECT` 没有副作用。MySQL stored function 可能修改数据或以 definer 权限运行，`GET_LOCK()` 会创建 session state，metadata 可见性也取决于权限。命名连接还可能复用比 raw-query 角色更宽的凭据。 | 部署指导，不做函数 denylist | 把 SQL checker 与 `ALLOWED_TABLES` 定位为应用层 guard。生产只读 alias 只授予对象级 `SELECT`，撤销不需要的 `EXECUTE`、`FILE`、`PROCESS`、管理与跨 schema 权限；可行时分离读写凭据。不断扩大的函数 denylist 很脆弱，不能替代 grant。 | v3.7 已在 README、env example、Skills 安全指南、release/guide 与本登记表记录。代码继续执行保守 shape/table policy，但不声称语义证明。 | 若 mutation alias 必须使用更宽凭据，可在未来由真实需求驱动的版本考虑禁止该 alias 的 raw query。把 stored routine 与账号 grant 作为部署工件评审。 |
| DRR-2026-053 | 已接受 | 中 | 2026-08-20 | 跨数据库 demo reset 的行唯一性 | MySQL/SQLite reset 使用按 `orders.id` 和 status 匹配的可移植乐观锁 UPDATE。若数据库没有强制 id 唯一，畸形 schema 或并发插入可能匹配多行；应用层预读无法跨两种方言提供原子唯一性保证。 | Schema 契约加诊断 guard | 要求 `orders.id` 是 `PRIMARY KEY` 或 `UNIQUE`，与内置 demo schema 和一般关系数据库设计一致。保留可移植的 read-side 精确基数检查，在 preview 前拒绝已经损坏的 fixture；但不声称它替代 constraint，也不为 demo Skill 增加方言分支或 framework transaction API。 | Skill 会验证只读到一行、要求显式 expected source state，并采用与 `sample-update-order-status` 相同的可移植乐观锁形状。单元回归覆盖重复行诊断拒绝；受支持执行依赖数据库唯一约束。 | 真实目标无法实施唯一约束时不得启用该 Skill。只有出现确切的跨方言 mutation，需要应用层实施多语句不变量时，才增加 adapter transaction primitive。 |
| DRR-2026-054 | 已实现 | 中 | 2026-08-27 | HMAC preview envelope 冗余与 opaque-handle 迁移 | 进程内 Store 已经权威负责签发、过期、replay 和 execution binding；长 self-describing HMAC envelope 重复暴露状态，增加模型上下文与复制错误面，还保留无法在重启后恢复 Store 的签名 secret 配置。替换时不能削弱 mismatch preservation 或一次性消费，移除响应字段也有客户端兼容成本。 | 是，明确兼容说明 | 保留公共 `preview_token` 字段和两次调用协议。生成 256-bit 随机 bearer handle，只存 digest；canonical request/execution binding 留在有界 Store，同一锁内比较/消费。废弃 secret 被忽略并只输出不含值 warning。保留绝对过期时间，移除三个重复 convenience 字段，并说明依赖它们的客户端需迁移。 | v3.7.1 已在 `mcp_sql_server.py` 与 `preview_token_store.py` 实现。代表性 handle 从 508 缩短为 43 字符（约 91.5%，不是固定 wire-size 保证）。测试直接覆盖 32 字节 CSPRNG 请求和只登记 digest 的 Store 接线，并覆盖 handle 唯一性、未知/变更值、mismatch preservation、replay、并发、重启、terminal failure 和 non-disclosure。Bearer 泄漏、同进程部署、preview 交付歧义和 commit/响应不确定性仍存在。 | 不要在未独立评审授权 UX 和服务端执行材料前增加 token-only confirm。可判定重试需与业务写同事务的 operation record 和重连状态 API；不得把 memory handle 当作该 ledger。 |
| DRR-2026-055 | 已实现 | 中 | 2026-08-27 | 默认连接 UNION policy 泄漏到无目标 prompt | `sql_assistant()` 没有 `connection_id` 参数，却描述 module-level `ALLOW_UNION`/`ALLOWED_TABLES`；二者是默认连接的兼容别名。多连接部署中，它可能为拒绝 UNION 的目标建议 UNION，或阻止允许它的目标。启动日志也像全局声明。Raw/query-Skill runtime 原本已正确使用目标 policy。 | 是 | Prompt 改为 target-neutral：通过 `list_connections()` 查看目标 alias，并依赖 runtime 权威校验；module-load 日志明确是默认 alias 摘要。保留 per-alias policy 披露且不暴露凭据或路径。 | v3.7.1 已实现。回归覆盖默认拒绝/目标允许和反向两种矩阵，检查 per-alias summary、raw-query 实际执行、prompt 不含默认派生的能力声明，以及缺少 allowlist 时的目标连接化指引。 | 无参数 prompt 只做描述，不做权威判断。未来若 prompt 接受目标参数，可渲染该目标 policy，但不能代替工具执行时检查。 |
| DRR-2026-056 | 已接受 | 中 | 2026-08-27 | 独立 `execute_sql()` 未实施完整连接 policy | Compatibility helper 会先解析目标连接并运行 `is_sql_safe()`，但不执行 MCP 层的 `ALLOW_UNION`、`ALLOWED_TABLES`、raw SHOW、system-schema 或扩展 table-scope policy。MCP raw query 与 Query Skill 会先应用完整目标 policy，所以这不是 MCP 绕过；Python 直调方仍可能高估 helper 契约。 | 记录边界，暂缓抽取共享 policy | 在 helper docstring、release/design 文档和登记表明确它只是保守 statement-shape compatibility gate；不要让 helper 导入 `mcp_sql_server`，也不要复制持续增长的 policy。 | 当前 MCP 工具仍正确按目标执行。Helper 仍在 shape check 前拒绝未知 alias，并通过目标 adapter 执行，保留 DRR-2026-033 的较窄不变量。 | 若 direct helper 使用者需要完整 policy，抽取无循环依赖的共享 policy 模块，并补 raw/query-Skill/helper parity 回归。在此之前，安全敏感集成应使用 MCP 工具或自行实施等价应用 policy。 |
| DRR-2026-057 | 已实现 | 中 | 2026-08-29 | Metadata 失败或不可用估计被压成不存在或 ready 状态 | MySQL/SQLite adapter 元数据方法曾对合法不存在和脱敏后的执行失败都返回 `[]` 或 `0`，导致核心发现工具把数据库错误报告为空数据库/schema、表不存在或 0 行估计。另有两种不可用估计也可能被误报成 0：SQLite 已发现的表名超出生成 metadata SQL 所用的保守 identifier 语法，以及 MySQL `TABLE_ROWS` 为 NULL。引入 `MetadataQueryError` 后，Skills readiness 调用方又把该失败转换成与“主动关闭检查”相同的 `None` sentinel，可能让依赖表的 Skill 在 readiness 未知时仍显示 `schema_ready=true` 且可执行。 | 是 | 对 table、column、statistics 和有界 sampling 查询失败抛出专用且脱敏的 `MetadataQueryError`；核心 MCP metadata 工具返回 `success=false`、稳定的 `error_code="metadata_query_failed"`，且不返回部分 schema。发现阶段和单表工具的逐表估计不可用时保留为 `row_count=null`，不虚构 0；估计不可用时 `row_count_approximate` 和 `is_large` 也为 null。详细 schema 检查对不支持的 identifier 仍明确失败。Skills readiness 使用明确的 disabled/available/unavailable snapshot：检查已启用但不可用时设置 `schema_check_available=false`、`schema_ready=false`，不伪造 `missing_tables`，由 `available_only=true` 过滤，并在 query SQL、mutation preview、token 签发或写入前 fail closed。只捕获 `MetadataQueryError`，不吞掉编程异常。 | 核心失败处理于 2026-08-29 在 `db_adapter.py` 与 `mcp_sql_server.py` 实现；Skills 调用方补漏于 2026-09-01 实现；不可用估计/null 语义于 2026-09-03 完成。`tests/test_db_adapter.py` 与 `tests/test_v342_meta_and_schema.py` 覆盖 adapter/核心工具失败区分，以及 discovery、`describe_table()` 和 approximate `get_table_summary()` 中的 SQLite 不支持名称和 MySQL NULL estimate 行为；`tests/test_skills_disclosure.py` 覆盖不可用 discovery/detail、完整目录诊断、关闭检查与编程异常；`tests/test_mutation_multi_connection_v36_design.py` 证明 query/mutation 会在 SQL、token 和写入前停止。错误保持脱敏，不暴露 SQL、绑定值或连接细节。 | 后续 metadata 调用方必须区分“不存在”“零”“估计不可用”“检查关闭”和“运行失败”。若将来确有部分 schema 产品需求，应设计显式的逐表错误 envelope，而不是静默省略失败表。 |
| DRR-2026-058 | 已实现 | 高 | 2026-09-10 | 影响行数检查发生在 adapter COMMIT 之后 | 两个内置 Skill 仅在 `execute_write()` 返回后检查 `rowcount`，因此零行乐观锁冲突或多行基数异常可能在数据库已经提交后才报告拒绝。 | 是 | 两个 adapter 新增仅限关键字的 `expected_rowcount`，拒绝负数、非整数和 bool；语句执行后、COMMIT 前检查，不匹配时回滚。省略时保留合法批量写兼容性。 | v3.7.2 增加类型化结果/异常和 `ExpectedRowcountMismatchError`；两个内置 Skill 均要求一行并移除提交后检查。SQLite 实数据测试证明零/多行回滚与未约束批量写。2026-09-12 另在真实 MySQL InnoDB 上以两条独立旧状态预览验证竞态：恰有一次 COMMIT 和一次影响行数不匹配回滚。 | 精确的整个 Skill 结论只覆盖两个内置单语句 Skill；自定义 Skill 保持接口，不得用单条语句的 rollback 推断整个 Skill。MySQL 竞态测试不模拟断网或 COMMIT 回执不明。 |
| DRR-2026-059 | 已实现并接受剩余风险 | 严重 | 2026-09-10 | COMMIT 异常无法区分回滚与已提交，可能诱发危险重试 | 服务端可能已提交，但连接在成功回执到达客户端前断开；若把随后 rollback 正常返回当成提交失败证据，自动重试可能产生重复副作用。 | 是，但本版不做持久化消歧 | 显式追踪 setup/execute/rowcount/commit。提交前失败只有确认 rollback 后才是 `rolled_back`；rollback 调用抛异常使用 `rollback_failed`，调用正常返回但事务/连接证据不足使用 `rollback_unconfirmed`，两者均为 `unknown`。任何 COMMIT 异常也是 `unknown`。确认 COMMIT 后 cleanup/audit/response 失败仍是 `committed`。Adapter 不重试 SQL，host 不重做 execute。 | 故障测试覆盖 execute+rollback 成功、rollback 抛异常、无法确认的本地 rollback、COMMIT 回执丢失、cleanup、取消、audit 与 response 失败；MCP 结构化结果和宿主 terminal 状态已实现。 | MySQL 结论只覆盖事务性 InnoDB DML，不覆盖非事务表、隐式提交或外部副作用。没有 operation ledger/status API 时，unknown 需要人工核查业务状态。诊断错误码只细化 unknown 原因，绝不授权重试。 |
| DRR-2026-060 | 已实现的兼容变化 | 高 | 2026-09-10 | Mutation 客户端以“未抛异常”或未校验身份的响应推断数据库成功 | 可处理执行失败过去以文本异常返回；宿主仅接受身份匹配的 `success=true`，其它响应笼统失败。缺失、畸形或外来响应可能诱发不安全后续调用。 | 是 | 结构化 mutation 结果要求 `execution_outcome`，失败带稳定 `error_code`，metadata/audit 同步。先校验 Skill/连接/DB 类型身份；timeout、异常、畸形、未知或矛盾响应全部 terminal unknown；旧服务只兼容严格成功。 | v3.7.2 server 与批准 host 已实现四类结论；宿主回归断言最多一次 execute 且之后没有写调用；`idempotentHint` 仍为 false。 | 客户端必须同时检查 `success` 和 `execution_outcome`。项目无法强制第三方宿主遵守“不确定不重试”，只能通过 schema 与文档约束。 |
| DRR-2026-061 | 暂缓 | 高 | 2026-09-10 | Mutation 未知结果的持久化恢复 | 进程内 token 无法在断连/重启后回答不确定 COMMIT 是否成功。当前业务状态符合请求预期，不等于证明该状态由本次请求造成。通用请求去重、回执和结果查询需要持久 operation identity 与生命周期语义。 | 不属于 v3.7.2 | 保留未来方向：由调用方持有稳定 operation ID，并绑定身份与已批准意图；operation record 与业务写同事务原子提交，再提供鉴权的回执/status 查询。本维护版不加入不完整的表、Redis、后台任务或状态机。 | 未新增 schema、依赖或后台能力；接受人工核查成本，重启后不恢复未知操作。在未来协议明确权威一致性、处理中状态、保留期和 terminal-not-found 语义之前，查询不到回执不能作为已回滚证据，也不授权重试。 | 出现重启后结果查询、无人值守恢复，或可量化的人工核查成本成为具体需求时，再作为独立版本公共协议重评。设计必须覆盖 retention、authorization、请求/意图绑定、idempotency、事务耦合、migration 和多副本部署。此风险条目是暂缓事项的权威记录；只有触发条件带来明确 owner 与实施范围后，才创建版本化设计文档/ADR。 |
| DRR-2026-062 | 已实现 | 严重 | 2026-09-10 | 自定义 Mutation 成功被无条件升级为 `committed` | MCP 成功分支曾在任何 `run_execute()` 返回后硬编码 `committed`。自定义 Skill 即使没有写、吞掉写异常、返回畸形/自报失败结果，或混合多条写和外部副作用，也会得到错误 COMMIT 声明；此前整个 Skill 的限制只覆盖失败路径。 | 是，修正公共结果 | 用内部 dict 子类型携带 adapter COMMIT 证据，并同时要求框架登记的 exact Skill、它的 exact 声明和保留下来的成功 `WriteExecutionResult`。框架拥有的 `MutationBase.run_execute()` 在 MCP 消费类型化结论前校验结果和权威 MCP Skill 名。普通自定义成功为 `success=true, unknown`；自定义 exact 声明在 discovery 失败；非法/false 结果为 `invalid_skill_result`；已登记 exact Skill 缺证据为 `missing_commit_evidence`；缺少框架 bookkeeping 时服务端真实尝试 best-effort 审计，不默认 true。 | 两个已登记内置 Skill 在保持公共 dict 兼容的同时保留类型化 adapter 结果。单元/MCP/host/audit 回归覆盖真实 custom-style 写、自定义 self-declaration 拒绝与基类防御、缺失证据、畸形结果、子类/基类篡改边界、响应 fallback 和 `success=true, unknown`；wrapper 所有权见 DRR-2026-064。 | Python Skill 属于可信代码，仍可故意伪造对象、修改框架登记、monkeypatch runtime 或执行不可观察的外部行为；运行时证据防止意外过度声明，不能防御同进程恶意代码。按明确兼容要求保留的旧服务端 `success=true` 识别不能追溯证明 COMMIT；依赖新保证前必须升级。自定义 Skill 若要声明 committed，需要未来单独评审的整个操作协议。 |
| DRR-2026-063 | 已实现并保留传输边界 | 高 | 2026-09-10 | COMMIT 取消丢失结构化 unknown 证据 | Adapter 的 COMMIT handler 会在 `asyncio.CancelledError` 后清理，但因它属于 `BaseException` 而原样抛出，MCP 无法像普通 COMMIT 异常一样返回结构化 `unknown`；宿主只是因为没有结果才保守判 unknown。 | 是 | rollback/连接清理后，把 COMMIT 抛出的普通 `Exception` 与 `asyncio.CancelledError` 都转换为 `WriteExecutionError(commit_outcome_unknown, unknown)`；其它进程控制异常继续传播。COMMIT 前取消在清理后仍传播，以免静默阻止 shutdown/timeout cancellation。 | MySQL/SQLite 故障测试均注入 COMMIT 取消并断言类型化 unknown、资源清理且没有虚假 rollback 结论；既有 MCP 路径消费该类型化异常并返回结构化 unknown。 | 框架或 transport 可能已经无法投递响应，客户端对缺失响应仍只能判 unknown。`KeyboardInterrupt`、`SystemExit`、`GeneratorExit` 和 COMMIT 前取消可能在清理后传播，而不产生结构化 payload。 |
| DRR-2026-064 | 已实现的兼容变化 | 高 | 2026-09-12 | 框架执行包装器可被覆盖 | 自定义 Mutation 可以直接覆盖 `MutationBase.run_execute()`，或通过中间父类继承替代实现，从而绕过集中式结果校验、整个 Skill 结论、错误脱敏和执行审计。MCP 为此重复了大量基类策略，形成两个可能漂移的实现。 | 是，在正式发布前修正 | 用 `@final` 标记 `run_execute()`，并在 discovery 时把静态解析到的方法与框架方法做身份比较；直接和继承覆盖均拒绝，并给出迁移提示。MCP 直接调用基类 wrapper，不通过自定义实例虚分派。业务扩展继续使用 `execute()` 与 `execute_with_binding()`。删除 MCP 重复的业务分类，只保留面向基类篡改或框架故障的窄型 fail-closed 类型结果检查。 | Loader 回归覆盖直接覆盖、继承覆盖和 `@final` 标记；MCP 回归证明加载后子类 lookalike 会被忽略、非法框架返回会 fail closed，普通自定义和 exact 内置路径继续经过基类包装器。此前覆盖 wrapper 的发布前自定义 Skill 必须迁移后才能加载；版本仍为 v3.7.2。 | 这是可强制的扩展契约，不是不可信代码 sandbox。可信代码仍能 monkeypatch 基类或其它运行时对象，也能执行隐藏副作用。MCP guard 对检测到的非法框架结果报告 `unknown`，但无法观察所有同进程恶意行为。正式发布或出现已知第三方采用后，应重新评估兼容与废弃策略。 |

| DRR-2026-065 | 已实现 | 严重 | 2026-09-12 | 仅用内置 Skill 名称判断精确结论资格 | DRR-2026-062 首次修复仅按公开名称允许 `exact_transaction_outcome=True`。另一个 `SKILLS_DIR` 可加载同名双语句自定义 Mutation：第一条已提交、第二条回滚，却对整个 Skill 返回 `rolled_back`。这属于正常配置路径，不只是恶意 monkeypatch。 | 是，纳入 v3.7.2 | 核对 mutation 源码解析后的路径是否为对应的仓库内置文件，只有此前提成立才允许 exact 声明并为本次 discovery 登记实际加载的类身份。执行期同时校验身份、权威名称、声明及 adapter 证据。同名自定义 exact 声明拒绝加载；默认 flag 的同名自定义 Skill 可加载，但整个操作结论保持 `unknown`。每次 discovery 替换进程内登记。 | 单元回归覆盖两个保留名称、真正内置类登记及重新发现后清空登记；真实 FastMCP Client 使用项目内临时 `SKILLS_DIR` 证明同名双写自定义 Skill 第一条 COMMIT 后第二条行数不匹配回滚，返回 `success=false, unknown` 且数据库中第一条变更仍存在。没有新增 schema、公共字段或依赖。 | 可信 Python Skill 仍能故意修改框架/登记或内置源码，不是不可信插件沙箱。精确结论仅覆盖经过源码评审的两个内置单语句 Skill；解析至同一内置文件的符号链接使用同一已评审源码，同时受既有路径包含检查约束。全局重新 discovery 可能保守撤销旧类身份，但不得把自定义类升级为精确资格。连接级 `MUTATION_SKILLS` 仍有意按当前 catalog 名称授权，不校验源码身份；更换 `SKILLS_DIR` 必须同时复核源码和写入授权策略。 |
| DRR-2026-069 | 已实现的兼容强化 | 高 | 2026-09-16 | 关闭 Mutation 后仍会导入自定义 mutation 模块 | 自最初的 v3.0 Skills 提交 `04603e4` 起，只要启用 Skills，discovery 即使在 `SKILLS_ALLOW_MUTATIONS=0` 时也会执行各 `mutation.py`。后来的示例目录与忽略规则提交 `8753f30`/`dba3a29` 只是让这个既有边界更显眼，并非问题来源。因此，禁写部署启动时仍会运行可信扩展代码。 | 是，在正式发布前修正 | 增加由 `SKILLS_ALLOW_MUTATIONS` 控制的显式 discovery 模式。禁写时只校验元数据、声明文件和路径包含关系，不导入 mutation 模块，也不构造 mutation 类；Query Skill 加载不变。 | Loader 与 FastMCP 集成哨兵使用“导入即产生可观察状态”的 mutation 模块：禁写时状态不存在、mutation 工具不注册，同时元数据仍可发现；启用路径的既有测试继续覆盖类和 plan 校验。 | 这会减少无必要的启动期代码执行，但不会把已启用的 Python Skill 变成不可信或沙箱代码。启用 Mutation 后仍必须审核模块。Git 忽略规则既不是执行授权，也不是安全边界。 |
| DRR-2026-070 | 已实现的发布前契约调整 | 高 | 2026-09-16 | Python 回调可能过度声明整个 Skill 的精确结论 | v3.7.2 的源码/类登记能阻止普通自定义代码自行升级，但 Python Skill 返回 adapter 证据仍不能证明它此前没有执行数据库写、文件/网络操作或隐藏回调副作用；同时，精确结论被限制在两个内置实现，缺少安全的自定义扩展契约。 | 是，在正式发布前修正 | 用冻结的 `ManagedMutationPlan` 取代 exact flag 与源码/类登记。Discovery 校验一条直接 `INSERT`、`UPDATE` 或 `DELETE`、完整绑定、显式参数/preview binding/常量来源、预期行数和结果映射，并缓存不可变 plan。消费 token 后由框架解析值并仅直接调用 adapter 一次，确认阶段不执行 Skill 回调。命令式 `MutationBase` 仍可扩展，但整个操作始终报告 `unknown`。 | 两个内置 Mutation 已迁移为受管 plan。测试覆盖 plan 校验、缺失/非标量值在访问 adapter 前失败、精确成功/失败证据、缺少 COMMIT 证据、取消和确认期无回调；旧 `exact_transaction_outcome` 声明在 discovery 时给出迁移提示并拒绝。 | “精确”刻意只描述框架管理的那一条数据库语句的事务结论，不证明导入期或 preview 期 Python 副作用，也不覆盖数据库 trigger/UDF 的外部副作用、MySQL 非事务表、隐式提交或 COMMIT 回执丢失。可变业务约束必须保留在语句谓词中；启用的 Skill 模块仍是可信应用代码。 |

**v3.7.2 复查补充（2026-09-10），DRR-2026-059/060/062：** 回滚确认新增
事务活跃状态、回滚前后连接有效性检查；SQLAlchemy 在连接失效或关闭后仅完成本地
清理时保持 unknown，不通过重连推断原事务。加载后 wrapper 篡改与意外框架异常统一
返回脱敏 unknown 并尝试失败审计；宿主非字符串 outcome 不再因集合查找抛异常。
兜底审计异常不覆盖执行证据；序列化失败的备用响应丢弃不可序列化的原始结果。
回归覆盖真实 SQLAlchemy 事务、写后自定义异常、审计失败、畸形 JSON outcome 和
不可序列化的成功结果；这些测试不等于真实 MySQL 网络故障验证，也不提供持久恢复。

**v3.7.2 诊断与文档补充（2026-09-11），DRR-2026-059/061：**
`rollback_failed` 现在只表示 rollback 抛异常；本地清理正常返回但缺少数据库证据时
使用 `rollback_unconfirmed`。两者的执行结论仍均为 `unknown`。未来可选回执方向继续
以 DRR-2026-061 作为权威记录，不另建可能漂移的推测性计划文档。只有已记录的触发
条件形成明确 owner、范围、兼容方案和实施决策后，才值得创建版本化设计文档/ADR。

**v3.7.2 扩展契约补充（2026-09-12），DRR-2026-062/064：**
`MutationBase.run_execute()` 现由框架拥有，加载的自定义类不能直接替换，也不能通过
中间父类继承替代实现。自定义逻辑迁移到 `execute()` 或
`execute_with_binding()`。这项有意的发布前契约调整删除了 MCP 重复的业务分类，
同时保留窄型 fail-closed 边界 guard。`@final` 本身只提示类型检查器，loader 才负责
运行时强制。MCP 直接调用基类 wrapper，加载后子类替换会被忽略；可信同进程代码
仍不属于不可信插件 sandbox。同一复查还把 `exact_transaction_outcome=True` 限定给
两个已登记内置 Skill，并由基类复核权威 Skill 名。但首次仅核对名称的方案
无法识别同名自定义源码；DRR-2026-065 记录了追加的内置源码路径与加载类身份
复核，才关闭普通配置路径下的 self-upgrade 漏洞。
自定义 Skill 的行数不匹配说明也不再宣称整个 Skill 未提交：即使本条语句已回滚，
此前的自定义语句仍可能已提交。

**v3.7.3 受管契约补充（2026-09-16），DRR-2026-069/070：** 上述 v3.7.2 文字作为
历史记录保留。现行契约已删除 exact flag 与源码/类登记：受管确认不实例化或调用
Skill Python，只执行缓存的单条语句；命令式回调保持 `unknown`。关闭 Mutation 后
也不再导入自定义 mutation 模块。精确证据只覆盖该框架受管语句，不证明 import、
preview 或数据库之外的副作用。

**同轮补充：preview 权威来源与审计一致性。** 初版受管实现仍接受 Skill 自行展示
SQL/绑定值，确认时却执行独立的缓存计划。现改由框架从计划与最终序列化 binding
生成预览字段，并在 token 签发前解析 SQL 值及结果映射；Skill 提供保留字段会被
拒绝。结果映射同时保留 `error`/`error_code`。临时 `SKILLS_DIR` 下的非内置 Skill
经 FastMCP Client 验证精确提交、状态变化回滚、展示/执行 SQL 与值一致、拒绝时
不签 token，以及确认阶段无 Skill 回调。业务文字及预览期 Python 仍属可信内容/
代码，不在该保证之内。

**DRR-2026-057 补充（2026-09-03）：** SQLite 表若在 discovery 与有界采样之间
消失，现在会得到不可用估计（`row_count=null`），不再误报为零行；MySQL 单表
metadata row 缺失时也采用相同 unknown 语义。FastMCP 已启用
strict input validation，使协议输入必须匹配发布的 JSON Schema；关键 boolean 的
Python 直调仍保留显式 handler 校验。Server 重启无法清除 Host 自有的工具缓存，
因此重新连接或重载 Host，并重新获取 `tools/list`，仍是独立的发布验收步骤。

### Agent 路由复查（2026-09-13）

| ID | 状态 | 风险等级 | 首次登记日期 | 领域 | 风险或关注点 | 是否计划修改 | 修改逻辑 | 当前结果 | 下一步 |
|---|---|---|---|---|---|---|---|---|---|
| DRR-2026-066 | 待修复 | 中 | 2026-09-13 | 诊断范围选择及用户当次限制 | 最初三个独立 Luna 样本有两个把未明确范围的诊断扩大到全部；后续发现用途猜库、未请求先诊断和冲突处理差异。最新 fixture 还出现检查明确禁止目标，属于违反用户当次意图，未证明配置中的 SQL/写策略被绕过。 | 路由指引已实现；明确禁止目标的行为仍未解决 | 9 月 22 日起统一 check_connection：默认／指定单查及显式 scope=all，共用独立诊断与报告契约；合并接口不等于补齐当次意图授权。普通无目标诊断仅默认；确定目标来自用户选择、可信请求绑定或唯一结构化 db_type 匹配。用途/指代/类型未明确时至多列配置后等待。对于已请求诊断，明确只允许一个确定目标或默认时限制宽泛范围；禁止包含连接诊断，拒绝部分或无法协调限制时等待。不增加服务器推断式会话路由或模型填写的确认字段。 | [9 月 15 日原生记录](../validation/v3.7/V3_7_3_LIVE_MCP_TEST_CONNECTION_ROUTING_2026_09_15_ZH.md)保留旧契约的 12 个上下文/36 次调用：用途、默认和全部工作流通过，三个冲突未澄清。后续[fixture 记录](../validation/v3.7/V3_7_3_LIVE_MCP_TEST_CONNECTION_BOUNDARIES_2026_09_15_ZH.md)两阶段共 15 个上下文/13 次调用；最终明确允许收窄的样本 2/2 通过、拒绝部分的样本停止，但明确禁止组仍有 2/3 上下文发起禁止目标检查，共三次调用。 | 保持开放；不改旧评分、不混合不同阶段错误率。9 月 22 日已连接 Host 暴露统一契约，各范围原生诊断通过；完整任务仍作为 fixture 证据独立评分。自然语言指引不能强制执行每次请求范围。要求硬性目标限制的部署，必须在上线前提供可信应用/Host 上下文及调用前校验，覆盖显式别名、实际隐式默认及批量的全部配置目标，见[严格部署验收条件](../guides/MCP_AGENT_BEHAVIOR_VALIDATION_ZH.md#18-限制优先级与配置解读的可复用验收)。受信任本地使用可保留该已知限制，不因此否定整次维护修复；不能用只读淡化禁止目标检查，也不无限堆叠同义提示。绑定/类型/其它模型等仍待验收，结果解读另记 068。 |
| DRR-2026-067 | 已实现 | 低 | 2026-09-13 | 参数示例与工具 schema 不一致 | 三个完整 Luna 任务首次都向 `describe_table` 传了 `name`，而 schema 要求 `table_name`。公开 `list_tables` 描述和结果提示含 `describe_table(name)`；三次均被拒绝后纠正，增加延迟与失败点。已观察到关联，尚未证明因果，也无法确定校验发生在 Host 还是服务端具体组件。 | 示例修复完成；原生 Host 初步验收通过 | 以 table_name 和 skill_name 为唯一 schema 参数名，对齐工具 hint、实际获取的 sql_assistant 及当前 README 示例，保留历史轨迹。不新增别名或自动改参。 | 2026-09-15 三个原生完整任务再次首次正确传 table_name。完整 review 发现 Skill 工具还存在历史遗留的 name 示例，已统一当前示例为 skill_name。新增 mutation 注册开/关两种配置的 prompts/get 与 tools/list 对照，旧示例先失败、修复后通过；未执行 Skill 或 preview。元数据测试 49 passed；全量 637 passed、4 skipped；六个 Python 文件 Pyright 通过。 | 保留协议/schema 对照回归。Skill 参数补充修复的证据来自本地协议测试，本轮未做原生 Skill 行为实测。小样本不保证未来零误填，也不能关闭路由和结果解读风险。 |
| DRR-2026-068 | 已实现 | 低 | 2026-09-15 | 把配置白名单说成数据库事实 | 三个原生 Luna 完整任务中，两次首轮仅 list_connections 就声称 SQLite 只有 orders 表。allowed_tables 是策略，不证明表存在或物理库完整清单；后续查询不能追认先前无依据的表述。 | 工具/结果说明及初步本地验收已实现 | list_connections 描述及新增 hint 明确配置允许范围；同步双语 README。发现配置仍不访问数据库，不为证明表述而自动探测结构。 | 三项协议用例证明列配置不连接、创建或修改存在/缺失的数据库，并区分配置、可见和物理表集合。全量 640 passed、4 skipped；七个 Python 文件 Pyright 通过。最终三个隔离 Luna fixture 样本均正确限定配置事实，见[补充实测](../validation/v3.7/V3_7_3_LIVE_MCP_TEST_CONNECTION_BOUNDARIES_2026_09_15_ZH.md)。 | 已实现表示代码/文档及初步本地验收，不保证未来零误述；9 月 22 日已连接 Host 已返回配置性质 hint；仅诊断冒烟不证明原生 Agent 已正确理解该 hint。保留原无依据表述，范围与解读分开评分；未新增运行时 gate 或自动结构探测。 |

同日未修改版本复测：3 个新的相同含糊请求均选择批量工具，3 个新的完整会话
也均先误传 `name` 后纠正。这些是追加基线证据，不是修改后验证；
该次复测时 DRR-2026-066/067 均为待修复；上表证据保留 9 月 15 日的观察，066 当前方案于 9 月 22 日更新为统一接口。不同措辞或约束的样本不合并成总体错误率。

可复用步骤见[Agent 行为验证方法](../guides/MCP_AGENT_BEHAVIOR_VALIDATION_ZH.md)。
9 月 13–15 日的登记及提示／示例修正属于当时的文档和说明更新：该阶段输入契约、校验约束及既有输出字段保持不变，list_connections 的输出新增说明性 hint 字段。通常这是兼容的返回扩展，但自行使用封闭响应模型的客户端可能拒绝额外字段，需要同步更新模型，不能保证所有此类客户端都兼容。上表记录当前状态，未完成的行为和部署验收不标记关闭。
方案参考 [Anthropic 的任务与轨迹评估建议](https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents)
及 [Google 的函数/参数说明建议](https://ai.google.dev/gemini-api/docs/function-calling)。

### 统一诊断补充评审（2026-09-22）

合并工具后 DRR-2026-066 仍保持开放。显式 `scope="all"` 是模型输入，不是许可；
可信 Host／应用必须在每次动作前覆盖已解析别名、实际默认及全查的全部配置目标。
历史失败仍是失败，源码／fixture 验证不能证明刷新后的原生 Host 验收通过。

本次有意删除复数工具及旧单查输出。两种范围共用工作线程持有的新建连接和必填
scope 的报告。客户端需要迁移解析，单查也承受现有忙／清理禁用的可用性代价。
连通性与资源清理仍分开，不引入新的恢复或授权子系统。

9 月 22 日的 C 文案试验又出现用途目标未确定却检查默认连接的样本。即使只读
连接成功，它仍属于路由失败。最终源码按冻结规则恢复 B 文案，保留 C 失败轨迹；
恢复 B 后的全新样本也出现同类默认探测，因此并非 C 独有。回退既不补齐当次
授权缺口，也不证明 Agent 以后不会误用。

后续已连接 Host 评审确认统一签名、默认／指定／全部诊断成功，以及冲突参数的
工具错误。这消除了该 Host 的元数据刷新疑问，不代表补齐当次授权。用户授权
补齐的完整任务独立于此前阻断记录，使用合成 SQLite 数据库，不能冒充原生
业务工作流验收；历史禁止访问失败仍保留。
新 cohort 已完成九个六轮任务、63 次 MCP 调用，未观察到新的范围违规；九次
用户故意拼错的别名均拒绝且未回退。答复语言与百分比正文措辞偏差独立评分，
这些新观察不抵销此前用途未定／明确禁止场景的失败。

回归覆盖位于 `tests/test_connection_diagnostics.py` 及多连接／元数据协议测试。
本轮验证与分阶段 Agent 结果见[9 月 22 日记录](../validation/v3.7/V3_7_3_LIVE_MCP_TEST_UNIFIED_CONNECTION_DIAGNOSTICS_2026_09_22_ZH.md)，上文数量均属于历史阶段。详见
[设计与迁移记录](../guides/V3_7_CONNECTION_DIAGNOSTICS_DESIGN_ZH.md)。

### v3.8.1 拒绝恢复与令牌到期报告（2026-10-01）

| ID | 状态 | 风险等级 | 首次登记日期 | 领域 | 风险或关注点 | 是否计划修改 | 修改逻辑 | 当前结果 | 下一步 |
|---|---|---|---|---|---|---|---|---|---|
| DRR-2026-071 | 已实现（仅线索） | 低 | 2026-10-01 | Skill 拒绝后过早断定“无路径” | `delivered → shipped` 预览被拒后，Copilot Agent 未检索可执行的重置 Skill，直接称需管理员处理；相关元数据原本可被发现。子代理在拒绝由父代理转述时，即使加入 Agent 规则仍不发起发现调用。 | 是 | `validation_failed` 时返回可选 `related_available_skills`：被拒 Skill 自己的 `related_skills` 中、按 `list_skills` 同一可用性判断在同一连接可执行的写入 Skill 名称。不含参数、建议、授权、批准或令牌；查找失败时省略，不改变 `success`、`error_code`、`execution_outcome`。同时补反向关联、生命周期描述、非原子恢复说明，并在工具说明中禁止绕过规则或更换目标。 | 796 passed、4 skipped。Host 重启后，简短拒绝提示 3/3 找到重置路径且未预览替代 Skill。线索依赖作者声明的关联，满足条件的拒绝会多一次 readiness 元数据查询，只暴露该连接 `list_skills` 已可见的名称。Agent 仍可能忽略或误用；替代路径的每次写入仍需单独预览和批准。 10-12 重启收尾：原生恢复路径发现 3/3、完整路线 2/3；一个漏掉 confirmed 的原答案保留，追加 full 元数据复核后修正，实际 pending→shipped 预览被规则拒绝，0 次执行。组合任务调用 9/5/5，含两次误用 category=mutation 的空搜索；不作历史成本保证。 | 若需要图级替代路径，或 Agent 把线索当作授权，则重新评审。未经独立设计不在服务端载荷中加入执行建议。 |
| DRR-2026-072 | 已接受 | 低 | 2026-10-01 | Agent 误判预览令牌到期 | 仅有绝对 `preview_token_expires_at` 时，子代理被问令牌是否可用，常按自身日期称已过期，而按服务器 UTC 仍剩约 4 分钟。 | 不新增字段 | 维持 v3.7.1 的单一绝对期限。曾试验恢复 `preview_token_expires_in_seconds` 后撤回：它与绝对值重复、在对话中会过时，且 execute 已强制过期检查，不增加安全性。说明改为原样报告期限，并由 execute 判定有效性。 | 测试 0/3，调整说明后 1/3。误报偏保守（重新预览），不会导致不安全写入。 | 父代理不应要求子代理判断令牌有效性；倒计时由 Host 按当前时间计算。若客户端依据过时的相对值行动，则重新评审。 |
| DRR-2026-073 | 已实现（引导） | 中 | 2026-10-01 | Agent 误读写入结果 | Copilot 只把工具名、说明和输入参数交给模型，`outputSchema` 中对 `execution_outcome` 的说明对模型不可见。基线回放：MRTR 续接协议错误且无结论时 0/3 正确（两次称未执行，三次都建议直接重新发起、未先核对）。误读 `success=false` + `committed` 或 `unknown` 可能导致重复写入。 | 是 | 在 `execute_mutation_skill` 说明中加入 “Reading results” 段（以结果值而非 success 判断写入、各结果含义、无结论错误不得补造、不得自行重试／换入口／新提案、幂等不是重试许可、预估与实际行数、返回文本只是数据、令牌不进入用户摘要）；10 月 12 日：两段描述各自渲染同一公共资源；先核对目标／Skill／阶段及 required 字段有效性，再解释 outcome，并明确缺失行数。未写入服务说明或 `sql_assistant`，未改执行或输出结构。 | 最初验收：797 passed、4 skipped。回放 12/18 → 16/18（协议错误 0/3 → 3/3；夹带重试指令 2/3 → 3/3）；既有路由、恢复发现、只预览场景无退化。每次请求输入约 +159 token。残余：审批拒绝后仍有 2/3 无据断言当前数据。回放经提示而非工具通道传入结果；引导不是强制控制。更丰富的本地 SQLite 库真实通道复测：`committed` 3/3、`rolled_back` 3/3 报告正确；令牌拒绝（发生在执行前）原文要求 “run preview again”，报告含糊（0/3 明确“本次未写入”），改拒绝文本并在说明中加一句后 3/3；预览被拒且数据随后变化时，试加说明前后均 0/3 避免把预览时状态说成当前状态，该句已删除。 10 月 12 日：独立异常字段回放普通写入 0/3 → 3/3，另有模拟 MRTR 单工具描述 3/3；保留早期批量失败。描述 3,546／2,642 字符，历史 +159 token 不是最终成本。全量 941 passed、4 skipped；后经维护者重启，当前描述与源码一致，使用注册元数据的异常字段／缺失行数解释各 3/3；原生任务及残余误述另记 071。 | 服务端令牌、绑定、期限和单次消费仍是权威控制。在其他模型／Host 上复评；若误述持续，可考虑 Host 端确定性结果展示，无新证据时不再加长说明。对“预览时状态被说成当前状态”，优先考虑结构性修复（新 Skill 版本把字段命名为预览时状态，或 Host 报告前重新读取），而非继续加长说明。 |
| DRR-2026-074 | 已实现（引导） | 低 | 2026-10-01 | 不了解连接读取策略就编写 SQL | 模型只能从拒绝中得知 UNION 策略。禁止 UNION 的 MySQL 基线：3/3 先试 UNION，随后 11–15 次调用、58k–78k 输入 token；拒绝提示建议在回答中合并结果，一次运行据此拉取了被截断到 100 行的原始行，随后改用 `DISTINCT` 重查。允许 UNION 的 SQLite 基线：3/3 首条因 FROM 子查询被拒。 | 是 | 服务说明（及无参数 `sql_assistant`）按连接列出别名、数据库类型、禁止读取或范围类型及表数量、是否允许 UNION；启动时从已加载配置生成，不访问数据库、不列表名；最多 12 行加数量摘要。补充“FROM 子查询一律拒绝、改用 CTE”和“允许 UNION 不扩大范围”。UNION 拒绝提示保留前缀，改为建议一条允许的查询，或在 SQL 中聚合并检查截断与重复。未采纳 `sql_assistant(connection_id)`：Copilot 中 Prompt 仅由用户调用。 | 799 passed、4 skipped。禁止 UNION：0/3 被拒、2 次调用、约 44.0k token；允许 UNION：0/3 被拒、1 次调用、约 27.9k token；答案 6/6 正确。路由、恢复发现、只预览、MRTR 错误与提交对照场景均保持 3/3，调用次数不变。每次请求固定输入约 +184 token。残余：重启并刷新 Host 前文本不变；Host 可能忽略 instructions；别名与范围大小可见（`list_connections()` 已暴露）。引导不是强制控制。 10 月 12 日：真实 Runtime A/B/A 及注册 Prompt 隔离、无 Adapter 获取／构造检查通过；三次 GPT-6 Luna 原生聚合均返回独立真值 1,023／20、720／38，零策略拒绝。用量另记，不与不同历史环境作成本保证。 | 执行时策略检查仍是权威。若常超过上限、Host 允许模型获取 Prompt，或配置支持运行时重载，则重新评审。 |
| DRR-2026-075 | 已实现 | 中 | 2026-10-03 | 通过 SELECT 读取服务器、账号与文件路径状态 | 原始 SHOW 与系统库已被拒绝，但 `query()` 仍接受 SELECT 形式的服务器状态读取。在 MySQL 8.0.25 测试服务器上实测（未记录具体值）：`@@hostname`、`@@datadir`、`@@secure_file_priv`、`@@version_compile_os` 与 `CURRENT_USER()` 均可读。SQLite 在 `read.mode="all"` 时，`pragma_database_list` 会返回数据库文件路径。这些值不是表数据，表范围无法授权。 | 是 | 共享读取策略（原始 `query()` 及 Query Skill 启动／运行时检查）按 token 而非正则拒绝：`@@` 系统变量；`USER`、`CURRENT_USER`、`SESSION_USER`、`SYSTEM_USER`、`CURRENT_ROLE`；关系位置的内置 PRAGMA 对象（含引用名）；普通 pragma_ 列／别名及非保留业务表名允许。字符串字面量、保留 PRAGMA 关系名之外的普通引号标识符、名为 `user` 的普通列、用户变量（`@x`）、`VERSION()` 与 `sqlite_version()` 仍允许。 | 测试覆盖拒绝与放行两类形式。这是黑名单而非函数白名单：其他函数仍可用，包括 `DATABASE()`、`CONNECTION_ID()`、`UUID()`、`SLEEP()`、`BENCHMARK()`，以及 `GET_LOCK()` 等命名锁函数（会在连接池的会话上留下副作用）。最小权限数据库账号仍是主要控制。 | 另行评审锁、SLEEP 与 BENCHMARK 函数；如需更严格的读取模式，考虑函数白名单。 |
| DRR-2026-076 | 已实现 | 中 | 2026-10-03 | MySQL 表名大小写与白名单身份 | 加载器把白名单条目转为小写，策略也把每个表引用转为小写。MySQL 在 `lower_case_table_names=0`（Linux 默认）时 `Orders` 与 `orders` 是不同的表，因此允许 `orders` 也会放行 `SELECT * FROM Orders`，并让 `list_tables()`/`get_full_schema()` 列出并描述 `Orders`。测试服务器（Windows，`lower_case_table_names=1`）不受影响。 | 是 | MySQL 连接保留配置中的大小写，并在原始查询、Query Skill 检查、`describe_table()`、`list_tables()`、`get_full_schema()` 及 Query Skill 可用性中精确比较表引用（`ConnectionPolicy.case_sensitive_tables`、`allows_table()`）。CTE 名称精确匹配，大小写不同的引用按基表检查。SQLite 仍不区分大小写。未新增读取服务器设置的数据库 I/O。 | 测试覆盖 MySQL 精确大小写匹配、CTE 大小写和加载器行为；SQLite 行为不变。偏保守的取舍：在不区分大小写的服务器（`lower_case_table_names=1/2`）上，大小写与存储名不同的查询或白名单条目现会被拒绝或隐藏，大小写不同的 CTE 引用会按基表检查。10 月 12 日：schema readiness 也按连接表身份检查（MySQL 精确、SQLite 折叠），仍为参考，不是授权。 | MySQL 白名单条目应使用存储名。若合法的不区分大小写部署受阻，考虑按连接读取 `lower_case_table_names`。 10 月 13 日：真实 Oracle 8.0.25／大小写配置 1 确认 F/f 保守误拒；保留精确匹配并给 CTE 大小写提示，MySQL 0/2 与 MariaDB 真实矩阵未验收。 |
| DRR-2026-077 | 已接受 | 低 | 2026-10-03 | 通过 describe_table() 披露索引元数据 | Agent 无法列出索引（MySQL 与 SQLite 任务均 0/3）。曾考虑在 `query()` 中按连接开关允许有限原始 `SHOW INDEX`/`SHOW COLUMNS`。 | 是（结构化，而非原始 SHOW） | 对已授权的表，`describe_table()` 返回索引名、是否主键、是否唯一、按序键列、表达式／部分索引标记及 MySQL 非 BTREE 类型；在既有检查之后，由适配器以绑定参数读取。不新增开关、对象范围或 SQL 语法。不返回注释、表达式原文、部分索引条件与基数；不选 `CARDINALITY`，不会刷新统计信息。仅索引读取失败时报告 `indexes_status="unavailable"`，不返回空列表。 | 两库实测均 3/3，1–3 次调用；输出与原生 `SHOW INDEX` 和 PRAGMA 一致。残余：索引名可能透露业务意图；除移出白名单外，运维无法隐藏已授权表的索引；Agent 需要表达式原文时无法获得。未提供原始 SHOW。 10 月 12 日：保留前缀／方向／collation／优化器可见性，固定 main 与采集预算（079）。已批准的默认增加元数据工作／披露，不能称默认成本不变。原生 Luna 索引 3/3 正确，各两次调用，用量见最终证据。 | 仅在部署确有需要时增加开关或字段过滤。仅在出现明确兼容需求时独立评估原始 SHOW。 |
| DRR-2026-078 | 已实现 | 中 | 2026-10-12 | CTE 与关系对象范围提取 | 把 CTE 名全局视为可见会漏掉更早／非递归定义中的物理表；特殊关系形式可能未完整检查。 | 是 | 按定义顺序／显式递归判断可见性，复用关系提取；关系括号组、单引号对象、ODBC 包装与 TABLE 形式在数据库访问前拒绝。 | tests/test_read_policy_review.py 覆盖拒绝和正常语法；隔离 MySQL 原生 CTE 确实读取四行夹具，原策略放行而修复后白名单拒绝。全量 941 passed。保守子集可能拒绝 SQLite 前向／隐式递归。 | 只有具备作用域／方言解析证据才扩大支持；保留最小权限账号，不宣称完整 SQL 解析器。 |
| DRR-2026-079 | 已实现 | 中 | 2026-10-12 | 索引属性、namespace 与采集资源 | 缺失前缀／方向／可见性可能被解读为更强索引；main/temp 错配及无界采集会造成误述或额外工作／输出。 | 是 | SQLite 元数据固定 main；保留 key_parts 和优化器可见性，MySQL 探测能力但不弱化错误。完整采集限 128 索引、2048 键项、64 KiB 索引数组 UTF-8 和协作式剩余时间；失败保留列并报告 unavailable/null。 | tests/test_table_indexes.py、tests/test_index_metadata_boundaries.py 覆盖真实 SQLite、同名阴影、精确预算、共享查询与错误。真实 MySQL 8.0.25／SQLite 夹具对照原生元数据并清理；5.7 路径为替身。无表达式原文／部分谓词，字节／时间限制不覆盖整个工具或硬取消驱动。 | 依据实际部署负载才复评默认；不能从元数据推导完整 DDL、必然使用索引或会话隔离。 |
| DRR-2026-080 | 已实现 | SQLite 白名单下高 | 2026-10-13 | SQLite 成员关系漏查 | IN/NOT IN 右侧裸表／函数未进入 FROM/JOIN 提取，未授权成员探测及 PRAGMA 元数据可放行。 | 是 | 共享 membership targets 与作用域表／虚拟对象检查、PRAGMA 保留名；保留授权的受支持 SQL。 | 真实 SQLite／网关回归覆盖拒绝、放行及执行前拒绝；临时夹具清理。未支持形态仍保守。 | 扩展语法需原生正反例。authorizer 原型未上线；缓存、虚拟对象及可信内部操作需单独设计。 |
| DRR-2026-081 | 已实现；当前 Host 核验通过 | 中 | 2026-10-13 | 策略原因与依赖解析不一致 | bool／元组拒绝混淆原因，关键字／依赖正则误读字符串。 | 是 | PolicyDecision 统一原因码／说明／提示；token 检查与 scoped 依赖解析供 Query Skill 启动／发现／执行和 raw query 共用；执行策略拒绝先于 readiness。 | 回归覆盖字符串、引号依赖、按目标判定和拒绝不执行；重启后原生检查及三次同任务 Luna 通过，每次调用 4→3；输入均值 +2.7%、中位数 +5.4%，发现／编排混杂，不作成本保证。  追加两协议 20 次 Client 调用确认 SQLite CTE F/f 假依赖：raw query 成功，Skill 白名单误拒，all 的 readiness 误报缺表；13 日当时未修。  14 日分离声明／按目标推断并同步搜索／readiness／执行，复现边界已修复；最新源码检查与十次原生只读核验见验收追加章节。 | 继续按目标验证复杂语法，hint 不授予权限；旧 Luna usage 仅对应 13 日快照，CTE 能力／身份细节见 083/084。 |
| DRR-2026-082 | 已实现 | 中 | 2026-10-13 | 查询错误丢失恢复原因 | list 或错误字符串接口掩盖缺失列／函数，连接丢失误作超时。 | 是 | DatabaseQueryError 使用驱动码／SQLite 前缀和固定脱敏类别；读取／metadata 调用点同步；Query Skill SQL／策略错误改为结构化业务结果。 | 原生 SQLite／MySQL 与两协议回归验证类别、脱敏和 metadata unavailable；写入 outcome 独立。发布前直接同步调用方，不加旧接口包装。 | 新驱动错误可能仍通用；查询原因不能证明写入状态；参数／目标／readiness 可继续 ToolError。 |
| DRR-2026-083 | 已实现；当前 Host 核验通过 | 中 | 2026-10-14 | CTE 比较未按实际连接规则 | MySQL 精确匹配可误拒 F/f；统一 lower 又可能把物理表当作 CTE。 | 是 | 常量、无 FROM 的重名探测验证 ASCII CTE 比较，成功按适配器缓存；未知保持精确、30 秒后可重试，close 清除；依赖解析分离 CTE 比较与物理授权。 | 当前 MySQL 1 与两协议真实 Client 验证兼容、缓存一次和确定拒绝前不连库；声明／推断独立，限定／自／前向依赖保留。首次歧义可有可信常量 I/O，无额外 MCP 步骤。 | 非 ASCII 大小写保守；0/2 与 MariaDB 独立实测待补；不承诺完整 SQL 解析或总体成本下降。 |
| DRR-2026-084 | 已实现；最终 Host 核验通过 | 高（SQLite 白名单，特殊标识符） | 2026-10-14 | 名称规范化改变对象身份 | Unicode lower／strip、整体空白压缩和重复解引用可把物理名错认成 CTE／授权对象，或造成假依赖。 | 是 | 折叠 ASCII，处理空白 token 并保留引号内容，从原始标识符组件仅解码一层；声明名与显式限定名保留，标签规则独立。 | 原生 SQLite 与最后 25 项回归覆盖空格／制表符／换行、分隔符、CTE／授权及 raw／Skill 一致性；全量 1114、安装 stdio 22 项、维护者重启后的最后主会话 11 项通过，早期证据保留。 | 元数据标识符语法仍有限制，不承诺任意引号／完整方言；新证据单独索引，不把旧 Luna usage 归给最终源码。 |
| DRR-2026-085 | 已实现 | 中（会话副作用／资源） | 2026-10-14 | 读取调用获取／释放锁或故意等待计算 | SELECT 形态可改变会话锁或占用连接／CPU。 | 是 | raw／Skill 真实五种调用在 I/O 前拒绝；ASCII 身份保留 literal／列／CTE，启动隔离加运行时独立检查。 | 新增 47 回归、全量 1089 通过，类型／提示契约及安装 stdio 通过；维护者重启后主会话 13 项通过，包含 MySQL 五种拒绝及正常读取／Skill，未执行原生锁副作用。 | 小范围规则，不证明全部函数／成本受控；同名自定义调用也受限。I/O 前顺序由回归验证，Host 返回本身不是 adapter 轨迹。 |
| DRR-2026-086 | 隔离验证通过；生产暂缓 | 中 | 2026-10-14 | 通用 AST／scope 不等于项目授权 | Table 遍历漏 SQLite IN，CTE 可见性不同，不透明命令可隐藏依赖。 | 未替换生产 | 固定 SQLGlot 30.22.0 隔离投影，按方言规则处理，虚拟／不透明形态标为不支持，执行原 SQL。 | 52 语料＋11 定点案例，原生真值支持断言，五次导入／RSS 测量。 | 接入前定义接口／适配并完成语义／升级回归；authorizer 单独做。 |
| DRR-2026-087 | 已测；更广矩阵／完整 Host 成本未验 | 低至中 | 2026-10-14 | 有限方言／成本证据被外推 | 当前服务与 SQLite 前向／隐式递归不同；耗时波动和不同失败结果混杂成本。 | 证据 | 原生真值与保守策略分记，明确缺少实例；串行 A/B/A，保留初版失败和缺少 MCP 的 Luna 尝试。 | 当前 SQLite／MySQL 1、固定元数据不变、策略探索 p95 门槛通过；required 原生 CLI 六项对照通过；不作总体／计费保证。 | 0/2／MariaDB 与完整 Host 模型任务需明确启动和可用环境；不承诺总体延迟／计费改善。 |
| DRR-2026-088 | 已实现；最后验收完成 | 高（SQLite 白名单，点号名称） | 2026-10-15 | 限定名与单个点号名共享授权 | 拼接 schema/name 会同时授权 main.orders 和另一个字面 main.orders 表。 | 是 | RelationReference 在提取、授权、推断及 readiness 中保留组件；展示文本不作键。声明首个点区分 schema/name，SQL 从 token 取组件；元数据绑定默认 schema。 | 修改前两模式同一 grant 读取 7／99；修改后 48 新回归、全量 1162、安装 stdio 36 次及真实 MySQL 只读 12 次通过。 | 任意带点 schema 的声明语法与完整语义解析不纳入；生产 AST／authorizer 暂缓。 |
| DRR-2026-089 | 已实现；最后验收完成 | 中 | 2026-10-15 | 消费令牌后复验异常丢失写入结果 | 类型化适配器异常进入 validation.errors，JSON 序列化失败，只返回通用 ToolError。 | 是 | 适配器脱敏后转字符串，保留 validation_failed／not_executed 及令牌已消费状态；不恢复一次性令牌。 | 两模式类型／普通／实际 adapter 异常均通过：执行回调／写入未发生、数据未变化、重放拒绝；安装 stdio 确认结果。 | 受信任命令式 validator 仍负责自身行为；修复框架结果边界，不成为任意 Python 的沙盒或完整事务保证。 |
| DRR-2026-090 | 已实现；最后验收完成 | 中 | 2026-10-15 | readiness 混淆限定依赖和裸快照 | main.orders 被误报缺表，或由另一个字面点号表错误满足。 | 是 | 带 schema 的结构化快照比较，支持 SQLite main／配置的 MySQL database；其他 schema 为 unverified_tables，不报假缺表；发现／详情／执行一致。 | 覆盖真实／缺失／字面表、声明、大小写和附加 aux；配置的 MySQL 限定 raw／Skill／元数据通过。 | readiness 仍是有限默认 schema 快照，不证明引擎搜索顺序或完整列语义；full 字段及返回字节增加，不作模型成本保证。 |
| DRR-2026-091 | 已实现；已批准范围验收完成 | 高（schema 绑定读取） | 2026-10-15 | 内部采样／计数丢失授权 schema | main.orders 获授权，裸 SQL 却读取同名临时表／视图，或主表缺失时的附加库对象。 | 是 | 同一 metadata RelationReference 贯穿授权和逐组件渲染；SQLite 固定 main，MySQL 元数据用参数绑定配置库。 | 修改前后各 130 次 Client 矩阵、新增 48 项、安装 stdio 60 次及真实 MySQL 只读 18 次通过；全量 1210 passed／4 skipped，重启后现有工具原生 20/20 通过；特殊边界由隔离／安装夹具覆盖。 | raw SQL 保留引擎名称解析。MySQL 临时对象生命周期、pool reset 和其他大小写设置另行处理；重启后主会话现有工具 20 项通过；其中 sample／table_summary 关闭，未配置视图／故障 validator 夹具。 |
| DRR-2026-092 | 已实现；已批准范围验收完成 | 中（功能误拒） | 2026-10-15 | 表目录快照误报授权视图缺失 | 默认 schema 中视图 raw SELECT 成功，Query Skill 却被 readiness 隐藏／拒绝。 | 是 | ReadRelation 保留 schema/name/kind；get_read_relations 无估计观察 table／view，独立于只列表的发现工具。 | SQLite raw／发现／详情／执行及字面点号视图反例覆盖两模式；配置 MySQL 表 readiness 通过，MySQL 视图夹具未实测。 | 存在不等于完整 SQL／底层授权／可写性。新 adapter 实现明确观察接口；生产 AST／authorizer 暂缓。 |
| DRR-2026-093 | 已实现；已批准范围验收完成 | 中（可信扩展鲁棒性） | 2026-10-15 | 非法校验返回导致令牌消费后的结构化失败丢失 | 可信 callback 违反字符串错误约定，返回异常对象、非 bool valid 或不可序列化字段。 | 是 | preview／命令式复验共享归一检查：严格 bool、可选字符串 list errors、可 JSON 序列化业务字段；非法返回固定安全校验失败。 | 两阶段／两模式和六类形态覆盖；预览不发令牌、未调用 execute，执行保留 consumed 状态并拒绝重放；安装 stdio 通过。 | 不隔离可信 callback 的副作用，不任意 str 对象；原已修的抛异常路径继续覆盖，托管确认不新增 callback。 |
| DRR-2026-094 | 已实现；现有 Host 核验通过 | 中（功能误拒） | 2026-10-15 | 内部前缀通配误过滤合法 SQLite 关系 | 表／关系目录均用 LIKE sqlite_%，合法 sqliteX... 表／视图 raw 可读却被报缺失；采样指南把 SQLite 隔离保证扩展到 MySQL。 | 是 | 共享前 7 字符 sqlite_ 的字面 NOCASE 比较；分别描述 SQLite main 与 MySQL 配置库／同会话临时表边界。 | 修改前后各 72 次 Client、新增 12 项、全量 1222 passed／4 skipped、安装 CLI／stdio 84 次及类型／提示契约通过；内部对象仍排除。维护者重启后现有工具原生核验 16/16 通过。 | 不改变授权／API／identifier／依赖。特殊前缀案例保留隔离测试归属，原生运行核验不作为驻留代码加载证明；旧 20/20 保留原源码归属。 |
| DRR-2026-095 | 已实现；驻留验收通过 | 中（功能误拒） | 2026-10-15 | Unicode 转换混淆业务名称与保留名称 | PRAGMA lower() 将含开尔文符号的表名合并为 locking_mode；相邻 upper() 将含长 s 的普通列合并为 CURRENT_USER。raw 与 Query Skill 启动校验均误拒。 | 是 | 两个 PRAGMA 分支、账户检查及内部解析默认值复用 ASCII 转换，保留真实 ASCII 名称拒绝；README 阶段提示移入日志／发布与验收导航。 | 新增 56 项，全量 1278 passed／4 skipped，最终类型／提示通过；修改前后各 26 次 Client、安装 stdio 26 次。维护者重启后，同输入三个修正探针、两个保留名称对照及现有 Skill 原生 6/6 通过。 | 保留重启前误拒，不据此认定缓存根因；不扩大授权／API／依赖／元数据语法。保留旧源码归属及初始环境／探针失败。 |
| DRR-2026-096 | 已实现；本批驻留验收通过 | 高（关系授权）；功能误拒 | 2026-10-15 | 上下文／Unicode 关系边界及保留调用引用 | 目标扫描将 window／offset／lock 及 Unicode 名称当子句结束，orders-only 可允许其他表；词汇转换还误拒业务名，带引号文件／账户调用则漏拒。 | 是 | 先定位目标再判断子句，关键字形名称保留结构化身份；从原始 token 做 ASCII 比较，共享真实调用的引用识别。 | 新增 107 项、全量 1385 passed／4 skipped，类型／提示通过；前后各 68 次 Client、安装 stdio 68 次、真实 MySQL 12 次；97 名称／542 案例未再发现范围漏查。 | 维护者重启后，同输入四个原生探针与正常对照 10/10 通过；18 个保守误拒已验证标准引用恢复，带引号 CTE 列列表仍有限制。不承诺完整方言、视图源、生产 AST／authorizer 或模型成本保证。 后续授权的 099 已修复这些复现语法／readiness 限制；源码／包及重启后原生 20/20 验收通过。 |
| DRR-2026-097 | 已实现；驻留验收通过 | 高（保留读取调用策略） | 2026-10-15 | CTE 声明排除集误包含查询体 | 带引号列列表与 AS／body 组成同一 Identifier，整组排除使全表范围真实调用漏查。锁／耗时路径原有缺口，096 合并扫描后文件／账户也受影响。 | 是 | 按原始叶子及括号深度，仅排除声明层 AS 前的名称／列列表；无法识别边界不扩大排除，查询体保持既有调用检查。 | 新增 132 项、全量 1517 passed／4 skipped；类型／提示通过，前后各 80 次 Client、安装 stdio 80 次、真实 MySQL 12 次。576 组中 96 组旧放行关闭；1000 个上下文及重跑 542 关系案例未见新范围漏查。 | 重启后同输入原生探针与正常对照 10/10 通过；allowlist 旧探针曾在关系解析阶段拒绝，全表复现归属私有源码／安装包。保守语法／readiness、生产 AST／authorizer 仍另行推进；未执行真实锁／等待／文件／账户副作用。 后续授权的 099 已修复这些复现语法／readiness 限制；源码／包及重启后原生 20/20 验收通过。 |
| DRR-2026-098 | 已由 099 修复；驻留验收通过 | 中（可用性／恢复） | 2026-10-15 | UNKNOWN CTE 被归为非读取 | 部分合法 SQLite 名称／注释收到 read_only_required 或产生假物理依赖；修改前原生与源码一致，不是旧 MCP 差异证据。 | 先修诊断，后授权修功能 | 初期仅保留拒绝并改 sql_parse_failed；后续 099 共用结构／作用域／依赖分析，修复已复现功能案例。 | 保留诊断阶段新增 43 项／1560 通过及其原生 10/10；099 的 1750 项／源码／包／实库证据独立归属。 | 已复现功能缺口在源码／安装包修复，重启后原生 20/20 通过；不承诺任意方言或实际任务成本，旧原生／模型证据不改写。 |
| DRR-2026-099 | 已实现；驻留验收通过 | 中（有边界 SQL 分析） | 2026-10-15 | CTE 分组与关系角色判断不一致 | 关键字／Unicode 名、引用列列表、AS 注释／物化、上下文 DML 名及截断的 WHERE IN 是有效读取，却在 raw／Skill／readiness 误拒。 | 是 | 共用原始叶子的 WITH 结构与关系目标识别，保留作用域／顺序／大小写／schema/name；只排除声明和名称叶子，查询体及真实写入／调用继续检查，在当前块展开可选 WHERE 容器。 | 全量 1750 passed／4 skipped，类型／提示通过；相同输入 Client 56 次、70 项资源与安装 stdio 96 次、真实 MySQL 24 次；300 合法功能案例两策略通过，四项未授权对照拒绝。542／1000 关系案例未见漏查／误拒，576 个无副作用函数夹具拒绝。 | 维护者重启后原生 20/20 通过，十条同输入及十条补充，文本／结构化一致；有边界结构并非完整方言 AST／authorizer，保留 SQLite 保守递归／前向及未测后端范围。纯策略 A/B/A p95 为 13.12／17.71／16.15 ms，不承诺无延迟代价或 token 改善。 |
| DRR-2026-100 | 已实施；批准范围验收通过 | 中 | 2026-10-16 | 名称角色与授权组件 | 引用、空格、Unicode 与点号不能经通用字符串归一化合并。 | 是 | 保留 RelationReference，原文／引用／作用域另存；结构化声明与目标方言角色规则，名称等价不自动扩大授权。 | 1896 项完整回归通过；组件／Skill／元数据及原生名称矩阵通过，首批驻留检查通过，CTE 计数补修另见 DRR-106。 | 只覆盖现有 SQLite／MySQL 支持范围；不承诺所有数据库合法名称。 |
| DRR-2026-101 | 已实施；批准范围验收通过 | 中 | 2026-10-16 | MySQL 会话语义绑定 | sql_mode 属于实际会话，池归还的 rollback 不重置任意会话状态。 | 是 | 完整模式逐物理连接初始化／校验，首次继承或显式配置；可信任意操作／写入会话不回读取池，正常请求无新增模式探测。 | 八种模式／144 条原生观察及显式／继承的真实私有池生命周期通过。 | 可信数据库定义和扩展须遵守会话契约；不能只凭限定库名宣称消除任意临时对象影响。 |
| DRR-2026-102 | 已实施；批准范围验收通过 | 中 | 2026-10-16 | 生产 AST 完整性与原始拼写 | SQLGlot 也有 Unicode 关键字／函数归一化和上下文名称误判，原型字符串投影不能直接用于授权。 | 是 | 固定 30.22.0、显式方言／模式，共享结构化结果；保留原名称／函数 token，部分分析明确拒绝，执行原 SQL。 | 300 个功能 CTE、四个拒绝对照、542 个物理名、1000 个关系上下文及 576 个无害保留调用对照；串行成本另测。 | complete 只指项目支持的分析契约，不证明数据库语法／目录／视图内部语义。 |
| DRR-2026-103 | 已实施；批准范围验收完成 | 中 | 2026-10-16 | SQLite authorizer 生命周期与视图 | 共享物理连接、编译缓存与来源名称可造成上下文串用或合法视图误拒。 | 是 | 独占覆盖执行／取数／清理，稳定回调、DBAPI 缓存关闭；核对根授权、CTE 来源与视图依赖边，拒绝整条语句。 | 视图／CTE／遮蔽／rowid／附加库／缓存／并发及外部改定义通过；两协议 58 次安装语义调用通过；CTE 计数补修最终原生 5/5 通过。 | 可达视图来源同名且跨 schema 的歧义保守拒绝；可信 Python 和任意数据库定义不是沙箱对象。 |
| DRR-2026-104 | 已实施；批准范围验收通过 | 中 | 2026-10-16 | 元数据名字与传输绑定 | 通用 64 字符白名单误拒 SQLite 名称，SQLAlchemy text 可能把名称／字符串／注释冒号当占位符。 | 是 | 按方言校验、组件引用、PRAGMA 参数化；传输编译仅绑定真实参数，驱动端原文内容保持。 | 名称／驱动原内容／真实绑定参数通过；结构化 config explain 已修复；58 次安装包 child stdio 语义调用通过。 | 传输保护不是 SQL 转译；非法／不支持名称不 trim 修正。 |
| DRR-2026-105 | 已实施；批准范围验收完成 | 中 | 2026-10-16 | v3.8.2 分层验收与证据归属 | 旧版本测试或模型轨迹不能证明新解析／连接／回调实现。 | 是 | 冻结 3323f9c 源码与环境，先独立真值，再全量、安装、实库、Host、Luna 与成本；保留失败和未测范围。 | 1896 项回归／四项跳过，类型／提示、75 个安装资源哈希及实库矩阵通过；首批 Host 10/10、12 个 Luna trial／36 轮已完成（固定检查 11/12）；CTE 补修最终原生 5/5 通过；三次双轮销售按明确目标 2/3，模型拼写错误及机械评分限制保留。 | 维护者手动重启；未具备的 MySQL 变体／MariaDB 不冒充已测；无通用计费或无开销保证。 |
| DRR-2026-106 | 已实施；批准范围验收完成 | 中（功能误拒） | 2026-10-16 | 物化 CTE 的空列 READ 被当作物理关系 | 完整 Luna 销售任务原生复现：合法复合 CTE COUNT(*) 产生 database=null、列名为空的 CTE READ，误返回 view_scope_unresolved；Agent 拆分查询后恢复。 | 是 | 只对声明唯一、所有附加目录无同名对象的 CTE 标签接受这种空列事件；目录检查有预算、位于回调外，真实底表／函数／操作仍独立核验。 | 原生 SQLite 真值及 6 项失败复现保留；新增 15 项回归，全量 1896／四项跳过、类型／提示和安装两协议 58 调用通过；重启后原综合查询一次返回完整 11 行，原生 5/5；三次双轮销售未见服务误拒，保留一项模型工具名拼写失败。 | 同名目录／作用域歧义保守拒绝；增加有界目录查找。最后手动重启后原生及 Luna 定点复验完成；按明确目标 2/3 完成，机械评分 1/3，原因分列；原 12 个 trial 不改标为修复后源码。 |
| DRR-2026-107 | 已实现；限定范围验收完成 | 中 | 2026-10-17 | 采样／计数／估算未激活读取 guard | 固定模板仍可执行已授权视图内部的保留调用或来源，query 与元数据入口行为不一致。 | 是 | 数据读取走 execute_read，目录仍可信；先核验根关系，恢复唯一视图计数边；估算被拒返回 null。 | 新增跨入口／授权／正常视图回归，函数计数为零，私有数据不变；证据及最终回归见本批报告；重启后原生 28/28 通过，未暴露的 sample／精确计数仍保留安装覆盖。 | 增加解析／目录检查，不增加 Agent 必需步骤；可信 schema/UDF 范围和 MySQL 无等价 authorizer 的限制不变。 |
| DRR-2026-108 | 已补修；限定驻留复验通过 | 中（功能回归） | 2026-10-17 | 非执行型 DML 计划与间接读取 | EXPLAIN 仍触发编译授权；已授权触发器 READ、WITH REPLACE 与 UPDATE OR 尚未完整恢复。 | 是 | 绑定原 SQL／上下文，核验实际计划目标；回调外按需补充依赖，共用累计截止时间／预算；视图丢失来源的 COUNT 先核验触发器 WHEN／body，SQLite 按语句角色适配。  SELECT／DML 来源及触发器局部 CTE 先在回调外验证，再判定物理绑定；重名 owner 的依赖独立检查。  按真实表达式角色消费 WHEN 后再定位 BEGIN；原条件及全部正文仍完整分析。 | 新增 101 项，全量 2067 passed／4 skipped、类型／提示、140 次源码及 272 次安装 stdio 通过（75 资源一致）；旧原生 28/28 保留前批归属，维护者重启后原生 42/42 符合预期（26 项计划、12 项拒绝等），完整五行五列不变；最终包／驻留状态见[后续报告](../validation/v3.8/V3_8_2_EXPLAIN_FOLLOWUP_2026_10_17_ZH.md)。  后续局部 CTE 新增 129 项，全量 2196 passed／4 skipped、类型／提示及安装 340 次通过；重启后限定验收 57/57（38 项计划、13 项拒绝、6 项对照），三次五行五列快照不变；另存 12 次探索预期偏差（10 次未授权限定形式、2 次既有外层重复 CTE 限制）。[最新证据](../validation/v3.8/V3_8_2_TRIGGER_CTE_2026_10_17_ZH.md)。  相邻审计新增确认六种 begin 列形式／两前缀 12 项功能回归，冻结旧源码同输入 24 项全通过；两种 Client 共 28 次调用复现。当前完整 Luna 销售 2/3，另一次 Host 可用性失败保留。[最新审计](../validation/v3.8/V3_8_2_ADJACENT_AUDIT_2026_10_17_ZH.md)。  WHEN 补修新增 79 项，全量 2275 passed／4 skipped、类型／提示及安装 394 次通过，76 组符合预期；维护者重启后原生限定核验 57/57 通过，三次完整快照不变，专用触发器仍保留回归／安装归属。三个 fresh 子会话各预检后完成双轮销售任务，最终 3/3（一次初稿 FROM 拒绝后自主恢复，无拒绝试验 2/3）；此前含 Host 失败的 2/3 保留。[最新修复](../validation/v3.8/V3_8_2_TRIGGER_WHEN_2026_10_17_ZH.md)。 | 触发器／UDF／计划 Skill 未新增配置库原生夹具，保留同源码回归／安装覆盖；来源歧义／不支持触发器定义仍拒绝，实际写入、PRAGMA／DDL／ATTACH、受限调用不放行，不增加 grant 或 Agent 必需步骤。外层独立子查询的重复 CTE 名仍保守拒绝，不同局部名可恢复，前后源码与原生证据已保留。  WHEN 同输入及限定原生核验通过，按上述源码／安装及 57 项驻留范围关闭；不宣称配置触发器原生覆盖或完整方言支持。带预检的新业务试验不作为历史可用性／成本 A/B，原 exact-ready-client 故障底层原因仍未证明。 |
| DRR-2026-109 | 已补修；限定驻留复验通过 | 低（功能兼容） | 2026-10-18 | SQLite IS／ESCAPE 操作数 COLLATE 解析 | 固定 SQLGlot 的 NULL／placeholder IS 右值及字符串／NULL／参数 ESCAPE 右值快捷分支遗漏 COLLATE，e49cd0e 误拒合法读取。 | 是 | SQLite 按表达式优先级解析这些右值；原 SQL／参数、独立读取策略及 authorizer 保留，其他 IS 及 MySQL 分支继续按原方言处理。 | 新增 100 项，全量 2375 passed／四项跳过，类型／提示通过；同输入 40 次恢复原 26 次拒绝，源码 stdio 96 次及安装包 490 次通过，75 项资源一致。维护者重启后固定原生 25/25 通过（20 项常量读取、三项拒绝、两次完整五行五列快照相同），内容／结构化结果一致；独立重启封存保持此前 556 项原字节。[证据](../validation/v3.8/V3_8_2_COLLATE_REPAIR_2026_10_18_ZH.md)。 | 按已记录源码／安装及 25 项原生范围关闭；保留重启前四例拒绝、父检查点待验状态、原 P3 发现、中间失败和源码归属。本次未新增配置触发器／参数 Skill 原生夹具、Luna 或成本 A/B，DRR-108 保持限定关闭；不通用补括号、不新增 grant／依赖或零成本承诺。 |
| DRR-2026-110 | 已补修；限定驻留复验通过 | 低（功能兼容） | 2026-10-18 | SQLite 完整判断后缀与续接 | 继承的 range 解析遗漏后缀 COLLATE 及高优先级续接，误拒合法读取并跳过 Query Skill。 | 是 | SQLite range 续接时显式保留完整判断结合位置，复用节点／操作数；原 SQL、绑定、独立策略及 authorizer 保留。 | 新增 190 项，最终 2565 passed／四项跳过，类型／提示通过；同输入 114 次及 540 条分析全通过，新增接受 480 条往返语义一致；源码 stdio 130 次、安装 524 次及 75 项资源一致；维护者重启后 71/71 项原生通过，66 条常量与独立 SQLite 一致，三项拒绝及前后完整五行五列快照相同，内容／结构化结果一致。[补修](../validation/v3.8/V3_8_2_PREDICATE_COLLATE_REPAIR_2026_10_18_ZH.md)。 | 按源码／安装及 71 项原生范围关闭；此前 621 项封存原字节保留，原生证据另封存。独立元数据勘误修正说明中的旧计数，不改变 66 条结果或结论。七项既有生成器括号差异有原 SQL 工具对照；此前 573 项封存及复评失败保留。无新 grant／依赖／Agent 必需步骤或零成本承诺；DRR-109／108 保留原源码限定关闭。 |
| DRR-2026-111 | 已实现；限定原生／模型验收通过 | 中（功能兼容） | 2026-10-19 | 派生视图与 JSON 虚拟关系 | 过宽名称适配及将表函数当物理关系，误拒合法视图／JSON。 | 是 | 保留查询分派，记录虚拟调用与真实参数依赖，核对 SQLite 实际模块绑定；原 SQL 不变。 | 新增正反例及两协议 child-stdio；最终层级状态见[本批记录](../validation/v3.8/V3_8_2_READ_CAPABILITIES_2026_10_19_ZH.md)。 | 解析不证明引擎有效；未知扩展不借用内置能力，raw 派生关系仍拒绝。 |
| DRR-2026-112 | 已实现；限定原生／模型验收通过 | 中（功能兼容／边界） | 2026-10-19 | FTS 冷暖、影子与内容来源 | FTS 内部 PRAGMA／存储被拒，结果受元数据顺序影响。 | 是 | 核验实际模块、shadow 类型及内容列，每请求限定内部能力；先检查所有直接根，回调外有界准备。 | 冷暖／重连、三种存储、名字／元数据／未授权直接读取与受限函数验证；原生／模型单列。 | 内部与直接 PRAGMA 回调可能相同，完整分析是必要边界；不宣称任意虚表／可信 UDF 沙箱。 |
| DRR-2026-113 | 已实现；契约及限定验收确认 | 中（范围契约） | 2026-10-19 | all 与默认名称身份 | all 跨库、裸名和限定名在多个入口含义不一致。 | 是 | all 绑定默认 schema；裸 grant 表示默认对象，统一早拒／Skill／metadata／guard；跨库用显式 allowlist。 | 结构化身份、temp／aux、点号单名、无 I/O 拒绝与发现一致性覆盖。 | 公开前明确契约变化；不改账号权限，不保证 MySQL 临时对象或 DEFINER 视图／函数隔离。 |
| DRR-2026-114 | 已实现；限定原生／模型验收通过 | 中（锁读契约） | 2026-10-19 | 锁读与误导诊断 | 新放行 FOR UPDATE，共享锁此前已可读；会话赋值／绑定提示不精确。 | 是 | 普通读取拒绝执行型锁读，确认不执行的计划保留；赋值、位置参数、明确非读及原因文案分开。 | AST／静态拒绝覆盖；未在配置库实际持锁。 | SELECT-only 不能覆盖所有共享锁；未知读取不引导去写入；不新增锁协调接口。 |
| DRR-2026-115 | 已实现；限定原生／模型验收通过 | 低（效率／维护） | 2026-10-19 | 目录重连及 authorizer 开关取舍 | 固定库名／诊断误用 trusted 并废弃连接；关闭 authorizer 会形成两套保证。 | 是（重连）；否（关闭开关） | 展示绑定库名，固定诊断走 metadata；保留可信任意操作／写会话废弃，authorizer 不提供 TOML 关闭项。 | 事件计数／最终类型及安装状态见本批记录。 | 内部检查有成本，不作零开销／第三方倍率承诺；真实替换需求另设计。 |
| DRR-2026-116 | 已实现；限定组合验收完成 | 中（窄读取策略边界） | 2026-10-20 | 预编译 FTS 内容视图函数 | 可信完整投影后模块内部 SQL 可不再重报函数，受控读取因缓存状态而不同。 | 是 | 共享受限函数事实判定；每请求在回调外检查完整可达视图／触发器分析，原回调继续检查实际编译操作。 | 24 个相同前后输入，受控求值两次降至零；40 项新回归，源码／安装各240次stdio；重启后现有夹具8/8原生通过，数据摘要不变；特殊预热条件由源码／安装覆盖。 | 完整定义含受限函数时，即使未选该表达式也拒绝；正常派生视图与间接授权保留，可信UDF／生成列边界未扩为通用沙箱。[补修](../validation/v3.8/V3_8_2_FTS_FOLLOWUPS_2026_10_20_ZH.md)。 |
| DRR-2026-117 | 已实现；限定组合验收完成 | 中（功能兼容） | 2026-10-20 | 限定命名 FTS 调用误拒 | 显式 aux FTS grant 可执行普通 MATCH，但等价表调用／IN 被内置函数默认库规则拦下。 | 是 | schema 限制仅对 builtin 应用；具名根继续组件授权与实际模块核验。 | 12 次误拒全部恢复；两协议、aux／temp、预热／未预热、点号名称与错误schema拒绝覆盖。 | all 默认库、不支持模块、直接内容／影子授权和非默认readiness边界不放宽；重启后现有夹具8/8原生通过，数据摘要不变；aux特殊条件由源码／安装覆盖。[补修](../validation/v3.8/V3_8_2_FTS_FOLLOWUPS_2026_10_20_ZH.md)。 |
| DRR-2026-118 | 已实现；限定原生验收通过 | 低（效率／维护） | 2026-10-20 | SQLite 元数据重复工作 | 截断前估算全部授权表，逐表统计检查／查询及无冒号传输分词重复。 | 是 | 分开目录与补全，先投影实际返回表；选中统计按绑定／结果限额批读，缺失仍受控计数；仅跳过无冒号传输分词。 | 2697 通过／四项跳过、类型／提示通过，源码及安装各134次；维护者重启后9/9原生通过，三库摘要及独立列／行数真值相同；成本独立记录。 | 不缓存授权／目录，不自动 ANALYZE 或关闭 authorizer；真实 adapter 扩展实现明确目录接口，FTS 后续补修另见DRR-116／117。[证据](../validation/v3.8/V3_8_2_METADATA_OPTIMIZATION_2026_10_20_ZH.md)。 |
| DRR-2026-119 | 已实现；限定驻留验收通过 | 中（迁移／维护） | 2026-10-20 | 受管计划解析器与目标语义 | 旧sqlparse仅启动分类，无实际目标方言／模式；替换可能改变语法接受或把归一化REPLACE误当INSERT。 | 是 | 默认SQLGlot，独立写规则／原主动词／原SQL与绑定，预览／实际写前目标复验；显式临时sqlparse回退，不自动切换。 | 固定980组对照、独立生命周期／提交证据回归、真实MySQL非执行计划64次、源码／安装各40次；重启后16次原生调用符合契约，保留搜索预期校正；无业务写入，SQLite摘要不变；成本／验收限制见记录。 | 依维护者选择保留依赖与双路径测试，两至三个发布检查点后评估退出；补测SQLite流程+5–11%，hint／HIGH_NOT_PRECEDENCE确有合法保守拒绝，该检查点仅建议分类复用／细化支持；复用随后见DRR-120，该阶段兼容细化延后，随后见DRR-121—123；解析不是数据库验证，旧回退及既有私有Parser风险保留。[证据](../validation/v3.8/V3_8_2_MANAGED_PARSER_2026_10_20_ZH.md)。 |
| DRR-2026-120 | 已实现；限定驻留验收通过 | 低／中（性能／缓存） | 2026-10-20 | 受管 readiness 与纯分类复用 | schema guard 重跑完整可用性，固定六调用分类11次；若复用授权或旧目标语义会改变边界。 | 是 | 共享纯 readiness；每实例128项LRU，键为原SQL／完整不可变上下文／解析器；目标语义、授权和token仍即时核验，确认消费后再次取上下文；关闭清空。 | 2815通过／4跳过，类型／提示及源码／安装各40次调用通过、77资源一致；980组判定不变，成对成本／分阶段漂移保留；维护者重启后22/22原生通过（3预览／6预期拒绝），两个DB摘要及80行订单摘要不变、23份旧封存／580文件保持；不据原生输出断言缓存命中。 | 只保留不可变纯决定（含确定性拒绝）；连接失败／抛出异常、AST及DB状态不缓存；容量按项，允许并发miss重复纯计算。hint与HIGH_NOT_PRECEDENCE该阶段另做，后续见DRR-121—123。[证据](../validation/v3.8/V3_8_2_MANAGED_CLASSIFICATION_REUSE_2026_10_20_ZH.md)。 |
| DRR-2026-121 | 已实现；限定驻留验收通过 | 低／中（兼容） | 2026-10-20 | SQLite注释语义 | 共享MySQL指令／dash规则误拒SQLite空白注释及Query Skill。 | 是 | 按实际方言检查，字符串／引号名称保留；原SQL及Query Skill启动／readiness边界不变。 | 全量2920通过／4跳过及随后2项Query Skill检查；矩阵／源码／安装／原生范围见记录。 | 未闭合块注释的分词仍属支持包络限制；无目标shape helper仍跨候选保守处理。不新增grant／配置或authorizer绕过。[证据](../validation/v3.8/V3_8_2_DIALECT_COMMENTS_NOT_2026_10_20_ZH.md)。 |
| DRR-2026-122 | 已实现；限定驻留验收通过 | 中（hint语义） | 2026-10-20 | MySQL计划提示子集 | 一律拒绝造成误拒，直接忽略又可能改变会话／约束／资源约定。 | 是 | 检查每个原始注释区域，仅已知计划名／扁平名称参数；状态／资源／超时／未知／嵌套体拒绝，仅分析流移除验证后的HINT。 | 1513组输入上下文、sqlparse原判定保持；真实MySQL模式／非执行计划及源码／安装见记录。 | 不保证全hint语法或服务器采用提示；显式旧回退限制保留，不新增SET_VAR单语句会话契约。[证据](../validation/v3.8/V3_8_2_DIALECT_COMMENTS_NOT_2026_10_20_ZH.md)。 |
| DRR-2026-123 | 已实现；限定驻留验收通过 | 中（解析／会话） | 2026-10-20 | HIGH_NOT_PRECEDENCE与! | 高NOT模式整会话拒绝；上游也把普通模式!错误按低优先级NOT分组。 | 是 | 现有NOT一元分派按实际模式／原!token处理，中缀语法、原SQL和物理会话初始化保持。 | 16个真实会话、272次常量比较／128个非执行DML计划，全部模式AST分组回归通过。 | 无新增方法覆盖，但私有分派／_prev／解析方法依赖仍固定版本；启动候选9→17，启动与暖态成本分开；不执行生成SQL、不承诺任意语法。[证据](../validation/v3.8/V3_8_2_DIALECT_COMMENTS_NOT_2026_10_20_ZH.md)。 |
| DRR-2026-124 | 已实现；限定驻留验收通过 | 中（P2兼容） | 2026-10-20 | 单句读取的尾注释 | 无执行内容的注释尾节点被当第二句，Query Skill启动跳过。 | 是 | 完整检查原始注释，形态／计句忽略合法HINT trivia及无执行内容的Semicolon尾节点；原SQL、授权及真实第二句拒绝保持。 | 全量3003通过／4跳过，之后会话绑定另2项通过；源码／安装各84调用，最终wheel另6次MySQL调用，77资源相同。读取／CTE／计划／Skill及真实负例覆盖。 | 维护者重启后34/34限定检查通过，数据摘要不变。审计旧拒绝保留历史，不算能力通过；临时显式sqlparse仍保留受管尾注释旧限制。[补修](../validation/v3.8/V3_8_2_READ_PLAN_REPAIR_2026_10_20_ZH.md)。 |
| DRR-2026-125 | 已实现；限定驻留验收通过 | 中（P2受管绑定） | 2026-10-20 | 计划加载与执行绑定身份 | 原始text误认字面／注释／名称冒号，加载与传输不一致。 | 是 | 共享named_parameters／statement_text；启动每候选同时满足语法与精确绑定，实际目标／消费token后仍复验。纯分类键增加不可变声明名，值／状态即时处理。 | 两解析器／两协议临时写入、恢复、重放拒绝及回滚通过；16个实际MySQL会话验证32字面比较／32非执行计划，订单不变。源码／安装总数见报告。 | 过去绕过误认的假参数应删除，内部classifier钩子增加声明名；无自动回退、权限／令牌／状态缓存或生成SQL执行。当前已有Skill／预览原生通过，自定义模板保持源码／安装覆盖。[补修](../validation/v3.8/V3_8_2_READ_PLAN_REPAIR_2026_10_20_ZH.md)。 |
| DRR-2026-126 | 已实现；限定驻留验收通过 | 低／中（性能／投影） | 2026-10-20 | 启动候选与MySQL列读取 | 已允许的Query Skill仍重复候选；schema逐表列查询及超时设置增加往返。 | 是 | 启动首个允许短路，全拒绝保留首个完整决定；授权／截断后经显式get_columns_batch，MySQL每批199名称加schema，精确名称／列序及整体失败保持。 | 五实库逐表／批列相同；固定16表stdio schema成对中位改善81–85%，22-Skill暖态Runtime约43%。保留SQLite反向组／控制组及近持平受管流程。 | SQLite默认逐表组合；定制MySQL列backend需考虑批量钩子。无元数据／授权缓存，不外推冷态／模型。[成本与限制](../validation/v3.8/V3_8_2_READ_PLAN_REPAIR_2026_10_20_ZH.md)。 |
| DRR-2026-127 | 已研究；暂缓通用生产缓存 | 低／中（复用／状态生命周期） | 2026-10-20 | 请求内纯读取分析 | 冷依赖推断可重复分析，通用缓存常态收益未明而增加生命周期工作。 | 是 | 原型按原SQL／完整context／view角色复用不可变SQLAnalysis，操作后清空；不生产接入，若冷推断成本重要先评估直接传分析。 | 16场景：20-Skill冷发现40→20分析；所测暖态／raw／窗口视图／物化CTE触发器计划无重复键；payload、状态及即时权限变化符合预期。 | 观察器／原型是handler局部成本，不是Host／模型预测或所有SQL零命中证明。禁止缓存授权／目录／readiness／数据库状态及恢复statement cache。[研究决议](../validation/v3.8/V3_8_2_READ_PLAN_REPAIR_2026_10_20_ZH.md)。 |
| DRR-2026-128 | 已验证；持续验收约束 | 中（Host／证据归属） | 2026-10-20 | 子会话就绪、实际模型与用量对照 | 主MCP可用不代表子会话可用；关闭恢复虽能恢复工具，实际模型／effort可能改变，污染同模型token对照。 | 是 | 每个实际子会话先canary并核对公开逐轮model／effort；保留失败和混合诊断，只替换模型协议不符的样本而非挑业务成功。分开服务器正确性、业务完成、调用与实际用量。 | 15个fresh Luna medium最终通过，60条SQL重放一致；新15／旧9逐轮实际模型核实。保留3次初始失败及恢复为Sol ultra的诊断，全程初始可用15/18。 | 未定位工具不可用底层根因，不确认缓存；无引导消融、账单或普遍省token声明。九项描述性业务总-6.30%，保留子集上升；不据此改运行配置。[证据](../validation/v3.8/V3_8_2_COMPLETE_AGENT_EVAL_2026_10_20_ZH.md)。 |

早期写入证据见[10 月 1 日验收记录](../validation/v3.8/V3_8_MRTR_NATIVE_2026_10_01_ZH.md)；IN 检查、查询契约和新的原生三次对照见[10 月 13 日复评整改](../validation/v3.8/V3_8_1_FOLLOWUP_2026_10_13_ZH.md)。


## 初始 v3.4.3 评审批次状态

1. V343-001 是本组唯一运行时行为修改，已实现。
2. V343-002 仅作为措辞/消息清理实现；adapter 级查询 streaming 暂缓。
3. V343-003 至 V343-005 作为文档和工具描述清理实现。
4. V343-006 至 V343-008 已明确作为文档和运维约束收口，而不是新增运行时控制。

## 当前明确不做的事项

- 面向任意 SQL 的通用 `query(limit, offset)` 或 cursor-token 分页。
- 进程内 p50/p95 聚合或模型可见 stats 工具/资源。
- 对所有基础工具统一添加严格 output schema。
- 没有失效策略的 session schema cache。
- 在出现明确客户端需求前新增 `db://schema` resource。
- 在部署要求明确前加入进程内日志轮转/保留逻辑。
- 没有隐私敏感部署需求时新增 raw SQL echo 开关或 audit 脱敏策略引擎。
- 在启动期新增运行时生成的人工文档/维护产物；现有 `skills/SKILLS.md` 启动期生成已由 DRR-2026-001 跟踪。
- 没有明确客户端/部署需求时新增展示型环境默认值或低层调优开关。
- 没有明确启动需求时新增 import-time 文件系统副作用或配置读取，让测试必须靠 reload module 才能切换配置。
- 对可以通过公开 helper 或 MCP tool 行为测试覆盖的逻辑新增源码字符串回归测试。
- 在自由 `query(sql)` 工具中允许 MySQL `SELECT` 文件读写特性（`OUTFILE`、`DUMPFILE`、`LOAD_FILE`）。
- SQL 方言把注释/引号当作语法时，仅依赖匹配普通空白或未引用形式的 regex 来阻断 system schema 与 SHOW 命令。
- 本地 DB error logs 记录 SQLAlchemy 参数值。
- 在仓库没有 CI workflow 时，声明测试会在 CI 中失败或由 CI 自动拦截。
- 有结构化 URL API 可用时，仍用原始凭据字符串手写 SQLAlchemy database URL。
- 将字符串前缀路径检查视为可信本地 Skills 代码的充分 containment。
- 在 validation 尚未共享前，声明 query skill SQL 与自由 `query(sql)` 工具获得相同扩展 safety checks。
- 将轻量 Skills params schema 描述成完整 JSON Schema，或在没有显式验证测试时新增参数类型。
- 将 best-effort audit 写入描述成完整、fail-closed 的 mutation audit。
- 没有显式 integration-test opt-in 时，让默认 pytest 连接 live database 或打印 sampled row data。
- 将只有下限或未固定版本的依赖安装视为可复现 release input。
- 没有版本特定证明时，把偏 SELECT 的 MySQL timeout 设置当作 mutation/lock-wait 保护。
- 接受模型传入任意 DSN，或在 `connection_id` 未知时静默回退到默认连接。
- 用一个目标连接计算 Skills 可用性，却用另一个目标连接执行。
- 在 per-connection 写策略、preview/execute 目标绑定和 audit 语义设计完成前启用多连接 mutation 写入。
- 将真实写入联调对被跟踪示例 fixture 数据库造成的副作用一并提交。
- 在模型可见的 server instructions 或工具描述中，声称比当前配置下实际注册的工具界面更窄的能力。
- 在已要求 preview-state binding 后，仍为状态敏感的 mutation Skill 保留第二条无绑定写入路径。
- 编写无法触发失败的回归断言，或只搭建场景而不断言结果的测试。
- 在默认 pytest 仍会从开发者 `.env` 读取 live database 配置时，声称它是 hermetic 的。

## 更新流程

当某个条目被实现、拒绝或重新定范围时：

1. 更新 `状态`、必要时更新 `风险等级`、`是否计划修改`、`修改逻辑`、`当前结果` 和 `最近评审`。
2. 行为修改必须补充或更新测试，并在条目中记录测试文件。
3. 纯文档修改要记录修改过的文档，以及为什么不需要运行时测试。
4. 策略条目在修改运行时行为前，先记录兼容性/安全取舍。
5. 新增条目时，`首次登记日期` 填该风险首次进入本登记表的日期，而不是最近复审日期。
6. 除非条目创建有误，不要删除历史条目；将旧条目标记为已接受、暂缓或不计划。

## 评审清单

- 是否新增了模型可见 tool、resource、prompt、schema 或 meta 字段？
- 是否记录了 SQL、params、rows、用户标识、凭据或操作模式？
- 是否引入可能无界增长或过期的进程内/session 状态？
- 启动/import 路径是否写入生成式人工文档或维护产物？
- 启动/import 路径是否在环境校验前创建文件、安装 handler 或冻结配置？
- 公共内部边界是否依赖上游校验，而不是自己做最小 identifier validation/quoting？
- 顶层 read-only SQL 类型是否仍能在当前方言中执行文件 I/O、读取 server 文件或包含嵌套 DML？
- 在返回 sanitized client error 前，日志里是否已经包含 raw SQL、bound params、secret 或 SQLAlchemy 参数 dump？
- 文档是否声明了 CI、生产或自动化 enforcement，而仓库实际上没有提供？
- database URL 和 DB error log 的构造方式是否可能暴露或误解析 credentials/parameters？
- Skills path、frontmatter 字段、mutation class 和自定义参数 schema 是否在 loader 边界 fail closed？
- Query skills 与自由 query tool 是否共享同一 SQL safety policy？如果没有，文档是否分别说明？
- 默认 pytest 是否保持 hermetic，还是在未显式 opt-in 时也会连接 live database 并打印数据？
- 依赖版本是否能复现当前声明的行为和 API？
- Timeout 表述是否由实际执行的数据库语句类型支持，尤其是 writes 和 lock waits？
- 是否让昂贵数据库操作看起来像轻量元数据？
- 是否先解析 `ConnectionContext`，再做 policy、readiness、helper SQL、执行、metadata、audit 和 telemetry？
- Skills 的列表/详情/执行是否使用同一目标连接，并在未知 connection id 时 fail closed？
- 新增日志/meta/audit 字段是否暴露了连接串、host、用户、密码、SQLite 路径、SQL params 或返回行？
- 是否声明了代码无法保证的校验、完整性、精确性或排序？
- 测试是否覆盖了预期路径和被拒绝的失败模式？
- 本次 diff 是否把真实联调对被跟踪二进制或示例 fixture 的副作用，当成了有意变更？
- server `instructions` 和工具描述是否与当前 feature switch 下实际注册的工具界面一致？
- 默认测试套件是否隔离了代码在 import 时读取的全部配置变量，而不只是之前弄坏过 fixture 的那几个？
- 新增的每条断言是否真的可能失败，新增测试是否断言了其名称声称覆盖的行为？
## 10 月 20 日关系调用与列元数据补修

| ID | 状态 | 问题与决定 | 验证及剩余范围 |
| --- | --- | --- | --- |
| DRR-2026-129 | 已按源码／安装／限定原生范围验证 | 标量别名／参数规则改错 SQLite 关系身份并误拒 FTS；内置 JSON 同名对象可能漏记存储依赖。关系调用头独立解析，参数递归检查，实际模块／grant 绑定，Skill 从当前快照补充条件依赖，仅缓存不可变分析。 | 定点正例／拒绝通过，覆盖 main／temp／aux 实际 FTS 及目录变化。重启后 12 项冻结原生检查全部通过，使用现有授权；特殊名称夹具仍归属源码／安装覆盖。源码／安装／原生和成本分开，不新增授权／目录缓存。[当前验收](../validation/v3.8/V3_8_2_RELATION_CALLS_COLUMNS_2026_10_20_ZH.md)。 |
| DRR-2026-130 | 已按源码／安装／限定原生范围验证 | 既有 table_info 漏掉生成列。table_xinfo 返回可见普通／生成列，区分 virtual／stored，hidden=1 不混入默认列及计数。 | 列投影和不求值表达式检查通过。原生 pages 已返回完整 10 列及 virtual status，compact/full 总列数为 34，FTS 隐藏列仍排除。生成表达式／UDF 信任仍属既有执行边界，元数据不能证明表达式安全或完整 DDL 相同。[契约及验收](../validation/v3.8/V3_8_2_RELATION_CALLS_COLUMNS_2026_10_20_ZH.md)。 |

## 10 月 21 日读取结果与依赖补修

| ID | 状态 | 问题与决定 | 验证及剩余范围 |
| --- | --- | --- | --- |
| DRR-2026-131 | 已验证（声明的源码／安装／原生范围） | 重复行标签静默丢值；转映射前检查实际标签，返回 duplicate_result_columns 及唯一 AS 提示。 | 空结果无返回值／列描述；不新增有序结果接口。[验收](../validation/v3.8/V3_8_2_READ_RESULTS_2026_10_21_ZH.md)。 |
| DRR-2026-132 | 已验证（声明的源码／安装／原生范围） | BLOB 通用错误或丢类型、非有限值变 null；binary/base64 与 float 类型标记，不支持值固定错误，保留时间／Decimal 惯例。 | 非法 Unicode 和不透明对象不进入协议编码，写入结果处理独立；接受二进制膨胀和编码成本。 |
| DRR-2026-133 | 已验证（声明的源码／安装／原生范围） | 首行超限仍返回、sample 无字符保护；共享编码后紧凑 JSON 限额、零行截断与恢复说明。 | 原生query通过，sample保持源码／安装覆盖；仅数据数组，不承诺整帧／fetch／数据库工作或模型 token；result_chars 为 0 或 >=2，不新增字段切片或流式接口。 |
| DRR-2026-134 | 已测场景通过；相邻补修已实施 | 非默认／目录失败的JSON依赖消失；保留三态。DRR-135现以有序范围及完整性扩展原TEMP-only观察。 | 特殊aux/TEMP及目录失败保持源码／安装归属。不放宽grant／authorizer／AST，不缓存状态或新增开关。 |
| DRR-2026-135 | 已按声明的源码／安装／原生范围验证 | 未限定JSON同名调用实际绑定附加FTS根，readiness却标builtin；现保留有序两名称对象及成功查找前缀，仅完整缺失才能判builtin。 | 新增67回归及原源码／wheel各332调用保持归属；统一重启后20/20原生通过，包含默认目录路径。附加名称／部分目录保持源码／安装覆盖，父pending与失败原样保留。[当前补充](../validation/v3.8/v382_metadata_pragma_repair_2026_10_21/resident_restart/README.md)。 |
| DRR-2026-136 | 已按声明的源码／安装／原生范围验证 | 业务名称遮蔽元数据PRAGMA表值函数；现用四种固定main语句，保留解码目标名称及列／索引语义。 | 新增57回归，源码／wheel各元数据192+readiness332调用；统一重启20/20原生通过，pages列／索引及compact/full与独立只读SQLite真值一致。保留多索引代价及128／2048／64KiB／截止时间／有限取回，特殊碰撞仍属源码／安装。[当前补充](../validation/v3.8/v382_metadata_pragma_repair_2026_10_21/resident_restart/README.md)。 |
| DRR-2026-137 | 已修复；限定验收完成 | FTS bootstrap表值PRAGMA被同名业务对象遮蔽，授权读取及元数据误拒。 | 实际schema固定语句逐个核验shadow身份／类型，保留目录／截止时间／有限取回及cursor清理；源码／正常wheel各488应用调用一致。不扩大grant。维护者重启后10/10既有别名原生核验通过，碰撞夹具保持源码／安装范围。[补修](../validation/v3.8/V3_8_2_FTS_CATALOG_STATISTICS_REPAIR_2026_10_21_ZH.md)。 |
| DRR-2026-138 | 已修复；限定验收完成 | 部分索引行数误作整表基数，2c0a9e7亦复现。 | 优先整表统计，否则核验当前完整索引／WITHOUT ROWID主树；候选过量或统计缺失／无效回退受控有界读取。替换任意首统计的镜像测试，保留统计过期及10000下界语义。原生既有库估算与独立真值一致，特殊部分索引夹具仍归属源码／安装。[补修](../validation/v3.8/V3_8_2_FTS_CATALOG_STATISTICS_REPAIR_2026_10_21_ZH.md)。 |
| DRR-2026-139 | 已修复；限定验收完成 | FTS external-content隐式rowid与回调列身份不同，可信预热掩盖冷态误拒。 | 本轮新确认独立根因：批前冻结源码冷态8/15误拒、暖态15/15成功；有界固定PRAGMA核验普通表、整数主键别名、DESC例外和显式rowid列，补修后冷态15/15通过；直接底表／影子授权保持。重启后10/10原生通过，专用冷态夹具仍为源码／安装证据。[证据](../validation/v3.8/V3_8_2_FTS_CATALOG_STATISTICS_REPAIR_2026_10_21_ZH.md)。 |

## 10月22日 SQLite 写入事务补修

| ID | 状态 | 问题与决定 | 证据与限制 |
| --- | --- | --- | --- |
| DRR-2026-142 | 已实现；源码／安装及限定原生12/12通过 | P1：旧 sqlite3 控制下，逻辑 begin 未保护 WITH／分号 DML，持久化后可能谎报 rolled_back。同连接显式建立真实 BEGIN，核验回滚前后物理状态，清理不明时退休连接。 | 私有文件库独立真值覆盖部分失败、游标清理；两分类器／模式／传输的源码／安装完整流程通过。MySQL 规则独立；COMMIT 不明及引擎自行回滚仍 unknown。旧 DRR-058 测试遗漏这些语句形式；未写配置库，无新模型证据。[契约与验收](../validation/v3.8/V3_8_2_SQLITE_WRITE_TRANSACTIONS_2026_10_22_ZH.md)。  原生仅覆盖读取／拒绝／非执行计划／未确认预览，实际写入证明仍属私有夹具。[重启补充](../validation/v3.8/V3_8_2_WRITE_RESTART_AND_STABILIZATION_2026_10_22_ZH.md)。 |
| DRR-2026-143 | 已实现；源码／安装及限定原生12/12通过 | P2：RETURNING 未完成／缓存或未知 rowcount 误拒合法写入。在现有截止时间内完成关闭结果，取原生完成态计数，实际 DML 才用同连接 changes() 补数。 | 不累计触发器／级联／返回行，视图 INSTEAD OF 保留直接零计数；非 DML 不继承旧 changes。Python 分批不消除 SQLite 内部缓冲；消费／补数有成本，不外推 Agent token。[证据与代价](../validation/v3.8/V3_8_2_SQLITE_WRITE_TRANSACTIONS_2026_10_22_ZH.md)。  原生仅覆盖读取／拒绝／非执行计划／未确认预览，实际写入证明仍属私有夹具。[重启补充](../validation/v3.8/V3_8_2_WRITE_RESTART_AND_STABILIZATION_2026_10_22_ZH.md)。 |
| DRR-2026-144 | 已修复；源码／安装及限定原生6/6通过 | MySQL execute_read 补 analysis.source_sql 精确相等，与SQLite一致；此前MCP调用一致，无生产授权绕过复现。 | 新增12回归、五组旧坏／当前spy及正向控制、真机初始／复用／重连通过，77wheel资源一致；原SQL／参数及合法匹配调用保持。[修复与限制](../validation/v3.8/V3_8_2_MYSQL_WRITE_CONTRACTS_2026_10_22_ZH.md)。维护者重启后六项原生通过；内部错配参数未暴露为工具参数，分支证明仍属源码／安装。父待重启封存保留。[独立补充](../validation/v3.8/v382_mysql_write_contracts_2026_10_22/resident_restart/README.md)。 |
| DRR-2026-145 | 已补齐声明的真机验证缺口；非新缺陷结论 | MySQL8.0.25／InnoDB独立核对事务、计数、触发器／级联、故障及清理；维护者确认三门槛定义，自增空洞允许、无生产全库比较。 | 源码／wheel各14组、19故障、3竞争及96应用调用／32流程；unknown已提交／未变两对照、只执行一次及令牌重放拒绝。原可选四项另显式4/4，与默认四跳过分开；真实错误／断连与客户端注入分列，既定16类契约的稳定性门槛现已通过，更广范围仍未覆盖。[证据](../validation/v3.8/V3_8_2_MYSQL_WRITE_CONTRACTS_2026_10_22_ZH.md)。原生6/6刷新不增加确认写入证明；剩余门槛已列[有限执行表](../validation/v3.8/V3_8_2_STABILIZATION_PLAN_2026_10_22_ZH.md)。 [范围内最终验收](../validation/v3.8/V3_8_2_STABILIZATION_2026_10_22_ZH.md)。 |

工程化补充：[可移植哨兵与显式发布门槛](../validation/v3.8/V3_8_2_PORTABLE_RELEASE_GATES_2026_10_22_ZH.md)将这些性质保留在普通pytest及依赖感知的正常安装包／实库入口中。快速通过仍将实库标未验，不凭产品摘要自动复用；非新生产缺陷，不扩张未测范围保证，Hosted执行单列未验。

## 10月21日声明类型复评

| ID | 状态 | 问题与建议 | 证据与限制 |
| --- | --- | --- | --- |
| DRR-2026-140 | 已修复；维护者重启后限定核验通过 | SQLite原生空类型曾被补成TEXT，并错误合并compact组。 | 按批准保留原生PRAGMA类型（含空字符串／空格），覆盖describe／summary／compact/full；直接对比独立原生类型，去除测试中复制TEXT补值的做法。无亲和性推断／新查询／提示／grant或authorizer改动；分组可能增大响应。源码／wheel各184应用调用一致，新增13回归；最终源码／安装及限定原生范围见[补修](../validation/v3.8/V3_8_2_SQLITE_DECLARED_TYPES_REPAIR_2026_10_21_ZH.md)。维护者重启后9/9冻结原生检查通过；新增源码／安装各144次相邻调用，类型／默认值保持，无新独立生产根因。77资源／配置／数据库及65旧封存／2097记录保持；历史评估及137／138／139限定证据保留。 |
| DRR-2026-141 | 已实现；源码／安装及限定驻留检查通过 | 真实PRIMARY身份／顺序取代表列序PRI推断；可选primary_key_position复用SQLite原生位置、MySQL原有有界列读取连接真实PRIMARY目录。 | 三引擎非空唯一索引真机复现PRI不证明PRIMARY。源码／wheel各192调用、3373回归通过，独立目录对齐；compact是有序成员摘要，不是重复物理键项／完整DDL。接受目录连接／返回体成本，最新重启后原生12/12，位置／完整列对齐独立目录；此前原生7/12、新CLI12/12差异原样封存，具体绑定／缓存根因仍未确认。MariaDB不作验收要求，历史评估保留。[补修、成本与范围](../validation/v3.8/V3_8_2_PRIMARY_KEY_METADATA_REPAIR_2026_10_21_ZH.md)。 |
