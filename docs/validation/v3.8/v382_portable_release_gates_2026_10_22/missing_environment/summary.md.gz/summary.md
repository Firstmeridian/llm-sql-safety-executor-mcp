# Contract gate

Profile: release; status: unverified
Release ready: False

| Scenario | Status |
| --- | --- |
| fast | not_run |
| sqlite_semantics | not_run |
| sqlite_reads | not_run |
| sqlite_writes | not_run |
| mysql_writes | not_run |
| mysql_unknown | not_run |
| mysql_reads | not_run |

not_run means UNVERIFIED, not passed. Fast regression alone is not release acceptance.
Actual dependency/runtime identity is recorded; no automatic reuse of prior results.
