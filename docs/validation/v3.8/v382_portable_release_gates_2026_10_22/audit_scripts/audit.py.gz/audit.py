"""Read-only old-seal checks plus this batch's exact evidence assertions."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parents[1]
E = HERE/'evidence'


def read(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_manifest(path):
    value = read(path)
    files = value['files']
    entries = files.items() if isinstance(files, dict) else ((r['path'], r) for r in files)
    total, resolved = 0, {}
    for name, meta in entries:
        target = next(p for p in (path.parent/name, path.parent.parent/name, ROOT/name) if p.is_file())
        raw = target.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == (meta['sha256'] if isinstance(meta, dict) else meta), (path, name)
        resolved[name] = target
        if isinstance(meta, dict):
            if 'bytes' in meta:
                assert len(raw) == meta['bytes']
            if 'decoded_sha256' in meta:
                decoded = gzip.decompress(raw)
                assert hashlib.sha256(decoded).hexdigest() == meta['decoded_sha256']
                assert len(decoded) == meta['decoded_bytes']
        total += 1
    for name, meta in value.get('compressed_decoded_records', {}).items():
        decoded = gzip.decompress(resolved[name].read_bytes())
        assert hashlib.sha256(decoded).hexdigest() == meta.get('decoded_sha256', meta.get('sha256'))
        assert len(decoded) == meta.get('decoded_bytes', meta.get('bytes'))
    return total


def audit():
    before = read(E/'before.json')
    for name, digest in before['manifest_files'].items():
        assert sha(ROOT/name) == digest, name
    for name, digest in before['private_configs'].items():
        assert sha(ROOT/name) == digest, name
    current = {str(p.relative_to(ROOT/'src/sql_safety_executor')): sha(p)
               for p in (ROOT/'src/sql_safety_executor').rglob('*')
               if p.is_file() and p.suffix in {'.py', '.md'}}
    assert current == before['runtime'] and len(current) == 77
    old_plan = read(ROOT/'local_archive/v382_review/20261022_stabilization/evidence/frozen_plan.json')
    manifests = [ROOT/spec['manifest'] for spec in old_plan['certified_manifests']]
    manifests += [ROOT/'local_archive/v382_review/20261022_stabilization/manifest.json',
                  ROOT/'docs/validation/v3.8/v382_stabilization_2026_10_22/manifest.json']
    records = sum(verify_manifest(path) for path in manifests)
    assert len(manifests) == 87 and records == 2891
    release = read(E/'release_installed/report.json')
    assert release['status'] == 'passed' and release['release_ready'] is True
    assert all(v['status'] == 'passed' for v in release['checks'].values())
    assert release['fingerprint']['runtime'] == current
    assert release['checks']['fast']['passed'] == 3541
    assert release['checks']['fast']['skipped'] == 4
    source = read(E/'fast_source/report.json')
    assert source['status'] == 'passed' and source['release_ready'] is False
    assert source['checks']['fast']['passed'] == 3539
    assert source['checks']['mysql_writes']['status'] == 'not_run'
    calls = {}
    for name in ('sqlite_semantics', 'sqlite_reads', 'sqlite_writes',
                 'mysql_writes', 'mysql_unknown', 'mysql_reads'):
        value = read(E/'release_installed'/(name+'.json.gz'))
        rows = value.get('records', value.get('client_records', value.get('calls')))
        calls[name] = len(rows)
        resources = value.get('resources', value.get('source_sha256', value.get('installed_source_sha256')))
        assert resources == current
    assert calls == {'sqlite_semantics': 130, 'sqlite_reads': 74, 'sqlite_writes': 432,
                     'mysql_writes': 72, 'mysql_unknown': 24, 'mysql_reads': 128}
    live = read(E/'release_installed/mysql_writes.json.gz')
    assert live['legacy_integration']['passed'] == 4 and live['legacy_integration']['skipped'] == 0
    for name in ('mysql_writes', 'mysql_unknown', 'mysql_reads'):
        assert read(E/'release_installed'/(name+'.json.gz'))['disposable_schema_removed'] is True
    assert read(E/'portable_checkout_final.json')['passed'] is True
    assert read(E/'entrypoint_controls.json')['all_scenarios_unverified'] is True
    return {'passed': True, 'runtime_unchanged': 77, 'private_tomls_unchanged': 3,
            'old_manifest_digests_unchanged': len(before['manifest_files']),
            'old_certified_seals_verified': len(manifests), 'old_file_records_verified': records,
            'new_regular_tests': 36, 'final_wheel_full_passes': 3541, 'initial_optional_skips': 4,
            'live_optional_passes': 4, 'live_optional_skips': 0, 'application_calls': calls,
            'total_application_calls': sum(calls.values()), 'server': live['server'],
            'hosted_workflow_executed': False, 'new_model_trials': 0, 'restart_required': False,
            'limits': ['finite existing contract matrix', 'normal wheel with frozen dependency reuse',
                       'two result variants, not exhaustive mutation testing',
                       'source fast checkpoint before two additional infrastructure self-checks',
                       'historical model/wording/cost limits remain separate']}


if __name__ == '__main__':
    value = audit()
    path = E/'checks.json'
    assert not path.exists()
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(value, ensure_ascii=False))
