"""Append this batch's public/private evidence without touching older seals."""
import gzip
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parents[1]
E = HERE/'evidence'
PUBLIC = ROOT/'docs/validation/v3.8/v382_portable_release_gates_2026_10_22'
DOC = ROOT/'docs/validation/v3.8/V3_8_2_PORTABLE_RELEASE_GATES_2026_10_22_ZH.md'
ACTIVE = [
    'AI_COLLABORATION_GUIDE.md', 'REFACTORING_LOG.md', 'REFACTORING_LOG_ZH.md',
    'docs/README.md', 'docs/README_ZH.md', 'docs/guides/TEST_MCP_CLIENT_GUIDE.md',
    'docs/releases/RELEASE_NOTES_v3_8.md', 'docs/security/DESIGN_RISK_REGISTER.md',
    'docs/security/DESIGN_RISK_REGISTER_ZH.md', 'docs/security/V3_8_SECURITY.md',
    'scripts/validation/README.md', str(DOC.relative_to(ROOT)),
    'local_archive/v382_review/README.md',
    'local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md',
    'local_archive/AGENT_WORKFLOW_PLAYBOOK_ZH.md',
]


def packed(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists(), target
    target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))


def manifest(root):
    files = {}
    for path in sorted(root.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or path == root/'manifest.json':
            continue
        raw = path.read_bytes()
        value = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        if path.suffix == '.gz':
            decoded = gzip.decompress(raw)
            value.update(decoded_bytes=len(decoded), decoded_sha256=hashlib.sha256(decoded).hexdigest())
        files[str(path.relative_to(root))] = value
    (root/'manifest.json').write_text(json.dumps({
        'date': '2026-10-22', 'checkpoint': 'portable release gates',
        'append_rule': 'Sealed; future changes use a new supplement, never overwrite this record.',
        'files': files}, ensure_ascii=False, indent=2)+'\n')
    return len(files)


def check_links(paths):
    count = 0
    for path in paths:
        text = re.sub(r'```.*?```', '', path.read_text(), flags=re.S)
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', text):
            target = target.strip().strip('<>')
            if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', target) or target.startswith('#'):
                continue
            name = unquote(target.split('#')[0])
            if not name:
                continue
            destination = Path(name) if name.startswith('/') else path.parent/name
            assert destination.exists(), (str(path.relative_to(ROOT)), target)
            count += 1
    return count


def run():
    assert not (HERE/'manifest.json').exists() and not PUBLIC.exists()
    assert json.loads((E/'checks.json').read_text())['passed'] is True
    PUBLIC.mkdir(parents=True)
    (PUBLIC/'README.md').write_text('''# Portable release gate evidence · October 22, 2026

See the [report](../V3_8_2_PORTABLE_RELEASE_GATES_2026_10_22_ZH.md) and
[reusable commands](../../../../scripts/validation/README.md).

The normally installed wheel passes 3541 regular tests/four initial optional
skips, then 860 application calls and four actual MySQL passes/no skips. Real
MySQL 8.0.25/InnoDB matrices and owned-schema cleanup pass. The earlier source
checkpoint passes 3539 before two additional infrastructure checks. The final
minimal checkout passes all 36 new tests without archives/history/conftest.

Compressed outputs retain actual dependencies, JUnit, application records,
script/doc snapshots and the interrupted sandbox attempt. The old wheel is
normally installed with RECORD verification and frozen dependency-directory
reuse, not a new dependency resolution. No production/configuration/grant change.
No new Host restart, model/token/performance claim or Hosted execution proof.
Application records are not complete protocol frames. Old evidence remains sealed.
The manifests cover compressed and decoded bytes; append future supplements.
''')
    for path in sorted(E.rglob('*')):
        if path.is_file():
            rel = path.relative_to(E)
            target = PUBLIC/rel
            target = target if target.suffix == '.gz' else target.with_name(target.name+'.gz')
            if path.suffix == '.gz':
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(path.read_bytes())
            else:
                packed(path, target)
    scripts = ['scripts/validation/release_gate.py', 'scripts/validation/mysql_writes.py',
               'tests/test_contract_sentinels.py', 'tests/test_release_gate.py',
               '.github/workflows/ci.yml', '.github/workflows/release-contracts.yml']
    for name in scripts:
        source = ROOT/name
        packed(source, PUBLIC/'inputs'/(name+'.gz'))
        packed(source, E/'inputs'/(name+'.gz'))
    for name in ACTIVE:
        source = ROOT/name
        packed(source, E/'docs'/(name+'.gz'))
        if not name.startswith('local_archive/'):
            packed(source, PUBLIC/'docs'/(name+'.gz'))
    links = check_links([ROOT/name for name in ACTIVE]+[PUBLIC/'README.md', HERE/'reports/README_ZH.md'])
    result = {'passed': True, 'local_links_checked': links,
              'hosted_execution_claim': False, 'runtime_changed': False}
    (E/'documentation_checks.json').write_text(json.dumps(result, indent=2)+'\n')
    packed(E/'documentation_checks.json', PUBLIC/'documentation_checks.json.gz')
    # Keep this very publisher/auditor with the public evidence too.
    for name in ('audit.py', 'publish.py'):
        packed(HERE/'scripts'/name, PUBLIC/'audit_scripts'/(name+'.gz'))
    public_count = manifest(PUBLIC)
    private_count = manifest(HERE)
    print(json.dumps({**result, 'private_files': private_count, 'public_files': public_count}))


if __name__ == '__main__':
    run()
