"""Grade the frozen canary-plus-two-turn sales trials using public evidence."""
from collections import Counter
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parents[1] / 'evidence/resident_restart/real_tasks'


def read(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)


def finals(record):
    return ['\n'.join(c.get('text', '') for c in e.get('content', []))
            for e in record['events'] if e.get('kind') == 'message'
            and e.get('role') == 'assistant' and e.get('channel') == 'final']


def has_numbers(text, values):
    # Magnitudes are compared here; direction is checked independently below.
    found = {abs(Decimal(n)) for n in re.findall(r'(?<![\w])[-+]?\d+(?:\.\d+)?', text.replace(',', ''))}
    return all(abs(Decimal(str(n))) in found for n in values)


def usage_delta(later, earlier):
    result = {key: later[key] - earlier.get(key, 0) for key in later}
    assert all(value >= 0 for value in result.values())
    return result


def main():
    plan = read(OUT / 'plan.json')
    before, after = read(OUT / 'truth_before.json'), read(OUT / 'truth_after.json')
    assert before['source_sha256'] == after['source_sha256']
    for name, digest in before['source_sha256'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    for alias, record in before['connections'].items():
        assert record['authorized_data'] == after['connections'][alias]['authorized_data']
        assert record['results'] == after['connections'][alias]['results']
    truth = before['connections']['union_test_sqlite']['results']
    trials = []
    for item in read(OUT / 'agents.json'):
        i = item['trial']
        full, canary = read(OUT / f'sales_{i}.json.gz'), read(OUT / f'canary_{i}.json.gz')
        final = finals(full)
        # The shared collector recognizes exact scripted texts. This batch's
        # first business input additionally prepends base_prompt, so its stored
        # legacy turn labels lag one turn. Preserve that original record and
        # derive phase labels from the exact public input boundaries here.
        inputs = []
        for event in full['events']:
            if event.get('kind') == 'message' and event.get('role') == 'user':
                text = '\n'.join(c.get('text', '') for c in event.get('content', []))
                if (text.startswith(plan['trial_marker'])
                        or text == plan['base_prompt'] + '\n\n' + plan['cases']['sales']['turns'][1]
                        or text == plan['cases']['sales']['turns'][2]):
                    inputs.append(event['timestamp'])
        obs = []
        for original in full['observations']['mcp_response_observations']:
            row = dict(original)
            row['collector_original_turn'] = row['turn']
            row['turn'] = sum(start <= row['timestamp'] for start in inputs)
            obs.append(row)
        setup = [o for o in obs if o['turn'] == 1]
        business = [o for o in obs if o['turn'] in (2, 3)]
        code = '\n'.join(e.get('input', e.get('arguments', '')) for e in full['events']
                         if e.get('kind') in ('custom_tool_call', 'function_call'))
        methods = Counter(m.removeprefix('mcp__sql_safety_executor_mcp__')
                          for o in obs for m in o['method_candidates'])
        # Validate each phase separately; preserve failed trials rather than
        # replacing them or counting setup SELECT 7 as a business outcome.
        checks = {
            'actual_child_canary': len(setup) == 1 and setup[0]['success'] is True
                and setup[0]['body'].get('data') == [{'n': 7}]
                and setup[0]['connection_id'] == 'union_test_sqlite',
            'all_three_scripted_inputs_observed': len(inputs) == 3,
            'three_finals': len(final) == 3,
            'same_child': full['agent_id'] == canary['agent_id'] == item['agent_id'],
            'only_requested_connection': all(o.get('connection_id') in (None, 'union_test_sqlite') for o in obs),
            'native_mcp_only': all(name.startswith('mcp__sql_safety_executor_mcp__')
                                   for name in re.findall(r'await tools\.(\w+)', code)),
            'read_tools_only': set(methods) <= {'query', 'list_tables', 'get_full_schema', 'describe_table', 'list_skills', 'get_skill_detail'},
            'no_host_error': all(o['isError'] is not True for o in obs),
            'no_truncated_data': all(o.get('truncated') is not True for o in obs),
            'business_returned_each_turn': all(any(o['turn'] == t for o in business) for t in (2, 3)),
            'within_budget': max(Counter(o['turn'] for o in obs).values(), default=0) <= 12,
        }
        initial = final[1] if len(final) > 1 else ''
        update = final[2] if len(final) > 2 else ''
        initial_numbers = [720, 38, 331921.71, 110389.19, 110985.37, 110547.15, 0.39, 27.92]
        initial_numbers += [r['revenue'] for r in truth['top_products']]
        updated_numbers = [548, 38, 253826.38] + [r['revenue'] for r in truth['without_east_top_products']]
        checks['initial_metrics'] = (has_numbers(initial, initial_numbers)
            and all(r['product_code'] in initial for r in truth['top_products'])
            and ('south' in initial.lower() or '南区' in initial)
            and bool(re.search(r'下降|减少|负|[-−]0\.39', initial)))
        checks['updated_metrics'] = (has_numbers(update, updated_numbers)
            and all(r['product_code'] in update for r in truth['without_east_top_products']))
        # Semantic assessment (correct record-preserving aggregation, no
        # cross-connection fallback, scope-change explanation) is separately
        # attested against public SQL and finals in manual_review.json.
        manual = read(OUT / 'manual_review.json')[str(i)]
        checks.update(manual['checks'])
        trials.append({
            'trial': i, 'agent_id': item['agent_id'], 'checks': checks,
            'passed': all(checks.values()), 'methods': dict(methods),
            'no_policy_or_tool_rejection': all(o['success'] is True for o in obs),
            'rejections': [{'phase': o['turn'], 'error_code': o.get('error_code')}
                           for o in obs if o['success'] is not True],
            'phase_observations': [{k: v for k, v in o.items() if k != 'body'} for o in obs],
            'phase_attribution': 'Recomputed from exact public scripted input timestamps; original collector turn labels retained separately.',
            'all_mcp_returns': len(obs), 'canary_mcp_returns': len(setup),
            'business_mcp_returns': len(business),
            'business_by_turn': dict(Counter(o['turn'] for o in business)),
            'return_profiles': dict(Counter(o['profile'] for o in obs)),
            'catalog_inspections': full['observations']['local_tool_catalog_inspections'],
            'all_model_responses': len(full['per_response_usage']),
            'business_model_responses': len(full['per_response_usage']) - len(canary['per_response_usage']),
            'all_usage': full['usage'], 'canary_usage': canary['usage'],
            'business_usage_delta': usage_delta(full['usage'], canary['usage']),
            'all_active_seconds': full['active_turn_wall_seconds'],
            'canary_active_seconds': canary['active_turn_wall_seconds'],
            'business_active_seconds': round(full['active_turn_wall_seconds'] - canary['active_turn_wall_seconds'], 3),
            'public_tool_output_bytes': sum(len(str(e.get('output', '')).encode()) for e in full['events']
                                            if e.get('kind') in ('custom_tool_call_output', 'function_call_output')),
            'manual_review': manual['notes'],
        })
    assert len(trials) == plan['repeats_per_case'] == 3
    summary = {
        'version': '3.8.2', 'model': plan['model'], 'reasoning_effort': plan['reasoning_effort'],
        'trials': trials, 'planned_trials': 3, 'passed_complete_business_trials': sum(t['passed'] for t in trials),
        'trials_without_policy_or_tool_rejection': sum(t['no_policy_or_tool_rejection'] for t in trials),
        'scripted_user_inputs': 9, 'setup_canary_inputs': 3, 'business_user_inputs': 6,
        'all_mcp_returns': sum(t['all_mcp_returns'] for t in trials),
        'business_mcp_returns': sum(t['business_mcp_returns'] for t in trials),
        'all_model_responses': sum(t['all_model_responses'] for t in trials),
        'business_model_responses': sum(t['business_model_responses'] for t in trials),
        'all_active_seconds': round(sum(t['all_active_seconds'] for t in trials), 3),
        'business_active_seconds': round(sum(t['business_active_seconds'] for t in trials), 3),
        'all_usage': {k: sum(t['all_usage'][k] for t in trials) for k in trials[0]['all_usage']},
        'business_usage_delta': {k: sum(t['business_usage_delta'][k] for t in trials) for k in trials[0]['business_usage_delta']},
        'scope': 'Each actual child passed one setup call before its own two business turns. This warms the same context and is not a matched A/B with earlier unprepared trials. Three trials do not establish an availability rate.',
        'cost_limits': 'Host cumulative usage minus saved canary checkpoint; cached input is a subset. Active intervals include model/Host/tool/shared-service time; public output bytes include metadata, omit complete transport. No invoice, pure server latency, legacy A/B or WHEN-specific business coverage claim.',
        'data_integrity': {'authorized_tables_unchanged': 7, 'runtime_resources_unchanged': 75, 'configured_writes': False},
        'historical_business_result': 'Original pre-WHEN three trials remain 2/3, with one Host availability failure; not relabeled by this batch.',
    }
    (OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: v for k, v in summary.items() if k != 'trials'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
