"""Append native and complete-task evidence without rewriting parent seals."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
LOCAL = BATCH / 'evidence/resident_restart'
PARENT = ROOT / 'docs/validation/v3.8/v382_when_2026_10_17'
PUBLIC = PARENT / 'resident_restart'


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not PUBLIC.exists(), 'Append a new supplement instead of replacing a seal'
    checkpoint = read(PARENT / 'verification.json')
    for relative, digest in checkpoint['runtime_resources'].items():
        assert sha(ROOT / 'src/sql_safety_executor' / relative) == digest, relative
    for relative, digest in checkpoint['scripts'].items():
        assert sha(ROOT / relative) == digest, relative
    preserved = {}
    manifests = list(checkpoint['preserved_manifests']) + [str((PARENT / 'manifest.json').relative_to(ROOT))]
    for name in manifests:
        manifest = ROOT / name
        old = read(manifest)
        base = manifest.parent.parent if name.startswith('local_archive/') else manifest.parent
        for relative, info in old['files'].items():
            path = base / relative
            assert sha(path) == info['sha256'] and path.stat().st_size == info['bytes'], str(path)
        if name in checkpoint['preserved_manifests']:
            assert sha(manifest) == checkpoint['preserved_manifests'][name]['manifest_sha256']
        preserved[name] = len(old['files'])
    assert sum(preserved.values()) == 469

    native = read(LOCAL / 'native.json')
    assert native['summary'] == {'calls': 57, 'passed': 57}
    assert len(native['records']) == len(native['checks']) == 57
    for row, check in zip(native['records'], native['checks']):
        raw = row['raw']
        assert not raw.get('isError') and row['name'] == check['name']
        payload = raw['structuredContent']
        text = [c['text'] for c in raw['content'] if c['type'] == 'text']
        assert len(text) == 1 and json.loads(text[0]) == payload
        assert check['passed'] and all(payload.get(k) == v for k, v in row['expected'].items())
    snapshots = [r['raw']['structuredContent']['data'] for r in native['records'] if r['name'].startswith('snapshot_')]
    assert len(snapshots) == 3 and snapshots[0] == snapshots[1] == snapshots[2]
    assert len(snapshots[0]) == 5 and all(len(r) == 5 for r in snapshots[0])
    snapshot_hash = hashlib.sha256(json.dumps(snapshots[0], sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
    tasks = read(LOCAL / 'real_tasks/summary.json')
    assert tasks['planned_trials'] == tasks['passed_complete_business_trials'] == 3
    assert tasks['trials_without_policy_or_tool_rejection'] == 2
    assert (tasks['all_mcp_returns'], tasks['business_mcp_returns']) == (18, 15)
    before, after = read(LOCAL / 'real_tasks/truth_before.json'), read(LOCAL / 'real_tasks/truth_after.json')
    assert before['source_sha256'] == after['source_sha256']
    assert len(before['source_sha256']) == 75
    for name, digest in before['source_sha256'].items():
        assert sha(ROOT / name) == digest, name
    for alias, record in before['connections'].items():
        assert record['authorized_data'] == after['connections'][alias]['authorized_data']
        assert record['results'] == after['connections'][alias]['results']
    facts = read(LOCAL / 'real_tasks/fixture_scope_checks.json')
    assert facts['initial_trial3_unsupported_from']['sqlite_success']
    assert facts['initial_trial3_unsupported_from']['mcp_error_code'] == 'sql_parse_failed'
    verification = {
        'version': '3.8.2', 'status': 'accepted_with_explicit_native_coverage_limits',
        'observed_utc': native['observed_utc'], 'maintainer_restart': native['maintainer_restart'],
        'native': {'recorded_calls': 57, 'checks_passed': 57, 'successful_plans': 38,
                   'required_refusals': 13, 'other_controls': 6, 'text_structured_matching': 57,
                   'protocol': 'Not exposed by this native facade.',
                   'fixture_source': 'Rerun only the 57 previously matched specifications. Historical 12 exploratory mismatches remain in their original supplement.'},
        'data_integrity': {'native_connection_id': 'analytics_demo_sqlite', 'rows': 5, 'columns': 5,
                           'native_snapshots': 3, 'native_snapshot_sha256': snapshot_hash,
                           'configured_SQLite_authorized_table_fingerprints_unchanged': 7, 'configured_writes': False},
        'source': {'disk_resources_match_parent': 75, 'scripts_tests_match_parent': len(checkpoint['scripts']),
                   'loaded_code_objects': 'Not introspected; current native observations are distinct from disk/wheel hashes.'},
        'complete_business_trials': {'planned': 3, 'passed_final_outcomes': 3,
                    'without_initial_policy_or_tool_rejection': 2, 'actual_child_canaries_passed': 3,
                    'actual_inputs': 9, 'business_inputs': 6, 'canary_inputs': 3,
                    'business_MCP_returns': 15, 'all_MCP_returns': 18,
                    'retained_refusal': 'Trial 3: unsupported FROM subquery returned sql_parse_failed; same child recovered with CTEs.',
                    'old_trials': 'Pre-WHEN complete business result remains 2/3, one Host availability failure. No historical relabeling.',
                    'comparability': 'Canary-warmed actual-child contexts differ from earlier unprepared trials; not an availability/cost A/B.'},
        'parent_checkpoint': {'manifest': '../manifest.json', 'sha256': sha(PARENT / 'manifest.json'),
                             'files_unchanged': 69, 'scope': 'Retains its then-pending status; this append supplies the post-restart observations.'},
        'preserved_manifests': preserved, 'preserved_sealed_files_verified': 469,
        'coverage_limits': [
            'No configured trigger/WHEN/UDF/plan-Skill fixture was added. The exact WHEN repair has 79 regressions and 394 same-source installed targeted calls, rather than a native fixture replay.',
            'Sample and exact-count tools are not exposed by this native Host; their coverage remains source/package evidence.',
            'Native tool metadata is not a wire tools/list. Application evidence omits full frames and notifications.',
            'Complete sales tasks exercise current native multi-CTE aggregation and task recovery, not trigger-definition execution or complete dialect coverage.',
            'Three successes after real canaries do not establish a Host availability rate or explain the original exact-ready-client failure.',
            'Existing repeated outer-CTE false refusal and trusted generated-column/UDF scope remain; no new backend, server latency or model-cost A/B claim.',
        ],
    }
    PUBLIC.mkdir()
    for name in ('native', 'tool_catalog'):
        (PUBLIC / (name + '.json.gz')).write_bytes(gzip.compress((LOCAL / (name + '.json')).read_bytes(), mtime=0))
    shutil.copytree(LOCAL / 'real_tasks', PUBLIC / 'real_tasks')
    for name in ('summarize_restart_tasks.py', 'seal_restart.py'):
        (PUBLIC / (name + '.gz')).write_bytes(gzip.compress((BATCH / 'scripts' / name).read_bytes(), mtime=0))
    (PUBLIC / 'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
    files = {p.relative_to(PUBLIC).as_posix(): {'sha256': sha(p), 'bytes': p.stat().st_size}
             for p in sorted(PUBLIC.rglob('*')) if p.is_file()}
    (PUBLIC / 'manifest.json').write_text(json.dumps({
        'closed_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Post-restart native and three canary-conditioned complete business trials; all prior seals unchanged.',
        'files': files}, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'native_checks': 57, 'complete_business_passed': 3, 'planned_trials': 3,
                      'retained_business_refusals': 1, 'source_resources': 75,
                      'preserved_files': 469, 'new_sealed_files': len(files)}))


if __name__ == '__main__':
    main()
