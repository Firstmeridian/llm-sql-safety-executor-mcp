"""Advance current documentation; leave all sealed evidence unchanged."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4]
REPORT='V3_8_2_TRIGGER_WHEN_2026_10_17_ZH.md'
changes={}


def replace(name,old,new):
    text=changes.get(name,(ROOT/name).read_text());assert text.count(old)==1,(name,old)
    changes[name]=text.replace(old,new,1)


for name,title,body in [
    ('REFACTORING_LOG.md','v3.8.2 Repair trigger WHEN roles and diagnose Host readiness (October 17, 2026; resident verification pending)',
     'Parse the complete WHEN expression with the existing SQLite SQLGlot parser before requiring BEGIN, preserving begin columns/CTEs/functions and checking every original condition/body fragment. Keep original SQL/parameters, grants, callback isolation and budgets; no new dependency or required Agent step. One extra expression parse applies only to prepared trigger WHEN definitions.\n\n- Add 79 regressions: 2275 passed/four optional MySQL skips, clean type/prompt checks; all 76 matched fixture/prefix cases meet expectations, restoring 12 false refusals. Source child stdio 254 calls and installed wheel 394 targeted calls pass across both protocols. The fresh wheel interpreter explicitly reuses frozen dependencies; all 75 package resources match. Resident acceptance awaits the maintainer restart.\n\n- Host structured logs show cached catalog advertisement without waiting for startup, then omission because no exact ready client existed. Successful children also used cached catalogs; stale content/initialization/binding root cause remains unproven. Closing/resuming the same failed child restores a real call; retain the original 2/3 business result and separate a new canary argument error/correction. Independent configured stdio passes 9/9 outside the sandbox; sandbox 10/60-second failures are not evidence of the native child root cause. No global Host configuration was changed.'),
    ('REFACTORING_LOG_ZH.md','v3.8.2 修复触发器 WHEN 角色并排查 Host 就绪（2026-10-17；待驻留复验）',
     '通过现有 SQLite SQLGlot 解析完整 WHEN 后再要求正文 BEGIN，保留 begin 业务列／CTE／函数角色，原条件与每个正文仍完整核验。原 SQL、参数、grant、回调独占及预算不变，不新增依赖或 Agent 必需步骤；仅需要准备的触发器 WHEN 增加一次表达式解析。\n\n- 新增 79 项，全量 2275 passed／4 skipped，类型／提示通过；76 个同输入夹具／前缀组合符合预期，恢复 12 项误拒。源码 child stdio 254 次、wheel 两协议定点 394 次通过，75 项资源一致；独立 wheel 解释器明确复用锁定依赖。待维护者重启后限定复验。\n\n- Host 结构化日志确认先复用缓存目录不等 startup，随后因无 exact ready client 省略服务；成功会话也使用缓存，不能断言缓存过旧，初始化／绑定底层原因仍未定。同一失败子会话关闭／恢复后真实调用成功；原业务 2/3 保留，新探针参数错误及纠正另列。沙盒外同配置 stdio 9/9，沙盒内 10／60 秒失败不反推原生故障原因。未改用户级 Host 配置。'),
]:
    text=(ROOT/name).read_text();offset=text.index('## v3.8.2 ');assert title not in text
    link='Findings, evidence and pending restart' if name=='REFACTORING_LOG.md' else '修复、Host 恢复办法、证据与待重启状态'
    changes[name]=text[:offset]+f'## {title}\n\n- {body}\n\n- [{link}](docs/validation/v3.8/{REPORT})。\n\n'+text[offset:]

for name,marker,new in [
    ('README.md','A [later adjacent audit]',f'The adjacent audit\'s trigger-WHEN boundary is now repaired: **2275 tests pass, 4 skipped**, with 394 installed targeted calls. Host cached-catalog/exact-client diagnostics and verified child recovery are recorded separately from the earlier 2/3 business result. Scoped resident verification awaits the maintainer restart; see the [WHEN repair](docs/validation/v3.8/{REPORT}).'),
    ('README_ZH.md','后续[相邻复查]',f'相邻复查的触发器 WHEN 边界已补修：**2275 passed／4 skipped**、394 次安装定点调用通过；Host 缓存目录／就绪客户端的诊断与已验证恢复办法另列，原业务 2/3 不改写。待维护者重启限定复验，见[WHEN 修复报告](docs/validation/v3.8/{REPORT})。'),
    ('docs/security/V3_8_SECURITY.md','Current follow-up: the [adjacent audit]',f'Current follow-up: the [WHEN repair](../validation/v3.8/{REPORT}) consumes the real condition expression before requiring the body marker, restoring the confirmed begin-column regression. Every original condition/body dependency and function remains checked. Source/package validation passes; scoped resident acceptance awaits a maintainer restart. Separate Host logs confirm cached metadata without an exact ready client, with close/resume recovery observed; they do not prove stale cache or an underlying startup/binding root cause.'),
]:
    lines=[line for line in (ROOT/name).read_text().splitlines() if marker in line];assert len(lines)==1,(name,lines)
    replace(name,lines[0],new)

for name,marker,block in [
    ('docs/releases/RELEASE_NOTES_v3_8.md','The [later adjacent audit]',f'Subsequent [WHEN repair](../validation/v3.8/{REPORT}): consume the true expression before BEGIN, preserve original SQL and all dependency/function checks. Add 79 regressions, 2275 full passes/four skips and 394 installed targeted calls; resident checks are pending. Host catalog/client mismatch logs and close/resume recovery remain separate from the original business failure and unproven underlying cause.'),
    ('docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md','再后续相邻审计确认',f'上述 WHEN／BEGIN 问题随后按表达式真实角色补修：可选 FOR EACH ROW 后，现有 SQLite SQLGlot 解析消费完整条件，再要求正文标记；原始 WHEN 与各片段仍独立分析，运行原 SQL。多一次表达式解析，无新增 I/O／grant／Agent 必需调用。当前 2275 回归及安装 394 次通过，待驻留复验；Host 目录缓存与就绪客户端的排查另见[最新报告](../validation/v3.8/{REPORT})。'),
    ('docs/guides/TEST_MCP_CLIENT_GUIDE.md','Use `scripts/validation/sqlite_trigger_ctes.py',f'The same trigger script now includes keyword-shaped WHEN columns, CASE/subquery controls, a denied WHEN dependency and a bound WHEN plan Skill. Verify original conditions and every body fragment; do not repair delimiter ambiguity by skipping the condition or disabling the authorizer. [Latest validation](../validation/v3.8/{REPORT}).'),
]:
    line=next(line for line in (ROOT/name).read_text().splitlines() if marker in line)
    replace(name,line,line+'\n\n'+block)

for name,title,link in [
    ('docs/README.md','v3.8.2 WHEN repair and Host readiness diagnosis',f'validation/v3.8/{REPORT}'),
    ('docs/README_ZH.md','v3.8.2 触发器 WHEN 修复与 Host 就绪排查',f'validation/v3.8/{REPORT}'),
]:
    text=(ROOT/name).read_text();marker='V3_8_2_ADJACENT_AUDIT_2026_10_17_ZH.md'
    line=next(line for line in text.splitlines() if marker in line)
    replace(name,line,line+f'\n- [{title}]({link})。')

name='docs/validation/v3.8/V3_8_2_ADJACENT_AUDIT_2026_10_17_ZH.md'
title=(ROOT/name).read_text().splitlines()[0]
replace(name,title,title+f'\n\n> 后续：已获准补修 WHEN 角色边界，源码／安装验证通过，待本批驻留复验；Host 结构化就绪日志与恢复实测见[后续报告]({REPORT})。下文保留发现时的原始结论、2/3 业务结果和源码范围。')

for name,zh in [('docs/security/DESIGN_RISK_REGISTER.md',False),('docs/security/DESIGN_RISK_REGISTER_ZH.md',True)]:
    line=next(line for line in (ROOT/name).read_text().splitlines() if line.startswith('| DRR-2026-108 |'))
    cells=line.split('|');assert len(cells)==12
    cells[2]=' 已补修；WHEN 批次待驻留复验 ' if zh else ' Implemented; WHEN resident verification pending '
    cells[8]+= (' 按真实表达式角色消费 WHEN 后再定位 BEGIN；原条件及全部正文仍完整分析。 ' if zh else ' Consume WHEN using the dialect expression parser before requiring BEGIN; retain complete original condition/body analysis. ')
    cells[9]+= (f' WHEN 补修新增 79 项，全量 2275 passed／4 skipped、类型／提示及安装 394 次通过，76 组符合预期；待维护者重启。[最新修复](../validation/v3.8/{REPORT})。 ' if zh else f' WHEN repair: 79 new regressions, 2275 full passes/four skips, clean type/prompt checks and 394 installed calls; 76 matched cases meet expectations. Resident restart pending. [Latest repair](../validation/v3.8/{REPORT}). ')
    cells[10]=cells[10].replace('Repair the actual WHEN/body role boundary and rerun matched inputs before final closure.','WHEN boundary is repaired and matched inputs pass; finish scoped resident acceptance before final closure.').replace('下一步修 WHEN／正文真实角色边界并复验，当前不宣称最终关闭。','WHEN 已补修且同输入复验通过，完成本批限定驻留核验后再最终关闭。')
    replace(name,line,'|'.join(cells))

name='docs/guides/TEST_MCP_CLIENT_GUIDE.md'
line=next(line for line in (ROOT/name).read_text().splitlines() if line.startswith('Build backend packages need not'))
replace(name,line,line+'\n\nAn offline build may reuse already-cached backend distributions with `python -m build --no-isolation`; record the backend versions. A normal wheel installation in a fresh interpreter may explicitly reuse a frozen dependency directory: assert the tested package comes from that interpreter, reject editable import hooks and compare packaged resources. Describe this as dependency reuse, not fresh dependency resolution. The WHEN batch records this path and the interrupted/timeout uv downloads separately.')

name='local_archive/v382_review/README.md';text=(ROOT/name).read_text()
changes[name]=text+f'\n## WHEN 修复与 Host 就绪排查\n\n`20261017_when_repair/` 的 scripts／evidence 保存 79 项回归、2275 全量通过、394 次安装定点调用及限定 Host 诊断。正式[修复报告](../../docs/validation/v3.8/{REPORT})待驻留补充，旧 400 项封存不改写。Host 操作建议见 [handoff](handoff/codex-sql-mcp-readiness.md)；未自动改用户级配置。\n'

name='local_archive/v382_review/handoff/commit-message-v382.txt'
replace(name,'- retain native Luna failures, scoped evidence and cost comparisons','- retain Luna failures, Host recovery evidence and scoped cost measurements')

for name,text in changes.items():(ROOT/name).write_text(text)
print({'documentation_files':len(changes),'status':'source/package passed; resident restart pending'})
