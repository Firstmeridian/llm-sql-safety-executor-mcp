"""Read only whitelisted catalog-binding diagnostics from the local Host log."""
from datetime import datetime,timezone
import gzip
import json
from pathlib import Path
import sqlite3

BATCH=Path(__file__).resolve().parents[1]
ids=['01a14994-ceb4-7632-b67a-e2e9fac28337','01a14994-cf9e-7042-9786-ce1f5c024395',
     '01a14994-d166-7682-95cc-06df68495191']
start=int(datetime(2026,10,17,11,17,20,tzinfo=timezone.utc).timestamp())
source=Path.home()/'.codex/logs_2.sqlite'
with sqlite3.connect(source.as_uri()+'?mode=ro',uri=True) as db:
    db.execute('PRAGMA query_only=ON')
    rows=db.execute("SELECT id,ts,ts_nanos,level,target,thread_id,feedback_log_body FROM logs "
        "WHERE ts BETWEEN ? AND ? AND target='codex_mcp::connection_manager::tool_catalog' "
        "AND thread_id IN (?,?,?) AND feedback_log_body LIKE '%server_name=sql-safety-executor-mcp%' "
        "ORDER BY ts,ts_nanos",(start,start+90,*ids)).fetchall()
records=[]
for identity,ts,nanos,level,target,thread,body in rows:
    marker='capture_binding_with_metadata: '
    assert marker in body
    message=body.split(marker,1)[1]
    assert message.startswith(('using cached MCP catalog without waiting for startup',
                               'omitting MCP server without an exact ready client'))
    records.append(dict(log_row_id=identity,utc=datetime.fromtimestamp(ts,timezone.utc).isoformat(),
        ts_nanos=nanos,level=level,target=target,thread_id=thread,message=message,
        feedback_log_body=body))
assert any(r['thread_id']==ids[2] and 'omitting' in r['message'] for r in records)
assert any(r['thread_id']==ids[2] and 'using cached' in r['message'] for r in records)
assert any(r['thread_id']!=ids[2] and 'using cached' in r['message'] for r in records)
data={'source':'Codex local logs_2.sqlite, read-only URI and query_only',
      'filter':'Exact tool_catalog target, three original trial ids, 90-second time window, SQL MCP server marker only',
      'records':records,
      'interpretation':{'confirmed':'The failed context first advertised cached tool metadata without waiting for startup, then omitted SQL MCP because no exact ready client existed. Successful contexts also used cached metadata.',
                        'unproven':['Why the exact ready client was absent','Whether initialization failed or was still pending','Whether a config/binding race occurred','Whether stale metadata content caused the issue'],
                        'limits':'These catalog logs do not contain the underlying process/handshake failure; do not infer that clearing caches or a larger timeout is a proven root fix.'}}
path=BATCH/'evidence/host_binding_logs.json.gz';assert not path.exists()
path.write_bytes(gzip.compress((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
print(json.dumps({'records':len(records),'confirmed_cached_catalog_then_no_exact_ready_client':True,'root_initialization_cause':'unproven'}))
