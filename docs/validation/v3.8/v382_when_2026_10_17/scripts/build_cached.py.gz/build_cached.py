"""Build sdist then wheel with existing cached backend distributions, offline."""
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[4]
archive=Path.home()/'.cache/uv/archive-v0'
modules=['hatchling','pathspec','trove_classifiers','tomlkit']
paths=[]
for name in modules:
    matches=[p for p in archive.iterdir() if (p/name).is_dir()]
    assert len(matches)==1,(name,matches)
    paths.append(str(matches[0]))
env=os.environ.copy();env['PYTHONPATH']=os.pathsep.join(paths);env['PYTHONDONTWRITEBYTECODE']='1'
out=Path('/tmp/v382_when_dist');assert not out.exists()
code='import importlib.metadata as m,json; print(json.dumps({n:m.version(n) for n in ["build","hatchling","pathspec","tomlkit","trove-classifiers"]}))'
record=json.loads(subprocess.check_output([sys.executable,'-c',code],env=env))
print(json.dumps({'backend_versions':record,'source':'Existing uv cache; no dependency installation or network','outdir':str(out)}),flush=True)
subprocess.run([sys.executable,'-m','build','--no-isolation','--outdir',str(out)],cwd=ROOT,env=env,check=True)
(Path(__file__).resolve().parents[1]/'evidence/build_backend.json').write_text(json.dumps(record,indent=2)+'\n')
