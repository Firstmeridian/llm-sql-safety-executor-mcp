"""Bounded configured-stdio startup probes; only SELECT 7 on the resolved alias."""
import asyncio
import argparse
from datetime import datetime,timezone
import gzip
import hashlib
import json
import logging
from pathlib import Path
import re
import time
import tomllib

from fastmcp import Client
from fastmcp.client.transports import StdioTransport

ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parents[1]/'evidence'


def resources():
    root=ROOT/'src/sql_safety_executor'
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file() and p.suffix in {'.py','.md'}}


async def main(label):
    logging.disable(logging.CRITICAL)
    before=resources()
    settings=tomllib.loads((Path.home()/'.codex/config.toml').read_text())
    server=settings['mcp_servers']['sql-safety-executor-mcp']
    assert 'command' in server and server.get('enabled',True)
    records=[]
    async def probe(stage,trial,timeout):
        path=OUT/f'stdio_{label}_{stage}_{trial}.stderr.txt'
        assert not path.exists()
        start=time.perf_counter()
        row={'stage':stage,'trial':trial,'init_timeout_seconds':timeout,
             'command_matches_current_Host_config':True,'configured_database_write':False}
        try:
            transport=StdioTransport(command=server['command'],args=server.get('args',[]),
                cwd=server.get('cwd',str(ROOT)),env=server.get('env'),keep_alive=False,log_file=path)
            async with Client(transport,init_timeout=timeout,timeout=60) as client:
                row['initialized_ms']=round((time.perf_counter()-start)*1000,3)
                row['protocol']=client.protocol_version
                response=await client.call_tool('query',{'sql':'SELECT 7 AS n','connection_id':'union_test_sqlite'},raise_on_error=False)
                row['raw']={'isError':response.is_error,'structuredContent':response.structured_content,
                            'content':[v.model_dump(mode='json',exclude_none=True) for v in response.content]}
                row['success']=response.structured_content['success'] and response.structured_content['data']==[{'n':7}]
        except Exception as error:
            text=re.sub(r'https?://\S+','<url-redacted>',str(error))
            row.update(success=False,error_type=type(error).__name__,error=text[:500])
        row['whole_context_ms']=round((time.perf_counter()-start)*1000,3)
        records.append(row)
    for i in range(1,4):
        await probe('serial_10',i,10)
    for stage,timeout in [('parallel_10',10),('parallel_60',60)]:
        await asyncio.gather(*(probe(stage,i,timeout) for i in range(1,4)))
    after=resources()
    assert before==after,'Do not mix source changes within a startup probe'
    data={'observed_utc':datetime.now(timezone.utc).isoformat(),'records':records,
          'source_resources':before,'configured_writes':False,
          'configuration':{'transport':'stdio','enabled':server.get('enabled',True),
            'required':server.get('required',False),'startup_timeout_seconds':server.get('startup_timeout_sec',10),
            'optional_startup_grace_ms':settings.get('mcp_optional_startup_grace_ms',1000),
            'tool_allowlist_present':'enabled_tools' in server,'tool_denylist_present':'disabled_tools' in server},
          'scope':'Independent FastMCP Client launches using the configured command. Not the Codex per-child manager; timings include startup/protocol/Host workload, not model tokens or controlled server latency. Other Host canaries may share CPU.'}
    output=OUT/f'stdio_startup_{label}.json.gz';assert not output.exists()
    output.write_bytes(gzip.compress((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
    print(json.dumps({'calls':len(records),'passed':sum(r['success'] for r in records),'records':[{k:v for k,v in r.items() if k!='raw'} for r in records]}))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--label',required=True)
    label=parser.parse_args().label
    assert label.isascii() and label.replace('_','').isalnum()
    asyncio.run(main(label))
