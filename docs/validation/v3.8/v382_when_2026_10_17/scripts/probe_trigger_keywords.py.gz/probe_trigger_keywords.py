"""Valid keyword-shaped columns in trigger WHEN must retain identifier roles."""
import argparse
from pathlib import Path
import probe_adjacent as probe


def keyword_cases():
    result=[]
    for name in ['begin','end','when','on']:
        for quoted in [False,True]:
            # SQLite itself rejects bare NEW.when / NEW.on. Keep quoted
            # controls; do not count an invalid fixture as a product refusal.
            if not quoted and name in {'when','on'}:
                continue
            field='"'+name+'"' if quoted else name
            ddl='ALTER TABLE orders ADD COLUMN "'+name+'" INTEGER;'
            ddl+=probe.trigger('INSERT INTO audit_log VALUES(NEW.n)',when=f'WHEN NEW.{field} IS NULL')
            result.append((name+('_quoted' if quoted else '_bare'),ddl,'INSERT INTO orders(n) VALUES(99)',None))
    # A quoted BEGIN string is a control; it cannot become a region boundary.
    result.append(('begin_string',probe.trigger("SELECT 'BEGIN;END;'",when="WHEN NEW.n!=length('BEGIN')"),'INSERT INTO orders(n) VALUES(99)',None))
    extra='ALTER TABLE orders ADD COLUMN "begin" INTEGER;'
    result.append(('old_begin_update',extra+probe.trigger('INSERT INTO audit_log VALUES(NEW.n)',event='UPDATE',when='WHEN OLD.begin IS NULL'),'UPDATE orders SET n=99',None))
    result.append(('old_begin_delete',extra+probe.trigger('INSERT INTO audit_log VALUES(OLD.n)',event='DELETE',when='WHEN OLD.begin IS NULL'),'DELETE FROM orders',None))
    result.append(('begin_case',extra+probe.trigger('INSERT INTO audit_log VALUES(NEW.n)',when='WHEN (CASE WHEN NEW.n>0 THEN NEW.begin ELSE 0 END) IS NULL'),'INSERT INTO orders(n) VALUES(99)',None))
    result.append(('begin_function',extra+probe.trigger('INSERT INTO audit_log VALUES(NEW.n)',when='WHEN COALESCE(NEW.begin,0)=0'),'INSERT INTO orders(n) VALUES(99)',None))
    result.append(('begin_subquery','ALTER TABLE audit_log ADD COLUMN "begin" INTEGER;'+probe.trigger('INSERT INTO audit_log(n) VALUES(NEW.n)',when='WHEN EXISTS(SELECT begin FROM audit_log)'),'INSERT INTO orders(n) VALUES(99)',None))
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    probe.cases=keyword_cases
    probe.main(parser.parse_args())
