"""Private native/guard comparison of adjacent SQLite plan and schema cases."""
import argparse
import gzip
import hashlib
import json
import logging
from pathlib import Path
import sqlite3
import sys
import tempfile


BASE = ('CREATE TABLE orders(n); INSERT INTO orders VALUES(7);'
        'CREATE TABLE audit_log(n); CREATE TABLE hidden(n); INSERT INTO hidden VALUES(17);'
        'CREATE VIEW normal_view AS SELECT n FROM hidden;')
COUNT = 'WITH chosen(n) AS MATERIALIZED (SELECT 7) SELECT COUNT(*) FROM chosen'


def trigger(body, *, when='', name='log_orders', event='INSERT', timing='AFTER'):
    return f'CREATE TRIGGER {name} {timing} {event} ON orders {when} BEGIN {body}; END;'


def cases():
    values = [
        ('instead_of_view', 'CREATE VIEW entry AS SELECT n FROM orders;'
         f'CREATE TRIGGER log_entry INSTEAD OF INSERT ON entry BEGIN INSERT INTO audit_log SELECT ({COUNT}); END;', 'INSERT INTO entry VALUES(99)', None),
        ('before_when', trigger('INSERT INTO audit_log VALUES(NEW.n)', timing='BEFORE', when=f'WHEN ({COUNT})>0'), 'INSERT INTO orders VALUES(99)', None),
        ('update_of_old_new', trigger(f'INSERT INTO audit_log SELECT ({COUNT})+OLD.n+NEW.n', event='UPDATE OF n'), 'UPDATE orders SET n=99', None),
        ('insert_returning', trigger(f'SELECT ({COUNT})'), 'INSERT INTO orders VALUES(99) RETURNING n', None),
        ('update_returning', trigger(f'SELECT ({COUNT})', event='UPDATE'), 'UPDATE orders SET n=99 RETURNING n', None),
        ('delete_returning', trigger(f'SELECT ({COUNT})', event='DELETE'), 'DELETE FROM orders RETURNING n', None),
        ('case_semicolon', trigger(f"SELECT CASE WHEN NEW.n>0 THEN ';END;BEGIN;' ELSE 'WHEN' END; SELECT ({COUNT})"), 'INSERT INTO orders VALUES(99)', None),
        ('raise_ignore', trigger(f'SELECT CASE WHEN NEW.n=0 THEN RAISE(IGNORE) ELSE ({COUNT}) END'), 'INSERT INTO orders VALUES(99)', None),
        ('trigger_replace', trigger(f'REPLACE INTO audit_log SELECT ({COUNT})'), 'INSERT INTO orders VALUES(99)', None),
        ('two_sibling_scopes', trigger(f'INSERT INTO audit_log SELECT ({COUNT})+({COUNT})'), 'INSERT INTO orders VALUES(99)', None),
        ('cte_inside_in', trigger(f'SELECT NEW.n IN ({COUNT})'), 'INSERT INTO orders VALUES(99)', None),
        ('cte_inside_exists', trigger(f'SELECT EXISTS({COUNT})'), 'INSERT INTO orders VALUES(99)', None),
        ('temp_trigger', f'CREATE TEMP TRIGGER log_orders AFTER INSERT ON main.orders BEGIN SELECT ({COUNT}); END;', 'INSERT INTO orders VALUES(99)', None),
        ('ungranted_when', trigger('SELECT 7', when='WHEN (SELECT COUNT(*) FROM hidden)>0'), 'INSERT INTO orders VALUES(99)', 'table_access_denied'),
        ('ungranted_sibling', trigger(f'SELECT ({COUNT})+(WITH chosen(n) AS MATERIALIZED (SELECT n FROM hidden) SELECT COUNT(*) FROM chosen)'), 'INSERT INTO orders VALUES(99)', 'table_access_denied'),
        ('restricted_when', trigger('SELECT 7', when=f'WHEN (WITH chosen AS MATERIALIZED (SELECT SLEEP(0)) SELECT COUNT(*) FROM chosen)>0'), 'INSERT INTO orders VALUES(99)', 'expensive_function_denied'),
    ]
    for option in ['ROLLBACK', 'ABORT', 'FAIL', 'IGNORE', 'REPLACE']:
        values.append(('trigger_update_or_' + option.lower(), trigger(f'UPDATE OR {option} audit_log SET n=({COUNT})'), 'INSERT INTO orders VALUES(99)', None))
        values.append(('trigger_insert_or_' + option.lower(), trigger(f'INSERT OR {option} INTO audit_log SELECT ({COUNT})'), 'INSERT INTO orders VALUES(99)', None))
    return values


def main(args):
    source = args.source.resolve()
    assert (source/'sql_safety_executor/__init__.py').is_file()
    sys.path.insert(0, str(source))
    import sql_safety_executor
    from sql_safety_executor.core.policy import _prepare_sql_read
    from sql_safety_executor.database.errors import DatabaseQueryError
    from sql_safety_executor.database.models import ConnectionPolicy, DatabaseConfig
    from sql_safety_executor.database.sqlite import SQLiteAdapter
    assert Path(sql_safety_executor.__file__).resolve().parent == source/'sql_safety_executor'
    logging.disable(logging.CRITICAL)
    records = []
    policy = ConnectionPolicy(allowed_tables=frozenset(['orders', 'audit_log', 'normal_view', 'entry']))
    with tempfile.TemporaryDirectory(prefix='v382-adjacent-audit-') as temporary:
        for name, ddl, body, expected in cases():
            for prefix in ['EXPLAIN', 'EXPLAIN QUERY PLAN']:
                path = Path(temporary)/(name+'_'+prefix.replace(' ','_')+'.sqlite')
                native_calls = []
                with sqlite3.connect(path) as native:
                    native.create_function('SLEEP', 1, lambda _: native_calls.append(1) or 0)
                    native.executescript(BASE+ddl)
                    snapshots = {t:native.execute('SELECT * FROM '+t).fetchall() for t in ['orders','audit_log','hidden']}
                    sql = prefix+' '+body
                    item = dict(case=name, sql=sql, ddl=ddl, expected_code=expected, native={})
                    try:
                        item['native'] = dict(success=True, row_count=len(native.execute(sql).fetchall()))
                    except sqlite3.Error as error:
                        item['native'] = dict(success=False, error=str(error))
                    assert not native_calls
                # TEMP triggers are connection-local. Recreate only that fixture
                # on the serving connection rather than claiming it persisted.
                adapter = SQLiteAdapter(config=DatabaseConfig('private_fixture','sqlite',5,5,policy,sqlite_database_path=str(path)))
                calls = []
                try:
                    assert adapter.connect()
                    with adapter._engine.connect() as db:
                        raw = db.connection.dbapi_connection
                        raw.create_function('SLEEP',1,lambda _:calls.append(1) or 0)
                        if name == 'temp_trigger':
                            raw.executescript(ddl)
                    plan = _prepare_sql_read(None,sql,policy,adapter=adapter)
                    result = dict(success=False, error_code=plan.decision.error_code)
                    if plan.decision.allowed:
                        try:
                            result.update(success=True,row_count=len(adapter.execute_read(sql,policy=policy,analysis=plan.analysis)))
                        except DatabaseQueryError as error:
                            result.update(success=False,error_code=error.error_code,error=str(error))
                    item['product'] = result
                    item['expected_matches'] = result['success'] if expected is None else not result['success'] and result['error_code']==expected
                    item['data_unchanged'] = snapshots == {t:[tuple(row) for row in adapter.execute('SELECT * FROM '+t)] for t in snapshots}
                    item['restricted_function_calls'] = len(calls)
                    item['cleaned_up'] = adapter._active_guard is None and adapter._read_request is None
                    assert item['data_unchanged'] and not calls and item['cleaned_up']
                finally:
                    adapter.close()
                records.append(item)
        # Generated-column callbacks are documented to occur at schema parse,
        # not each use. Use a harmless deterministic counter, never a delay.
        path=Path(temporary)/'generated.sqlite'
        with sqlite3.connect(path) as native:
            native.create_function('SLEEP',1,lambda n:n,deterministic=True)
            native.executescript('CREATE TABLE generated(n, g AS (SLEEP(n)) VIRTUAL); INSERT INTO generated(n) VALUES(7);')
        generated_policy=ConnectionPolicy(allowed_tables=frozenset(['generated']))
        adapter=SQLiteAdapter(config=DatabaseConfig('private_generated','sqlite',5,5,generated_policy,sqlite_database_path=str(path)))
        generated_calls=[]
        try:
            assert adapter.connect()
            with adapter._engine.connect() as db:
                raw=db.connection.dbapi_connection
                raw.create_function('SLEEP',1,lambda n:generated_calls.append(n) or n,deterministic=True)
            for sql in ['SELECT g FROM generated','SELECT COUNT(*) AS n FROM generated','EXPLAIN SELECT g FROM generated']:
                generated_calls.clear()
                plan=_prepare_sql_read(None,sql,generated_policy,adapter=adapter)
                result={'success':False,'error_code':plan.decision.error_code}
                if plan.decision.allowed:
                    try:
                        data=adapter.execute_read(sql,policy=generated_policy,analysis=plan.analysis)
                        result.update(success=True,row_count=len(data),data=[list(row) for row in data] if not sql.startswith('EXPLAIN') else None)
                    except DatabaseQueryError as error:
                        result.update(error_code=error.error_code,error=str(error))
                records.append({'case':'trusted_generated_column','sql':sql,'product':result,'restricted_function_calls':len(generated_calls),'scope':'Trusted deterministic UDF and persisted schema; observation, not a normal-table grant bypass.'})
        finally:
            adapter.close()
    package=Path(sql_safety_executor.__file__).parent
    output={'source':str(source),'source_sha256':{str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(package.rglob('*')) if p.is_file() and p.suffix in {'.py','.md'}},'records':records,'configured_database_writes':False}
    assert not args.output.exists()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_bytes(gzip.compress((json.dumps(output,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
    print(json.dumps({'cases':len(cases()),'plan_observations':len(records)-3,'generated_observations':3,'unexpected':[{'case':r['case'],'sql':r['sql'],'native':r['native'],'product':r['product']} for r in records if r.get('expected_matches') is False],'generated':records[-3:]}))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    main(parser.parse_args())
