"""Standard wheel install in a fresh venv; explicitly reuse frozen dependencies."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import venv
import zipfile
import io

ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parents[1]/'evidence'


def fetch(url):
    return subprocess.check_output(['curl','-fsSL','--connect-timeout','10','--max-time','60',url],timeout=65)


meta=json.loads(fetch('https://pypi.org/pypi/installer/0.7.0/json'))
entry=next(v for v in meta['urls'] if v['filename']=='installer-0.7.0-py3-none-any.whl')
assert entry['url'].startswith('https://files.pythonhosted.org/')
data=fetch(entry['url']);assert hashlib.sha256(data).hexdigest()==entry['digests']['sha256']
tools=Path('/tmp/v382_when_installer');assert not tools.exists();tools.mkdir()
with zipfile.ZipFile(io.BytesIO(data)) as archive:
    for name in archive.namelist():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
    archive.extractall(tools)
target=Path('/tmp/v382_when_wheel_env');assert not target.exists()
venv.EnvBuilder(with_pip=False).create(target)
site=next((target/'lib').glob('python*/site-packages'))
dependencies=ROOT/'.venv-v38/lib/python3.12/site-packages'
# A plain .pth path appends the locked dependencies without executing their
# editable-project .pth files. The tested package is installed into this venv
# and must precede that directory. This is not fresh dependency resolution.
(site/'frozen_dependencies.pth').write_text(str(dependencies)+'\n')
wheel=Path('/tmp/v382_when_dist/llm_sql_safety_executor_mcp-3.8.2-py3-none-any.whl')
env=os.environ.copy();env['PYTHONPATH']=str(tools)
python=target/'bin/python'
subprocess.run([str(python),'-m','installer',str(wheel)],env=env,cwd='/tmp',check=True)
code='''import importlib.metadata as m,hashlib,json,pathlib,sys,sql_safety_executor
p=pathlib.Path(sql_safety_executor.__file__).parent
assert p.is_relative_to(pathlib.Path(sys.prefix))
assert not any('__editable__' in str(x) for x in sys.meta_path)
print(json.dumps(dict(package=str(p),version=m.version('llm-sql-safety-executor-mcp'),resources={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file() and f.suffix in {'.py','.md'}})))'''
installed=json.loads(subprocess.check_output([str(python),'-c',code],cwd='/tmp'))
package=ROOT/'src/sql_safety_executor'
current={str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest() for p in package.rglob('*') if p.is_file() and p.suffix in {'.py','.md'}}
assert current==installed['resources'] and len(current)==75
record={'installer':entry['filename'],'installer_sha256':entry['digests']['sha256'],'source':'Official PyPI PyPA installer 0.7.0',
        'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'installed':installed,
        'dependency_scope':'Fresh interpreter and ordinary wheel installation, reusing the existing frozen dependency directory. No editable package import, no new dependency resolver or clean dependency-install claim.'}
(OUT/'installed_resources.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'installed_resources':75,'version':installed['version'],'package':installed['package'],'dependency_scope':record['dependency_scope']}))
