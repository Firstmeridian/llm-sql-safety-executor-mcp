"""Keep the pinned, PyPI-hash-verified validation tool in ignored local data."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parents[4]
VERSION='0.8.22'
TARGET=ROOT/'local_data/.validation_tools'/('uv-'+VERSION)
def fetch(url,deadline):
    return subprocess.check_output(['curl','-fsSL','--connect-timeout','10','--max-time',str(deadline),url],timeout=deadline+5)


meta=json.loads(fetch('https://pypi.org/pypi/uv/'+VERSION+'/json',30))
files=[v for v in meta['urls'] if 'manylinux' in v['filename'] and v['filename'].endswith('x86_64.whl')]
assert len(files)==1
entry=files[0]
assert entry['url'].startswith('https://files.pythonhosted.org/')
wheel=fetch(entry['url'],90)
assert hashlib.sha256(wheel).hexdigest()==entry['digests']['sha256']
with zipfile.ZipFile(io.BytesIO(wheel)) as archive:
    names=[v for v in archive.namelist() if v.endswith('/uv') and archive.getinfo(v).file_size>1_000_000]
    assert len(names)==1
    executable=archive.read(names[0])
TARGET.mkdir(parents=True,exist_ok=True)
target=TARGET/'uv'
if target.exists():
    assert target.read_bytes()==executable,'Do not overwrite a different local tool'
else:
    target.write_bytes(executable);target.chmod(0o755)
record={'version':VERSION,'wheel':entry['filename'],'wheel_sha256':entry['digests']['sha256'],
        'binary_sha256':hashlib.sha256(executable).hexdigest(),'source':'Official PyPI uv distribution',
        'location':str(target.relative_to(ROOT)),'scope':'Ignored local validation tool only; no runtime dependency or global PATH change.'}
(TARGET/'provenance.json').write_text(json.dumps(record,indent=2)+'\n')
(Path(__file__).resolve().parents[1]/'evidence/uv_provenance.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
