"""Seal current source/package checks and scoped Host diagnostics before restart."""
from datetime import datetime,timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import zipfile

ROOT=Path(__file__).resolve().parents[4]
BATCH=Path(__file__).resolve().parents[1]
LOCAL=BATCH/'evidence'
PUBLIC=ROOT/'docs/validation/v3.8/v382_when_2026_10_17'
AUDIT=ROOT/'docs/validation/v3.8/v382_adjacent_audit_2026_10_17'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(gzip.decompress(path.read_bytes())) if path.suffix=='.gz' else json.loads(path.read_text())


def resources(package):
    return {str(p.relative_to(package)):sha(p) for p in package.rglob('*') if p.is_file() and p.suffix in {'.py','.md'}}


def main():
    assert not PUBLIC.exists(),'Append a new checkpoint; do not overwrite seals'
    current=resources(ROOT/'src/sql_safety_executor');before=read(LOCAL/'source_before.json')
    assert len(current)==len(before)==75
    assert [name for name in before if before[name]!=current[name]]==['core/analysis.py']
    frozen=Path('/tmp/v382-when-before/src/sql_safety_executor')
    assert resources(frozen)==before
    restored=0
    for old_name,new_name,count in [('matrix_current.json.gz','matrix_after.json.gz',52),
                                    ('trigger_keywords_extended_current.json.gz','keywords_after.json.gz',24)]:
        old=read(AUDIT/old_name);new=read(LOCAL/new_name)
        assert old['source_sha256']==before and new['source_sha256']==current
        assert len(old['records'][:count])==len(new['records'][:count])==count
        for a,b in zip(old['records'][:count],new['records'][:count]):
            assert (a['case'],a['sql'],a['ddl'])==(b['case'],b['sql'],b['ddl'])
            assert b['native']['success'] and b['expected_matches']
            assert b['data_unchanged'] and b['cleaned_up'] and not b['restricted_function_calls']
            restored+=not a['expected_matches']
    assert restored==12
    for name,count in [('source_stdio.json.gz',254),('installed_ctes.json.gz',254),('installed_plans.json.gz',140)]:
        data=read(LOCAL/name)
        assert data['source_sha256']==current and data['calls']==count
        assert data['data_unchanged'] and data['restricted_function_calls']==0
        assert {(r['mode'],r['protocol']) for r in data['records']}=={('auto','2026-07-28'),('legacy','2025-11-25')}
    assert '2275 passed, 4 skipped, 240 warnings' in (LOCAL/'full_regression.txt').read_text()
    assert '309 passed' in (LOCAL/'focused_after.txt').read_text()
    assert '48 failed, 27 passed' in (LOCAL/'tests_before.txt').read_text()
    assert '0 errors, 0 warnings' in (LOCAL/'pyright.txt').read_text()
    installed=read(LOCAL/'installed_resources.json')
    assert installed['installed']['resources']==current
    wheel=Path('/tmp/v382_when_dist/llm_sql_safety_executor_mcp-3.8.2-py3-none-any.whl')
    assert sha(wheel)==installed['wheel_sha256']
    with zipfile.ZipFile(wheel) as archive:
        packed={name.removeprefix('sql_safety_executor/'):hashlib.sha256(archive.read(name)).hexdigest()
                for name in archive.namelist() if name.startswith('sql_safety_executor/') and Path(name).suffix in {'.py','.md'}}
    assert packed==current
    prior=read(AUDIT/'verification.json')['preserved_manifests']
    prior={**prior,str((AUDIT/'manifest.json').relative_to(ROOT)):{'files':29,'manifest_sha256':sha(AUDIT/'manifest.json')}}
    preserved=0
    for relative,info in prior.items():
        path=ROOT/relative;assert sha(path)==info['manifest_sha256']
        base=path.parent.parent if relative.startswith('local_archive/') else path.parent
        manifest=read(path);assert len(manifest['files'])==info['files']
        for name,entry in manifest['files'].items():
            p=base/name;assert sha(p)==entry['sha256'] and p.stat().st_size==entry['bytes'],p
            preserved+=1
    assert preserved==400
    data_after=read(LOCAL/'data/truth_after.json')
    old_truth=read(AUDIT/'real_tasks/truth_after.json')
    for alias,entry in old_truth['connections'].items():
        assert entry['authorized_data']==data_after['connections'][alias]['authorized_data']
        assert entry['results']==data_after['connections'][alias]['results']
    sandbox=read(LOCAL/'stdio_startup.json.gz');outside=read(LOCAL/'stdio_startup_outside.json.gz')
    assert len(sandbox['records'])==len(outside['records'])==9
    assert not any(r['success'] for r in sandbox['records']) and all(r['success'] for r in outside['records'])
    assert sandbox['source_resources']==outside['source_resources']==before
    binding=read(LOCAL/'host_binding_logs.json.gz');assert len(binding['records'])==9
    assert any('omitting' in r['message'] for r in binding['records'])
    resumed=read(LOCAL/'host_resumed_diagnostic.json.gz')
    assert len([e for e in resumed['events'] if e.get('role')=='assistant' and e.get('channel')=='final'])==1
    assert any('SELECT 7 AS n' in str(e.get('output','')) for e in resumed['events'])
    canaries=[read(LOCAL/f'host_agents/canary_{i}.json.gz') for i in [1,2,3]]
    assert [r['observations']['observed_mcp_responses'] for r in canaries]==[2,1,1]
    first=canaries[0]['observations']['mcp_response_observations']
    assert first[0]['isError'] and first[1]['success']

    PUBLIC.mkdir()
    for path in sorted(LOCAL.iterdir()):
        if path.is_file():
            name=path.name if path.suffix in {'.gz','.json'} else path.name+'.gz'
            (PUBLIC/name).write_bytes(path.read_bytes() if path.name==name else gzip.compress(path.read_bytes(),mtime=0))
    for relative in ['data/truth_after.json',*[f'host_agents/canary_{i}.json.gz' for i in [1,2,3]]]:
        p=LOCAL/relative;out=PUBLIC/relative;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
    scripts=PUBLIC/'scripts';scripts.mkdir()
    paths=list((BATCH/'scripts').glob('*.py'))+[
        ROOT/'scripts/validation/sqlite_trigger_ctes.py',ROOT/'scripts/validation/sqlite_plans.py',
        ROOT/'tests/test_trigger_when_v382.py',ROOT/'scripts/review_v381/real_task_eval.py',
        ROOT/'local_archive/v382_review/20261017_adjacent_audit/scripts/probe_adjacent.py',
        ROOT/'local_archive/v382_review/20261017_adjacent_audit/scripts/probe_trigger_keywords.py']
    for p in paths:(scripts/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w') as archive:
        for name in sorted(before):archive.add(frozen/name,arcname='sql_safety_executor/'+name,recursive=False)
    (PUBLIC/'before_source.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
    closed=datetime.now(timezone.utc).isoformat()
    verification={'version':'3.8.2','status':'source_and_package_passed_resident_restart_pending','closed_utc':closed,
        'runtime_resources':current,'changed_runtime_resources':['core/analysis.py'],
        'tests':{'new':79,'focused_passed':309,'full_passed':2275,'skipped':4,'warnings':240},
        'same_input':{'combinations':76,'restored_false_refusals':12,'all_expected_results_met':True},
        'source_child_stdio_calls':254,'installed_targeted_calls':394,
        'wheel':{'name':wheel.name,'sha256':sha(wheel),'bytes':wheel.stat().st_size,
                 'installed_package':installed['installed']['package'],'dependency_scope':installed['dependency_scope']},
        'scripts':{str(p.relative_to(ROOT)):sha(p) for p in paths},
        'Host_diagnostics':{'Codex_version':'0.163.0','original_complete_business_trials':'2/3, preserved unchanged',
            'catalog_binding_logs':9,'confirmed':'Cached catalog without waiting for startup, then omission without an exact ready client.',
            'successful_contexts_also_use_cached_catalogs':True,
            'underlying_initialization_or_binding_cause':'Unproven; no stale-content or cache-clearing root-fix claim.',
            'original_failed_child_close_resume':'One real call succeeded after close/resume; original failure is not relabeled.',
            'fresh_canary_initial':'Two successes and one argument validation error; one bounded separate correction succeeded.',
            'independent_stdio':{'sandbox_passed':0,'outside_passed':9,'runs_each':9,'timeout_seconds_tested':[10,60],
                'source_scope':'Pre-WHEN-repair source; startup availability only, not fix coverage.'},
            'global_configuration_changes':False,'required_true':'Optional fail-early recommendation, not applied or A/B-verified.'},
        'data_integrity':{'configured_writes':False,'authorized_SQLite_table_fingerprints_match_prior_snapshot':7,
                          'private_fixtures_cleaned':True,'restricted_counter_calls':0},
        'preserved_sealed_files':400,'preserved_manifests':prior,
        'limits':['No native trigger/UDF/plan-Skill fixture added to configured databases; await manual restart for scoped resident verification.',
                  'No new complete business trial after this repair; Host diagnostic canaries do not replace frozen sales tasks.',
                  'Application events only, not full protocol frames; no model-cost or service-latency A/B claim.',
                  'Fresh wheel interpreter reuses frozen dependencies; no clean dependency-resolution claim. uv download failures retained.',
                  'Existing repeated outer-CTE and trusted generated-column limits remain unchanged.']}
    (PUBLIC/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')
    files={str(p.relative_to(PUBLIC)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(PUBLIC.rglob('*')) if p.is_file()}
    (PUBLIC/'manifest.json').write_text(json.dumps({'closed_utc':closed,
        'scope':'Immutable source/package/Host-diagnostic checkpoint; resident restart pending. Append post-restart observations separately.',
        'files':files},ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'sealed_files':len(files),'runtime_resources':75,'prior_sealed_files_verified':400,'full_passed':2275,'installed_calls':394,'resident_restart':'pending'}))


if __name__=='__main__':main()
