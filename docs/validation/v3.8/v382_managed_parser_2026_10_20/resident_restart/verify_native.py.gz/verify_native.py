"""Verify native application results, read-only DB truth and previous seals."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3

from sql_safety_executor import load_config

ROOT=Path(__file__).resolve().parents[5]
LOCAL=Path(__file__).resolve().parents[1]
BATCH=LOCAL.parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify(apply_erratum):
    config=load_config(ROOT/'config/server.toml')
    plan=json.loads((LOCAL/'evidence/native_plan.json').read_text())
    raw=json.loads((LOCAL/'evidence/native_application.json').read_text())
    correction=json.loads((LOCAL/'evidence/expectation_erratum.json').read_text())
    checks=[]
    for index,(record,item) in enumerate(zip(raw['records'],plan['checks'],strict=True)):
        assert record['index']==index and record['tool']==item['tool'] and record['arguments']==item['arguments']
        expected=dict(item['expected'])
        if apply_erratum and index==correction['record_index']:
            expected['skill_names']=correction['corrected_expected_skill_names']
        response=record['result'];errors=[]
        def check(condition,reason):
            if not condition:errors.append(reason)
        check(response.get('isError') is expected.get('isError',False),'Host isError')
        payload=response.get('structuredContent')
        if expected.get('isError'):
            check(payload is None,'authorization failure has no business payload')
            text=' '.join(row.get('text','') for row in response['content'])
            check('not authorized by skills.mutation.allowed_connections' in text,'explicit target admission refusal')
        else:
            texts=[row['text'] for row in response['content'] if row['type']=='text']
            check(len(texts)==1 and json.loads(texts[0])==payload,'text matches structured after stated token redaction')
            check(payload['connection_id']==item['arguments']['connection_id'],'exact target')
            if 'error_code' in expected:
                check(payload['success'] is False and payload['error_code']==expected['error_code'],'specific refusal')
                if item['tool']=='execute_mutation_skill':
                    check(payload['execution_outcome']=='not_executed' and 'preview_token' not in payload,'rejected preview issued no token')
                    check(expected['related'] in payload['related_available_skills'],'recovery Skill available on same target')
            else:
                check(payload['success'] is True,'successful handling')
            if 'data' in expected:
                check(payload['data']==expected['data'] and payload['truncated'] is False,'complete expected rows')
            if 'skill_names' in expected:
                check(sorted(row['name'] for row in payload['skills'])==expected['skill_names'],'frozen Skill search set')
                check(all(row['executable'] for row in payload['skills']),'returned Skills executable')
            if 'executable' in expected:
                check(payload['skill']['executable'] is expected['executable'],'target executable state')
            if expected.get('preview'):
                check(item['arguments']['confirm'] is False and payload['mode']=='preview' and payload['execution_outcome']=='not_executed','preview only')
                check(payload['preview_token']=='[REDACTED_PREVIEW_HANDLE]' and isinstance(payload['preview_token_expires_at'],str),'opaque handle issued then redacted')
                check(payload['preview']['preview_sql']=='UPDATE orders SET status = :new_status WHERE id = :order_id AND status = :expected_status','unchanged cached SQL')
                check(payload['preview']['bound_params']=={'order_id':1,'expected_status':'confirmed','new_status':expected['new_status']},'exact preview bindings')
                check(payload['preview']['affected_rows_estimate']==1,'single row estimate')
        checks.append({'index':index,'id':item['id'],'passed':not errors,'errors':errors})
    assert len(checks)==16
    if not apply_erratum:
        output=LOCAL/'evidence/original_verification.json';assert not output.exists()
        output.write_text(json.dumps({'checks':checks,'passed':sum(row['passed'] for row in checks),'total':len(checks)},indent=2)+'\n')
        assert all(row['passed'] for row in checks),checks
        return
    assert all(row['passed'] for row in checks),checks
    assert raw['redacted_preview_handle_count']==2
    assert all(not item['arguments'].get('confirm',False) for item in raw['records'])
    truth={}
    for alias,expected in plan['databases'].items():
        path=Path(config.connections[alias].sqlite_database_path)
        assert digest(path)==expected['file_sha256']
        with sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True) as db:
            if alias=='rich_mutation_sqlite':
                db.row_factory=sqlite3.Row
                snapshot=[dict(row) for row in db.execute('SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')]
                rows=[tuple(row) for row in db.execute('SELECT * FROM main.orders ORDER BY id')]
                assert snapshot==expected['snapshot'] and len(rows)==expected['row_count']
                current=hashlib.sha256(json.dumps(rows,ensure_ascii=False,default=str).encode()).hexdigest()
                assert current==expected['all_order_rows_sha256']
                truth[alias]={'file_sha256_before':expected['file_sha256'],'file_sha256_after':digest(path),
                    'all_order_rows_sha256':current,'row_count':len(rows),'snapshot':snapshot}
            else:
                count=db.execute("SELECT COUNT(*) FROM main.pages_fts WHERE pages_fts MATCH 'sqlite'").fetchone()[0]
                assert count==expected['fts_match_count']
                truth[alias]={'file_sha256_before':expected['file_sha256'],'file_sha256_after':digest(path),'fts_match_count':count}
        assert digest(path)==expected['file_sha256']
    prior=json.loads((BATCH/'evidence/previous_seals.json').read_text())
    manifests=[ROOT/row['manifest'] for row in prior['records']]
    manifests.extend([BATCH/'manifest.json',ROOT/'docs/validation/v3.8/v382_managed_parser_2026_10_20/manifest.json'])
    verified=0
    for manifest in manifests:
        values=json.loads(manifest.read_text())['files']
        entries=values.items() if isinstance(values,dict) else ((x['path'],x) for x in values)
        for name,item in entries:
            file=manifest.parent/name
            assert digest(file)==item['sha256'] and file.stat().st_size==item['bytes'],str(file)
            verified+=1
    package=ROOT/'src/sql_safety_executor'
    resources={str(p.relative_to(package)):digest(p) for p in package.rglob('*') if p.is_file() and p.suffix in {'.py','.md'}}
    assert resources==json.loads((BATCH/'evidence/verification.json').read_text())['runtime_resources']
    assert len(resources)==77 and verified==435 and len(manifests)==17
    summary={'owner_restart_confirmed':True,'verified_utc':datetime.now(timezone.utc).isoformat(),'passed':16,'total':16,
        'original_frozen_expectations':{'passed':15,'total':16,'one_test_expectation_corrected':True,'native_response_repeated':False},
        'successful_query_reads':6,'catalog_detail_checks':4,'successful_previews':2,'expected_refusals':4,
        'checks':checks,'independent_truth':truth,'source_resources_match_final_wheel':77,
        'old_manifest_count':17,'old_sealed_files_verified':435,
        'preview_handling':'Two confirm=false previews only; abandon confirmation. No public revoke tool is exposed. Handles redacted before export and naturally expire under the configured 300-second TTL; no assertion of active revocation or observed expiry.',
        'limits':['Owner-confirmed restart and current Host behavior; not a resident source-hash attestation.',
                  'Special dialect/target-switch/commit/rollback combinations remain isolated source/package coverage, not identical native replay.',
                  'No new complete Luna tasks or model/provider usage. Current native channel only; not a two-protocol claim.',
                  'Host application records omit some protocol metadata; not raw wire frames or proof of original field omission. Preview handles consistently redacted.'],
        'source_or_configuration_changes_this_supplement':False,'configured_business_writes':False,'all_checks_passed':True}
    out=LOCAL/'evidence/summary.json';assert not out.exists()
    out.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'native_checks':'16/16 after one documented search-expectation correction','successful_previews':2,'expected_refusals':4,'sqlite_files_unchanged':2,'old_sealed_files_verified':verified,'source_resources_match_final_wheel':77}))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply-erratum',action='store_true')
    verify(parser.parse_args().apply_erratum)
