"""Freeze scoped native inputs and independent read-only fixture truth."""
import hashlib
import json
from pathlib import Path
import sqlite3

from sql_safety_executor import load_config

ROOT=Path(__file__).resolve().parents[5]
OUT=Path(__file__).resolve().parents[1]/'evidence/native_plan.json'
assert not OUT.exists()
config=load_config(ROOT/'config/server.toml')
databases={}
for alias in ('rich_mutation_sqlite','sqlite_features_sqlite'):
    path=Path(config.connections[alias].sqlite_database_path)
    databases[alias]={'file_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    with sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True) as db:
        db.row_factory=sqlite3.Row
        if alias=='rich_mutation_sqlite':
            snapshot=[dict(row) for row in db.execute('SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')]
            all_rows=[tuple(row) for row in db.execute('SELECT * FROM main.orders ORDER BY id')]
            assert snapshot[0]=={'id':1,'status':'confirmed'}
            databases[alias].update(snapshot=snapshot,row_count=len(all_rows),
                all_order_rows_sha256=hashlib.sha256(json.dumps(all_rows,ensure_ascii=False,default=str).encode()).hexdigest())
        else:
            count=db.execute("SELECT COUNT(*) FROM main.pages_fts WHERE pages_fts MATCH 'sqlite'").fetchone()[0]
            databases[alias]['fts_match_count']=count

checks=[]
def add(label,tool,alias,expect,**kwargs):
    checks.append({'id':label,'tool':tool,'arguments':{'connection_id':alias,**kwargs},'expected':expect})
rich='rich_mutation_sqlite';mysql='orders_demo_mysql';features='sqlite_features_sqlite'
update='sample-update-order-status';reset='sample-reset-order-to-pending'
add('canary','query',rich,{'data':[{'n':7}]},sql='SELECT 7 AS n')
add('available','list_skills',rich,{'skill_names':[update]},search=update,detail_level='full')
add('execution_detail','get_skill_detail',rich,{'executable':True},skill_name=update,detail_level='execution')
for label in ('snapshot_before','snapshot_after'):
    # The final snapshot is placed last below, after previews and controls.
    add(label,'query',rich,{'data':databases[rich]['snapshot']},sql='SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')
after=checks.pop()
add('update_preview','execute_mutation_skill',rich,{'preview':True,'new_status':'shipped'},skill_name=update,params={'order_id':1,'new_status':'shipped'},confirm=False)
add('reset_preview','execute_mutation_skill',rich,{'preview':True,'new_status':'pending'},skill_name=reset,params={'order_id':1,'expected_status':'confirmed'},confirm=False)
add('backward_refused','execute_mutation_skill',rich,{'error_code':'validation_failed','related':reset},skill_name=update,params={'order_id':1,'new_status':'pending'},confirm=False)
add('readonly_catalog','list_skills',mysql,{'skill_names':[]},search=update,detail_level='full')
add('readonly_detail','get_skill_detail',mysql,{'executable':False},skill_name=update,detail_level='full')
add('readonly_preview_refused','execute_mutation_skill',mysql,{'isError':True},skill_name=update,params={'order_id':1,'new_status':'shipped'},confirm=False)
add('mysql_canary','query',mysql,{'data':[{'n':7}]},sql='SELECT 7 AS n')
add('mysql_cte_case','query',mysql,{'data':[{'n':7}]},sql='WITH CaseData AS (SELECT 7 AS n) SELECT n FROM casedata')
add('fts','query',features,{'data':[{'n':count}]},sql="SELECT COUNT(*) AS n FROM main.pages_fts WHERE pages_fts MATCH 'sqlite'")
add('function_refused','query',features,{'error_code':'expensive_function_denied'},sql='SELECT SLEEP(0)')
add('shadow_refused','query',features,{'error_code':'table_access_denied'},sql='SELECT * FROM main.pages_fts_idx LIMIT 1')
checks.append(after)
assert len(checks)==16
plan={'owner_restart_confirmed':True,'parser_default':config.skills.mutation.managed_plan_parser,
      'preview_ttl_seconds':config.skills.mutation.preview.ttl_seconds,'databases':databases,'checks':checks,
      'scope':'Existing configured fixtures only. Never confirm a write. Preview handles are not revoked by a public cancellation tool and naturally expire; do not claim active revocation. Special target-mode switches/commit/rollback are source/package coverage, not identical native replay.'}
OUT.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
print('Frozen native checks:',len(checks))
