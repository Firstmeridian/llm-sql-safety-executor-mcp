"""Publish scoped evidence and independently hash current resources before sealing."""
import ast
import gzip
import hashlib
import importlib.metadata
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
from urllib.parse import unquote
import zipfile
from email.parser import BytesParser

ROOT=Path(__file__).resolve().parents[4]
BATCH=Path(__file__).resolve().parents[1]
PUBLIC=ROOT/'docs/validation/v3.8/v382_managed_parser_2026_10_20'
E=BATCH/'evidence'
assert not (PUBLIC/'verification.json').exists()
installed=json.loads((E/'installed_resources_final.json').read_text())
package=ROOT/'src/sql_safety_executor'
resources={str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest() for p in package.rglob('*') if p.is_file() and p.suffix in {'.py','.md'}}
assert resources==installed['installed']['resources']
before=json.loads((E/'before.json').read_text())
for name,digest in before['files'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
for filename in ['source_stdio.json.gz','installed_stdio_final.json.gz']:
 value=json.loads(gzip.decompress((E/filename).read_bytes()));assert value['passed']
 assert value['resource_sha256']==resources
 assert len(value['records'])==40
wheel=Path(installed['wheel']);assert hashlib.sha256(wheel.read_bytes()).hexdigest()==installed['wheel_sha256']
with zipfile.ZipFile(wheel) as archive:
 metadata=BytesParser().parsebytes(archive.read('llm_sql_safety_executor_mcp-3.8.2.dist-info/METADATA'))
 assert metadata.get_payload(decode=True).decode('utf-8').strip()==(ROOT/'README.md').read_text().strip()
assert '2791 passed, 4 skipped' in (E/'pytest_full_final.log').read_text()
assert '0 errors, 0 warnings' in (E/'pyright_final.log').read_text()
with tarfile.open(E/'after_runtime.tar.gz','w:gz') as archive:
 for name in resources:archive.add(package/name,arcname='sql_safety_executor/'+name)
(E/'dist').mkdir(exist_ok=True)
shutil.copy2(wheel,E/'dist'/wheel.name)
for name in ['corpus.json','final_comparison.json.gz','mysql_plans.json','source_stdio.json.gz','installed_stdio_final.json.gz',
             'parser_cost.json','pytest_full.log','pytest_full_final.log','pyright_final.log','prompt_contract.log','installed_prompt_contract.log',
             'installed_config_check.log','diff_check.log','installed_resources_final.json','previous_seals.json','before.json']:
 source=E/name;target=PUBLIC/(name if name.endswith('.gz') else name+'.gz')
 assert not target.exists()
 target.write_bytes(source.read_bytes() if name.endswith('.gz') else gzip.compress(source.read_bytes(),mtime=0))
for source in [BATCH/'scripts/compare_final.py',BATCH/'scripts/mysql_plans.py',BATCH/'scripts/parser_cost.py',
               BATCH/'scripts/freeze_corpus.py',BATCH/'scripts/build_install.py',ROOT/'scripts/validation/managed_parser.py',Path(__file__)]:
 (PUBLIC/(source.name+'.gz')).write_bytes(gzip.compress(source.read_bytes(),mtime=0))
changed=sorted(set(resources)^set(before['resources'])|{name for name in resources.keys()&before['resources'].keys() if resources[name]!=before['resources'][name]})
parser_defs=[{'name':node.name,'line':node.lineno} for node in ast.walk(ast.parse((package/'core/analysis.py').read_text())) if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name.startswith('_parse_')]
links=[];broken=[]
changed_docs=subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines()
changed_docs+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
for name in sorted(set(changed_docs)):
 p=ROOT/name
 if p.suffix!='.md' or not p.is_file():continue
 for raw in re.findall(r'(?<!!)\[[^\]]*\]\(([^\n)]*)\)',p.read_text()):
  raw=raw.strip().split(' "',1)[0].strip('<>')
  if not raw or raw.startswith(('#','http:','https:','mailto:','app:','data:')):continue
  path=unquote(raw.split('#',1)[0])
  if not path:continue
  target=p.parent/path
  links.append({'document':name,'target':raw})
  if not target.exists():broken.append(links[-1])
assert not broken,broken
verification={'checkpoint':'source_package_passed_resident_pending','versions':{n:importlib.metadata.version(n) for n in before['versions']},
 'runtime_resources':resources,'changed_runtime_resources_from_actual_baseline':changed,'existing_parse_definitions':parser_defs,
 'wheel_sha256':installed['wheel_sha256'],'final_wheel_readme_matches_current':True,'full_regression':{'passed':2791,'skipped':4,'warnings':417},
 'source_stdio_calls':40,'final_installed_stdio_calls':40,'earlier_installed_stdio_calls':40,'matrix_pairs':980,'mysql_explain_calls':64,
 'old_seals':json.loads((E/'previous_seals.json').read_text()),'local_links_checked':len(links),'broken_local_links':broken,
 'unchanged_source_file_hashes':before['files'],'scope':'No new full model trials, configured business writes, private config or dependency changes. App results, not protocol frames. Final wheel runtime+README explicitly verified; later narrative docs are not wheel-resource assertions.'}
for output in [E/'verification.json',PUBLIC/'verification.json']:
 output.write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'resources':len(resources),'changed_resources':changed,'private_parser_definitions':len(parser_defs),'links_checked':len(links),'wheel_sha256':installed['wheel_sha256']},indent=2))
