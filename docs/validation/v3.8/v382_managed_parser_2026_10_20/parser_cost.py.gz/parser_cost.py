"""Sequential matched classifier/catalog microbenchmark; no DB or model claims."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import tarfile
import tempfile
import time

ROOT=Path(__file__).resolve().parents[4]
BATCH=Path(__file__).resolve().parents[1]


def worker(args):
    sys.path.insert(0,args.source)
    from sql_safety_executor.skills.mutation import ManagedMutationPlan,ManagedMutationValue,validate_managed_mutation_plan
    from sql_safety_executor.skills.catalog import SkillCatalog
    plan=ManagedMutationPlan('UPDATE orders SET status=:new_status WHERE id=:order_id AND status=:expected_status',
        tuple(ManagedMutationValue.constant(name,value) for name,value in [('new_status','confirmed'),('order_id',1),('expected_status','pending')]),1)
    kwargs={} if args.parser=='baseline' else {'parser':args.parser}
    samples=[]
    for index in range(1100):
        start=time.perf_counter_ns();assert validate_managed_mutation_plan(plan,**kwargs) is plan
        elapsed=(time.perf_counter_ns()-start)/1e6
        if index>=100:samples.append(elapsed)
    catalog_samples=[]
    with tempfile.TemporaryDirectory(prefix='managed-catalog-cost-') as folder:
        for name in ('sample-update-order-status','sample-reset-order-to-pending'):
            shutil.copytree(ROOT/'skills'/name,Path(folder)/name)
        for index in range(55):
            start=time.perf_counter_ns()
            catalog=SkillCatalog();catalog.discover(Path(folder),**({} if args.parser=='baseline' else {'managed_plan_parser':args.parser}))
            assert len(catalog.get_skills_cache())==2
            elapsed=(time.perf_counter_ns()-start)/1e6
            if index>=5:catalog_samples.append(elapsed)
    resources={str(p.relative_to(Path(args.source)/'sql_safety_executor')):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in (Path(args.source)/'sql_safety_executor').rglob('*') if p.is_file() and p.suffix in {'.py','.md'}}
    return {'parser':args.parser,'resources':resources,'plan_ms':samples,'catalog_ms':catalog_samples,
        'median_plan_ms':statistics.median(samples),'median_catalog_ms':statistics.median(catalog_samples)}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--worker',action='store_true');parser.add_argument('--source');parser.add_argument('--parser')
    args=parser.parse_args()
    if args.worker:
        print(json.dumps(worker(args)));raise SystemExit()
    output=BATCH/'evidence/parser_cost.json';assert not output.exists()
    runs=[]
    with tempfile.TemporaryDirectory(prefix='managed-before-') as folder:
        with tarfile.open(BATCH/'evidence/before_runtime.tar.gz') as archive:
            archive.extractall(folder,filter='data')
        for label,source,backend in [('A1',folder,'baseline'),('B',str(ROOT/'src'),'sqlglot'),('C',str(ROOT/'src'),'sqlparse'),('A2',folder,'baseline')]:
            env=os.environ.copy();env['PYTHONPATH']=source
            completed=subprocess.run([sys.executable,__file__,'--worker','--source',source,'--parser',backend],
                env=env,cwd='/tmp',text=True,capture_output=True,check=True)
            (BATCH/'evidence'/('parser_cost_'+label+'.stderr.log')).write_text(completed.stderr)
            result=json.loads(completed.stdout);result['phase']=label;runs.append(result)
    output.write_text(json.dumps({'scope':__doc__,'runs':runs,'same_workload':True,'db_round_trips':0,
        'limitations':'Warm parser plus two-plan catalog only; not full startup, MCP latency, new contextual checks in preview/confirmation, model completion or provider tokens.'},indent=2)+'\n')
    print(json.dumps([{k:r[k] for k in ['phase','parser','median_plan_ms','median_catalog_ms']} for r in runs],indent=2))
