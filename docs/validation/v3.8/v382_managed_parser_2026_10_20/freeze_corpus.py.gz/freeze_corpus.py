"""Freeze real managed definitions plus synthetic statement-boundary cases."""
import ast
import hashlib
import itertools
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parents[1]/'evidence'
assert not (OUT/'corpus.json').exists()
definitions=[]
for path in sorted((ROOT/'skills').glob('*/mutation.py')):
    tree=ast.parse(path.read_text())
    for node in ast.walk(tree):
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='ManagedMutationPlan':
            sql=next(ast.literal_eval(item.value) for item in node.keywords if item.arg=='sql')
            definitions.append({'source':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'sql':sql,'definition':ast.get_source_segment(path.read_text(),node)})
cases=[]
def add(label,sql,category='boundary'):
    cases.append({'id':label,'sql':sql,'category':category})
for index,item in enumerate(definitions):add('existing_'+str(index),item['sql'],'existing')
for label,sql in [
 ('insert','INSERT INTO orders(id,n) VALUES(:id,:n)'),
 ('update','UPDATE orders SET n=:n WHERE id=:id'),
 ('delete','DELETE FROM orders WHERE id=:id'),
 ('cte_update','WITH chosen AS (SELECT :n AS n) UPDATE orders SET n=(SELECT n FROM chosen) WHERE id=:id'),
 ('cte_insert','WITH chosen AS (SELECT :id AS id,:n AS n) INSERT INTO orders(id,n) SELECT id,n FROM chosen'),
 ('cte_delete','WITH chosen AS (SELECT :id AS id) DELETE FROM orders WHERE id IN (SELECT id FROM chosen)'),
 ('insert_select','INSERT INTO archive SELECT * FROM orders'),
 ('upsert_sqlite','INSERT INTO orders(id,n) VALUES(:id,:n) ON CONFLICT(id) DO UPDATE SET n=excluded.n'),
 ('upsert_mysql','INSERT INTO orders(id,n) VALUES(:id,:n) ON DUPLICATE KEY UPDATE n=VALUES(n)'),
 ('update_from','UPDATE orders SET n=source.n FROM source WHERE orders.id=source.id'),
 ('delete_using','DELETE orders FROM orders JOIN source ON orders.id=source.id'),
 ('delete_target_alias','DELETE o FROM orders AS o WHERE o.id=:id'),
 ('default_values','INSERT INTO orders DEFAULT VALUES'),
 ('returning','UPDATE orders SET n=:n WHERE id=:id RETURNING id'),
 ('mysql_set_insert','INSERT INTO orders SET id=:id,n=:n'),
 ('mysql_ignore','UPDATE LOW_PRIORITY IGNORE orders SET n=:n WHERE id=:id'),
 ('mysql_qualified','UPDATE business.orders SET n=:n WHERE id=:id'),
 ('sqlite_qualified','UPDATE main.orders SET n=:n WHERE id=:id'),
 ('quoted','UPDATE "orders" SET "n"=:n WHERE "id"=:id'),
 ('backtick','UPDATE `orders` SET `n`=:n WHERE `id`=:id'),
 ('bracket','UPDATE [orders] SET [n]=:n WHERE [id]=:id'),
 ('unicode','UPDATE "Korders" SET n=:n WHERE id=:id'),
 ('spaces','UPDATE " f " SET n=:n WHERE id=:id'),
 ('colon_identifier','UPDATE "a\\:b" SET n=:n WHERE id=:id'),
 ('semicolon_literal',"UPDATE orders SET note='a;b' WHERE id=:id"),
 ('binding_literal',"UPDATE orders SET note=':literal' WHERE id=:id"),
 ('colon_literal',"UPDATE orders SET note='a:b' WHERE id=:id"),
 ('mysql_escapes',"UPDATE orders SET note='a\\\';DELETE FROM orders;-- ' WHERE id=:id"),
 ('double_literal','UPDATE orders SET note="hello" WHERE id=:id'),
 ('pipe','UPDATE orders SET note=\'a\'||\'b\' WHERE id=:id'),
 ('not_precedence','UPDATE orders SET n=NOT 1 BETWEEN 0 AND 1 WHERE id=:id'),
 ('function','UPDATE orders SET note=replace(note,\'a\',\'b\') WHERE id=:id'),
 ('column_named_replace','UPDATE orders SET "replace"=:n WHERE id=:id'),
 ('named_placeholders','UPDATE orders SET n=:n WHERE id=:id AND n=:n'),
 ('qmark','UPDATE orders SET n=? WHERE id=?'),
 ('qmark_number','UPDATE orders SET n=?1 WHERE id=?2'),
 ('format_bind','UPDATE orders SET n=%s WHERE id=%s'),
 ('numeric_bind','UPDATE orders SET n=:1 WHERE id=:2'),
 ('dollar_bind','UPDATE orders SET n=$1 WHERE id=$2'),
 ('plain_replace','REPLACE INTO orders(id,n) VALUES(:id,:n)'),
 ('cte_replace','WITH chosen(n) AS (SELECT :n) REPLACE INTO orders(n) SELECT n FROM chosen'),
 ('nested_write','WITH chosen AS (DELETE FROM orders RETURNING id) INSERT INTO archive SELECT * FROM chosen'),
 ('multi','UPDATE orders SET n=:n;DELETE FROM orders'),
 ('multi_comment','UPDATE orders SET n=:n;/*comment*/DELETE FROM orders'),
 ('select','SELECT * FROM orders'),
 ('explain','EXPLAIN UPDATE orders SET n=:n'),
 ('explain_plan','EXPLAIN QUERY PLAN DELETE FROM orders'),
 ('create','CREATE TABLE sample(n)'),
 ('drop','DROP TABLE orders'),
 ('pragma','PRAGMA user_version=7'),
 ('begin','BEGIN;UPDATE orders SET n=:n;COMMIT'),
 ('set','SET @n=7'),
 ('empty',''),('comment_only','-- nothing\n'),('separators','; ;'),
 ('bad_update','UPDATE SET n=:n'),('bad_assignment','UPDATE orders SET'),
 ('bad_insert','INSERT INTO orders VALUES('),('bad_cte','WITH chosen AS SELECT 7 UPDATE orders SET n=7'),
]:add(label,sql)
for choice in ['ROLLBACK','ABORT','FAIL','IGNORE','REPLACE']:
    add('insert_or_'+choice.lower(),f'INSERT OR {choice} INTO orders(id,n) VALUES(:id,:n)')
    add('update_or_'+choice.lower(),f'UPDATE OR {choice} orders SET n=:n WHERE id=:id')
for name in ['replace','"insert"','"update"','"delete"','unıon','offſet']:
    add('cte_name_'+name,f'WITH {name}(n) AS (SELECT :n) INSERT INTO orders(n) SELECT n FROM {name}')
for label,prefix,suffix in [('line','-- header\n',''),('block','/* header ; */ ',''),('tail_comment','','; -- tail'),('tail_block','','; /* tail */'),('tail_semis','','; ;'),('leading_semi','; ',''),('single_semi','',';')]:
    for verb,sql in [('update','UPDATE orders SET n=:n WHERE id=:id'),('insert','INSERT INTO orders(n) VALUES(:n)'),('delete','DELETE FROM orders WHERE id=:id')]:
        add(label+'_'+verb,prefix+sql+suffix)
contexts=[{'dialect':'sqlite','sql_modes':[],'default_schema':'main'}]
for bits in itertools.product([False,True],repeat=3):
    contexts.append({'dialect':'mysql','sql_modes':[name for name,on in zip(['ANSI_QUOTES','NO_BACKSLASH_ESCAPES','PIPES_AS_CONCAT'],bits) if on],'default_schema':'business'})
contexts.append({'dialect':'mysql','sql_modes':['HIGH_NOT_PRECEDENCE'],'default_schema':'business'})
record={'scope':'Only statement classification/comparison; all SQL is synthetic except two trusted builtin definitions. No configured database writes. Native SQLite truth will use non-executing EXPLAIN with a disposable fixture. Parser acceptance is not engine-validity proof.','definitions':definitions,'contexts':contexts,'cases':cases}
(OUT/'corpus.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'definitions':len(definitions),'cases':len(cases),'contexts':len(contexts),'comparisons':len(cases)*len(contexts)}))
