"""Actual MySQL session modes and non-executing DML plans; no business writes."""
import argparse
from dataclasses import replace
import itertools
import json
from pathlib import Path

from sql_safety_executor import load_config
from sql_safety_executor.core.managed_sql import check_managed_sql
from sql_safety_executor.database.mysql import MySQLAdapter
from sql_safety_executor.database.transport import statement_text


def run(config):
    records=[]
    mode_names=('ANSI_QUOTES','NO_BACKSLASH_ESCAPES','PIPES_AS_CONCAT')
    cases=[
        ('existing','UPDATE orders SET status=:s WHERE id=:id'),
        ('insert','INSERT INTO orders(id,status) VALUES(:id,:s)'),
        ('delete','DELETE FROM orders WHERE id=:id'),
        ('cte','WITH chosen AS (SELECT :id AS id) UPDATE orders SET status=:s WHERE id IN (SELECT id FROM chosen)'),
        ('double_quote','UPDATE orders SET status="confirmed" WHERE id=:id'),
        ('escape',"UPDATE orders SET status='a\\\'b' WHERE id=:id"),
        ('pipes',"UPDATE orders SET status='a'||'b' WHERE id=:id"),
        ('sqlite_only','UPDATE OR IGNORE orders SET status=:s WHERE id=:id'),
    ]
    for bits in itertools.product((False,True),repeat=3):
        modes=('STRICT_TRANS_TABLES','NO_ENGINE_SUBSTITUTION',*(n for n,on in zip(mode_names,bits) if on))
        adapter=MySQLAdapter(replace(config,mysql_sql_mode=modes))
        try:
            assert adapter.connect()
            context=adapter.resolve_analysis_context()
            assert context.sql_modes==frozenset(modes)
            # Each actual execution checkout verifies the pre-existing physical
            # initializer contract, not a probe of another arbitrary connection.
            with adapter._engine.connect() as first,adapter._engine.connect() as second:
                assert first.connection.dbapi_connection is not second.connection.dbapi_connection
                for connection in (first,second):
                    observed=frozenset(connection.exec_driver_sql('SELECT @@SESSION.sql_mode').scalar_one().split(','))
                    assert observed==context.sql_modes
                for label,sql in cases:
                    decision=check_managed_sql(sql,context)
                    try:
                        first.execute(statement_text('EXPLAIN '+sql,context),{'id':1,'s':'confirmed'}).fetchall()
                        native,error=True,None
                    except Exception as exc:
                        native,error=False,type(exc).__name__
                    records.append({'id':label,'modes':sorted(context.sql_modes),'candidate':decision.allowed,
                        'candidate_code':decision.error_code,'explain_compiles':native,'native_error_class':error})
            assert all(row['candidate'] and row['explain_compiles'] for row in records[-len(cases):] if row['id'] in {'existing','insert','delete','cte','pipes'})
            assert not records[-1]['candidate'] and not records[-1]['explain_compiles']
        finally:
            adapter.close()
    return {'records':records,'scope':__doc__,'physical_sessions_checked':16,
        'independent_mode_check':True,'no_business_or_global_writes':True,'passed':True}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,required=True)
    parser.add_argument('--alias',required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();assert not args.output.exists()
    result=run(load_config(args.config).connections[args.alias])
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print('MySQL non-executing plans:',len(result['records']))
