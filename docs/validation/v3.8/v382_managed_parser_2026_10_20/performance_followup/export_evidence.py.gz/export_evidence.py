"""Verify and publish performance/ability follow-up without rewriting old seals."""
import gzip
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import re
import statistics
import subprocess
from urllib.parse import unquote

ROOT=Path(__file__).resolve().parents[5]
LOCAL=Path(__file__).resolve().parents[1]
BATCH=LOCAL.parent
PUBLIC=ROOT/'docs/validation/v3.8/v382_managed_parser_2026_10_20/performance_followup'
assert not (LOCAL/'manifest.json').exists() and not (PUBLIC/'manifest.json').exists()
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
cost=json.loads(gzip.decompress((LOCAL/'evidence/lifecycle_cost.json.gz').read_bytes()))
ability=json.loads(gzip.decompress((LOCAL/'evidence/ability_boundaries.json.gz').read_bytes()))
frequency=json.loads((LOCAL/'evidence/classification_counts.json').read_text())
assert cost['all_checks_passed'] and len(cost['records'])==1728 and cost['measured_calls']==1440 and cost['warmup_calls']==288
assert all(row['success'] for row in cost['records'])
assert frequency['total_classifications']==11 and len(frequency['records'])==6
assert len(ability['records'])==18 and ability['intentional_engine_valid_refusals']==6
assert all(row['native_explain_compiles'] for row in ability['records'])
comparisons=[]
for mode in ('auto','legacy'):
    phases=[x for x in cost['phases'] if x['mode']==mode]
    pooled=[]
    for phase in ('A1','A2'):
        for cycle in range(40):
            selected=[x for x in cost['records'] if x['mode']==mode and x['phase']==phase and x['iteration']==cycle]
            assert len(selected)==6
            pooled.append(sum(x['elapsed_ms'] for x in selected))
    baseline=statistics.median(pooled)
    current=next(x['cycle_median_ms'] for x in phases if x['phase']=='B')
    comparisons.append({'mode':mode,'pooled_baseline_cycle_median_ms':baseline,'current_cycle_median_ms':current,
        'delta_ms':current-baseline,'relative_percent':100*(current/baseline-1),
        'baseline_phase_medians_ms':[x['cycle_median_ms'] for x in phases if x['phase']!='B']})
final=json.loads((BATCH/'evidence/verification.json').read_text())
package=ROOT/'src/sql_safety_executor'
current={str(p.relative_to(package)):digest(p) for p in package.rglob('*') if p.is_file() and p.suffix in {'.py','.md'}}
assert current==final['runtime_resources'] and len(current)==77
prior=json.loads((BATCH/'evidence/previous_seals.json').read_text())
manifests=[ROOT/x['manifest'] for x in prior['records']]
public_parent=PUBLIC.parent
manifests.extend([BATCH/'manifest.json',public_parent/'manifest.json',BATCH/'resident_restart/manifest.json',public_parent/'resident_restart/manifest.json'])
verified=0
for path in manifests:
    values=json.loads(path.read_text())['files']
    entries=values.items() if isinstance(values,dict) else ((x['path'],x) for x in values)
    for name,item in entries:
        file=path.parent/name
        assert digest(file)==item['sha256'] and file.stat().st_size==item['bytes'],str(file)
        verified+=1
assert verified==459 and len(manifests)==19
for name in ('lifecycle_cost.json.gz','ability_boundaries.json.gz'):
    (PUBLIC/name).write_bytes((LOCAL/'evidence'/name).read_bytes())
(PUBLIC/'classification_counts.json.gz').write_bytes(gzip.compress((LOCAL/'evidence/classification_counts.json').read_bytes(),mtime=0))
for file in sorted((LOCAL/'scripts').glob('*.py')):
    (PUBLIC/(file.name+'.gz')).write_bytes(gzip.compress(file.read_bytes(),mtime=0))
changed=subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines()
changed+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
changed+=[str(p.relative_to(ROOT)) for p in LOCAL.rglob('*.md')]
link_count=0;broken=[]
for name in sorted(set(changed)):
    file=ROOT/name
    if file.suffix!='.md' or not file.is_file():continue
    for raw in re.findall(r'(?<!!)\[[^\]]*\]\(([^\n)]*)\)',file.read_text()):
        target=raw.strip().split(' "',1)[0].strip('<>')
        if not target or target.startswith(('#','http:','https:','mailto:','app:','data:')):continue
        path=unquote(target.split('#',1)[0])
        if not path:continue
        link_count+=1
        if not (file.parent/path).exists():broken.append({'document':name,'target':target})
assert not broken,broken
check=subprocess.run(['git','diff','--check'],cwd=ROOT,text=True,capture_output=True)
assert check.returncode==0,check.stdout+check.stderr
summary={'date':'2026-10-20','scope':'Fixed warm SQLite child-stdio six-call workflow; independent untimed counts and non-executing SQLite/MySQL controls. Assessment only, no production implementation change.',
    'environment':{'python':platform.python_version(),'os':platform.system(),'machine':platform.machine(),
        'versions':{name:importlib.metadata.version(name) for name in ('sqlglot','sqlparse','fastmcp','mcp','sqlalchemy')}},
    'comparisons':comparisons,'measured_calls':1440,'warmup_calls':288,'complete_cycles':288,
    'classifications_in_one_six_call_cycle':11,'database_valid_intentional_refusal_examples':6,'native_explain_controls':18,
    'unchanged_source_resources':77,'prior_sealed_files_verified':459,'prior_manifests_verified':19,
    'local_links_verified':link_count,'broken_links':broken,'diff_check_passed':True,
    'findings':['Warm startup validator is faster but the full successful tool workflow is modestly slower in this measurement.',
                'Existing built-in paths complete; HNP whole-session and hint-shaped-comment restrictions can refuse engine-valid managed SQL.',
                '187/980 newly refused corpus combinations are not a business refusal rate; 78 are HNP controls.',
                'Pure classification reuse and finer HNP/hint support are recommendations, not implemented or approved follow-up changes.'],
    'limits':['Sum of six call_tool round trips, excluding connection startup, model inference, local assertions/orchestration gaps and independent truth.',
              'Serial A/B/A with retained phase drift, not randomized causal identification, arbitrary-load/MySQL-write performance or provider token evidence.',
              'Metric/outcome records are not full application responses or protocol frames. All DML writes use disposable SQLite only.']}
for path in (LOCAL/'evidence/summary.json',PUBLIC/'summary.json'):
    path.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
for folder in (LOCAL,PUBLIC):
    files={}
    for file in sorted(folder.rglob('*')):
        if not file.is_file() or file.name=='manifest.json' or '__pycache__' in file.parts:continue
        files[str(file.relative_to(folder))]={'sha256':digest(file),'bytes':file.stat().st_size}
    (folder/'manifest.json').write_text(json.dumps({'date':'2026-10-20','checkpoint':'performance_ability_assessment_complete',
        'scope':'No production repair/optimization. Existing acceptance and historical evidence retain their scope.',
        'files':files},ensure_ascii=False,indent=2)+'\n')
    for name,item in files.items():assert digest(folder/name)==item['sha256']
    print(str(folder.relative_to(ROOT)),len(files),'files sealed')
print(json.dumps({'comparisons':comparisons,'old_files_verified':verified,'links_checked':link_count},indent=2))
