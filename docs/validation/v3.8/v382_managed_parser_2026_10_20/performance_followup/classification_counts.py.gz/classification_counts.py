"""Separate untimed instrumentation: classification frequency, temporary SQLite."""
import asyncio
import json
from pathlib import Path
import shutil
import sqlite3
import tempfile

from sql_safety_executor.mcp.bootstrap import prepare_framework
prepare_framework()
from fastmcp import Client
from sql_safety_executor import create_server,load_config
import sql_safety_executor.skills.access as access
import sql_safety_executor.skills.mutation as mutation

ROOT=Path(__file__).resolve().parents[5]
OUT=Path(__file__).resolve().parents[1]/'evidence/classification_counts.json'
assert not OUT.exists()

async def run():
    update,reset='sample-update-order-status','sample-reset-order-to-pending'
    count=[];original=mutation.check_managed_sql
    def wrapped(*args,**kwargs):
        count.append(True)
        return original(*args,**kwargs)
    access.check_managed_sql=mutation.check_managed_sql=wrapped
    with tempfile.TemporaryDirectory(prefix='managed-frequency-') as folder:
        root=Path(folder)
        with sqlite3.connect(root/'fixture.sqlite') as db:
            db.executescript("CREATE TABLE orders(id INTEGER PRIMARY KEY,status TEXT);INSERT INTO orders VALUES(1,'pending');")
        for name in (update,reset):shutil.copytree(ROOT/'skills'/name,root/'skills'/name)
        (root/'server.toml').write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="fixture"\n')
        (root/'connections.toml').write_text('schema_version=1\n[connections.fixture]\ntype="sqlite"\nsqlite.path="fixture.sqlite"\nread.mode="all"\nmutation.enabled=true\nmutation.skills=["'+update+'","'+reset+'"]\n')
        (root/'skills.toml').write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=true\n[skills.mutation]\nenabled=true\nallowed_connections=["fixture"]\n[skills.mutation.mrtr]\nenabled=false\n[skills.audit]\npath="audit.jsonl"\n')
        server=create_server(load_config(root/'server.toml'))
        records=[]
        try:
            async with Client(server) as client:
                async def call(step,tool,args):
                    count.clear()
                    response=await client.call_tool(tool,{'connection_id':'fixture',**args})
                    payload=response.structured_content
                    assert payload['success']
                    records.append({'step':step,'tool':tool,'classifications':len(count),'success':True})
                    return payload
                await call('catalog','list_skills',{'search':update,'detail_level':'full'})
                await call('detail','get_skill_detail',{'skill_name':update,'detail_level':'execution'})
                params={'order_id':1,'new_status':'confirmed'}
                preview=await call('update_preview','execute_mutation_skill',{'skill_name':update,'params':params,'confirm':False})
                await call('update_confirm','execute_mutation_skill',{'skill_name':update,'params':params,'confirm':True,'preview_token':preview['preview_token']})
                params={'order_id':1,'expected_status':'confirmed'}
                preview=await call('reset_preview','execute_mutation_skill',{'skill_name':reset,'params':params,'confirm':False})
                await call('reset_confirm','execute_mutation_skill',{'skill_name':reset,'params':params,'confirm':True,'preview_token':preview['preview_token']})
            with sqlite3.connect(root/'fixture.sqlite') as db:
                assert db.execute('SELECT id,status FROM orders').fetchall()==[(1,'pending')]
        finally:
            server.gateway_runtime.close()
    result={'scope':__doc__,'records':records,'total_classifications':sum(x['classifications'] for x in records),
        'note':'Function-reference instrumentation exists only inside this disposable process; not the timed stdio runs or resident Host. No production source/config change.'}
    OUT.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':asyncio.run(run())
