"""Classify intentional restrictions against independent non-executing plans."""
from dataclasses import replace
import gzip
import json
from pathlib import Path
import sqlite3

from sql_safety_executor import load_config
from sql_safety_executor.database.mysql import MySQLAdapter
from sql_safety_executor.database.semantics import DialectContext
from sql_safety_executor.skills.mutation import ManagedMutationPlan,validate_managed_mutation_plan

ROOT=Path(__file__).resolve().parents[5]
OUT=Path(__file__).resolve().parents[1]/'evidence/ability_boundaries.json.gz'
assert not OUT.exists()
base=[
    ('plain',"UPDATE orders SET status='confirmed' WHERE id=1"),
    ('ordinary_comment',"UPDATE /* ordinary comment */ orders SET status='confirmed' WHERE id=1"),
    ('optimizer_hint',"UPDATE /*+ NO_ICP(orders) */ orders SET status='confirmed' WHERE id=1"),
    ('hint_like_literal',"UPDATE orders SET status='/*+ literal */' WHERE id=1"),
]
records=[]
def classify(label,sql,context):
    result={'id':label,'sql':sql,'dialect':context.dialect,'modes':sorted(context.sql_modes)}
    for parser in ('sqlparse','sqlglot'):
        try:
            validate_managed_mutation_plan(ManagedMutationPlan(sql,(),1),parser=parser,context=context)
            result[parser]={'allowed':True}
        except (TypeError,ValueError) as error:
            result[parser]={'allowed':False,'safe_reason':str(error)}
    return result

with sqlite3.connect(':memory:') as db:
    db.executescript("CREATE TABLE orders(id INTEGER PRIMARY KEY,status TEXT);INSERT INTO orders VALUES(1,'pending');")
    before='\n'.join(db.iterdump())
    for label,sql in base:
        row=classify(label,sql,DialectContext('sqlite'))
        db.execute('EXPLAIN '+sql).fetchall()
        row['native_explain_compiles']=True
        records.append(row)
    assert before=='\n'.join(db.iterdump())

config=load_config(ROOT/'config/server.toml').connections['orders_demo_mysql']
mysql_controls=[
    ('delete_modifiers','DELETE LOW_PRIORITY QUICK IGNORE FROM orders WHERE id=1'),
    ('update_modifiers',"UPDATE LOW_PRIORITY IGNORE orders SET status='confirmed' WHERE id=1"),
    ('insert_low',"INSERT LOW_PRIORITY INTO orders(id,status) VALUES(1,'pending')"),
    ('insert_high',"INSERT HIGH_PRIORITY INTO orders(id,status) VALUES(1,'pending')"),
    ('insert_ignore',"INSERT IGNORE INTO orders(id,status) VALUES(1,'pending')"),
    ('delete_alias','DELETE o FROM orders AS o WHERE o.id=1'),
]
for high_not in (False,True):
    modes=('STRICT_TRANS_TABLES','NO_ENGINE_SUBSTITUTION',*(('HIGH_NOT_PRECEDENCE',) if high_not else ()))
    adapter=MySQLAdapter(replace(config,mysql_sql_mode=modes))
    try:
        assert adapter.connect()
        context=adapter.resolve_analysis_context()
        with adapter._engine.connect() as db:
            observed=frozenset(db.exec_driver_sql('SELECT @@SESSION.sql_mode').scalar_one().split(','))
            assert observed==context.sql_modes==frozenset(modes)
            for label,sql in base+([] if high_not else mysql_controls):
                row=classify(label,sql,context)
                try:
                    db.exec_driver_sql('EXPLAIN '+sql).fetchall()
                    row['native_explain_compiles']=True
                except Exception as exc:
                    row['native_explain_compiles']=False
                    row['native_error_class']=type(exc).__name__
                records.append(row)
    finally:
        adapter.close()
assert all(row['native_explain_compiles'] for row in records)
assert all(row['sqlparse']['allowed'] for row in records)
assert all(row['sqlglot']['allowed'] for row in records if not row['modes'] or 'HIGH_NOT_PRECEDENCE' not in row['modes'] if row['id']!='optimizer_hint')
new_refusals=[row for row in records if not row['sqlglot']['allowed']]
OUT.write_bytes(gzip.compress(json.dumps({'scope':__doc__,'records':records,'intentional_engine_valid_refusals':len(new_refusals),
    'sqlite_dump_unchanged':True,'mysql_business_or_global_writes':False,
    'notes':['SQLGlot rejects a whole HIGH_NOT_PRECEDENCE session, even the simple UPDATE without NOT.',
             'Hint-shaped comments are rejected for both databases; SQLite ignores this comment, MySQL accepts it as optimizer-hint syntax.',
             'No actual DML was executed. A valid EXPLAIN is not proof a future commit satisfies data constraints.',
             'Current explicit rollback retains the former classifier; it is not a read-policy or authorizer bypass.']},ensure_ascii=False,indent=2).encode(),mtime=0))
print('Boundary cases:',len(records),'engine-valid intentional refusals:',len(new_refusals))
