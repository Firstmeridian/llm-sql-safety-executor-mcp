"""Verify the final tested source/package and append an immutable evidence batch."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import zipfile

ROOT=Path(__file__).resolve().parents[4]
BATCH=Path(__file__).resolve().parents[1]
LOCAL=BATCH/'evidence'
ASSESS=ROOT/'local_archive/v382_review/20261017_trigger_cte_assessment'
PUBLIC=ROOT/'docs/validation/v3.8/v382_trigger_cte_2026_10_17'
assert not PUBLIC.exists()
PUBLIC.mkdir()


def sha(value):
    return hashlib.sha256(value).hexdigest()


def resources(package):
    return {str(p.relative_to(package)):sha(p.read_bytes()) for p in sorted(package.rglob('*'))
            if p.is_file() and p.suffix in {'.py','.md'}}


def read(path):
    return json.loads(gzip.decompress(path.read_bytes()))


current=resources(ROOT/'src/sql_safety_executor')
before=json.loads((LOCAL/'before_source.json').read_text())
assert len(current)==len(before)==75
assert resources(Path('/tmp/v382-before-trigger-cte/src/sql_safety_executor'))==before
changed=[name for name,digest in current.items() if before[name]!=digest]
assert changed==['database/authorizer.py'],changed
for name in ['final_matrix.json.gz','final_collisions.json.gz','source_stdio.json.gz','installed_ctes.json.gz','installed_plans.json.gz','cost_B.json.gz']:
    data=read(LOCAL/name)
    assert data['source_sha256']==current,name
for name in ['cost_A1.json.gz','cost_A2.json.gz']:
    assert read(LOCAL/name)['source_sha256']==before
for name,calls in [('source_stdio.json.gz',200),('installed_ctes.json.gz',200),('installed_plans.json.gz',140)]:
    data=read(LOCAL/name)
    assert data['calls']==calls and data['data_unchanged'] and data['restricted_function_calls']==0
    assert {(r['mode'],r['protocol']) for r in data['records']}=={('auto','2026-07-28'),('legacy','2025-11-25')}

old=read(ASSESS/'evidence/current.json.gz')['records']+read(ASSESS/'evidence/collisions.json.gz')['records']
new=read(LOCAL/'final_matrix.json.gz')['records']+read(LOCAL/'final_collisions.json.gz')['records']
assert len(old)==len(new)==138
restored=0
for a,b in zip(old,new):
    assert (a['case'],a['mode'],a['sql'])==(b['case'],b['mode'],b['sql'])
    assert b['data_unchanged'] and b['function_calls']==0 and b['native_error'] is None
    if b['expected']=='allow':
        assert b['structured']['success'],b
        restored+=not a['structured']['success']
    elif b['expected']=='deny':
        assert not b['structured']['success'],b
assert restored==44
assert sum(r['expected']=='deny' for r in new)==42
assert '2196 passed, 4 skipped, 204 warnings' in (LOCAL/'full_regression_escalated.txt').read_text()
assert '129 passed' in (LOCAL/'cte_tests_final.txt').read_text()
assert '0 errors, 0 warnings' in (LOCAL/'pyright.txt').read_text()

wheel=Path('/tmp/v382-trigger-cte-wheel/llm_sql_safety_executor_mcp-3.8.2-py3-none-any.whl')
with zipfile.ZipFile(wheel) as archive:
    packed={name.removeprefix('sql_safety_executor/'):sha(archive.read(name)) for name in archive.namelist()
            if name.startswith('sql_safety_executor/') and Path(name).suffix in {'.py','.md'}}
assert packed==current
code='''import hashlib,json,pathlib,sql_safety_executor
p=pathlib.Path(sql_safety_executor.__file__).parent
print(json.dumps(dict(package=str(p),resources={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*') if f.is_file() and f.suffix in {'.py','.md'}})))'''
installed=json.loads(subprocess.check_output(['/tmp/v382-tools/wheel-env/bin/python','-c',code],cwd='/tmp'))
assert 'site-packages' in installed['package'] and installed['resources']==current

prior={}
manifests=[
 ('docs/validation/v3.8/v382_2026_10_16/manifest.json',False),
 ('docs/validation/v3.8/v382_read_boundaries_2026_10_17/manifest.json',False),
 ('docs/validation/v3.8/v382_read_boundaries_2026_10_17/resident_restart/manifest.json',False),
 ('docs/validation/v3.8/v382_explain_followup_2026_10_17/manifest.json',False),
 ('docs/validation/v3.8/v382_explain_followup_2026_10_17/resident_restart/manifest.json',False),
 ('local_archive/v382_review/20261017_explain_followup/evidence/manifest.json',True),
 ('local_archive/v382_review/20261017_explain_adjacency/evidence/manifest.json',True),
 ('local_archive/v382_review/20261017_trigger_cte_assessment/evidence/manifest.json',True),
]
for name,batch_relative in manifests:
    path=ROOT/name
    root=path.parent.parent if batch_relative else path.parent
    for name,entry in json.loads(path.read_text())['files'].items():
        p=root/name
        assert sha(p.read_bytes())==entry['sha256'] and p.stat().st_size==entry['bytes'],p
        prior[str(p)]=entry['sha256']
assert len(prior)==311

for p in sorted(LOCAL.iterdir()):
    if p.is_file():
        name=p.name if p.suffix in {'.gz','.json'} else p.name+'.gz'
        (PUBLIC/name).write_bytes(p.read_bytes() if name==p.name else gzip.compress(p.read_bytes(),mtime=0))
for name in ['current.json.gz','collisions.json.gz','baseline_3323f9c.json.gz','summary.json']:
    (PUBLIC/('assessment_'+name)).write_bytes((ASSESS/'evidence'/name).read_bytes())
scripts=[ROOT/'scripts/validation/sqlite_trigger_ctes.py',ROOT/'scripts/validation/sqlite_plan_cost.py',
    ROOT/'tests/test_sqlite_trigger_cte_v382.py',Path(__file__),BATCH/'scripts/update_docs.py',
    ASSESS/'scripts/assess_trigger_ctes.py',ASSESS/'scripts/assess_collisions.py',
    ROOT/'local_archive/v382_review/20261017_explain_adjacency/scripts/assess_adjacent.py']
for p in scripts:
    (PUBLIC/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    for name in before:
        archive.add(Path('/tmp/v382-before-trigger-cte/src/sql_safety_executor')/name,
                    arcname='sql_safety_executor/'+name,recursive=False)
(PUBLIC/'before_source.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
verification=dict(status='source_and_installed_passed_resident_restart_pending',
    closed_utc=datetime.now(timezone.utc).isoformat(),version='3.8.2',
    regression=dict(passed=2196,skipped=4,warnings=204,new=129),
    source_stdio_calls=200,installed_stdio_calls=340,same_input_calls=138,
    restored_false_refusals=44,required_refusals=42,prior_sealed_files_unchanged=311,
    runtime_resources=current,changed_runtime_resources=changed,
    tests={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in [ROOT/'tests/test_sqlite_trigger_cte_v382.py',ROOT/'tests/test_explain_followup_v382.py']},
    scripts={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in scripts},
    wheel=dict(name=wheel.name,sha256=sha(wheel.read_bytes()),bytes=wheel.stat().st_size,installed_package=installed['package']),
    limits=['No configured database changes. Private fixtures automatically cleaned.',
        'In-process and real child stdio application results are not complete wire frames.',
        'Prior native 42/42 and Luna tasks retain prior-source scope; no new Host trigger fixture or model tokens.',
        'A/B/A includes failure-to-success workloads and drift; no zero-cost claim.'])
(PUBLIC/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')
files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(PUBLIC.iterdir()) if p.is_file()}
(PUBLIC/'manifest.json').write_text(json.dumps(dict(closed_utc=verification['closed_utc'],scope='Immutable source/package checkpoint, resident restart pending. Append later Host results separately.',files=files),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(sealed_files=len(files),runtime_resources=len(current),prior_files_unchanged=len(prior),status=verification['status'])))
