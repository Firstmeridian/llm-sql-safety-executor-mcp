"""Compare documented native scope limits using automatically cleaned fixtures."""
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile


def main(args):
    requested = args.source.resolve() / 'sql_safety_executor'
    assert (requested / '__init__.py').is_file(), 'Missing source snapshot; do not fall back to editable install'
    sys.path.insert(0, str(args.source.resolve()))
    from sql_safety_executor.core.policy import _prepare_sql_read
    from sql_safety_executor.database.errors import DatabaseQueryError
    from sql_safety_executor.database.models import ConnectionPolicy, DatabaseConfig
    from sql_safety_executor.database.sqlite import SQLiteAdapter
    import sql_safety_executor
    assert Path(sql_safety_executor.__file__).resolve().parent == requested, 'Imported package does not match requested snapshot'

    policy = ConnectionPolicy(allowed_tables=frozenset(['orders']))
    repeated = ('UPDATE orders SET total_amount='
                '(WITH chosen(n) AS MATERIALIZED (SELECT 7) SELECT COUNT(*) FROM chosen)+'
                '(WITH chosen(n) AS MATERIALIZED (SELECT id FROM orders) SELECT COUNT(*) FROM chosen) WHERE 0')
    distinct = repeated.replace('(WITH chosen(n) AS MATERIALIZED (SELECT id FROM orders) SELECT COUNT(*) FROM chosen)',
                                '(WITH other(n) AS MATERIALIZED (SELECT id FROM orders) SELECT COUNT(*) FROM other)')
    cases = [('explicit_schema_not_granted', 'SELECT COUNT(*) AS n FROM main.orders'),
             ('bare_grant_read', 'SELECT COUNT(*) AS n FROM orders')]
    for label, body in [('repeated_outer_scopes', repeated), ('distinct_outer_scopes', distinct)]:
        for prefix in ['EXPLAIN', 'EXPLAIN QUERY PLAN']:
            cases.append((label + '_' + prefix.replace(' ', '_'), prefix + ' ' + body))
    rows = []
    with tempfile.TemporaryDirectory(prefix='v382-resident-limits-') as temporary:
        path = Path(temporary) / 'private.sqlite'
        with sqlite3.connect(path) as db:
            db.executescript('CREATE TABLE orders(id,customer_id,order_date,status,total_amount);'
                             "INSERT INTO orders VALUES(7,1,'2026-10-17','pending',7);")
            before = db.execute('SELECT * FROM orders ORDER BY id').fetchall()
            for name, sql in cases:
                result = db.execute(sql).fetchall()
                rows.append({'name': name, 'sql': sql, 'native_sqlite': {'success': True, 'row_count': len(result)}})
            assert db.execute('SELECT * FROM orders ORDER BY id').fetchall() == before
        adapter = SQLiteAdapter(config=DatabaseConfig('private_fixture', 'sqlite', 5, 5, policy,
                                                       sqlite_database_path=str(path)))
        assert adapter.connect()
        try:
            for row in rows:
                plan = _prepare_sql_read(None, row['sql'], policy, adapter=adapter)
                result = {'allowed_by_policy': plan.decision.allowed,
                          'error_code': plan.decision.error_code, 'success': False}
                if plan.decision.allowed:
                    try:
                        data = adapter.execute_read(row['sql'], policy=policy, analysis=plan.analysis)
                        result.update(success=True, row_count=len(data))
                    except DatabaseQueryError as error:
                        result.update(error_code=error.error_code, error=str(error))
                row['product'] = result
            assert adapter.execute('SELECT * FROM orders ORDER BY id') == before
        finally:
            adapter.close()
    package = Path(sql_safety_executor.__file__).parent
    data = {'stage': args.stage, 'source': str(args.source.resolve()), 'loaded_package': str(package.resolve()), 'records': rows,
            'data_unchanged': True, 'configured_database_touched': False,
            'source_sha256': {str(p.relative_to(package)): hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in sorted(package.rglob('*')) if p.is_file() and p.suffix in {'.py', '.md'}}}
    assert not args.output.exists(), 'Preserve prior evidence'
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'stage': args.stage, 'records': [{'name': r['name'], **r['product']} for r in rows]}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--stage', required=True)
    parser.add_argument('--output', required=True, type=Path)
    main(parser.parse_args())
