"""Append scoped resident acceptance, keeping unexpected probes and old seals."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
LOCAL = BATCH / 'evidence/resident_restart'
PARENT = ROOT / 'docs/validation/v3.8/v382_trigger_cte_2026_10_17'
PUBLIC = PARENT / 'resident_restart'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not PUBLIC.exists(), 'Append evidence; do not overwrite a seal'
    data = json.loads((LOCAL / 'native.json').read_text())
    records = data['records']
    assert data['summary'] == {'calls': 69, 'original_expected_matches': 57, 'original_expected_mismatches': 12}
    assert len(records) == len(data['checks']) == 69
    matched, fixture_errors, limitations = [], [], []
    for row, check in zip(records, data['checks']):
        assert check['name'] == row['name']
        raw = row['raw']
        payload = raw['structuredContent']
        assert not raw.get('isError', False)
        text = [item['text'] for item in raw['content'] if item['type'] == 'text']
        assert len(text) == 1 and json.loads(text[0]) == payload
        actual = all(payload.get(key) == value for key, value in row['expected'].items())
        assert check['passed'] == actual
        if actual:
            matched.append(row)
        elif 'main.orders' in row['arguments']['sql']:
            assert row['expected']['success'] and payload['error_code'] == 'table_access_denied'
            fixture_errors.append(row['name'])
        else:
            assert row['name'].startswith('repeated_scopes_update_')
            assert row['name'].endswith('_configured_bare_grant')
            assert row['expected']['success'] and payload['error_code'] == 'view_scope_unresolved'
            limitations.append(row['name'])
    assert (len(matched), len(fixture_errors), len(limitations)) == (57, 10, 2)
    plan_count = sum(row['arguments'].get('sql', '').startswith('EXPLAIN') and row['expected']['success'] for row in matched)
    refusal_count = sum(row['expected'].get('success') is False for row in matched)
    assert (plan_count, refusal_count) == (38, 13)
    snapshots = [row['raw']['structuredContent']['data'] for row in records if row['name'] in {'snapshot_before', 'snapshot_after', 'snapshot_final'}]
    assert len(snapshots) == 3 and snapshots[0] == snapshots[1] == snapshots[2]
    assert len(snapshots[0]) == 5 and all(len(row) == 5 for row in snapshots[0])
    snapshot_hash = hashlib.sha256(json.dumps(snapshots[0], sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()

    closure = json.loads((PARENT / 'verification.json').read_text())
    for relative, digest in closure['runtime_resources'].items():
        assert sha(ROOT / 'src/sql_safety_executor' / relative) == digest, relative
    for group in ['tests', 'scripts']:
        for relative, digest in closure[group].items():
            assert sha(ROOT / relative) == digest, relative
    before = json.loads((LOCAL / 'limits_before_verified.json').read_text())
    after = json.loads((LOCAL / 'limits_after_verified.json').read_text())
    assert len(before['records']) == len(after['records']) == 6
    assert after['source_sha256'] == closure['runtime_resources']
    assert before['source_sha256'] == json.loads((PARENT / 'before_source.json').read_text())
    assert Path(before['loaded_package']) == Path(before['source']) / 'sql_safety_executor'
    assert Path(after['loaded_package']) == Path(after['source']) / 'sql_safety_executor'
    assert [name for name in before['source_sha256'] if before['source_sha256'][name] != after['source_sha256'][name]] == ['database/authorizer.py']
    assert before['data_unchanged'] and after['data_unchanged']
    for a, b in zip(before['records'], after['records']):
        assert (a['name'], a['sql'], a['native_sqlite'], a['product']) == (b['name'], b['sql'], b['native_sqlite'], b['product'])
        assert a['native_sqlite']['success']
        if a['name'].startswith('repeated_outer_scopes'):
            assert a['product']['error_code'] == 'view_scope_unresolved'
        elif a['name'] == 'explicit_schema_not_granted':
            assert a['product']['error_code'] == 'table_access_denied'
        else:
            assert a['product']['success']

    manifests = [
        'docs/validation/v3.8/v382_2026_10_16/manifest.json',
        'docs/validation/v3.8/v382_read_boundaries_2026_10_17/manifest.json',
        'docs/validation/v3.8/v382_read_boundaries_2026_10_17/resident_restart/manifest.json',
        'docs/validation/v3.8/v382_explain_followup_2026_10_17/manifest.json',
        'docs/validation/v3.8/v382_explain_followup_2026_10_17/resident_restart/manifest.json',
        'local_archive/v382_review/20261017_explain_followup/evidence/manifest.json',
        'local_archive/v382_review/20261017_explain_adjacency/evidence/manifest.json',
        'local_archive/v382_review/20261017_trigger_cte_assessment/evidence/manifest.json',
        'docs/validation/v3.8/v382_trigger_cte_2026_10_17/manifest.json',
    ]
    preserved = {}
    for name in manifests:
        manifest = ROOT / name
        base = manifest.parent.parent if name.startswith('local_archive/') else manifest.parent
        old = json.loads(manifest.read_text())
        for relative, info in old['files'].items():
            path = base / relative
            assert sha(path) == info['sha256'] and path.stat().st_size == info['bytes'], path
        preserved[name] = len(old['files'])
    assert sum(preserved.values()) == 362
    verification = {
        'version': '3.8.2', 'status': 'accepted_with_explicit_native_coverage_limits',
        'observed_utc': data['observed_utc'], 'maintainer_restart': data['maintainer_restart'],
        'native': {'total_recorded_calls': 69, 'acceptance_passed': 57, 'acceptance_checks': 57,
                   'successful_plans': 38, 'required_refusals': 13, 'other_controls': 6,
                   'original_expectation_matches': 57, 'original_expectation_mismatches': 12,
                   'text_structured_results_matching': 69,
                   'protocol': 'Not exposed by the native facade.'},
        'exploratory_probes': {
            'fixture_expectation_errors': {'count': 10, 'records': fixture_errors,
                'reason': 'The configured grant is bare orders; explicit main.orders is independently checked. Original positive expectations were incorrect. Raw records and expectations remain unchanged; authorized bare forms were tested separately.'},
            'known_functional_limit': {'count': 2, 'records': limitations,
                'reason': 'Repeated CTE labels in independent outer-query subqueries remain conservatively ambiguous. Same-input private pre/post repair checks reproduce the same refusal, and distinct-label recovery succeeds both privately and natively. Trigger-local repeated-label support must not be generalized to this case.'},
            'private_comparison': {'cases_per_snapshot': 6, 'snapshots': ['before trigger-CTE repair', 'after trigger-CTE repair'],
                'same_results': True, 'native_sqlite_accepts': True, 'data_unchanged': True,
                'scope': 'Policy plus adapter comparison with current dependencies; not a historical environment replay or additional native Host calls.'},
            'invalid_initial_comparison': {
                'files': ['limits_before.json.gz', 'limits_after.json.gz'],
                'used_as_before_after_evidence': False,
                'reason': 'The old /tmp snapshot no longer existed. The initial probe silently imported the editable current package; source-hash validation rejected that comparison. Restore all 75 old resources from the sealed before_source archive, require a real source directory and matching loaded-package identity, then rerun into separate *_verified files. Preserve both initial records.'},
        },
        'data_integrity': {'connection_id': data['connection_id'], 'relation': 'orders', 'rows': 5, 'columns': 5,
                           'snapshots': 3, 'snapshot_sha256': snapshot_hash, 'unchanged': True,
                           'write_control_scope': 'Real-DML refusal probes use WHERE 0 or empty SELECT; plans are non-executing. No configured mutation, fixture or grant change.'},
        'source': {'current_resources_match_parent_checkpoint': len(closure['runtime_resources']),
                   'loaded_code_object_hashes': 'Not introspected; disk/package identity and observed native behavior are distinct evidence.'},
        'parent_checkpoint': {'manifest': '../manifest.json', 'sha256': sha(PARENT / 'manifest.json'),
                              'files_verified_unchanged': 51,
                              'scope': 'The parent preserves its then-pending restart checkpoint. This supplement supplies current resident observations.'},
        'preserved_sealed_files_verified': preserved,
        'coverage_limits': [
            'No configured trigger/view/UDF/plan-Skill fixture was created. Trigger-local CTE cases retain 129 regressions and 340 installed stdio calls; native CTE probes exercise existing outer-query facilities only.',
            'Sample and get_table_summary are not exposed by this Host; their cross-entry coverage remains regression/installed evidence.',
            'No fresh Luna full task or model-token/Host latency measurement. Previous model evidence and serial adapter costs keep their source attribution.',
            'Tool catalog is Codex available metadata, not a wire tools/list response. Application records omit complete frames and notifications.',
            'Repeated outer CTE labels remain a known conservative false refusal. Use distinct local labels; no claim of complete SQLite grammar or scope support.',
        ],
    }
    PUBLIC.mkdir()
    for name in ['native', 'tool_catalog', 'limits_before', 'limits_after', 'limits_before_verified', 'limits_after_verified']:
        (PUBLIC / (name + '.json.gz')).write_bytes(gzip.compress((LOCAL / (name + '.json')).read_bytes(), mtime=0))
    for name in ['probe_resident_limits.py', 'seal_restart.py']:
        (PUBLIC / (name + '.gz')).write_bytes(gzip.compress((BATCH / 'scripts' / name).read_bytes(), mtime=0))
    (PUBLIC / 'verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n')
    manifest = {'closed_utc': datetime.now(timezone.utc).isoformat(),
                'scope': 'Native post-restart supplement; retain 12 exploratory expectation mismatches separately from 57 passing acceptance checks. Prior checkpoints unchanged.',
                'files': {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(PUBLIC.iterdir())}}
    (PUBLIC / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'recorded_calls': 69, 'acceptance_passed': 57, 'fixture_expectation_errors': 10,
                      'known_limit_observations': 2, 'runtime_resources': 75,
                      'preserved_files': sum(preserved.values()), 'sealed_files': len(manifest['files'])}))


if __name__ == '__main__':
    main()
