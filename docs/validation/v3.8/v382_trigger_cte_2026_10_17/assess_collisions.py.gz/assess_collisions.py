"""Additional scope/collision controls after the first assessment matrix."""
from __future__ import annotations

import argparse
import asyncio
from pathlib import Path

import assess_trigger_ctes as matrix

harness=matrix.harness
harness.CASES=[]
SQL=matrix.SQL
GRANTS=matrix.GRANTS
count_cte=matrix.count_cte
trigger=matrix.trigger

harness.add('two_catalog_candidates_even_granted', SQL,
    ddl='CREATE TABLE chosen(n); INSERT INTO chosen VALUES(17);'+trigger(f'INSERT INTO audit_log SELECT ({count_cte()})'),
    session='CREATE TEMP TABLE chosen(n); INSERT INTO temp.chosen VALUES(19);',
    grants=GRANTS+['main.chosen','temp.chosen'],expected='deny')
harness.add('temp_shadow_ungranted_even_main_granted', SQL,
    ddl='CREATE TABLE chosen(n); INSERT INTO chosen VALUES(17);'+trigger(f'INSERT INTO audit_log SELECT ({count_cte()})'),
    session='CREATE TEMP TABLE chosen(n); INSERT INTO temp.chosen VALUES(19);',
    grants=GRANTS+['main.chosen'],expected='deny')
harness.add('same_label_then_ungranted_physical', SQL,
    ddl='CREATE TABLE chosen(n); INSERT INTO chosen VALUES(17);'+trigger(f'INSERT INTO audit_log SELECT ({count_cte()}); INSERT INTO audit_log SELECT COUNT(*) FROM chosen'),expected='deny')
harness.add('same_label_other_body_ungranted_cte_base', SQL,
    ddl=trigger(f'INSERT INTO audit_log SELECT ({count_cte()}); INSERT INTO audit_log SELECT ({count_cte("SELECT n FROM hidden")})'),expected='deny')
harness.add('same_label_nested_hidden_base', SQL,
    ddl=trigger('INSERT INTO audit_log SELECT (WITH chosen(n) AS (SELECT 7) SELECT (WITH chosen(n) AS MATERIALIZED (SELECT n FROM hidden) SELECT COUNT(*) FROM chosen))'),expected='deny')
harness.add('when_cte_restricted_function', SQL,
    ddl=trigger('INSERT INTO audit_log VALUES(7)',when=f'WHEN ({count_cte("SELECT SLEEP(0)")})>0'),expected='deny')
harness.add('cte_trigger_name_collision', SQL,
    ddl=trigger(f'INSERT INTO audit_log SELECT ({count_cte()})',name='chosen'),expected='conservative_deny')
harness.add('cte_view_name_collision', SQL,
    ddl='CREATE VIEW chosen AS SELECT n FROM hidden;'+trigger(f'INSERT INTO audit_log SELECT ({count_cte()})'),expected='conservative_deny')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    args.source=args.source.resolve()
    args.output=args.output.resolve()
    if args.output.exists():
        parser.error('Output already exists; choose a fresh filename')
    asyncio.run(matrix.run(args))
