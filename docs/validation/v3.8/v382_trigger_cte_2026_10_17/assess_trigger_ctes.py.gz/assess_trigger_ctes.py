"""Assess trigger-local CTE plan callbacks without changing runtime decisions."""
from __future__ import annotations

import argparse
import asyncio
from dataclasses import asdict
import gzip
import hashlib
import json
from pathlib import Path
import sys

REPO = Path(__file__).resolve().parents[4]
HARNESS = REPO / 'local_archive/v382_review/20261017_explain_adjacency/scripts'
sys.path.insert(0, str(HARNESS))
import assess_adjacent as harness

harness.CASES = []
SQL = 'INSERT INTO orders VALUES(99)'
GRANTS = ['orders', 'audit_log', 'lookup_values']


def trigger(body, *, when='', name='log_orders', target='orders'):
    return f'CREATE TRIGGER {name} AFTER INSERT ON {target} {when} BEGIN {body}; END;'


def count_cte(body='SELECT 7', hint='MATERIALIZED', *, name='chosen', expression='COUNT(*)'):
    return f'WITH {name}(n) AS {hint} ({body}) SELECT {expression} FROM {name}'


def add(name, query, **options):
    harness.add(name, SQL, ddl=trigger(f'INSERT INTO audit_log SELECT ({query})'), **options)


add('reported_constant_materialized', count_cte())
add('reported_authorized_materialized', count_cte('SELECT n FROM orders'))
add('constant_implicit', count_cte(hint=''))
add('constant_not_materialized', count_cte(hint='NOT MATERIALIZED'))
add('authorized_implicit', count_cte('SELECT n FROM orders', hint=''))
add('authorized_not_materialized', count_cte('SELECT n FROM orders', hint='NOT MATERIALIZED'))
add('constant_count_column', count_cte(expression='COUNT(n)'))
add('constant_materialized_value', count_cte(expression='n'))
add('authorized_materialized_value', count_cte('SELECT n FROM orders', expression='n'))
add('nested_cte', count_cte('WITH inner_choice(n) AS MATERIALIZED (SELECT 7) SELECT n FROM inner_choice'))
add('chained_ctes', 'WITH first_choice(n) AS MATERIALIZED (SELECT 7), chosen(n) AS MATERIALIZED (SELECT n FROM first_choice) SELECT COUNT(*) FROM chosen')
add('recursive_cte', 'WITH RECURSIVE chosen(n) AS (SELECT 1 UNION ALL SELECT n+1 FROM chosen WHERE n<3) SELECT COUNT(*) FROM chosen')
harness.add('when_constant_cte', SQL, ddl=trigger('INSERT INTO audit_log VALUES(7)', when=f'WHEN ({count_cte()})>0'))
harness.add('multiple_body_ctes', SQL, ddl=trigger(f'INSERT INTO audit_log SELECT ({count_cte()}); INSERT INTO audit_log SELECT ({count_cte("SELECT n FROM orders")})'))
harness.add('nested_trigger_cte', SQL, ddl=trigger('INSERT INTO audit_log VALUES(7)')+trigger(f'INSERT INTO lookup_values SELECT ({count_cte()})', name='log_audit', target='audit_log'))
harness.add('view_backed_cte', SQL, ddl='CREATE VIEW lookup_view AS SELECT n FROM hidden;'+trigger(f'INSERT INTO audit_log SELECT ({count_cte("SELECT n FROM lookup_view")})'), grants=GRANTS+['lookup_view'])
add('ungranted_cte_base', count_cte('SELECT n FROM hidden'), expected='deny')
add('restricted_cte_function', count_cte('SELECT SLEEP(0)'), expected='deny')
harness.add('separate_ungranted_count', SQL, ddl=trigger(f'INSERT INTO audit_log SELECT ({count_cte()}); INSERT INTO audit_log SELECT COUNT(*) FROM hidden'), expected='deny')
harness.add('actual_dml', SQL, ddl=trigger(f'INSERT INTO audit_log SELECT ({count_cte()})'), expected='deny')
for where, session in [('main', ''), ('temp', 'CREATE TEMP TABLE chosen(n); INSERT INTO temp.chosen VALUES(17);'), ('aux', "ATTACH ':memory:' AS aux; CREATE TABLE aux.chosen(n); INSERT INTO aux.chosen VALUES(17);")]:
    ddl=('CREATE TABLE chosen(n); INSERT INTO chosen VALUES(17);' if where=='main' else '')
    harness.add('collision_'+where, SQL, ddl=ddl+trigger(f'INSERT INTO audit_log SELECT ({count_cte()})'), session=session, expected='conservative_deny')
harness.add('collision_main_explicit_grant', SQL, ddl='CREATE TABLE chosen(n); INSERT INTO chosen VALUES(17);'+trigger(f'INSERT INTO audit_log SELECT ({count_cte()})'), grants=GRANTS+['main.chosen'], expected='conservative_deny')
harness.add('ungranted_qualified_same_name', SQL, ddl='CREATE TABLE chosen(n); INSERT INTO chosen VALUES(17);'+trigger(f'INSERT INTO audit_log SELECT ({count_cte("SELECT n FROM main.chosen")})'), expected='deny')
harness.add('physical_count_control', SQL, ddl=trigger('INSERT INTO audit_log SELECT COUNT(*) FROM orders'))
harness.add('plain_trigger_control', SQL, ddl=trigger('INSERT INTO audit_log VALUES(NEW.n)'))


async def run(args):
    sys.path.insert(0, str(args.source))
    await harness.assess(args)
    analysis_file = args.output.with_name(args.output.name.removesuffix('.json.gz')+'_analysis.json')
    if analysis_file.exists():
        raise RuntimeError('Analysis file already exists')
    analysis_results = []
    if (args.source/'sql_safety_executor/core/analysis.py').exists():
        from sql_safety_executor.core.analysis import analyze_sqlite_trigger
        from sql_safety_executor.database.semantics import DialectContext
        import sqlite3
        for case in harness.CASES:
            database = sqlite3.connect(':memory:')
            try:
                database.executescript(harness.BASE+case['ddl']+case['session'])
                for _, schema, _ in database.execute('PRAGMA database_list'):
                    for name, definition in database.execute(f'SELECT name,sql FROM {harness.quote(schema)}.sqlite_master WHERE type=\'trigger\''):
                        results = analyze_sqlite_trigger(definition, DialectContext('sqlite', default_schema='main'))
                        analysis_results.append(dict(case=case['name'], schema=schema, trigger=name,
                            results=None if results is None else [asdict(result) for result in results]))
            finally:
                database.close()
    payload=dict(source=str(args.source), analyses=analysis_results,
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        harness_sha256=hashlib.sha256((HARNESS/'assess_adjacent.py').read_bytes()).hexdigest())
    analysis_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=lambda item: sorted(item))+'\n')


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--reported-only', action='store_true')
    args=parser.parse_args()
    args.source=args.source.resolve()
    args.output=args.output.resolve()
    if args.output.exists():
        parser.error('Output already exists; choose a fresh filename')
    if args.reported_only:
        harness.CASES=harness.CASES[:2]
    asyncio.run(run(args))
