"""Append current acceptance/decisions while retaining older scoped records."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4]
REPORT='V3_8_2_TRIGGER_CTE_2026_10_17_ZH.md'


def after_line(path,marker,text):
    p=ROOT/path
    lines=p.read_text().splitlines()
    matches=[i for i,line in enumerate(lines) if marker in line]
    assert len(matches)==1,(path,matches)
    lines[matches[0]+1:matches[0]+1]=['',text]
    p.write_text('\n'.join(lines)+'\n')


for name,block in {
    'REFACTORING_LOG.md':f'''## v3.8.2 Restore trigger-local CTE explanations (October 17, 2026; resident verification pending)

- Reopen DRR-108 for database-less CTE count READs. Prepare verified SELECT/DML sources outside the callback, retaining owner/fragment/scope identities. Check every physical dependency before accepting a scoped ephemeral event; keep real-DML, function and ambiguous-object refusals.
- Cover WHEN, select-only/nested triggers, recursive/materialized CTEs, repeated local names across fragments/scopes/triggers, schema collisions and catalog changes. Add 129 regressions: **2196 passed/four skipped**, clean type/prompt checks, 200 source stdio and 340 independently installed calls across both protocols; rows/total_changes unchanged and restricted functions uncalled.
- Preserve pre-repair failures, the first test's empty-plan assertion error, intermediate shared-name refusal and sandbox-limited runs. Serial A/B/A records extra catalog/compile work; no zero-cost/model-token claim. Version/dependencies/configuration/grants/approval/required Agent calls stay unchanged. [Decisions, evidence, costs and pending restart](docs/validation/v3.8/{REPORT}); earlier native 42/42 retains its tested source.

''',
    'REFACTORING_LOG_ZH.md':f'''## v3.8.2 恢复触发器局部 CTE 计划（2026-10-17；待驻留复验）

- DRR-108 对空数据库名的 CTE 计数 READ 重开。SELECT／DML 来源在回调外准备，保留 owner／片段／scope 身份；所有物理依赖先独立核验，再接受限定临时事件。实际 DML、受限函数和对象歧义仍拒绝。
- 覆盖 WHEN、纯 SELECT／嵌套触发器、递归／物化 CTE、跨片段／作用域／触发器重名、schema 冲突及目录变更。新增 129 项，全量 **2196 passed／4 skipped**，类型／提示通过；源码 stdio 200 次、独立安装两协议 340 次，数据及 total_changes 不变、受限函数零调用。
- 保留修复前失败、新测试误要求空计划非空、首版多触发器重名误拒及沙盒受限记录。串行 A/B/A 明示额外目录／编译工作，不宣称零成本或模型 token。版本、依赖、配置、grant、审批及 Agent 必需调用不变。[决定、证据、成本与待重启状态](docs/validation/v3.8/{REPORT})；旧原生 42/42 保留其源码范围。

''',
}.items():
    p=ROOT/name
    text=p.read_text()
    offset=text.index('## v3.8.2 ')
    p.write_text(text[:offset]+block+text[offset:])

after_line('README.md','Shared SQLGlot analysis preserves',f'The later trigger-local CTE repair adds 129 regressions (**2196 passed, 4 skipped**) and 340 installed stdio calls, including WHEN, select-only triggers and repeated local names. Current resident verification awaits a maintainer restart; the earlier 42/42 result retains its prior-source scope. See the [CTE supplement](docs/validation/v3.8/{REPORT}) for costs and limits.')
after_line('README_ZH.md','共享 SQLGlot 分析保留',f'后续局部 CTE 补修新增 129 项回归（**2196 passed／4 skipped**）及 340 次安装 stdio，覆盖 WHEN、纯 SELECT 触发器和重复局部名。当前驻留状态待维护者重启复验，旧 42/42 保留前批源码范围；成本与限制见[CTE 补充报告](docs/validation/v3.8/{REPORT})。')
after_line('docs/README.md','- [v3.8.2 trigger, WITH',f'- [v3.8.2 trigger-local CTE plan repair](validation/v3.8/{REPORT}).')
after_line('docs/README_ZH.md','- [v3.8.2 触发器、WITH',f'- [v3.8.2 触发器局部 CTE 计划补修](validation/v3.8/{REPORT})。')
after_line('docs/releases/RELEASE_NOTES_v3_8.md','Later review reopened DRR-108',f'Trigger-local CTE count callbacks exposed one further P2 boundary. The [CTE supplement](../validation/v3.8/{REPORT}) records 129 new regressions, 2196 full passes/four skips and 340 installed stdio calls. SELECT/DML source preparation and scoped CTE proofs cover WHEN, select-only and repeated local names without new grants. Resident verification is pending a maintainer restart; retain prior native attribution and measured catalog/compile costs.')
after_line('docs/security/V3_8_SECURITY.md','The subsequent [plan follow-up]',f'A subsequent trigger-local CTE boundary reopens DRR-108: verified SELECT/DML sources and owner/fragment/scope declarations are prepared outside callbacks before database-less CTE count events are accepted. Real physical dependencies, writes, restricted functions and ambiguous source/catalog identities remain checked. Same local spellings in separately validated triggers do not share physical grants. See the [current supplement](../validation/v3.8/{REPORT}) for 2196 passes/four skips, installed coverage, costs and pending resident verification.')
after_line('docs/guides/TEST_MCP_CLIENT_GUIDE.md','Run `scripts/validation/sqlite_plans.py',f'Use `scripts/validation/sqlite_trigger_ctes.py --source <src> --output <fresh>.json.gz` for trigger-local CTEs; omit --source with the independent wheel interpreter. Both real stdio protocols cover constant/materialized CTE counts, WHEN, select-only/nested triggers, repeated names, raw/Skill readiness/execution, refusal controls and unchanged serving-connection total_changes. Extend scope/name regressions with schema collisions and catalog replacement. `sqlite_plan_cost.py` now includes trigger_cte_count; run A/B/A serially and separate recovered functionality from equal-work overhead. See the [supplement](../validation/v3.8/{REPORT}).')

for name,language in [('docs/security/DESIGN_RISK_REGISTER.md','en'),('docs/security/DESIGN_RISK_REGISTER_ZH.md','zh')]:
    p=ROOT/name
    lines=p.read_text().splitlines()
    index=next(i for i,line in enumerate(lines) if line.startswith('| DRR-2026-108 |'))
    cells=lines[index].split('|')
    assert len(cells)==12,len(cells)
    if language=='en':
        cells[2]=' Implemented; trigger-local CTE resident verification pending '
        cells[8]+=' Prepare SELECT/DML sources and scoped trigger-local CTE proofs before physical binding; validate repeated-owner dependencies independently. '
        cells[9]+=f' Later CTE supplement: 129 new regressions, 2196 full passes/four skips, type/prompt and 340 installed calls pass; resident verification pending. [Current evidence](../validation/v3.8/{REPORT}). '
    else:
        cells[2]=' 已补修；局部 CTE 待驻留复验 '
        cells[8]+=' SELECT／DML 来源及触发器局部 CTE 先在回调外验证，再判定物理绑定；重名 owner 的依赖独立检查。 '
        cells[9]+=f' 后续局部 CTE 新增 129 项，全量 2196 passed／4 skipped、类型／提示及安装 340 次通过；待本批驻留复验。[最新证据](../validation/v3.8/{REPORT})。 '
    lines[index]='|'.join(cells)
    p.write_text('\n'.join(lines)+'\n')

p=ROOT/'local_archive/v382_review/README.md'
p.write_text(p.read_text()+f'\n## 触发器局部 CTE 补修\n\n`20261017_trigger_cte_repair/` 按 scripts／evidence 组织实现、新增 129 项回归及串行成本。正式[CTE 补充报告](../../docs/validation/v3.8/{REPORT})记录 2196 passed／4 skipped、340 次安装 stdio 和待驻留复验状态。前批复评和封存文件保留原字节。\n')
p=ROOT/'local_archive/v382_review/handoff/commit-message-v382.txt'
text=p.read_text()
old='- guard SQLite view/metadata reads and restore trigger/DML plans'
assert old in text
p.write_text(text.replace(old,'- guard SQLite view/metadata reads and restore trigger/CTE/DML plans'))

p=ROOT/'docs/validation/v3.8'/REPORT
text=p.read_text()
for value in ['0.807/1.596','0.754/1.638','3.592/6.214','1.911/3.574（拒绝）','4.344/8.629','0.950/1.782']:
    assert '待填' in text
    text=text.replace('待填',value,1)
assert '待填' not in text
p.write_text(text)
print('Updated bilingual logs/README/DRR, docs navigation/contracts, test guide and commit-message draft.')
