"""Independent private SQLite plan fixtures; assess without runtime changes."""
from __future__ import annotations

import argparse
import asyncio
import gzip
import hashlib
import json
import logging
from pathlib import Path
import sqlite3
import sys
import tempfile

BASE = '''CREATE TABLE orders(n INTEGER UNIQUE); INSERT INTO orders VALUES(7);
CREATE TABLE audit_log(n); CREATE TABLE lookup_values(n); INSERT INTO lookup_values VALUES(13);
CREATE TABLE hidden(n); INSERT INTO hidden VALUES(17);'''
CASES = []

def add(name, sql, *, ddl='', session='', grants=None, expected='allow'):
    CASES.append(dict(name=name, sql=sql, ddl=ddl, session=session,
                      grants=grants or ['orders', 'audit_log', 'lookup_values'], expected=expected))

for name, body in [
    ('default_values', 'INSERT INTO orders DEFAULT VALUES'),
    ('insert_ignore', 'INSERT OR IGNORE INTO orders VALUES(99)'),
    ('insert_replace', 'INSERT OR REPLACE INTO orders VALUES(99)'),
    ('update_replace', 'UPDATE OR REPLACE orders SET n=99'),
    ('upsert_values', 'INSERT INTO orders VALUES(7) ON CONFLICT(n) DO UPDATE SET n=99'),
    ('upsert_cte', 'WITH chosen(n) AS (SELECT 7) INSERT INTO orders SELECT n FROM chosen WHERE 1 ON CONFLICT(n) DO UPDATE SET n=excluded.n'),
    ('insert_returning', 'INSERT INTO orders VALUES(99) RETURNING n'),
    ('update_returning', 'UPDATE orders SET n=99 RETURNING n'),
    ('delete_returning', 'DELETE FROM orders RETURNING n'),
    ('replace_returning', 'REPLACE INTO orders VALUES(99) RETURNING n'),
    ('with_update', 'WITH chosen(n) AS (SELECT 99) UPDATE orders SET n=(SELECT n FROM chosen)'),
    ('with_delete', 'WITH chosen(n) AS (SELECT 7) DELETE FROM orders WHERE n IN chosen'),
    ('with_insert_or_replace', 'WITH chosen(n) AS (SELECT 99) INSERT OR REPLACE INTO orders SELECT n FROM chosen'),
    ('with_replace_returning', 'WITH chosen(n) AS (SELECT 99) REPLACE INTO orders SELECT n FROM chosen RETURNING n'),
    ('with_replace_comment', 'WITH chosen(n) AS (SELECT 99) /* statement */ REPLACE INTO orders SELECT n FROM chosen'),
    ('with_replace_default', 'WITH chosen(n) AS (SELECT 99) REPLACE INTO orders DEFAULT VALUES'),
    ('update_from', 'UPDATE orders SET n=lookup_values.n FROM lookup_values'),
    ('update_alias', 'UPDATE orders AS o SET n=99 WHERE o.n=7'),
    ('update_count', 'UPDATE orders SET n=(SELECT COUNT(*) FROM lookup_values)'),
    ('insert_select_count', 'INSERT INTO orders SELECT COUNT(*) FROM lookup_values'),
]:
    add(name, body)

for name, trigger in [
    ('trigger_when', 'CREATE TRIGGER log_orders AFTER INSERT ON orders WHEN NEW.n>0 BEGIN INSERT INTO audit_log VALUES(99); END;'),
    ('trigger_nested', 'CREATE TRIGGER log_orders AFTER INSERT ON orders BEGIN INSERT INTO audit_log VALUES(99); END; CREATE TRIGGER log_audit AFTER INSERT ON audit_log BEGIN INSERT INTO lookup_values VALUES(NEW.n); END;'),
    ('trigger_view', 'CREATE VIEW lookup_view AS SELECT n FROM lookup_values; CREATE TRIGGER log_orders AFTER INSERT ON orders BEGIN INSERT INTO audit_log SELECT n FROM lookup_view; END;'),
    ('trigger_count_column', 'CREATE TRIGGER log_orders AFTER INSERT ON orders BEGIN INSERT INTO audit_log SELECT COUNT(n) FROM lookup_values; END;'),
    ('trigger_count_star', 'CREATE TRIGGER log_orders AFTER INSERT ON orders BEGIN INSERT INTO audit_log SELECT COUNT(*) FROM lookup_values; END;'),
    ('trigger_raise', "CREATE TRIGGER log_orders BEFORE INSERT ON orders BEGIN SELECT RAISE(IGNORE); END;"),
]:
    add(name, 'INSERT INTO orders VALUES(99)', ddl=trigger,
        grants=['orders', 'audit_log', 'lookup_values', 'lookup_view'])

add('trigger_view_target', 'INSERT INTO orders_view VALUES(99)',
    ddl='CREATE VIEW orders_view AS SELECT n FROM orders; CREATE TRIGGER insert_orders INSTEAD OF INSERT ON orders_view BEGIN INSERT INTO orders VALUES(NEW.n); END;',
    grants=['orders_view','orders'])
add('temp_trigger', 'INSERT INTO main.orders VALUES(99)',
    session='CREATE TEMP TRIGGER log_orders AFTER INSERT ON main.orders BEGIN INSERT INTO audit_log VALUES(NEW.n); END;')
add('trigger_quoted_names', 'INSERT INTO main.orders VALUES(99)',
    ddl='CREATE TRIGGER " odd.log " AFTER INSERT ON orders BEGIN INSERT INTO audit_log VALUES(NEW.n); END;')
add('trigger_count_aux', 'INSERT INTO main.orders VALUES(99)',
    session="ATTACH ':memory:' AS aux; CREATE TABLE aux.extra(n); INSERT INTO aux.extra VALUES(13); CREATE TEMP TRIGGER log_orders AFTER INSERT ON main.orders BEGIN INSERT INTO audit_log SELECT COUNT(*) FROM aux.extra; END;",
    grants=['main.orders','audit_log','aux.extra'])

for action in ['CASCADE','SET NULL','SET DEFAULT','RESTRICT','NO ACTION']:
    setup=f'CREATE TABLE parent(n INTEGER PRIMARY KEY); INSERT INTO parent VALUES(7); CREATE TABLE child(n INTEGER DEFAULT NULL REFERENCES parent(n) ON DELETE {action} ON UPDATE {action}); INSERT INTO child VALUES(7);'
    for operation, body in [('delete','DELETE FROM parent'),('update','UPDATE parent SET n=99'),('insert','INSERT INTO child VALUES(7)')]:
        add('fk_'+action.lower().replace(' ','_')+'_'+operation, body, ddl=setup,
            session='PRAGMA foreign_keys=ON;', grants=['parent','child'])

add('fk_ungranted_child', 'DELETE FROM parent',
    ddl='CREATE TABLE parent(n INTEGER PRIMARY KEY); INSERT INTO parent VALUES(7); CREATE TABLE child(n REFERENCES parent(n) ON DELETE CASCADE); INSERT INTO child VALUES(7);',
    session='PRAGMA foreign_keys=ON;', grants=['parent'], expected='deny')
add('fk_ungranted_parent', 'INSERT INTO child VALUES(7)',
    ddl='CREATE TABLE parent(n INTEGER PRIMARY KEY); INSERT INTO parent VALUES(7); CREATE TABLE child(n REFERENCES parent(n));',
    session='PRAGMA foreign_keys=ON;', grants=['child'], expected='deny')
add('autoincrement', 'INSERT INTO numbered(n) VALUES(99)',
    ddl='CREATE TABLE numbered(id INTEGER PRIMARY KEY AUTOINCREMENT,n); INSERT INTO numbered(n) VALUES(7);', grants=['numbered'])
add('without_rowid', 'INSERT INTO no_rowid VALUES(99)',
    ddl='CREATE TABLE no_rowid(n INTEGER PRIMARY KEY) WITHOUT ROWID; INSERT INTO no_rowid VALUES(7);', grants=['no_rowid'])
add('generated_column', 'INSERT INTO generated(n) VALUES(99)',
    ddl='CREATE TABLE generated(n, twice GENERATED ALWAYS AS (n*2) STORED); INSERT INTO generated(n) VALUES(7);', grants=['generated'])
add('expression_index', 'UPDATE orders SET n=99', ddl='CREATE INDEX orders_expression ON orders(abs(n));')
add('quoted_dotted_target', 'INSERT INTO "main.orders" VALUES(99)', ddl='CREATE TABLE "main.orders"(n); INSERT INTO "main.orders" VALUES(17);', grants=['main.orders'], expected='deny')
add('temp_shadow_explicit_main', 'INSERT INTO main.orders VALUES(99)', session='CREATE TEMP TABLE orders(n); INSERT INTO temp.orders VALUES(17);',grants=['main.orders'])
add('temp_shadow_unqualified', 'INSERT INTO orders VALUES(99)', session='CREATE TEMP TABLE orders(n); INSERT INTO temp.orders VALUES(17);',grants=['main.orders'],expected='deny')
add('plan_ungranted_source', 'INSERT INTO orders SELECT n FROM hidden', expected='deny')
add('plan_expensive_function', 'INSERT INTO orders VALUES(SLEEP(0))', expected='deny')
add('trigger_ungranted_target', 'INSERT INTO orders VALUES(99)', ddl='CREATE TRIGGER log_orders AFTER INSERT ON orders BEGIN INSERT INTO hidden VALUES(99); END;', expected='deny')
add('trigger_ungranted_source', 'INSERT INTO orders VALUES(99)', ddl='CREATE TRIGGER log_orders AFTER INSERT ON orders BEGIN INSERT INTO audit_log SELECT n FROM hidden; END;', expected='deny')
add('trigger_expensive_function', 'INSERT INTO orders VALUES(99)', ddl='CREATE TRIGGER log_orders AFTER INSERT ON orders BEGIN INSERT INTO audit_log VALUES(SLEEP(0)); END;', expected='deny')
add('actual_dml', 'UPDATE orders SET n=99', expected='deny')

def quote(name):
    return '"'+name.replace('"','""')+'"'

def snapshot(db):
    result={}
    for _, schema, _ in db.execute('PRAGMA database_list'):
        for (name,) in db.execute(f'SELECT name FROM {quote(schema)}.sqlite_master WHERE type=\'table\' ORDER BY name').fetchall():
            rows=db.execute(f'SELECT * FROM {quote(schema)}.{quote(name)}').fetchall()
            result[schema+'.'+name]=sorted([list(row) for row in rows],key=repr)
    return result

async def assess(args):
    sys.path.insert(0,str(args.source))
    import sql_safety_executor
    from sql_safety_executor.config.loader import load_config
    from sql_safety_executor.mcp.server import create_server
    from fastmcp import Client
    logging.disable(logging.CRITICAL)
    guard_events=[]
    if (Path(sql_safety_executor.__file__).parent/'database'/'authorizer.py').exists():
        from sql_safety_executor.database.authorizer import SQLiteReadGuard
        authorize=SQLiteReadGuard.authorize
        def traced(self,*values):
            result=authorize(self,*values)
            guard_events.append(dict(values=list(values),result=result,denial=self.denial))
            return result
        SQLiteReadGuard.authorize=traced
    records=[]
    for mode in ['auto','legacy']:
        for case in CASES:
            with tempfile.TemporaryDirectory(prefix='v382-adjacent-') as temp:
                root=Path(temp)
                native=sqlite3.connect(root/'fixture.sqlite',cached_statements=0)
                native_calls=[]
                native.create_function('SLEEP',1,lambda _:native_calls.append(True) or 0)
                native.executescript(BASE+case['ddl'])
                native.executescript(case['session'])
                before=snapshot(native)
                (root/'server.toml').write_text('schema_version=1\n[files]\nconnections="connections.toml"\n[server]\ndefault_connection="demo"\n')
                read_mode=case.get('read_mode','allowlist')
                tables='read.tables='+json.dumps(case['grants'])+'\n' if read_mode=='allowlist' else ''
                (root/'connections.toml').write_text('schema_version=1\n[connections.demo]\ntype="sqlite"\nsqlite.path="fixture.sqlite"\nread.mode='+json.dumps(read_mode)+'\n'+tables)
                server=create_server(load_config(root/'server.toml'))
                calls=[]
                try:
                    async with Client(server,mode=mode) as client:
                        adapter=server.gateway_runtime.registry.get_adapter('demo')
                        assert adapter.connect()
                        with adapter._engine.connect() as connection:
                            actual=connection.connection.dbapi_connection
                            actual.create_function('SLEEP',1,lambda _:calls.append(True) or 0)
                            actual.executescript(case['session'])
                            app_before=snapshot(actual)
                            assert app_before==before
                            native_fk=native.execute('PRAGMA foreign_keys').fetchone()[0]
                            actual_fk=actual.execute('PRAGMA foreign_keys').fetchone()[0]
                            assert native_fk==actual_fk
                            if 'PRAGMA foreign_keys=ON;' in case['session']:
                                assert actual_fk==1
                        prefixes=[''] if case['name']=='actual_dml' else ['EXPLAIN','EXPLAIN QUERY PLAN']
                        for prefix in prefixes:
                            sql=(prefix+' '+case['sql']).strip()
                            native_events=[]
                            native_error=None
                            plan=[]
                            if prefix:
                                native.set_authorizer(lambda *v:native_events.append(list(v)) or sqlite3.SQLITE_OK)
                                try:
                                    plan=native.execute(sql).fetchall()
                                except sqlite3.Error as exc:
                                    native_error=str(exc)
                                finally:
                                    native.set_authorizer(None)
                            assert not native_calls and snapshot(native)==before
                            guard_events.clear()
                            response=await client.call_tool('query',{'sql':sql},raise_on_error=False)
                            payload=response.structured_content
                            if isinstance(payload,dict):
                                content=[c.text for c in response.content if c.type=='text']
                                assert len(content)==1 and json.loads(content[0])==payload
                            with adapter._engine.connect() as connection:
                                after=snapshot(connection.connection.dbapi_connection)
                            assert after==before and not calls,(case['name'],mode,prefix)
                            records.append(dict(case=case['name'],mode=mode,protocol=client.protocol_version,sql=sql,
                                expected=case['expected'],foreign_keys=native_fk,native_error=native_error,
                                native_plan_rows=len(plan),native_authorizer_events=native_events,
                                mcp_guard_events=list(guard_events),structured=payload,isError=response.is_error,
                                content=[c.model_dump(mode='json',exclude_none=True) for c in response.content],
                                data_unchanged=True,function_calls=0))
                finally:
                    server.gateway_runtime.close()
                    native.close()
    package=Path(sql_safety_executor.__file__).parent
    result=dict(source=str(args.source),version=sql_safety_executor.__version__,sqlite_version=sqlite3.sqlite_version,
        cases=CASES,records=records,calls=len(records),
        source_sha256={str(p.relative_to(package)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(package.rglob('*')) if p.is_file() and p.suffix in {'.py','.md'}},
        scope='Private, auto-cleaned SQLite fixtures. Both sources use current installed dependencies. In-process Client application results, not full wire frames or installed-wheel/native Host checks. Trace delegates unchanged guard decisions. No runtime/configuration edits; no configured databases touched.')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_bytes(gzip.compress((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
    print(json.dumps(dict(source=str(args.source),cases=len(CASES),calls=len(records),native_invalid=sum(r['native_error'] is not None for r in records),
        successes=sum(r['structured'].get('success') is True for r in records),data_unchanged=True)))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    args.source=args.source.resolve();args.output=args.output.resolve()
    if args.output.exists():
        parser.error('Output already exists; choose a fresh filename')
    asyncio.run(assess(args))
