"""Keep the functional gap open; seal diagnostics and source/Host attribution."""
import difflib,gzip,hashlib,json,re,subprocess
from pathlib import Path
from urllib.parse import unquote
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/cte_classification_2026_10_15"
sha=lambda b:hashlib.sha256(b).hexdigest()
def read_result(name):
    p=OUT/name
    if not p.exists():p=OUT/(name+".gz")
    b=p.read_bytes();return json.loads(gzip.decompress(b) if p.suffix==".gz" else b)
def read_log(name):
    p=Path("/tmp")/name
    return p.read_text() if p.exists() else gzip.decompress((OUT/(name+".gz")).read_bytes()).decode()
source={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in (".py",".md")}
baseline=read_result("baseline_source.json")
changed=[n for n in source if source[n]!=baseline[n]]
assert changed==["src/sql_safety_executor/core/sql.py"]
assert baseline==json.loads((ROOT/"docs/validation/v3.8/cte_header_2026_10_15/automation.json").read_text())["source_sha256"]
previous={}
for name in ("cte_header_2026_10_15","lexical_identity_2026_10_15","pragma_identity_2026_10_15","sqlite_prefix_2026_10_15","real_tasks_2026_10_15","schema_binding_2026_10_15"):
    directory=ROOT/"docs/validation/v3.8"/name
    rows=json.loads((directory/"manifest.json").read_text())["artifacts"]
    for r in rows:assert sha((directory/r["path"]).read_bytes())==r["sha256"],(name,r["path"])
    previous[name]=len(rows)
before=read_result("before-calls.json.gz");after=read_result("after-calls.json.gz")
assert before["source_sha256"]==baseline and after["source_sha256"]==source
assert before["total_calls"]==after["total_calls"]==76
for old,new in zip(before["records"],after["records"]):
    assert (old["mode"],old["admitted"],old["requests"])==(new["mode"],new["admitted"],new["requests"])
    assert len(old["requests"])==len(new["requests"])==19
    for i in (*range(4),18):
        assert old["calls"][i]["structuredContent"]["error_code"]=="read_only_required"
        d=new["calls"][i]["structuredContent"]
        assert d["error_code"]=="sql_parse_failed" and "mutation" not in d["hint"].lower()
    for r in new["calls"][4:8]+new["calls"][13:17]:assert r["structuredContent"]["data"]==[{"n":7}]
    assert new["calls"][17]["structuredContent"]["error_code"]=="read_only_required"
    assert "mutation" in new["calls"][17]["structuredContent"]["hint"].lower()
wheel=read_result("installed_wheel.json")
assert wheel["total_calls"]==76 and wheel["source_files_verified"]==69
assert source=={"src/"+name:value for name,value in wheel["installed_source_sha256"].items()}
mysql=read_result("live_mysql.json.gz")
assert mysql["source_sha256"]==source and mysql["checks"]=={"passed":12,"failed":0}
matrix=read_result("classification_matrix.json.gz")
assert matrix["source_sha256"]==source
assert (matrix["cases"],matrix["native_read_cases"],matrix["acceptance_changes"])==(47,38,0)
for r in matrix["records"]:
    assert r["before_policy"]["allowed"]==r["after_policy"]["allowed"]
    if r["kind"]=="cte_name" and r["get_type"]=="UNKNOWN":
        assert all(d=={"allowed":False,"code":"read_only_required"} for d in r["archived_classifiers"].values())
        assert r["current_shape"]["code"]=="sql_parse_failed"
full=read_log("v381-cte-classification-full.log")
m=re.search(r"(\d+) passed, (\d+) skipped, (\d+) warnings in ([\d.]+)s",full)
assert m and m.group(1,2,3)==("1560","4","75")
assert "43 passed, 2 warnings in 5.77s" in read_log("v381-cte-classification-focused.log")
assert "0 errors, 0 warnings" in read_log("v381-cte-classification-pyright.log")
assert "Installed prompt resources and routing guidance valid" in read_log("v381-cte-classification-prompt.log")
for p in Path("/tmp").glob("v381-cte-classification-*.log"):
    (OUT/(p.name+".gz")).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in Path(__file__).parent.glob("*.py"):
    (OUT/(p.name+".gz")).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
old=gzip.decompress((OUT/"baseline_sql.py.gz").read_bytes()).decode()
(OUT/"change_from_prior.patch").write_text("".join(difflib.unified_diff(old.splitlines(keepends=True),(ROOT/changed[0]).read_text().splitlines(keepends=True),fromfile="before/"+changed[0],tofile="after/"+changed[0])))
p=OUT/"installed_wheel.json"
if p.exists():
    (OUT/"installed_wheel.json.gz").write_bytes(gzip.compress(p.read_bytes(),mtime=0));p.unlink()
native_before=read_result("native_before_restart.json");checkpoint=read_result("native_refresh_checkpoint.json")
assert len(native_before["records"])==8
for r in native_before["records"]:
    d=r["raw"]["structuredContent"]
    if r["quoted"]:assert d["success"] and d["data"]==[{"n":7}]
    else:assert not d["success"] and d["error_code"]=="read_only_required"
assert [r["args"] for r in checkpoint["records"]]==[r["args"] for r in native_before["records"][:2]]
assert checkpoint["records"][0]["raw"]["structuredContent"]["error_code"]=="read_only_required"
automation={"version":"3.8.1","source_sha256":source,"test_source_sha256":{p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted((ROOT/"tests").rglob("*.py"))},
    "changed_production_files":changed,"new_regressions":43,"focused":{"passed":43,"warnings":2,"seconds":5.77},
    "full_suite":{"passed":1560,"skipped":4,"warnings":75,"seconds":float(m[4]),"mysql_optin":False},
    "pyright":{"errors":0,"warnings":0},"prompt_contract":"passed","baseline_client_calls":76,"after_client_calls":76,"installed_cli_stdio_calls":76,"current_source_real_mysql_checks":12,
    "classification_matrix":{"cases":47,"native_read_cases":38,"acceptance_changes":0,"archived_classifier_stages":3,"dependency_version":matrix["sqlparse_version"]},
    "functional_support":"OPEN: tested unquoted keyword-like CTE names still rejected; shared analysis/AST support deferred, no acceptance expansion",
    "diagnostic_change":"Unknown WITH uses sql_parse_failed and same-connection read recovery, known writes retain read_only_required and approval guidance",
    "resident_diagnostics":"Pending maintainer refresh for this new diagnostic code/text; current bare probe still has preceding hint",
    "prechange_native_source_agreement":{"cases":8,"scope":"Observed error/data agreement for reviewer cases, not loaded-code attestation","maintainer_clarified_previous_restart_closed":True},
    "configured_database_writes":False,"production_config_changes":False,"new_model_usage_or_cost_claim":False,"prior_artifact_counts_verified":previous}
if (OUT/"native_after_restart.json").exists():
    native=read_result("native_after_restart.json")
    assert native["checks"]["failed"]==0
    assert [r["args"] for r in native["records"][:8]]==[r["args"] for r in native_before["records"]]
    for r in native["records"][:8]:
        d=r["raw"]["structuredContent"]
        if r["quoted"]:assert d["data"]==[{"n":7}]
        else:assert d["error_code"]=="sql_parse_failed" and "mutation" not in d.get("hint","").lower()
    automation["resident_diagnostics"]="Same-input diagnostic/recovery checks passed after maintainer refresh; functional bare-name limit remains open"
    automation["resident_host_checks"]=native["checks"]
if (OUT/"impact_matrix.json.gz").exists():
    impact=read_result("impact_matrix.json.gz")
    assert impact["source_sha256"]==source
    assert (impact["candidates"],impact["native_valid"],impact["classification_acceptance_changes"])==(314,304,0)
    assert all(r["classification"]["allowed"]==r["baseline_classification"]["allowed"] for r in impact["records"])
    controls=[r for r in impact["records"] if r["group"]=="authorization_control"]
    assert len(controls)==4 and all(r["native_valid"] and not r["policy"]["allowlist"]["allowed"] for r in controls)
    business=[r for r in impact["records"] if r["group"]=="business" and not r["quoted"] and not r["columns"]]
    assert {r["name"] for r in business if not r["policy"]["all"]["allowed"]}=={"summary","data","result","rollup"}
    skills=read_result("impact_skills.json.gz")
    assert skills["source_sha256"]==source and skills["total_calls"]==56
    error_count=0
    for profile in skills["profiles"]:
        calls=profile["calls"]
        assert len(calls)==14 and profile["loaded"]==["business-quoted","column-list-bare","column-list-quoted"]
        assert {s["name"] for s in calls[5]["structuredContent"]["skills"]}=={"business-quoted","column-list-bare"}
        blocked=next(s for s in calls[4]["structuredContent"]["skills"] if s["name"]=="column-list-quoted")
        assert not blocked["executable"] and blocked["missing_tables"]==["monthly_sales"]
        assert calls[0]["structuredContent"]["error_code"]=="sql_parse_failed"
        for i in (1,2,11,12):assert calls[i]["structuredContent"]["data"]==[{"n":7}]
        assert calls[6]["isError"] and calls[10]["isError"]
        error_count+=sum(c["isError"] for c in calls)
        if profile["read_scope"]=="all":
            assert calls[3]["structuredContent"]["data"]==[{"n":7}] and calls[13]["isError"]
        else:
            assert calls[3]["structuredContent"]["error_code"]==calls[13]["structuredContent"]["error_code"]=="relation_scope_unresolved"
    assert error_count==10
    spot=read_result("native_impact_spot_checks.json")
    assert spot["confirmed_checks"]["failed"]==0 and spot["confirmed_checks"]["total"]==9
    assert spot["initial_expectations"]["matched"]==8 and len(spot["initial_expectations"]["unexpected"])==1
    for p in Path("/tmp").glob("v381-cte-impact-*.log"):
        (OUT/(p.name+".gz")).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
    automation["followup_impact"]={"candidates":314,"native_valid_reads":304,"valid_functional_cases":300,
        "policy_decisions":628,"classification_acceptance_changes":0,"unauthorized_controls_denied":4,
        "private_client_observations":56,"observed_tool_errors_retained":10,"native_impact_observations":9,
        "initial_native_expectation_mismatches_retained":1,"production_or_test_changes":False,
        "recommendation":"Near-term bounded shared CTE structure/scope/dependency repair; no production implementation or workload-frequency/cost claim"}
(OUT/"automation.json").write_text(json.dumps(automation,ensure_ascii=False,indent=2)+"\n")
links=0
for line in subprocess.check_output(["git","status","--porcelain"],cwd=ROOT,text=True).splitlines():
    p=ROOT/line[3:]
    if not p.is_file() or p.suffix!=".md":continue
    for target in re.findall(r"\]\(([^)\n]+)\)",p.read_text()):
        target=target.strip().strip("<>")
        if "://" in target or target.startswith(("#","mailto:","data:")):continue
        filename=target.split("#",1)[0]
        if filename:
            resolved=(p.parent/unquote(filename)).resolve()
            assert resolved==OUT/"manifest.json" or resolved.exists(),(p,filename)
            links+=1
for name in ("DESIGN_RISK_REGISTER.md","DESIGN_RISK_REGISTER_ZH.md"):
    lines=(ROOT/"docs/security"/name).read_text().splitlines()
    ids=[match[1] for line in lines if (match:=re.match(r"^\| DRR-2026-(\d{3}) \|",line))]
    assert sorted(ids)==[f"{i:03}" for i in range(1,99)]
    i=next(i for i,line in enumerate(lines) if line.startswith("| DRR-2026-098 |"))
    assert lines[i-1].startswith("| DRR-2026-097 |")
draft=(ROOT/"local_archive/v381_review/commit-message-complete-v381.txt").read_text()
assert len(draft)<850 and sum(line.startswith("- ") for line in draft.splitlines())==7 and "through 098" in draft
subprocess.run(["git","diff","--check"],cwd=ROOT,check=True)
assert not subprocess.check_output(["git","diff","--","pyproject.toml","uv.lock"],cwd=ROOT)
(OUT/"document_checks.json").write_text(json.dumps({"local_file_links":links,"bilingual_drr_ids":98,"latest_drr_contiguous":True,"commit_draft_bullets":7,"commit_draft_characters":len(draft),"diff_check":"passed","scope":"Changed Markdown local targets and latest DRR; not all remote URLs/anchors"},indent=2)+"\n")
manifest={"version":"3.8.1","source_reference":"automation.json#source_sha256","recording_profile":"Source/test hashes, compressed application results and classifier/native-private-read comparisons; available Host content/structuredContent/isError, not complete protocol frames",
    "omitted":["Full JSON-RPC frames/notifications","No new model token/cost/latency claims","No executed configured writes or claim of restored unquoted-CTE grammar support"],
    "cleanup":"Private SQLite/CLI/install fixtures auto-cleaned; configured resident/database/TOML untouched","prior_evidence":"Prior manifests byte-verified; previous source/native/model acceptance not relabeled","artifacts":[]}
for p in sorted(OUT.iterdir()):
    if not p.is_file() or p.name=="manifest.json":continue
    b=p.read_bytes();row={"path":p.name,"bytes":len(b),"sha256":sha(b)}
    if p.suffix==".gz":
        raw=gzip.decompress(b);row.update(uncompressed_bytes=len(raw),uncompressed_sha256=sha(raw))
    manifest["artifacts"].append(row)
(OUT/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"full_passed":1560,"new_regressions":43,"source_files":len(source),"test_files":len(automation["test_source_sha256"]),"changed":changed,"client_calls_per_stage":76,"installed_calls":76,"mysql_checks":12,"matrix_cases":47,"acceptance_changes":0,"local_links":links,"drr_ids":98,"draft_characters":len(draft),"artifacts":len(manifest["artifacts"]),"functional_support":automation["functional_support"],"resident_diagnostics":automation["resident_diagnostics"]}))
