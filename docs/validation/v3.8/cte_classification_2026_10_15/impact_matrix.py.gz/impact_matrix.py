"""Bounded functional impact audit; private SQLite truth, no production edits."""
import gzip
import hashlib
import importlib.metadata
import json
import sqlite3
from collections import Counter, defaultdict
from dataclasses import asdict
from pathlib import Path
from types import ModuleType
import sqlparse
from sql_safety_executor.core.sql import classify_sql_statement
from sql_safety_executor.core.policy import _extract_relation_references, _validate_sql_query_policy
from sql_safety_executor.database.models import ConnectionPolicy

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "docs/validation/v3.8/cte_classification_2026_10_15"
baseline = json.loads((OUT / "baseline_source.json").read_text())
old_source = gzip.decompress((OUT / "baseline_sql.py.gz").read_bytes())
assert hashlib.sha256(old_source).hexdigest() == baseline["src/sql_safety_executor/core/sql.py"]
old_module = ModuleType("sql_safety_executor.core._impact_baseline_sql")
old_module.__package__ = "sql_safety_executor.core"
exec(compile(old_source, "hash_verified_baseline_sql.py", "exec"), old_module.__dict__)
names = {
    "business": "sales monthly_sales order_totals recent_orders totals summary ranked_orders report data base filtered aggregated sales_by_month daily_revenue eligible_orders cte src result results report_data revenue payments customers orders_summary rollup metrics stats monthly ranked dates".split(),
    "contextual": "window offset lock user range rows groups exclude recursive materialized notnull nulls first last filter partition over following preceding returning values replace with like regexp conflict action abort temp current current_date key index".split(),
    "unicode": ["unıon", "offſet", "wındow", "lımıt", "current_uſer", "locK", "订单汇总", "ventes_été", "café", "Δsales"],
}
cases = []
for group, group_names in names.items():
    for name in group_names:
        for quoted in (False, True):
            target = '"' + name + '"' if quoted else name
            for columns in (False, True):
                sql = f"WITH {target}{'(n)' if columns else ''} AS (SELECT n FROM orders) SELECT n FROM {target}"
                cases.append(dict(group=group, name=name, quoted=quoted, columns=columns, sql=sql))

shapes = {
    "two_ctes": "WITH base AS (SELECT n FROM orders), totals AS (SELECT n FROM base) SELECT n FROM totals",
    "two_ctes_columns": "WITH base(n) AS (SELECT n FROM orders), totals(n) AS (SELECT n FROM base) SELECT n FROM totals",
    "two_ctes_quoted_columns": 'WITH "base"(n) AS (SELECT n FROM orders), "totals"(n) AS (SELECT n FROM "base") SELECT n FROM "totals"',
    "nested_cte": "WITH base AS (WITH inner_cte AS (SELECT n FROM orders) SELECT n FROM inner_cte) SELECT n FROM base",
    "scalar_cte": "SELECT (WITH base AS (SELECT n FROM orders) SELECT n FROM base) AS n",
    "commented_cte": "/* report */ WITH /* declaration */ base AS /* body */ (SELECT n FROM orders) SELECT n FROM base",
    "recursive_prefix_no_recursion": "WITH RECURSIVE base(n) AS (SELECT n FROM orders) SELECT n FROM base",
    "recursive_bounded": "WITH RECURSIVE cnt(n) AS (SELECT 1 UNION ALL SELECT n+1 FROM cnt WHERE n<3) SELECT SUM(n) AS n FROM cnt",
    "recursive_quoted_columns": 'WITH RECURSIVE "cnt"(n) AS (SELECT 1 UNION ALL SELECT n+1 FROM "cnt" WHERE n<3) SELECT SUM(n) AS n FROM "cnt"',
    "materialized": "WITH base AS MATERIALIZED (SELECT n FROM orders) SELECT n FROM base",
    "not_materialized": "WITH base AS NOT MATERIALIZED (SELECT n FROM orders) SELECT n FROM base",
    "materialized_columns": "WITH base(n) AS MATERIALIZED (SELECT n FROM orders) SELECT n FROM base",
    "not_materialized_columns": "WITH base(n) AS NOT MATERIALIZED (SELECT n FROM orders) SELECT n FROM base",
    "values_body": "WITH base(n) AS (VALUES (7)) SELECT n FROM base",
    "quoted_values_columns": 'WITH "base"(n) AS (VALUES (7)) SELECT n FROM "base"',
    "explain_cte": "EXPLAIN QUERY PLAN WITH base AS (SELECT n FROM orders) SELECT n FROM base",
    "reserved_column_not_call": 'WITH base AS (SELECT n AS "SLEEP" FROM orders) SELECT "SLEEP" AS n FROM base',
    "normal_window_function": "WITH ranked AS (SELECT n, ROW_NUMBER() OVER (ORDER BY n) AS rn FROM orders) SELECT n FROM ranked WHERE rn=1",
}
for name, sql in shapes.items():
    cases.append(dict(group="shape", name=name, sql=sql))

controls = {
    "direct_unauthorized": "WITH base AS (SELECT n FROM private_orders) SELECT n FROM base",
    "quoted_columns_unauthorized": 'WITH "base"(n) AS (SELECT n FROM private_orders) SELECT n FROM "base"',
    "nested_unauthorized": "WITH base AS (WITH inner_cte AS (SELECT n FROM private_orders) SELECT n FROM inner_cte) SELECT n FROM base",
    "forward_qualified_physical": "WITH base AS (SELECT n FROM main.private_orders), private_orders AS (SELECT n FROM orders) SELECT n FROM base",
}
for name, sql in controls.items():
    cases.append(dict(group="authorization_control", name=name, sql=sql))

policies = {
    "all": ConnectionPolicy(read_mode="all", allowed_tables=frozenset({"*"}), allow_union=True),
    "allowlist": ConnectionPolicy(allowed_tables=frozenset({"orders"}), allow_union=True),
}
records = []
with sqlite3.connect(":memory:") as db:
    db.executescript("CREATE TABLE orders(n); INSERT INTO orders VALUES(7); CREATE TABLE private_orders(n); INSERT INTO private_orders VALUES(99);")
    for case in cases:
        row = dict(case)
        try:
            row["native_rows"] = [list(r) for r in db.execute(case["sql"]).fetchall()]
            row["native_valid"] = True
        except sqlite3.Error as exc:
            row.update(native_valid=False, native_error=str(exc))
        row["get_type"] = sqlparse.parse(case["sql"])[0].get_type()
        row["classification"] = asdict(classify_sql_statement(case["sql"]))
        row["baseline_classification"] = asdict(old_module.classify_sql_statement(case["sql"]))
        assert row["classification"]["allowed"] == row["baseline_classification"]["allowed"]
        row["policy"] = {name: asdict(_validate_sql_query_policy(None, case["sql"], p)) for name, p in policies.items()}
        try:
            row["strict_relations"] = [asdict(r) for r in _extract_relation_references(case["sql"], strict=True)]
        except ValueError as exc:
            row["strict_relation_error"] = str(exc)
        if case["group"] == "authorization_control":
            assert row["native_valid"] and row["native_rows"] == [[99]]
            assert not row["policy"]["allowlist"]["allowed"], row
        records.append(row)
    assert db.execute("SELECT n FROM orders").fetchall() == [(7,)]

summary = {}
for group in (*names, "shape", "authorization_control"):
    subset = [r for r in records if r["group"] == group]
    valid = [r for r in subset if r["native_valid"]]
    summary[group] = dict(candidates=len(subset), native_valid=len(valid), native_invalid=len(subset)-len(valid),
        allowed_all=sum(r["policy"]["all"]["allowed"] for r in valid), allowed_allowlist=sum(r["policy"]["allowlist"]["allowed"] for r in valid),
        refusal_codes_all=dict(Counter(r["policy"]["all"]["error_code"] for r in valid if not r["policy"]["all"]["allowed"])),
        refusal_codes_allowlist=dict(Counter(r["policy"]["allowlist"]["error_code"] for r in valid if not r["policy"]["allowlist"]["allowed"])))

source = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in (".py", ".md")}
data = dict(source_sha256=source, sqlparse_version=importlib.metadata.version("sqlparse"), sqlite_version=sqlite3.sqlite_version,
    scope="Selected name/CTE shapes under current source; independent native private SQLite reads and full shared-policy checks. UNION enabled for bounded recursive controls. Not a workload frequency estimate or complete dialect/Host/Skill test.",
    candidates=len(records), native_valid=sum(r["native_valid"] for r in records), policy_decisions=len(records)*2,
    summary=summary, records=records, baseline_classifier_sha256=baseline["src/sql_safety_executor/core/sql.py"], classification_acceptance_changes=0,
    configured_database_writes=False, production_changes=False)
(OUT/"impact_matrix.json.gz").write_bytes(gzip.compress((json.dumps(data,ensure_ascii=False,indent=2)+"\n").encode(),mtime=0))
print(json.dumps({k:data[k] for k in ("candidates", "native_valid", "policy_decisions", "summary")},ensure_ascii=False))
for group in ("business", "contextual", "unicode"):
    print(json.dumps({"group":group, "bare_no_columns_refusals":[{"name":r["name"],"all":r["policy"]["all"]["error_code"],"allowlist":r["policy"]["allowlist"]["error_code"]} for r in records if r["group"]==group and r["native_valid"] and not r["quoted"] and not r["columns"] and not r["policy"]["allowlist"]["allowed"]]},ensure_ascii=False))
print(json.dumps({"shape_results":[{"name":r["name"], "native_valid":r["native_valid"], "all":r["policy"]["all"]["error_code"],"allowlist":r["policy"]["allowlist"]["error_code"]} for r in records if r["group"]=="shape"]},ensure_ascii=False))
