"""Native read truth and hash-verified archived classifiers, not historical Host."""
import gzip,hashlib,importlib.metadata,json,sqlite3,sqlparse
from pathlib import Path
from types import ModuleType
from sql_safety_executor.core.sql import classify_sql_statement
from sql_safety_executor.core.policy import _validate_sql_query_policy
from sql_safety_executor.database.models import ConnectionPolicy
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/cte_classification_2026_10_15"
stages={}
for label,folder in [("after_095","lexical_identity_2026_10_15"),("after_096","cte_header_2026_10_15"),("before_current","cte_classification_2026_10_15")]:
    directory=ROOT/"docs/validation/v3.8"/folder
    hashes=json.loads((directory/"baseline_source.json").read_text())
    raw=gzip.decompress((directory/"baseline_sql.py.gz").read_bytes())
    assert hashlib.sha256(raw).hexdigest()==hashes["src/sql_safety_executor/core/sql.py"]
    module=ModuleType("sql_safety_executor.core._classification_"+label);module.__package__="sql_safety_executor.core"
    exec(compile(raw,f"archived_{label}_sql.py","exec"),module.__dict__)
    stages[label]={"classifier":module.classify_sql_statement,"source_ref":f"../{folder}/baseline_source.json"}
baseline=json.loads((OUT/"baseline_source.json").read_text())
raw=(ROOT/"src/sql_safety_executor/core/policy.py").read_bytes()
assert hashlib.sha256(raw).hexdigest()==baseline["src/sql_safety_executor/core/policy.py"]
old_policy=ModuleType("sql_safety_executor.core._policy_with_old_classifier");old_policy.__package__="sql_safety_executor.core"
exec(compile(raw,"unchanged_policy.py","exec"),old_policy.__dict__)
old_policy.classify_sql_statement=stages["before_current"]["classifier"]
cases=[]
for name in ["unıon","offſet","wındow","window","offset","lock","user"]:
    for quote in ["{}",'"{}"',"\x60{}\x60","[{}]"]:
        target=quote.format(name);cases.append(("cte_name",f"WITH {target} AS (SELECT 7 AS n)\nSELECT n FROM {target};",True))
for sql in ["SELECT 7 AS n","WITH business AS (SELECT 7 AS n) SELECT n FROM business","WITH user(n) AS (SELECT 7) SELECT n FROM user",'WITH "SLEEP"(n) AS (SELECT 7) SELECT n FROM "SLEEP"']:
    cases.append(("normal_read",sql,True))
for sql in ["WITH","WITH x AS","WITH x(n) AS MATERIALIZED (SELECT 7) SELECT n FROM x","WITH x(n) AS NOT MATERIALIZED (SELECT 7) SELECT n FROM x","WITH window AS (SELECT 7 AS n) UPDATE orders SET n=99","WITH unıon AS (SELECT 7 AS n) DELETE FROM orders"]:
    cases.append(("unknown_with",sql,"MATERIALIZED" in sql))
for sql in ["UPDATE orders SET n=99","INSERT INTO orders VALUES(99)","DELETE FROM orders","DROP TABLE orders","WITH c AS (SELECT 7 AS n) UPDATE orders SET n=99"]:
    cases.append(("known_write",sql,False))
for call in ["SLEEP(0)","USER()","LOAD_FILE(NULL)","GET_LOCK('fixture',0)"]:
    cases.append(("reserved_body",f'WITH "x"(n) AS (SELECT {call}) SELECT n FROM "x"',True))
records=[];p=ConnectionPolicy(read_mode="all",allowed_tables=frozenset({"*"}))
with sqlite3.connect(":memory:") as db:
    db.executescript("CREATE TABLE orders(n);INSERT INTO orders VALUES(7);")
    for name in ["SLEEP","USER","LOAD_FILE","GET_LOCK"]:db.create_function(name,-1,lambda *args:7)
    for kind,sql,native_read in cases:
        truth=[list(r) for r in db.execute(sql).fetchall()] if native_read else None
        if native_read:assert truth==[[7]]
        row={"kind":kind,"sql":sql,"native_read_rows":truth,"get_type":sqlparse.parse(sql)[0].get_type(),"archived_classifiers":{}}
        for label,stage in stages.items():
            d=stage["classifier"](sql);row["archived_classifiers"][label]={"allowed":d.allowed,"code":d.error_code}
        current=classify_sql_statement(sql);before=old_policy._validate_sql_query_policy(None,sql,p);after=_validate_sql_query_policy(None,sql,p)
        row.update(current_shape={"allowed":current.allowed,"code":current.error_code,"hint":current.hint},before_policy={"allowed":before.allowed,"code":before.error_code},after_policy={"allowed":after.allowed,"code":after.error_code})
        assert current.allowed==row["archived_classifiers"]["before_current"]["allowed"]
        assert before.allowed==after.allowed
        records.append(row)
    assert db.execute("SELECT n FROM orders").fetchall()==[(7,)]
source={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in (".py",".md")}
data={"source_sha256":source,"sqlparse_version":importlib.metadata.version("sqlparse"),"cases":len(records),"acceptance_changes":0,"native_read_cases":sum(r["native_read_rows"] is not None for r in records),"stage_refs":{name:s["source_ref"] for name,s in stages.items()},"records":records,"scope":"Archived SQL classifier reconstruction under current dependencies, plus direct native private SQLite reads; known write fixtures are never executed; not historical Host traces","configured_database_writes":False}
(OUT/"classification_matrix.json.gz").write_bytes(gzip.compress((json.dumps(data,ensure_ascii=False,indent=2)+"\n").encode(),mtime=0))
print(json.dumps({k:data[k] for k in ("cases","native_read_cases","acceptance_changes","sqlparse_version")}))
