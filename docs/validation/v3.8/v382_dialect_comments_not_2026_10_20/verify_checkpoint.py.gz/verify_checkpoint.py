"""Verify this source/package checkpoint, matrix verdicts and previous seals."""
import ast
from email.parser import BytesParser
import gzip
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
E = BATCH / 'evidence'
OUT = E / 'verification.json'
assert not OUT.exists()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

before = json.loads((E / 'before.json').read_text())
resources = {str(p.relative_to(ROOT / 'src')): digest(p) for p in sorted((ROOT / 'src').rglob('*'))
             if p.is_file() and p.suffix in {'.py', '.md'}}
assert resources == json.loads((E / 'after_resources.json').read_text())
changed = [name for name in sorted(resources.keys() | before['resources'].keys())
           if resources.get(name) != before['resources'].get(name)]
assert changed == ['sql_safety_executor/core/analysis.py', 'sql_safety_executor/core/managed_sql.py',
                   'sql_safety_executor/core/policy.py', 'sql_safety_executor/core/sql.py']
for name in ('pyproject.toml', 'uv.lock', 'skills/sample-update-order-status/mutation.py', 'skills/sample-reset-order-to-pending/mutation.py'):
    assert digest(ROOT / name) == before['files'][name]
package_resources = {name.removeprefix('sql_safety_executor/'): value for name, value in resources.items()}
installed = json.loads((E / 'installed_resources.json').read_text())
assert package_resources == installed['installed']['resources']
for name in ('source_stdio.json.gz', 'installed_stdio.json.gz'):
    result = json.loads(gzip.decompress((E / name).read_bytes()))
    assert result['passed'] and len(result['records']) == 64 and len(result['inventories']) == 4
    assert result['resource_sha256'] == package_resources and result['redacted_preview_handles'] == 12
assert '2920 passed, 4 skipped' in (E / 'full_pytest_first.log').read_text()
assert '2 passed' in (E / 'query_readiness.log').read_text()
assert '312 passed' in (E / 'targeted_verified.log').read_text()
assert '0 errors, 0 warnings' in (E / 'typecheck.log').read_text()
for name in ('prompt_contract.log', 'installed_prompt.log'):
    assert 'Installed prompt resources and routing guidance valid.' in (E / name).read_text()
baseline = json.loads(gzip.decompress((E / 'before_matrix.json.gz').read_bytes()))
after = json.loads(gzip.decompress((E / 'after_matrix.json.gz').read_bytes()))
assert baseline['cases'] == after['cases'] and baseline['sqlite_truth'] == after['sqlite_truth']
assert baseline['runtime_resources'] == {name.removeprefix('sql_safety_executor/'): value for name, value in before['resources'].items()}
assert after['runtime_resources'] == package_resources
assert len(after['records']) == 1513
changes = {'read_shape_recoveries': 0, 'managed_recoveries': 0}
for old, new in zip(baseline['records'], after['records'], strict=True):
    assert old['id'] == new['id'] and old['context'] == new['context']
    assert old['managed']['sqlparse'] == new['managed']['sqlparse']
    for key, previous, current in [
        ('read_shape_recoveries', old['read']['allowed'], new['read']['allowed']),
        ('managed_recoveries', old['managed']['sqlglot']['allowed'], new['managed']['sqlglot']['allowed']),
    ]:
        assert not previous or current, (new['id'], new['context'])
        changes[key] += int(not previous and current)
assert changes == {'read_shape_recoveries': 370, 'managed_recoveries': 341}
mysql = json.loads(gzip.decompress((E / 'mysql_truth.json.gz').read_bytes()))
assert len(mysql['sessions']) == 16 and len(mysql['scalar_truth']) == 272 and len(mysql['nonexecuting_plans']) == 128
assert mysql['database_unchanged'] and not mysql['configured_business_or_global_writes']
cost = json.loads(gzip.decompress((E / 'paired_cost.json.gz').read_bytes()))
assert cost['all_checks_passed'] and cost['measured_calls'] == 960 and cost['warmup_calls'] == 192
for run in cost['runs']:
    assert run['resource_sha256']['A'] == baseline['runtime_resources']
    assert run['resource_sha256']['B'] == package_resources
verified = 0
for record in before['previous_seals']:
    manifest = ROOT / record['manifest']
    assert digest(manifest) == record['sha256']
    files = json.loads(manifest.read_text())['files']
    entries = files.items() if isinstance(files, dict) else ((value['path'], value) for value in files)
    for name, entry in entries:
        path = manifest.parent / name
        assert digest(path) == entry['sha256'] and path.stat().st_size == entry['bytes']
        verified += 1
assert verified == 600 and len(before['previous_seals']) == 25
wheel = Path(installed['wheel'])
assert digest(wheel) == installed['wheel_sha256']
with zipfile.ZipFile(wheel) as archive:
    metadata = BytesParser().parsebytes(archive.read('llm_sql_safety_executor_mcp-3.8.2.dist-info/METADATA'))
    assert metadata.get_payload(decode=True).decode().strip() == (ROOT / 'README.md').read_text().strip()
source = ROOT / 'src/sql_safety_executor/core/analysis.py'
overrides = sorted(node.name for node in ast.walk(ast.parse(source.read_text()))
                   if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith('_parse_'))
with tarfile.open(E / 'before_runtime.tar.gz') as archive:
    old_source = archive.extractfile('sql_safety_executor/core/analysis.py').read().decode()
old_overrides = sorted(node.name for node in ast.walk(ast.parse(old_source))
                       if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith('_parse_'))
assert overrides == old_overrides
with tarfile.open(E / 'after_runtime.tar.gz', 'w:gz') as archive:
    for name in resources:
        archive.add(ROOT / 'src' / name, arcname=name)
(E / 'dist').mkdir(exist_ok=True)
shutil.copy2(wheel, E / 'dist' / wheel.name)
summary = {'status': 'source_package_passed_resident_pending', 'version': '3.8.2',
           'runtime_resources': package_resources, 'changed_runtime_resources': changed,
           'full_regression_passed': 2920, 'full_regression_skipped': 4, 'subsequent_query_skill_tests_passed': 2,
           'source_stdio_calls': 64, 'installed_stdio_calls': 64, 'matrix_groups': 1513, **changes,
           'no_allow_to_deny_in_frozen_matrix': True, 'sqlparse_verdicts_unchanged': True,
           'mysql_physical_sessions': 16, 'mysql_scalar_truth': 272, 'mysql_nonexecuting_plans': 128,
           'mysql_business_or_global_writes': False, 'runtime_parse_method_names_unchanged': overrides,
           'private_unary_dispatch_dependency_added': True, 'dependencies_unchanged': True,
           'dependency_versions': {name: importlib.metadata.version(name) for name in ('sqlglot', 'sqlparse', 'fastmcp', 'mcp', 'sqlalchemy')},
           'wheel_sha256': installed['wheel_sha256'], 'previous_manifests_verified': 25, 'previous_files_verified': 600,
           'startup': json.loads((E / 'startup_cost.json').read_text()),
           'paired_cost': [{key: value for key, value in run.items() if key != 'resource_sha256'} for run in cost['runs']],
           'limits': 'No new native/complete-model acceptance or model usage claim. read in the synthetic matrix is shape/function policy, not full grants. Original SQL is executed; AST generation is diagnostic. New runtime requires owner restart.',
           'all_source_package_checks_passed': True}
OUT.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key not in {'runtime_resources', 'startup', 'paired_cost'}}, ensure_ascii=False, indent=2))
