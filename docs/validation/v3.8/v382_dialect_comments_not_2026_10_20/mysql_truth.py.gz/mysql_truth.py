"""Actual MySQL session modes, scalar semantics and non-executing DML plans."""
from dataclasses import replace
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path

from sql_safety_executor import load_config
from sql_safety_executor.core.analysis import analyze_sql
from sql_safety_executor.core.managed_sql import check_managed_sql
from sql_safety_executor.database.mysql import MySQLAdapter

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parents[1] / 'evidence/mysql_truth.json.gz'
assert not OUT.exists()
config = load_config(ROOT / 'config/server.toml').connections['orders_demo_mysql']
names = ('ANSI_QUOTES', 'NO_BACKSLASH_ESCAPES', 'PIPES_AS_CONCAT', 'HIGH_NOT_PRECEDENCE')
expressions = [
    ('NOT 1 BETWEEN -5 AND 5', 'NOT (1 BETWEEN -5 AND 5)', '(NOT 1) BETWEEN -5 AND 5'),
    ('!1 BETWEEN -5 AND 5', '(NOT 1) BETWEEN -5 AND 5', '(NOT 1) BETWEEN -5 AND 5'),
    ('NOT 1 + 1', 'NOT (1+1)', '(NOT 1)+1'), ('!1 + 1', '(NOT 1)+1', '(NOT 1)+1'),
    ('NOT 0 = 2', 'NOT (0=2)', '(NOT 0)=2'), ('!0 = 2', '(NOT 0)=2', '(NOT 0)=2'),
    ('NOT 1 * 0', 'NOT (1*0)', '(NOT 1)*0'), ('!1 * 0', '(NOT 1)*0', '(NOT 1)*0'),
    ('NOT 0 ^ 2', 'NOT (0^2)', '(NOT 0)^2'),
    ('NOT 0 <=> 2', 'NOT (0<=>2)', '(NOT 0)<=>2'),
    ('NOT NOT 1 BETWEEN -5 AND 5', 'NOT (NOT (1 BETWEEN -5 AND 5))', '(NOT (NOT 1)) BETWEEN -5 AND 5'),
    ('1 NOT IN (2,3)', '1 NOT IN (2,3)', '1 NOT IN (2,3)'),
    ('1 NOT BETWEEN 2 AND 3', '1 NOT BETWEEN 2 AND 3', '1 NOT BETWEEN 2 AND 3'),
    ('1 IS NOT NULL', '1 IS NOT NULL', '1 IS NOT NULL'),
    ('NOT EXISTS(SELECT 1)', 'NOT (EXISTS(SELECT 1))', 'NOT (EXISTS(SELECT 1))'),
    ("'x' NOT LIKE 'y'", "'x' NOT LIKE 'y'", "'x' NOT LIKE 'y'"),
    ('NOT NULL', 'NOT NULL', 'NOT NULL'),
]
hints = ['NO_ICP(orders)', 'QB_NAME(qb) NO_ICP(orders@qb)',
         'NO_RANGE_OPTIMIZATION(orders PRIMARY)', 'JOIN_FIXED_ORDER()',
         'BKA(orders) NO_BKA(orders)', 'SEMIJOIN(FIRSTMATCH, LOOSESCAN)']
sessions, truth, plans = [], [], []
before_digest = None
for bits in product((False, True), repeat=4):
    modes = ('STRICT_TRANS_TABLES', 'NO_ENGINE_SUBSTITUTION', *(name for name, on in zip(names, bits) if on))
    adapter = MySQLAdapter(replace(config, mysql_sql_mode=modes))
    try:
        assert adapter.connect()
        context = adapter.resolve_analysis_context()
        with adapter._engine.connect() as db:
            observed = frozenset(db.exec_driver_sql('SELECT @@SESSION.sql_mode').scalar_one().split(','))
            assert observed == context.sql_modes == frozenset(modes)
            sessions.append({'modes': sorted(observed), 'actual_physical_session_verified': True})
            rows = [tuple(row) for row in db.exec_driver_sql('SELECT * FROM orders ORDER BY id').fetchall()]
            digest = hashlib.sha256(json.dumps(rows, ensure_ascii=False, default=str).encode()).hexdigest()
            if before_digest is None:
                before_digest = digest
            assert digest == before_digest
            for expression, low_reference, high_reference in expressions:
                reference = high_reference if bits[-1] else low_reference
                statement = f'SELECT ({expression}) AS actual, ({reference}) AS expected'
                result = db.exec_driver_sql(statement).one()
                assert result.actual == result.expected, (expression, modes, result)
                assert analyze_sql('SELECT ' + expression, context).complete
                truth.append({'modes': sorted(observed), 'expression': expression, 'reference': reference,
                              'actual': result.actual, 'expected': result.expected, 'passed': True})
            statements = ["UPDATE orders SET status='confirmed' WHERE id=1",
                          "UPDATE orders SET status='confirmed' WHERE NOT id BETWEEN -5 AND 5",
                          *[f"UPDATE /*+ {hint} */ orders SET status='confirmed' WHERE id=1" for hint in hints]]
            for statement in statements:
                decision = check_managed_sql(statement, context)
                assert decision.allowed, (statement, decision)
                # All DML is prefixed here; no DML execution or global SET.
                db.exec_driver_sql('EXPLAIN ' + statement).fetchall()
                warnings = [tuple(row) for row in db.exec_driver_sql('SHOW WARNINGS').fetchall()]
                plans.append({'modes': sorted(observed), 'sql': statement, 'explain_compiles': True,
                              'warnings': warnings, 'hint_application_claimed': False})
            after = [tuple(row) for row in db.exec_driver_sql('SELECT * FROM orders ORDER BY id').fetchall()]
            assert after == rows
    finally:
        adapter.close()
result = {'scope': __doc__, 'sessions': sessions, 'scalar_truth': truth, 'nonexecuting_plans': plans,
          'order_rows_sha256_before_and_after': before_digest, 'database_unchanged': True,
          'configured_business_or_global_writes': False,
          'limits': 'Separate test adapters explicitly initialize only their private physical-session modes. Original expressions are checked against hand-parenthesized references, not generated AST SQL. Plan compilation and warnings do not prove a hint is used or a future DML satisfies constraints. No new aliases or private config edits.'}
OUT.write_bytes(gzip.compress(json.dumps(result, ensure_ascii=False, default=str, indent=2).encode(), mtime=0))
print(json.dumps({'physical_sessions': len(sessions), 'scalar_truth': len(truth), 'nonexecuting_plans': len(plans), 'business_writes': False}))
