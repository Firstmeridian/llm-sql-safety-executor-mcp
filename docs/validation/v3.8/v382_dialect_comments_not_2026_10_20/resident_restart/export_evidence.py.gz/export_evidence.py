"""Publish and seal this resident supplement without rewriting parent seals."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[5]
LOCAL = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / 'docs/validation/v3.8/v382_dialect_comments_not_2026_10_20/resident_restart'
assert not (LOCAL / 'manifest.json').exists() and not (PUBLIC / 'manifest.json').exists()
summary = json.loads((LOCAL / 'evidence/summary.json').read_text())
plan = json.loads((LOCAL / 'evidence/native_plan.json').read_text())
assert summary['all_checks_passed'] and summary['passed'] == summary['total'] == 30
verified = 0
for item in plan['previous_seals']:
    manifest = ROOT / item['manifest']
    assert hashlib.sha256(manifest.read_bytes()).hexdigest() == item['sha256']
    files = json.loads(manifest.read_text())['files']
    entries = files.items() if isinstance(files, dict) else ((value['path'], value) for value in files)
    for name, entry in entries:
        data = (manifest.parent / name).read_bytes()
        assert hashlib.sha256(data).hexdigest() == entry['sha256'] and len(data) == entry['bytes']
        verified += 1
assert verified == 681 and len(plan['previous_seals']) == 27
for name in ('native_application.json', 'native_catalog.json', 'native_plan.json', 'truth_preflight_failure.txt'):
    destination = PUBLIC / (name + '.gz')
    assert not destination.exists()
    destination.write_bytes(gzip.compress((LOCAL / 'evidence' / name).read_bytes(), mtime=0))
(PUBLIC / 'summary.json').write_bytes((LOCAL / 'evidence/summary.json').read_bytes())
for source in sorted((LOCAL / 'scripts').glob('*.py')):
    (PUBLIC / (source.name + '.gz')).write_bytes(gzip.compress(source.read_bytes(), mtime=0))

changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=ROOT, text=True).splitlines()
changed += [str(path.relative_to(ROOT)) for path in LOCAL.rglob('*.md')]
changed += ['local_archive/v382_review/README.md', 'local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md']
count = 0
for name in sorted(set(changed)):
    file = ROOT / name
    if file.suffix != '.md' or not file.is_file():
        continue
    for raw in re.findall(r'(?<!!)\[[^\]]*\]\(([^\n)]*)\)', file.read_text()):
        target = raw.strip().split(' "', 1)[0].strip('<>')
        if not target or re.match(r'[a-zA-Z][a-zA-Z0-9+.-]*:', target):
            continue
        path = unquote(target.split('#', 1)[0])
        if not path:
            continue
        count += 1
        assert (file.parent / path).exists(), (name, target)
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
doc_check = {'local_links_verified': count, 'diff_check_passed': True,
             'runtime_or_private_config_change_this_supplement': False,
             'previous_manifests_verified': 27, 'previous_file_records_verified': 681}
for destination in (LOCAL / 'evidence/doc_verification.json', PUBLIC / 'doc_verification.json'):
    destination.write_text(json.dumps(doc_check, indent=2) + '\n')
for folder in (LOCAL, PUBLIC):
    files = {}
    for file in sorted(folder.rglob('*')):
        if not file.is_file() or '__pycache__' in file.parts or file.name == 'manifest.json':
            continue
        data = file.read_bytes()
        files[str(file.relative_to(folder))] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
    (folder / 'manifest.json').write_text(json.dumps({
        'date': '2026-10-20', 'checkpoint': 'scoped_resident_acceptance_passed',
        'scope': 'DRR-121/122/123: 30/30 current-Host checks after owner restart. No confirmed write/new model trial/all-mode native claim. Parent source/package pending and all earlier seals remain historical.',
        'files': files,
    }, ensure_ascii=False, indent=2) + '\n')
    for name, entry in files.items():
        data = (folder / name).read_bytes()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
    print(str(folder.relative_to(ROOT)), len(files), 'files sealed')
print('Valid local links:', count)
