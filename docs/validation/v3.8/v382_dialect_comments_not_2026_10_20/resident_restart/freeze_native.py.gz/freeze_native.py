"""Freeze current-Host checks, independent truth and prior immutable evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3

from sql_safety_executor import load_config
from sql_safety_executor.database.mysql import MySQLAdapter

ROOT = Path(__file__).resolve().parents[5]
LOCAL = Path(__file__).resolve().parents[1]
BATCH = LOCAL.parent
OUT = LOCAL / 'evidence/native_plan.json'
OUT.parent.mkdir(exist_ok=True)
assert not OUT.exists()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
config = load_config(ROOT / 'config/server.toml')
assert config.skills.mutation.managed_plan_parser == 'sqlglot'
resources = {str(p.relative_to(ROOT / 'src/sql_safety_executor')): digest(p)
             for p in (ROOT / 'src/sql_safety_executor').rglob('*')
             if p.is_file() and p.suffix in {'.py', '.md'}}
assert resources == json.loads((BATCH / 'evidence/verification.json').read_text())['runtime_resources']
before = json.loads((BATCH / 'evidence/before.json').read_text())
manifests = [ROOT / item['manifest'] for item in before['previous_seals']]
manifests += [BATCH / 'manifest.json', ROOT / 'docs/validation/v3.8/v382_dialect_comments_not_2026_10_20/manifest.json']
seals = []
for manifest in manifests:
    files = json.loads(manifest.read_text())['files']
    entries = files.items() if isinstance(files, dict) else ((item['path'], item) for item in files)
    for name, entry in entries:
        path = manifest.parent / name
        assert digest(path) == entry['sha256'] and path.stat().st_size == entry['bytes']
    seals.append({'manifest': str(manifest.relative_to(ROOT)), 'sha256': digest(manifest), 'file_count': len(files)})
assert len(seals) == 27 and sum(item['file_count'] for item in seals) == 681
rich, mysql = 'rich_mutation_sqlite', 'orders_demo_mysql'
update, reset = 'sample-update-order-status', 'sample-reset-order-to-pending'
path = Path(config.connections[rich].sqlite_database_path)
sqlite_state = {'file_sha256': digest(path)}
with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as db:
    db.row_factory = sqlite3.Row
    sqlite_state['snapshot'] = [dict(row) for row in db.execute('SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')]
    assert sqlite_state['snapshot'][0] == {'id': 1, 'status': 'confirmed'}
    rows = [tuple(row) for row in db.execute('SELECT * FROM main.orders ORDER BY id')]
    sqlite_state['row_count'] = len(rows)
    sqlite_state['all_order_rows_sha256'] = hashlib.sha256(json.dumps(rows, ensure_ascii=False, default=str).encode()).hexdigest()
assert digest(path) == sqlite_state['file_sha256']
adapter = MySQLAdapter(config.connections[mysql])
try:
    assert adapter.connect()
    context = adapter.resolve_analysis_context()
    with adapter._engine.connect() as db:
        rows = [tuple(row) for row in db.exec_driver_sql('SELECT * FROM orders ORDER BY id').fetchall()]
        mysql_state = {'sql_modes_on_separate_truth_adapter': sorted(context.sql_modes),
                       'row_count': len(rows), 'all_order_rows_sha256': hashlib.sha256(json.dumps(rows, ensure_ascii=False, default=str).encode()).hexdigest()}
        not_sql = 'SELECT NOT 1 BETWEEN -5 AND 5 AS n_not, !1 BETWEEN -5 AND 5 AS n_bang'
        not_truth = [dict(row._mapping) for row in db.exec_driver_sql(not_sql).fetchall()]
finally:
    adapter.close()
checks = [{'id': 'routing_catalog', 'tool': 'list_connections', 'arguments': {},
           'expected': {'connection_ids': sorted(config.connections)}}]


def add(label, tool, alias, expected, **arguments):
    checks.append({'id': label, 'tool': tool, 'arguments': {'connection_id': alias, **arguments}, 'expected': expected})


add('sqlite_canary', 'query', rich, {'data': [{'n': 7}]}, sql='SELECT 7 AS n')
add('snapshot_before', 'query', rich, {'data': sqlite_state['snapshot']}, sql='SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')
for label, comment in [('sqlite_hint_comment', "/*+ SET_VAR(sql_mode='x') SLEEP(0) */"),
                       ('sqlite_executable_shape', '/*! SLEEP(0) */ /*M! SLEEP(0) */'),
                       ('sqlite_dash_comment', '--suffix\n')]:
    add(label, 'query', rich, {'data': [{'n': 7}]}, sql=f'SELECT {comment} 7 AS n')
literal = "SELECT '/*+ SET_VAR(sql_mode=''x'') SLEEP(0) */' AS n"
add('sqlite_comment_literal', 'query', rich, {'data': [{'n': "/*+ SET_VAR(sql_mode='x') SLEEP(0) */"}]}, sql=literal)
add('mysql_canary', 'query', mysql, {'data': [{'n': 7}]}, sql='SELECT 7 AS n')
for label, hint in [('mysql_plan_hint', 'NO_ICP(orders)'), ('mysql_queryblock_hint', 'QB_NAME(qb) NO_ICP(orders@qb)')]:
    add(label, 'query', mysql, {'data': [{'n': mysql_state['row_count']}]}, sql=f'SELECT /*+ {hint} */ COUNT(*) AS n FROM orders')
add('mysql_not_bang', 'query', mysql, {'data': not_truth}, sql=not_sql)
add('mysql_comment_literal', 'query', mysql, {'data': [{'n': "/*+ SET_VAR(sql_mode='x') SLEEP(0) */"}]}, sql=literal)
for label, sql, code in [
    ('mysql_set_var_refused', "SELECT /*+ SET_VAR(sql_mode='ANSI_QUOTES') */ 7 AS n", 'unsafe_comment'),
    ('mysql_timeout_override_refused', 'SELECT /*+ MAX_EXECUTION_TIME(0) */ 7 AS n', 'unsafe_comment'),
    ('mysql_unknown_hint_refused', 'SELECT /*+ UNKNOWN_HINT(orders) */ 7 AS n', 'unsafe_comment'),
    ('mysql_executable_comment_refused', 'SELECT /*! +1 */ 7 AS n', 'unsafe_comment'),
    ('mysql_second_hint_refused', "SELECT /*+ NO_ICP(orders) */ /*+ SET_VAR(sql_mode='ANSI_QUOTES') */ 7 AS n", 'unsafe_comment'),
    ('mysql_real_function_refused', 'SELECT /*+ NO_ICP(orders) */ SLEEP(0) AS n', 'expensive_function_denied'),
    ('mysql_real_relation_refused', 'SELECT /*+ NO_ICP(orders) */ * FROM secret LIMIT 1', 'table_access_denied'),
]:
    add(label, 'query', mysql, {'error_code': code}, sql=sql)
add('sqlite_real_function_refused', 'query', rich, {'error_code': 'expensive_function_denied'}, sql='SELECT SLEEP(0) AS n')
add('sqlite_real_relation_refused', 'query', rich, {'error_code': 'table_access_denied'}, sql='SELECT /*+ NO_ICP(orders) */ * FROM secret LIMIT 1')
add('sqlite_raw_write_refused', 'query', rich, {'error_code': 'read_only_required'}, sql="UPDATE main.orders SET status='pending' WHERE id=1")
for phase in ('first', 'repeat'):
    add('available_' + phase, 'list_skills', rich, {'skill_names': sorted((update, reset))}, search=update, detail_level='full')
    add('execution_detail_' + phase, 'get_skill_detail', rich, {'executable': True}, skill_name=update, detail_level='execution')
    add('update_preview_' + phase, 'execute_mutation_skill', rich, {'preview': True, 'new_status': 'shipped'}, skill_name=update, params={'order_id': 1, 'new_status': 'shipped'}, confirm=False)
add('reset_preview', 'execute_mutation_skill', rich, {'preview': True, 'new_status': 'pending'}, skill_name=reset, params={'order_id': 1, 'expected_status': 'confirmed'}, confirm=False)
add('snapshot_after', 'query', rich, {'data': sqlite_state['snapshot']}, sql='SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')
assert len(checks) == 30 and all(not item['arguments'].get('confirm', False) for item in checks)
plan = {'owner_restart_confirmed': True, 'frozen_utc': datetime.now(timezone.utc).isoformat(),
        'databases': {rich: sqlite_state, mysql: mysql_state}, 'checks': checks, 'previous_seals': seals,
        'preview_ttl_seconds': config.skills.mutation.preview.ttl_seconds,
        'scope': 'Current Host only. No configured writes, confirmations, private config or mode edits. Native NOT/bang exercises the existing session configuration, not all sixteen modes; separate truth adapter modes do not attest the Host physical session. Query Skill comments and commented managed writes retain source/installed fixture coverage. No complete-model/provider-usage or native performance A/B claim. Native behavior cannot attest in-memory hashes/cache hits. Preview handles abandoned subject to natural TTL, not actively revoked or observed expiring.'}
OUT.write_text(json.dumps(plan, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'frozen_native_calls': len(checks), 'old_manifests': len(seals), 'old_files': 681, 'matching_runtime_resources': len(resources)}))
