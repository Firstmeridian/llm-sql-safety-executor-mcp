"""Validate exact native outcomes, independent data and prior sealed checkpoints."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3

from sql_safety_executor import load_config
from sql_safety_executor.database.mysql import MySQLAdapter

ROOT = Path(__file__).resolve().parents[5]
LOCAL = Path(__file__).resolve().parents[1]
BATCH = LOCAL.parent
OUT = LOCAL / 'evidence/summary.json'
assert not OUT.exists()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
config = load_config(ROOT / 'config/server.toml')
plan = json.loads((LOCAL / 'evidence/native_plan.json').read_text())
raw = json.loads((LOCAL / 'evidence/native_application.json').read_text())
catalog = json.loads((LOCAL / 'evidence/native_catalog.json').read_text())
metadata = []
for tool in catalog['tools']:
    description = catalog['shared_description_prefix'] + tool['description_suffix']
    assert len(description.encode('utf-16-le')) // 2 == tool['description_characters']
    metadata.append({'name': tool['name'], 'description_sha256': hashlib.sha256(description.encode()).hexdigest()})
checks = []
for index, (record, frozen) in enumerate(zip(raw['records'], plan['checks'], strict=True)):
    assert record['index'] == index and record['id'] == frozen['id']
    assert record['tool'] == frozen['tool'] and record['arguments'] == frozen['arguments']
    response, expected = record['result'], frozen['expected']
    assert not response.get('isError', False), frozen['id']
    payload = response['structuredContent']
    texts = [part['text'] for part in response['content'] if part['type'] == 'text']
    assert len(texts) == 1 and json.loads(texts[0]) == payload, frozen['id']
    if 'connection_id' in frozen['arguments']:
        assert payload['connection_id'] == frozen['arguments']['connection_id']
    if 'error_code' in expected:
        assert payload['success'] is False and payload['error_code'] == expected['error_code'], frozen['id']
    else:
        assert payload['success'] is True, frozen['id']
    if 'connection_ids' in expected:
        assert sorted(item['connection_id'] for item in payload['connections']) == expected['connection_ids']
        assert payload['connection_count'] == len(expected['connection_ids'])
    if 'data' in expected:
        assert payload['data'] == expected['data'] and payload['truncated'] is False, frozen['id']
        assert payload['query'] == frozen['arguments']['sql'], frozen['id']
    if 'skill_names' in expected:
        assert sorted(item['name'] for item in payload['skills']) == expected['skill_names']
        assert all(item['executable'] and item['schema_ready'] and not item['missing_tables'] and not item['unverified_tables'] for item in payload['skills'])
    if 'executable' in expected:
        assert payload['skill']['executable'] is expected['executable']
    if expected.get('preview'):
        assert frozen['arguments']['confirm'] is False and payload['mode'] == 'preview'
        assert payload['execution_outcome'] == 'not_executed'
        assert payload['preview_token'] == '[REDACTED_PREVIEW_HANDLE]'
        assert isinstance(payload['preview_token_expires_at'], str)
        assert payload['preview']['preview_sql'] == 'UPDATE orders SET status = :new_status WHERE id = :order_id AND status = :expected_status'
        assert payload['preview']['bound_params'] == {'order_id': 1, 'expected_status': 'confirmed', 'new_status': expected['new_status']}
        assert payload['preview']['affected_rows_estimate'] == 1
    checks.append({'index': index, 'id': frozen['id'], 'passed': True})
assert len(checks) == 30 and raw['redacted_preview_handle_count'] == 3
assert all(not item['arguments'].get('confirm', False) for item in raw['records'])
rich, mysql = 'rich_mutation_sqlite', 'orders_demo_mysql'
expected = plan['databases'][rich]
path = Path(config.connections[rich].sqlite_database_path)
assert digest(path) == expected['file_sha256']
with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as db:
    db.row_factory = sqlite3.Row
    snapshot = [dict(row) for row in db.execute('SELECT id,status FROM main.orders WHERE id<=12 ORDER BY id')]
    assert snapshot == expected['snapshot']
    rows = [tuple(row) for row in db.execute('SELECT * FROM main.orders ORDER BY id')]
    assert len(rows) == expected['row_count']
    assert hashlib.sha256(json.dumps(rows, ensure_ascii=False, default=str).encode()).hexdigest() == expected['all_order_rows_sha256']
assert digest(path) == expected['file_sha256']
adapter = MySQLAdapter(config.connections[mysql])
try:
    assert adapter.connect()
    context = adapter.resolve_analysis_context()
    assert sorted(context.sql_modes) == plan['databases'][mysql]['sql_modes_on_separate_truth_adapter']
    with adapter._engine.connect() as db:
        rows = [tuple(row) for row in db.exec_driver_sql('SELECT * FROM orders ORDER BY id').fetchall()]
    assert len(rows) == plan['databases'][mysql]['row_count']
    assert hashlib.sha256(json.dumps(rows, ensure_ascii=False, default=str).encode()).hexdigest() == plan['databases'][mysql]['all_order_rows_sha256']
finally:
    adapter.close()
verified = 0
for item in plan['previous_seals']:
    manifest = ROOT / item['manifest']
    assert digest(manifest) == item['sha256']
    files = json.loads(manifest.read_text())['files']
    entries = files.items() if isinstance(files, dict) else ((value['path'], value) for value in files)
    for name, entry in entries:
        path = manifest.parent / name
        assert digest(path) == entry['sha256'] and path.stat().st_size == entry['bytes']
        verified += 1
assert verified == 681 and len(plan['previous_seals']) == 27
resources = {str(p.relative_to(ROOT / 'src/sql_safety_executor')): digest(p)
             for p in (ROOT / 'src/sql_safety_executor').rglob('*')
             if p.is_file() and p.suffix in {'.py', '.md'}}
assert len(resources) == 77
assert resources == json.loads((BATCH / 'evidence/verification.json').read_text())['runtime_resources']
summary = {'owner_restart_confirmed': True, 'verified_utc': datetime.now(timezone.utc).isoformat(),
           'passed': 30, 'total': 30, 'checks': checks, 'routing_catalog_checks': 1,
           'successful_query_reads': 12, 'catalog_detail_checks': 4,
           'successful_previews': 3, 'expected_refusals': 10,
           'independent_truth_unchanged': plan['databases'],
           'source_resources_match_final_wheel': 77, 'source_or_configuration_change_this_supplement': False,
           'old_manifest_count': 27, 'old_sealed_files_verified': 681,
           'tool_description_digests': metadata,
           'preview_ttl_seconds': plan['preview_ttl_seconds'],
           'preview_handling': 'Three confirm=false previews; opaque handles consistently redacted before disk. No confirmations, active revocations or expiry observations. Natural configured TTL applies.',
           'configured_business_writes': False,
           'limits': [plan['scope'], 'Application results and model-visible names/descriptions; not complete protocol frames or original field-omission proof.',
                      'NOT/bang semantics on this existing Host configuration only; sixteen actual-mode truth adapters remain separate source/package evidence.',
                      'One initial sandboxed truth probe failed session_semantics_unavailable; targeted network escalation succeeded. No Full access or config change was needed; underlying connection failure detail was not captured.'],
           'all_checks_passed': True}
OUT.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({name: summary[name] for name in ('passed', 'total', 'successful_query_reads', 'successful_previews', 'expected_refusals', 'old_sealed_files_verified')}))
