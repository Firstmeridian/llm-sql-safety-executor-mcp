"""Alternating paired full six-call lifecycles; SQLite, separate verified sources.

Two persistent child servers per protocol, isolated fixture per server. Calls are
serial; pair order alternates A/B and B/A, bounding slow time drift more tightly
than staged A/B/A. No source instrumentation, DB maintenance or private config.
"""
import asyncio
from contextlib import AsyncExitStack, ExitStack
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import statistics
import sys
import tarfile
import tempfile
import time

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
OUT = BATCH / 'evidence/paired_cost.json.gz'
WARMUPS, REPEATS = 8, 40
UPDATE, RESET = 'sample-update-order-status', 'sample-reset-order-to-pending'


async def run():
    from sql_safety_executor.mcp.bootstrap import prepare_framework
    prepare_framework()
    from fastmcp import Client
    from fastmcp.client.transports import StdioTransport
    assert not OUT.exists()
    snapshots = {name: json.loads((BATCH / ('evidence/' + file)).read_text())
                 for name, file in [('A', 'before.json'), ('B', 'after_resources.json')]}
    snapshots['A'] = snapshots['A']['resources']
    records, runs, pairs = [], [], []
    with tempfile.TemporaryDirectory(prefix='managed-paired-before-') as folder:
        baseline = Path(folder)
        with tarfile.open(BATCH / 'evidence/before_runtime.tar.gz') as archive:
            archive.extractall(baseline, filter='data')
        for mode in ('auto', 'legacy'):
            with ExitStack() as temporary:
                async with AsyncExitStack() as sessions:
                    clients, databases, resources = {}, {}, {}
                    for variant, source in [('A', baseline), ('B', ROOT / 'src')]:
                        root = Path(temporary.enter_context(tempfile.TemporaryDirectory(prefix='managed-paired-fixture-')))
                        database = root / 'fixture.sqlite'
                        databases[variant] = database
                        with sqlite3.connect(database) as db:
                            db.executescript("CREATE TABLE orders(id INTEGER PRIMARY KEY,status TEXT);INSERT INTO orders VALUES(1,'pending');")
                        for name in (UPDATE, RESET):
                            shutil.copytree(ROOT / 'skills' / name, root / 'skills' / name)
                        (root / 'server.toml').write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="fixture"\n')
                        (root / 'connections.toml').write_text('schema_version=1\n[connections.fixture]\ntype="sqlite"\nsqlite.path="fixture.sqlite"\nread.mode="all"\nmutation.enabled=true\nmutation.skills=["' + UPDATE + '","' + RESET + '"]\n')
                        (root / 'skills.toml').write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=true\n[skills.mutation]\nenabled=true\nallowed_connections=["fixture"]\n[skills.mutation.mrtr]\nenabled=false\n[skills.audit]\npath="audit.jsonl"\n')
                        launcher = root / 'launcher.py'
                        launcher.write_text('import sys,json,hashlib\nfrom pathlib import Path\nsys.path.insert(0,' + repr(str(source)) + ')\n'
                            'import sql_safety_executor\np=Path(sql_safety_executor.__file__).resolve().parent\n'
                            'assert p==Path(' + repr(str(source)) + ')/"sql_safety_executor"\n'
                            'r={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob("*") if f.is_file() and f.suffix in {".py",".md"}}\n'
                            'Path("runtime.json").write_text(json.dumps(r))\n'
                            'from sql_safety_executor import create_server,load_config\ncreate_server(load_config("server.toml")).run(transport="stdio",show_banner=False)\n')
                        env = os.environ.copy()
                        env['PYTHONPATH'] = str(source)
                        transport = StdioTransport(command=sys.executable, args=[str(launcher)], cwd=str(root), env=env)
                        clients[variant] = await sessions.enter_async_context(Client(transport, mode=mode))
                        resources[variant] = json.loads((root / 'runtime.json').read_text())
                        assert resources[variant] == {name.removeprefix('sql_safety_executor/'): digest for name, digest in snapshots[variant].items()}
                    async def cycle(variant, iteration):
                        client = clients[variant]
                        total = 0.0
                        async def call(step, tool, args):
                            nonlocal total
                            start = time.perf_counter_ns()
                            response = await client.call_tool(tool, {'connection_id': 'fixture', **args}, raise_on_error=False)
                            elapsed = (time.perf_counter_ns() - start) / 1e6
                            total += elapsed
                            payload = response.structured_content
                            assert not response.is_error and payload['success'], (tool, payload)
                            if tool == 'execute_mutation_skill':
                                assert payload['execution_outcome'] == ('committed' if args.get('confirm') else 'not_executed')
                            records.append({'mode': mode, 'variant': variant, 'iteration': iteration, 'warmup': iteration < 0,
                                            'step': step, 'tool': tool, 'elapsed_ms': elapsed,
                                            'success': True, 'outcome': payload.get('execution_outcome')})
                            return payload
                        listing = await call('catalog', 'list_skills', {'search': UPDATE, 'detail_level': 'full'})
                        assert sorted(item['name'] for item in listing['skills']) == sorted((UPDATE, RESET))
                        detail = await call('detail', 'get_skill_detail', {'skill_name': UPDATE, 'detail_level': 'execution'})
                        assert detail['skill']['executable']
                        for name, params, step in [(UPDATE, {'order_id': 1, 'new_status': 'confirmed'}, 'update'),
                                                   (RESET, {'order_id': 1, 'expected_status': 'confirmed'}, 'reset')]:
                            preview = await call(step + '_preview', 'execute_mutation_skill', {'skill_name': name, 'params': params})
                            assert preview['preview']['bound_params'] == {'order_id': 1, 'new_status': 'confirmed' if step == 'update' else 'pending', 'expected_status': 'pending' if step == 'update' else 'confirmed'}
                            result = await call(step + '_confirm', 'execute_mutation_skill', {'skill_name': name, 'params': params, 'confirm': True, 'preview_token': preview['preview_token']})
                            assert result['result']['rowcount'] == 1
                        with sqlite3.connect(databases[variant]) as db:
                            assert db.execute('SELECT id,status FROM orders').fetchall() == [(1, 'pending')]
                        return total
                    for iteration in range(-WARMUPS, REPEATS):
                        order = ('A', 'B') if iteration % 2 == 0 else ('B', 'A')
                        elapsed = {}
                        for variant in order:
                            elapsed[variant] = await cycle(variant, iteration)
                        pairs.append({'mode': mode, 'iteration': iteration, 'warmup': iteration < 0,
                                      'order': list(order), 'A_ms': elapsed['A'], 'B_ms': elapsed['B'],
                                      'delta_ms': elapsed['B'] - elapsed['A'], 'delta_percent': (elapsed['B'] / elapsed['A'] - 1) * 100})
                    measured = [pair for pair in pairs if pair['mode'] == mode and not pair['warmup']]
                    run = {'mode': mode, 'protocol': clients['A'].protocol_version, 'pairs': len(measured),
                           'baseline_median_ms': statistics.median(pair['A_ms'] for pair in measured),
                           'optimized_median_ms': statistics.median(pair['B_ms'] for pair in measured),
                           'paired_delta_median_ms': statistics.median(pair['delta_ms'] for pair in measured),
                           'paired_delta_median_percent': statistics.median(pair['delta_percent'] for pair in measured),
                           'improved_pairs': sum(pair['delta_ms'] < 0 for pair in measured), 'resource_sha256': resources}
                    runs.append(run)
                    print(json.dumps({key: value for key, value in run.items() if key != 'resource_sha256'}), flush=True)
    result = {'scope': __doc__, 'runs': runs, 'records': records, 'pairs': pairs,
              'measured_calls': sum(not row['warmup'] for row in records), 'warmup_calls': sum(row['warmup'] for row in records),
              'all_checks_passed': True, 'complete_restored_cycles': len(pairs) * 2,
              'limits': 'Fixed small SQLite/default parser/readiness enabled. Alternating order, not randomized; two idle persistent servers instead of one. Cycle is sum of six tool roundtrips, excluding startup, local orchestration/assertions and independent DB truth. No model/MySQL-write/cold-start/general latency claim.'}
    OUT.write_bytes(gzip.compress(json.dumps(result, ensure_ascii=False, indent=2).encode(), mtime=0))
    print(json.dumps({'measured_calls': result['measured_calls'], 'warmup_calls': result['warmup_calls'], 'passed': True}), flush=True)


if __name__ == '__main__':
    asyncio.run(run())
