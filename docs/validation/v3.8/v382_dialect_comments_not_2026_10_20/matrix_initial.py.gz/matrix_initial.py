"""Frozen dialect comment/NOT matrix; classification is not DB validity proof."""
import argparse
from dataclasses import asdict
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path
import sqlite3

from sql_safety_executor.core.analysis import analyze_sql, _tokens
from sql_safety_executor.core.managed_sql import check_managed_sql
from sql_safety_executor.core.policy import _analysis_decision
from sql_safety_executor.database.models import ConnectionPolicy
from sql_safety_executor.database.semantics import DialectContext

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
assert not args.output.exists()
comments = [
    '', '/* ordinary */', '/*+ NO_ICP(orders) */', '/*+ BKA(orders) NO_BKA(other) */',
    '/*+ QB_NAME(qb) JOIN_FIXED_ORDER() */', '/*+ SET_VAR(sql_mode=\'ANSI_QUOTES\') */',
    '/*+ SET_VAR(foreign_key_checks=OFF) */', '/*+ RESOURCE_GROUP(batch) */',
    '/*+ MAX_EXECUTION_TIME(0) */', '/*! ,n=99 */', '/*M! ,n=99 */',
    '/*+ NO_ICP(orders) */ /*+ SET_VAR(sql_mode=\'ANSI_QUOTES\') */',
    '/*+ NO_ICP(orders) */ /*+ NO_BKA(other) */', '/*+ UNKNOWN_HINT(orders) */',
    '/*+ NO_ICP(SLEEP(0)) */', '/*+ NO_ICP(orders) --x */', '/*+ bad(( SLEEP(0) */',
    '/*+ NO_ICP(`a.b`) */', '/*+ NO_ICP(` f `) */', '/*+ NO_ICP(`  f  `) */',
    '/*+ NO_ICP(orders@qb) */', '/*+ */', '--suffix\n', '# note\n',
]
expressions = [
    'NOT 1 BETWEEN -5 AND 5', '!1 BETWEEN -5 AND 5', 'NOT 1 + 1', '!1 + 1',
    'NOT 0 = 2', '!0 = 2', 'NOT NOT 1 BETWEEN -5 AND 5', '!!1 BETWEEN -5 AND 5',
    '(NOT 1) BETWEEN -5 AND 5', 'NOT (1 BETWEEN -5 AND 5)',
    '1 NOT IN (2,3)', '1 NOT BETWEEN 2 AND 3', '1 IS NOT NULL', 'NOT EXISTS(SELECT 1)',
    "'x' NOT LIKE 'y'", 'NOT 0 AND 1', 'NOT 0 OR 0', "'NOT /*! /*+ !'", '`NOT`',
]
contexts = [DialectContext('sqlite', default_schema='main')]
names = ('ANSI_QUOTES', 'NO_BACKSLASH_ESCAPES', 'PIPES_AS_CONCAT', 'HIGH_NOT_PRECEDENCE')
contexts += [DialectContext('mysql', frozenset(name for name, on in zip(names, bits) if on), default_schema='business')
             for bits in product((False, True), repeat=4)]
cases = []
for index, comment in enumerate(comments):
    cases += [{'id': f'comment_read_{index}', 'sql': f'SELECT {comment} n FROM orders', 'kind': 'read'},
              {'id': f'comment_write_{index}', 'sql': f'UPDATE {comment} orders SET n=7', 'kind': 'write'}]
for index, expression in enumerate(expressions):
    cases += [{'id': f'not_read_{index}', 'sql': f'SELECT {expression} AS n FROM orders', 'kind': 'read'},
              {'id': f'not_write_{index}', 'sql': f'UPDATE orders SET n=7 WHERE {expression}', 'kind': 'write'}]
cases += [
    {'id': 'hidden_physical', 'sql': 'SELECT /*+ NO_ICP(secret) */ n FROM secret', 'kind': 'read'},
    {'id': 'hint_literal', 'sql': "SELECT '/*+ SET_VAR(sql_mode=\'x\') */' AS n", 'kind': 'read'},
    {'id': 'hint_quoted_name', 'sql': 'SELECT n FROM "/*+ SET_VAR */"', 'kind': 'read'},
]
policy = ConnectionPolicy(allowed_tables=frozenset({'orders'}))
records = []
for context in contexts:
    for case in cases:
        analysis = analyze_sql(case['sql'], context)
        record = {'id': case['id'], 'context': list(context.fingerprint), 'kind': case['kind'],
                  'read': asdict(_analysis_decision(analysis, policy)),
                  'analysis_status': analysis.status, 'relations': [asdict(value) for value in analysis.relations],
                  'functions': sorted(analysis.functions),
                  'managed': {parser: asdict(check_managed_sql(case['sql'], context, parser)) for parser in ('sqlglot', 'sqlparse')}}
        try:
            dialect, tokens = _tokens(case['sql'], context)
            record['ast'] = [tree.sql(dialect='mysql' if context.dialect == 'mysql' else 'sqlite') if tree else None
                             for tree in dialect.parser().parse(tokens, case['sql'])]
        except Exception as error:
            record['ast_error_class'] = type(error).__name__
        records.append(record)
truth = []
with sqlite3.connect(':memory:') as db:
    db.executescript('CREATE TABLE orders(n); INSERT INTO orders VALUES(7);')
    before = '\n'.join(db.iterdump())
    for case in cases:
        try:
            sql = 'EXPLAIN ' + case['sql'] if case['kind'] == 'write' else case['sql']
            rows = db.execute(sql).fetchall()
            truth.append({'id': case['id'], 'accepted': True, 'data': rows if case['kind'] == 'read' else None})
        except sqlite3.Error as error:
            truth.append({'id': case['id'], 'accepted': False, 'error': str(error)})
    assert before == '\n'.join(db.iterdump())
source = Path(__import__('sql_safety_executor').__file__).resolve().parent
resources = {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file() and p.suffix in {'.py', '.md'}}
result = {'scope': __doc__, 'cases': cases, 'records': records, 'sqlite_truth': truth,
          'sqlite_unchanged': True, 'runtime_resources': resources,
          'ast_limit': 'Generated AST SQL is diagnostic only; original SQL is always executed. Generator grouping may not preserve all source modes.'}
args.output.write_bytes(gzip.compress(json.dumps(result, ensure_ascii=False, indent=2).encode(), mtime=0))
print(json.dumps({'cases': len(cases), 'contexts': len(contexts), 'records': len(records), 'resources': len(resources)}))
