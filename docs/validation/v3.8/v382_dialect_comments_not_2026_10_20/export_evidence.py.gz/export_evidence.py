"""Export this source/package checkpoint; preserve earlier and resident history."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
E = BATCH / 'evidence'
PUBLIC = ROOT / 'docs/validation/v3.8/v382_dialect_comments_not_2026_10_20'
assert not (E / 'summary.json').exists()
assert not (PUBLIC / 'summary.json').exists()
assert not (BATCH / 'manifest.json').exists()
assert not (PUBLIC / 'manifest.json').exists()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


verification = json.loads((E / 'verification.json').read_text())
before = json.loads((E / 'before.json').read_text())
assert verification['all_source_package_checks_passed']
current = {str(p.relative_to(ROOT / 'src')).removeprefix('sql_safety_executor/'): digest(p)
           for p in sorted((ROOT / 'src').rglob('*')) if p.is_file() and p.suffix in {'.py', '.md'}}
assert current == verification['runtime_resources']
previous_files = 0
for record in before['previous_seals']:
    manifest = ROOT / record['manifest']
    assert digest(manifest) == record['sha256']
    files = json.loads(manifest.read_text())['files']
    entries = files.items() if isinstance(files, dict) else ((item['path'], item) for item in files)
    for name, entry in entries:
        path = manifest.parent / name
        assert digest(path) == entry['sha256'] and path.stat().st_size == entry['bytes']
        previous_files += 1
assert previous_files == 600 and len(before['previous_seals']) == 25

sources = [
    'before.json', 'after_resources.json', 'verification.json', 'installed_resources.json',
    'before_runtime.tar.gz', 'after_runtime.tar.gz', 'before_matrix.json.gz', 'after_matrix.json.gz',
    'mysql_truth.json.gz', 'source_stdio.json.gz', 'installed_stdio.json.gz',
    'startup_cost.json', 'paired_cost.json.gz', 'full_pytest_first.log', 'query_readiness.log',
    'targeted_first.log', 'targeted_final.log', 'targeted_verified.log',
    'typecheck.log', 'prompt_contract.log', 'installed_prompt.log', 'build_install.log',
    'before_matrix_initial_literal.json.gz', 'before_matrix_initial_literal.log', 'matrix_initial.py.gz',
]
references = {}
for name in sources:
    source = E / name
    filename = name if name.endswith('.gz') else name + '.gz'
    destination = PUBLIC / filename
    assert not destination.exists()
    destination.write_bytes(source.read_bytes() if name.endswith('.gz') else gzip.compress(source.read_bytes(), mtime=0))
    references[name] = {'file': filename, 'bytes': destination.stat().st_size, 'sha256': digest(destination)}
scripts = sorted((BATCH / 'scripts').glob('*.py'))
for source in scripts:
    destination = PUBLIC / (source.name + '.gz')
    assert not destination.exists()
    destination.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
validator = ROOT / 'scripts/validation/comment_modes.py'
(PUBLIC / 'validation_comment_modes.py.gz').write_bytes(gzip.compress(validator.read_bytes(), mtime=0))

# Link validation covers changed and untracked repository docs plus ignored handoff.
tracked = subprocess.check_output(['git', 'diff', '--name-only', '--', '*.md'], cwd=ROOT, text=True).splitlines()
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', '*.md'], cwd=ROOT, text=True).splitlines()
documents = {ROOT / name for name in tracked + untracked}
documents.update([BATCH / 'reports/README_ZH.md', PUBLIC / 'README.md',
                  ROOT / 'local_archive/v382_review/README.md',
                  ROOT / 'local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md'])
checked = 0
for file in sorted(documents):
    if not file.is_file():
        continue
    for target in re.findall(r'\[[^\]]*\]\(([^\s)]+)(?:\s+"[^"]*")?\)', file.read_text()):
        target = unquote(target.strip('<>')).split('#', 1)[0]
        if not target or re.match(r'[a-zA-Z][a-zA-Z0-9+.-]*:', target):
            continue
        path = (file.parent / target).resolve() if not target.startswith('/') else Path(target)
        assert path.exists(), (str(file.relative_to(ROOT)), target)
        checked += 1
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
paired = json.loads(gzip.decompress((E / 'paired_cost.json.gz').read_bytes()))
assert paired['all_checks_passed']
startup = verification['startup']
summary = {
    'date': '2026-10-20', 'version': '3.8.2', 'status': 'source_package_passed_resident_pending',
    'scope': 'DRR-121 SQLite comments; DRR-122 bounded MySQL plan hints; DRR-123 actual-session NOT and bang precedence.',
    'checks': {name: verification[name] for name in (
        'full_regression_passed', 'full_regression_skipped', 'subsequent_query_skill_tests_passed',
        'source_stdio_calls', 'installed_stdio_calls', 'matrix_groups', 'read_shape_recoveries',
        'managed_recoveries', 'no_allow_to_deny_in_frozen_matrix', 'sqlparse_verdicts_unchanged',
        'mysql_physical_sessions', 'mysql_scalar_truth', 'mysql_nonexecuting_plans',
        'dependencies_unchanged', 'wheel_sha256')},
    'startup_warm_gateway_ms': {name: startup[name] for name in (
        'baseline_median_ms', 'optimized_median_ms', 'delta_ms', 'delta_percent')},
    'timed_calls': paired['measured_calls'], 'warmup_calls': paired['warmup_calls'],
    'cost_conclusion': 'Small balanced warm SQLite workload: no clear regression; only 21/40 pairs faster in either protocol. No speedup or model-cost guarantee.',
    'previous_manifests_verified': 25, 'previous_files_verified': previous_files,
    'markdown_local_links_checked': checked, 'evidence': references,
    'collection_layer': 'Application observations and selected test/build diagnostics; not full JSON-RPC frames, notifications, original field omission or model usage. Opaque fixture handles consistently redacted before output.',
    'public_omissions': 'Duplicate large console transcripts and wheel binary remain local; original values/results, frozen runtime archives, recipes, build/resource/wheel digests and corrected-fixture failures are retained. No new native or complete-model acceptance claim.',
    'limits': 'Synthetic read matrix checks shape/functions, not full grants; independent scoped tests cover authorization. Generated AST SQL is diagnostic only; execution retains original SQL. Native evidence must append after owner restart without modifying this checkpoint.',
}
(E / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
(PUBLIC / 'summary.json').write_bytes((E / 'summary.json').read_bytes())
print(json.dumps({'published_results': len(sources), 'published_scripts': len(scripts) + 1,
                  'local_links_checked': checked, 'previous_files_verified': previous_files}))
