"""Validate current links/risk IDs and the unchanged tested source."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/phase123_2026_10_14"
auto=json.loads((OUT/"automation.json").read_text())
for name,expected in auto["source_sha256"].items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
paths=[]
status=subprocess.check_output(["git","status","--porcelain"],cwd=ROOT,text=True)
for line in status.splitlines():
    p=ROOT/line[3:]
    if p.suffix==".md":paths.append(p)
count=0
for p in paths:
    for link in re.findall(r"\]\(([^)\n]+)\)",p.read_text()):
        link=link.strip().strip("<>")
        if "://" in link or link.startswith(("#","mailto:","data:")):continue
        target=link.split("#",1)[0]
        if not target:continue
        assert (p.parent/unquote(target)).exists(),(p,target)
        count+=1
for name in ("DESIGN_RISK_REGISTER.md","DESIGN_RISK_REGISTER_ZH.md"):
    text=(ROOT/"docs/security"/name).read_text()
    ids=re.findall(r"^\| DRR-2026-(\d{3}) \|",text,re.M)
    assert sorted(ids)==[f"{n:03}" for n in range(1,88)],name
    assert "| DRR-2026-085" in text and "| DRR-2026-086" in text and "| DRR-2026-087" in text
assert 'version = "3.8.1"' in (ROOT/"pyproject.toml").read_text()
assert not subprocess.check_output(["git","diff","--","pyproject.toml","uv.lock"],cwd=ROOT,text=True)
subprocess.run(["git","diff","--check"],cwd=ROOT,check=True)
d={"relative_document_links":count,"bilingual_drr_ids":87,"continuous_unique_ids":True,
   "tested_source_hashes_match":True,"runtime_dependencies_unchanged":True,"version":"3.8.1",
   "diff_check":"passed","scope":"File targets; not remote URLs/heading anchors"}
(OUT/"document_checks.json").write_text(json.dumps(d,indent=2)+"\n")
print(json.dumps(d))
