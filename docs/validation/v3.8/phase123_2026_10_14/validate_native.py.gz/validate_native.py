"""Verify the captured primary Host results without making database calls."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "docs/validation/v3.8/phase123_2026_10_14"
path = OUT / "native_after_restart.json"
native = json.loads(path.read_text())
records = {r["name"]: r for r in native["records"]}
assert len(records) == len(native["records"]) == 13
expected_errors = {
    "sqlite_sleep_freshness": "expensive_function_denied",
    "sqlite_quoted_benchmark": "expensive_function_denied",
    "mysql_sleep": "expensive_function_denied",
    "mysql_benchmark": "expensive_function_denied",
    "mysql_lock_acquisition": "lock_function_denied",
    "mysql_lock_release": "lock_function_denied",
    "mysql_all_lock_release": "lock_function_denied",
}
payloads = {}
for name, record in records.items():
    result = record["result"]
    assert result["isError"] is False, name
    payload = result["structuredContent"]
    assert json.loads(result["content"][0]["text"]) == payload, name
    payloads[name] = payload
    if name in expected_errors:
        assert payload["success"] is False, name
        assert payload["error_code"] == expected_errors[name], name
        assert payload["connection_id"] == record["args"]["connection_id"], name
        assert payload["query"] == record["args"]["sql"], name
        assert "same connection" in payload["hint"], name
    else:
        assert payload["success"] is True, name
expected_data = {
    "sqlite_literal_and_ordinary_function": [{"label": "SLEEP(99)", "n": 7}],
    "sqlite_cte_declaration_name": [{"n": 7}],
    "sqlite_cte_ascii_case": [{"n": 5}],
    "mysql_cte_ascii_case": [{"n": 8}],
}
for name, expected in expected_data.items():
    assert payloads[name]["data"] == expected, name
catalog = payloads["sqlite_skill_catalog"]
query_skills = [s for s in catalog["skills"] if s["type"] == "query"]
assert len(query_skills) == 2
for skill in query_skills:
    assert skill["tables"] == ["orders"]
    assert skill["declared_tables"] == []
    assert skill["inferred_tables"] == ["orders"]
sqlite_skill = next(s for s in query_skills if s["name"].endswith("-sqlite"))
assert sqlite_skill["executable"] is True and sqlite_skill["schema_ready"] is True
skill_result = payloads["sqlite_ordinary_query_skill"]
assert skill_result["row_count"] == skill_result["total_rows"] == 5
assert sum(row["order_count"] for row in skill_result["data"]) == 5
native["checks"] = {
    "passed": 13,
    "failed": 0,
    "business_refusals": 7,
    "successful_reads_or_discovery": 6,
    "same_connection_hints": True,
    "text_matches_structured_content": True,
    "notes": "No write tools used. Pre-I/O ordering is established by regression tests; public Host results alone are not adapter traces.",
}
path.write_text(json.dumps(native, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(native["checks"]))
