"""Archive genuine native CLI A/B separately from initial tool-visibility trials."""
import json
from pathlib import Path
import statistics

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/phase123_2026_10_14"
expected=["SELECT SLEEP(0) AS n","SELECT 0 AS n","WITH F AS (SELECT COUNT(*) AS n FROM orders) SELECT n FROM f"]
records=[]
for stage in ("baseline","after"):
    for trial in range(1,4):
        d=json.loads((OUT/f"luna_cli_{stage}_{trial}.json").read_text())
        assert d["return_code"]==0
        calls=[e["item"] for e in d["events"] if e.get("type")=="item.completed" and e.get("item",{}).get("type")=="mcp_tool_call"]
        assert [c["arguments"]["sql"] for c in calls]==expected
        assert all(c["arguments"]["connection_id"]=="analytics_demo_sqlite" for c in calls)
        results=[]
        for c in calls:
            text=next(x["text"] for x in c["result"]["content"] if x["type"]=="text")
            results.append(json.loads(text))
        assert results[0]["error_code"]==("unknown_function" if stage=="baseline" else "expensive_function_denied")
        assert results[1]["data"]==[{"n":0}] and results[2]["data"]==[{"n":5}]
        usage=next(e["usage"] for e in d["events"] if e.get("type")=="turn.completed")
        finals=[e["item"]["text"] for e in d["events"] if e.get("type")=="item.completed" and e.get("item",{}).get("type")=="agent_message"]
        assert finals and "5" in finals[-1] and "0" in finals[-1]
        records.append({"stage":stage,"trial":trial,"native_mcp_calls":len(calls),"passed":True,
            "public_results":results,"usage":usage,"final_answer":finals[-1],
            "source_policy_sha256":d["source_policy_sha256"]})
stats={}
for stage in ("baseline","after"):
    rows=[r for r in records if r["stage"]==stage]
    stats[stage]={"passed":3,"native_calls_each":[r["native_mcp_calls"] for r in rows],
        "mean_total_input":statistics.mean(r["usage"]["input_tokens"] for r in rows),
        "median_total_input":statistics.median(r["usage"]["input_tokens"] for r in rows),
        "mean_cached_input":statistics.mean(r["usage"]["cached_input_tokens"] for r in rows),
        "mean_uncached_input":statistics.mean(r["usage"]["input_tokens"]-r["usage"]["cached_input_tokens"] for r in rows),
        "mean_output":statistics.mean(r["usage"]["output_tokens"] for r in rows)}
changes={k:100*(stats["after"][k]/stats["baseline"][k]-1) for k in [
    "mean_total_input","median_total_input","mean_uncached_input","mean_output"]}
comparison={"model":"gpt-6-luna","reasoning_effort":"medium","prompt":json.loads((OUT/"luna_plan.json").read_text())["prompt"],
    "records":records,"statistics":stats,"percent_change":changes,
    "order":"A1,B1,A2,B2,A3,B3","config":"Task-local required stdio MCP, only query and one existing SQLite alias; no global configuration changes",
    "limits":["Three samples per stage; no overall accuracy/cost guarantee",
        "CLI profile differs from full IDE tool exposure and xhigh peer tasks",
        "Provider usage is actual; full initial system/developer input and outer programmatic-tool orchestration not exposed by CLI events",
        "Cached inputs already included in total; do not add twice",
        "Uncached/output increase despite total-input reduction; no billing saving or no-regression claim"]}
(OUT/"luna_cli_comparison.json").write_text(json.dumps(comparison,ensure_ascii=False,indent=2)+"\n")

peer=json.loads((OUT/"luna_peer_plan.json").read_text())
attempts=[]
for item in peer["trials"]+[{"thread_id":"01a13a0e-42fd-7ad0-8f08-6bb8531a55fe"}]:
    f=next((Path.home()/".codex/sessions/2026/10/14").glob("*"+item["thread_id"]+".jsonl"))
    public=[];usage=[]
    for line in f.read_text().splitlines():
        e=json.loads(line);p=e.get("payload",{})
        if e.get("type")=="response_item":
            t=p.get("type")
            if t in {"custom_tool_call","custom_tool_call_output","function_call","function_call_output"}:
                public.append({k:p[k] for k in ("type","name","call_id","input","arguments","output") if k in p})
            elif t=="message" and (p.get("role")=="user" or p.get("phase")=="final_answer"):
                public.append({k:p[k] for k in ("role","phase","content") if k in p})
        elif e.get("type")=="event_msg" and p.get("type")=="token_count" and p.get("info"):
            usage.append(p["info"])
    attempts.append({**item,"public_trace":public,"usage":usage})
(OUT/"luna_peer_attempts.json").write_text(json.dumps({"attempts":attempts,
    "scope":"Independent xhigh task attempts: two completed the original task, one lacked callable SQL tools; resumed internal fork later made two real queries. Not mixed into controlled CLI metrics."},ensure_ascii=False,indent=2)+"\n")
diagnostic=json.loads((OUT/"subagent_mcp_diagnostic.json").read_text())
diagnostic["later_internal_probe"]={"agent_id":"01a13a0e-42fd-7ad0-8f08-6bb8531a55fe",
    "sql_tools":10,"real_query_success":True,"sleep_error_code":"expensive_function_denied"}
diagnostic["independent_task_result"]="2 passed, 1 initially lacked callable SQL MCP"
diagnostic["configured_required"]="unset";diagnostic["configured_optional_grace"]="unset; documented default 1000ms"
diagnostic["required_override_result"]="Six controlled CLI tasks, all tool-ready and passed; task-local overrides only"
diagnostic["startup_evidence"]="mcp_startup.json; three initialize+tools samples about 3.87–5.69s"
diagnostic["conclusion"]="Initial missing tools are not model incapability. Startup grace/config snapshot is a supported explanation; exact internal race not proven. required=true avoids silent absence in controlled tasks."
(OUT/"subagent_mcp_diagnostic.json").write_text(json.dumps(diagnostic,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"statistics":stats,"percent_change":changes}))
