"""Synchronize current contracts and decisions; no historical JSON edits."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
DOC="docs/validation/V3_8_1_PHASE123_2026_10_14_ZH.md"
for path, note, before in [
("README.md", "**October 14 matrix/function/AST follow-up:** current SQLite/MySQL CTE truth and matched cost baselines are recorded; raw reads and Query Skills reject real GET_LOCK/RELEASE_LOCK/RELEASE_ALL_LOCKS/SLEEP/BENCHMARK calls before I/O. Literal text, ordinary columns and CTE declarations remain supported. Unsafe templates are skipped offline at startup. SQLGlot 30.22.0 was evaluated in isolation; production AST/authorizer adoption is deferred. **1089 passed, 4 skipped**, Pyright/prompt contracts and 12 installed-wheel stdio calls passed. Resident restart pending; model trials lacked SQL MCP. See [decisions and evidence](docs/validation/V3_8_1_PHASE123_2026_10_14_ZH.md).", "**October 14 CTE repair:**"),
("README_ZH.md", "**10 月 14 日矩阵／函数／AST 后续：** 已记录当前 SQLite/MySQL CTE 真值及成本基线；raw query 与 Query Skill 在 I/O 前拒绝真实 GET_LOCK／RELEASE_LOCK／RELEASE_ALL_LOCKS／SLEEP／BENCHMARK 调用，保留字符串、普通列和 CTE 声明；危险模板启动时离线跳过。SQLGlot 30.22.0 已隔离验证，生产 AST／authorizer 接入留待下一轮。**1089 passed、4 skipped**，Pyright／提示契约与 12 次安装包 stdio 调用通过；原生重启待验，模型子代理缺少 SQL MCP。见[决议与证据](docs/validation/V3_8_1_PHASE123_2026_10_14_ZH.md)。", "**10 月 14 日 CTE 修复：**"),
]:
    p=ROOT/path;s=p.read_text()
    if note not in s:
        index=s.index(before);s=s[:index]+note+"\n\n"+s[index:];p.write_text(s)

for path, heading, body in [
("REFACTORING_LOG.md", "## v3.8.1 CTE matrix, read-function limits and SQLGlot experiment (October 14, 2026)",
"""- Maintainer approved phases 2 → 4 → 3; production AST/SQLite authorizer work remains a separate next phase. Version stays 3.8.1; prerelease compatibility scope is unchanged.
- Native SQLite 3.45.1 and Oracle MySQL 8.0.25/setting 1 matrix has 52 cases. SQLite forward/implicit recursion differences are recorded; current conservative production semantics remain. Other settings/MariaDB untested as agreed. Only private SQLite fixtures were written; MySQL reads existing orders/constants/version settings.
- Actual reserved lock/delay calls are refused before capability/readiness/business I/O with lock_function_denied or expensive_function_denied. Data, columns, quoted/Unicode identities and CTE column declarations are preserved; startup quarantines unsafe templates and cached execution independently checks. No function whitelist, bypass switch, new trusted operation or write behavior change.
- SQLGlot 30.22.0 verified wheel is experimental only. Native-informed projection handles scoped names and SQLite IN fields; opaque SQLite EXPLAIN and virtual relations require adapters. No runtime dependency/lock change or SQL rewriting. Five fresh processes measured median extra import about 119.87 ms and peak RSS +10292 KiB; candidate projection is not full authorization.
- 1089 passed, 4 skipped, 14 warnings; Pyright/prompt contract and outside-repository installed wheel on both protocols passed (12 calls). Serial A/B/A policy p95 meets the exploratory gate, fixed metadata is unchanged; noisy Client drift and changed error outcomes do not prove end-to-end speed or billing savings. Three Luna attempts lacked SQL MCP; preserve public failures/usage, not model passes. Resident service still old; acceptance awaits owner restart.
- DRR-2026-085–087 and bilingual docs are synchronized. [Acceptance and evidence](docs/validation/V3_8_1_PHASE123_2026_10_14_ZH.md)."""),
("REFACTORING_LOG_ZH.md", "## v3.8.1 CTE 矩阵、读取函数限制与 SQLGlot 验证（2026-10-14）",
"""- 维护者批准本轮依序完成 ②→④→③；生产 AST／SQLite authorizer 接入另做。版本仍 3.8.1，发布前兼容范围决定沿用。
- 当前 SQLite 3.45.1、Oracle MySQL 8.0.25／设置 1 共 52 个原生／策略案例。SQLite 前向／隐式递归差异已记录，生产保守规则保留；按维护者决定，其他设置／MariaDB 标为未测。仅私有 SQLite 夹具写入；MySQL 读取既有 orders、常量和版本设置。
- 真实保留锁／耗时函数在能力／readiness／业务 I/O 前拒绝，给出 lock_function_denied／expensive_function_denied；字符串、列、引号／Unicode 名称和 CTE 列列表保留。危险模板启动隔离，缓存执行独立检查。无全面函数白名单、绕过开关、新可信操作入口或写入规则变更。
- SQLGlot 30.22.0 校验 wheel 后仅实验使用，按作用域与 SQLite IN 补充投影；SQLite EXPLAIN 不透明节点、虚拟关系仍需适配。无生产依赖／锁文件变更或 SQL 转译。五个新进程额外导入中位数约 119.87 ms、peak RSS +10292 KiB；投影不等同完整授权。
- 1089 passed、4 skipped、14 warnings；Pyright／提示契约和仓库外两协议安装验证通过（12 调用）。串行 A/B/A 策略 p95 满足探索门槛、固定元数据不变；Client 漂移和不同失败结果不能证明端到端提速／计费改善。三个 Luna 尝试缺少 SQL MCP，保存公开失败／usage，不计模型通过。原生服务仍旧，待维护者重启。
- 双语文档与 DRR-2026-085–087 同步，见[验收与证据](docs/validation/V3_8_1_PHASE123_2026_10_14_ZH.md)。"""),
]:
    p=ROOT/path;s=p.read_text()
    if heading not in s:
        i=s.index("\n## ");s=s[:i]+"\n"+heading+"\n\n"+body+"\n"+s[i:];p.write_text(s)

appendices={
"docs/security/V3_8_SECURITY.md": """\n## October 14 matrix and function policy\n\nReal GET_LOCK/RELEASE_LOCK/RELEASE_ALL_LOCKS/SLEEP/BENCHMARK calls are now denied in raw reads and Query Skills before capability/readiness/business I/O. Use fixed lock_function_denied/expensive_function_denied business errors; startup skips unsafe templates, and cached execution independently checks. ASCII name comparison distinguishes Unicode names; literal data, ordinary columns and CTE column declarations remain valid. Quoted/schema calls with these reserved names and EXPLAIN are restricted too. No broad function whitelist or cost guarantee, no new trusted lock operation or mutation approval change.\n\nSQLGlot is experimental, not a runtime dependency; SQLite authorizer remains uninstalled. Native matrix exposes SQLite forward/implicit-recursion semantics still conservatively handled by production. Candidate scope/IN projection does not settle opaque commands, virtual objects, schema resolution or all dialect semantics. Other MySQL configurations/MariaDB and native model cost remain untested. See [decisions, measured costs and acceptance](../validation/V3_8_1_PHASE123_2026_10_14_ZH.md), DRR-2026-085–087.\n""",
"docs/architecture/V3_8_IMPLEMENTATION_ZH.md": """\n## 10 月 14 日矩阵、函数限制与 SQLGlot 验证\n\ncore/policy.py 的 _read_function_decision() 在共享扩展读取检查中识别五种真实调用；_cte_header_token_ids() 区分 CTE 声明列列表。名字仅 ASCII 折叠，引号真实字符保留；返回 PolicyDecision 的 lock_function_denied／expensive_function_denied，在适配器能力与业务 I/O 之前。启动模板验证沿用跳过机制，运行时仍独立检查。普通函数、literal／列／CTE 不扩大限制，metadata／受管写入模型保留。\n\nscripts/review_v381/ 为可复验的矩阵、成本和 SQLGlot 试验，生产包不导入。30.22.0 固定官方 wheel 仅隔离解压；投影明确 physical_tables、functions、ctes、parameters、unsupported，不生成执行 SQL。SQLite IN 的 field、CTE 方言范围需项目适配；SQLite EXPLAIN 可为不透明 Command。AST／authorizer 生产接入未实施；见[本轮验收](../validation/V3_8_1_PHASE123_2026_10_14_ZH.md)。\n""",
"docs/guides/CONFIGURATION_ZH.md": """\n## v3.8.1 读取函数限制\n\nraw query 与 Query Skill 默认拒绝真实 GET_LOCK／RELEASE_LOCK／RELEASE_ALL_LOCKS／SLEEP／BENCHMARK 调用，两种数据库一致，无新增配置开关或全面函数白名单。含此调用的 Query Skill 模板启动时跳过并记录固定原因；字符串、普通列／别名和 CTE 声明不受该名字限制，同名自定义实际调用仍受限。不要把 Query Skill 当作例外，现有写入批准规则不变。SQLGlot 为隔离验证，不需安装运行依赖；AST／SQLite authorizer 接入暂缓。见[范围与验收](../validation/V3_8_1_PHASE123_2026_10_14_ZH.md)。\n""",
"docs/guides/TEST_MCP_CLIENT_GUIDE.md": """\n## October 14 CTE/cost/SQLGlot probes\n\nUse scripts/review_v381/measure_policy.py and measure_client.py with explicit --source/--stage; freeze the before source before editing. --mysql reads the configured test orders and safe version/settings only; lock/delay calls are never run in native truth. Private SQLite covers unusual identifiers and both actual Client protocols. Record exploratory overlapping runs separately; serialize final A/B/A after regression, distinguish policy time, metadata/text/structured sizes and model usage. SQLGlot fetch_sqlglot.py pins 30.22.0, verifies its official wheel, and only extracts to /tmp; verify_sqlglot.py does not authorize or rewrite production SQL.\n\nSubagent tools must be checked before counting model trials. This batch's Luna agents lacked SQL MCP, so retain their failed attempts without claiming token or behavior passes. Full frames are additional protocol evidence, not inferred from application results. See [acceptance](../validation/V3_8_1_PHASE123_2026_10_14_ZH.md).\n""",
"docs/releases/RELEASE_NOTES_v3_8.md": """\n### v3.8.1 — CTE matrix, read-function restrictions and SQLGlot experiment (October 14, 2026)\n\n**Why/decision:** reserve real lock/delay calls in raw reads and Query Skills to avoid session effects and deliberate resource occupation. Preserve data/column/CTE names; startup skips unsafe templates and runtime independently refuses before I/O. Fixed lock_function_denied and expensive_function_denied carry same-connection recovery hints. No new bypass configuration or write approval change.\n\n**Evidence/compromises:** 52 native/policy cases on current SQLite/MySQL, serial A/B/A fixed costs, 1089 passed/4 skipped, clean Pyright/prompt checks and 12 installed-wheel stdio calls. SQLGlot 30.22.0 is an isolated candidate requiring scope/IN/opaque-command adapters; production AST/authorizer work is deferred. Other server variants and native model cost are untested; Luna subagents lacked SQL MCP. Resident refresh is pending. See [decisions and recording scope](../validation/V3_8_1_PHASE123_2026_10_14_ZH.md).\n""",
}
for path,extra in appendices.items():
    p=ROOT/path;s=p.read_text()
    if extra.strip() not in s:p.write_text(s.rstrip()+"\n"+extra)

for path,notice in [
("docs/README.md", "> Latest October 14 matrix/function/SQLGlot work: [acceptance and costs](validation/V3_8_1_PHASE123_2026_10_14_ZH.md); runtime AST/authorizer adoption is deferred.\n\n"),
("docs/README_ZH.md", "> 10 月 14 日矩阵／函数／SQLGlot 后续：[验收与成本](validation/V3_8_1_PHASE123_2026_10_14_ZH.md)；生产 AST／authorizer 接入另做。\n\n")]:
    p=ROOT/path;s=p.read_text()
    if notice not in s:p.write_text(notice+s)

# Explicitly date earlier narrative statements; preceding raw evidence remains intact.
p=ROOT/"docs/security/V3_8_SECURITY.md";s=p.read_text().replace(
    "Lock/delay function restrictions remain recommendations, not implemented policy.",
    "At the earlier October 14 CTE batch, lock/delay restrictions were recommendations; the later implementation below activates them.")
p.write_text(s)
p=ROOT/"docs/validation/V3_8_1_FOLLOWUP_2026_10_13_ZH.md";s=p.read_text().replace(
    "原生 Host 的新源码验收待维护者重启。",
    "本页 CTE 修复的原生核验已完成；随后矩阵／函数／SQLGlot 工作另见[新批次](V3_8_1_PHASE123_2026_10_14_ZH.md)。")
marker="### 锁／耗时函数策略建议\n"
note="\n> 此处保留此前 CTE 批次的建议；后续已批准实施，见[新批次](V3_8_1_PHASE123_2026_10_14_ZH.md)。\n"
if note not in s:s=s.replace(marker,marker+note)
p.write_text(s)

rows_en=[
"| DRR-2026-085 | Implemented; resident acceptance pending | Medium (session effects/resources) | 2026-10-14 | Read calls can acquire/release locks or deliberately wait/compute | SELECT-shaped SQL can mutate session lock state or occupy connections/CPU. | Yes | Five reserved actual calls denied before I/O in raw/Skill reads; ASCII identity, literal/column/CTE preservation; startup quarantine plus independent runtime check. | 47 new regressions, 1089 full passes, clean type/prompt and installed stdio checks; no native lock effects. | Narrow policy, not complete function/cost control; custom calls with these names also restricted. Owner restart pending. |",
"| DRR-2026-086 | Experiment validated; production deferred | Medium | 2026-10-14 | Generic AST/scope is not project authorization | Table-only traversal misses SQLite IN and misclassifies CTE visibility; opaque commands can hide dependencies. | No production replacement | Isolated pinned SQLGlot 30.22.0 projection with dialect rules; mark unsupported virtual/opaque shapes, keep original SQL. | 52 corpus plus 11 extra cases; native-informed assertions; five import/RSS samples. | Define production interface/adapters and run upgrade/semantic regressions before adoption; authorizer separate. |",
"| DRR-2026-087 | Measured; wider matrix/model cost unverified | Low to medium | 2026-10-14 | Incomplete dialect/cost evidence overstates compatibility | Current server differs from SQLite forward/implicit recursion; noisy calls and changed failures confound cost. | Evidence | Record native truth vs conservative policy, explicit missing instances and serial A/B/A; preserve initial failures and absent-MCP Luna attempts. | Current SQLite/MySQL 1, fixed metadata unchanged, policy exploratory p95 gate passed; native model task not executed. | 0/2/MariaDB and genuine model tasks require available environments; no universal latency/billing guarantee. |",
]
rows_zh=[
"| DRR-2026-085 | 已实现；原生验收待重启 | 中（会话副作用／资源） | 2026-10-14 | 读取调用获取／释放锁或故意等待计算 | SELECT 形态可改变会话锁或占用连接／CPU。 | 是 | raw／Skill 真实五种调用在 I/O 前拒绝；ASCII 身份保留 literal／列／CTE，启动隔离加运行时独立检查。 | 新增 47 回归、全量 1089 通过，类型／提示契约及安装 stdio 通过；未执行原生锁副作用。 | 小范围规则，不证明全部函数／成本受控；同名自定义调用也受限，待维护者重启。 |",
"| DRR-2026-086 | 隔离验证通过；生产暂缓 | 中 | 2026-10-14 | 通用 AST／scope 不等于项目授权 | Table 遍历漏 SQLite IN，CTE 可见性不同，不透明命令可隐藏依赖。 | 未替换生产 | 固定 SQLGlot 30.22.0 隔离投影，按方言规则处理，虚拟／不透明形态标为不支持，执行原 SQL。 | 52 语料＋11 定点案例，原生真值支持断言，五次导入／RSS 测量。 | 接入前定义接口／适配并完成语义／升级回归；authorizer 单独做。 |",
"| DRR-2026-087 | 已测；更广矩阵／模型成本未验 | 低至中 | 2026-10-14 | 有限方言／成本证据被外推 | 当前服务与 SQLite 前向／隐式递归不同；耗时波动和不同失败结果混杂成本。 | 证据 | 原生真值与保守策略分记，明确缺少实例；串行 A/B/A，保留初版失败和缺少 MCP 的 Luna 尝试。 | 当前 SQLite／MySQL 1、固定元数据不变、策略探索 p95 门槛通过；原生模型任务未执行。 | 0/2／MariaDB 与真实模型任务需可用环境；不承诺总体延迟／计费改善。 |",
]
for name,rows,notice in [
("DESIGN_RISK_REGISTER.md",rows_en,"> Latest phase123: DRR-2026-085–087 record function limits and experimental/cost boundaries; [acceptance](../validation/V3_8_1_PHASE123_2026_10_14_ZH.md).\n\n"),
("DESIGN_RISK_REGISTER_ZH.md",rows_zh,"> 最新前三阶段：DRR-2026-085–087 记录函数限制、试验与成本边界；见[验收](../validation/V3_8_1_PHASE123_2026_10_14_ZH.md)。\n\n")]:
    p=ROOT/"docs/security"/name;s=p.read_text()
    if "| DRR-2026-085 |" not in s:
        lines=s.splitlines();i=next(i for i,x in enumerate(lines) if x.startswith("| DRR-2026-084 |"))
        lines[i+1:i+1]=rows;s="\n".join(lines)+"\n"
    if notice not in s:s=notice+s
    p.write_text(s)
print("Synchronized bilingual contracts, decisions and DRR-2026-085–087")
