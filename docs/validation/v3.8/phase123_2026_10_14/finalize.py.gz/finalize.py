"""Summarize final evidence without modifying preceding batches."""
from dataclasses import asdict
import gzip
import hashlib
import json
from pathlib import Path
import re
import statistics
import subprocess

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/"docs/validation/v3.8/phase123_2026_10_14"
digest=lambda b:hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((OUT/n).read_text())
a,b,c=[read(stage+"_policy_matrix.json") for stage in ("baseline_quiet","after_quiet","baseline_return_quiet")]
comparison=[]
for before,after,returned in zip(a["timings"],b["timings"],c["timings"]):
    assert before["sql"]==after["sql"]==returned["sql"]
    delta=after["p95_ms"]-before["p95_ms"]
    comparison.append({"sql":before["sql"],"before":{k:v for k,v in before.items() if k!="raw_ms"},
        "after":{k:v for k,v in after.items() if k!="raw_ms"},"returned":{k:v for k,v in returned.items() if k!="raw_ms"},
        "p95_delta_ms":delta,"exploratory_gate":"passed" if delta<=max(.5,before["p95_ms"]*.25) else "exceeded"})
assert all(x["exploratory_gate"]=="passed" for x in comparison)
client=[]
for before,after,returned in zip(*(read(n+"_client.json")["records"] for n in ("baseline_quiet","after_quiet","baseline_return_quiet"))):
    assert before["protocol"]==after["protocol"]==returned["protocol"]
    assert before["fixed_metadata_characters_without_output_schema"]==after["fixed_metadata_characters_without_output_schema"]==returned["fixed_metadata_characters_without_output_schema"]
    client.append({"protocol":before["protocol"],"fixed_metadata_characters":before["fixed_metadata_characters_without_output_schema"],
        "structured_result_character_deltas":[y-x for x,y in zip(before["structured_result_characters"],after["structured_result_characters"])],
        "trace_medians_ms":[r["trace_median_ms"] for r in (before,after,returned)],
        "note":"Last operation becomes unknown-Skill after startup quarantine; latency drift and different failure outcomes prevent equivalent-completion cost claims"})
(OUT/"cost_comparison.json").write_text(json.dumps({"policy":comparison,"client":client,
    "gate_scope":"Exploratory local policy p95 delta <= max(0.5ms,25% of baseline); no machine exclusivity or end-to-end guarantee",
    "model_cost":"Controlled native CLI A/B measured; see luna_cli_comparison.json. Initial missing-tool attempts and peer runs remain separate."},ensure_ascii=False,indent=2)+"\n")
plan=read("luna_plan.json")
agents=[]
for entry in plan["baseline_agents"]:
    files=list((Path.home()/".codex/sessions/2026/10/14").glob("*"+entry["agent_id"]+".jsonl"))
    assert len(files)==1
    public=[];usage=[]
    for line in files[0].read_text().splitlines():
        event=json.loads(line);p=event.get("payload",{})
        if event.get("type")=="response_item":
            kind=p.get("type")
            if kind in {"custom_tool_call","custom_tool_call_output","function_call","function_call_output"}:
                public.append({k:p[k] for k in ("type","name","call_id","input","arguments","output") if k in p})
            elif kind=="message" and p.get("role")=="user":
                public.append({k:p[k] for k in ("type","role","content") if k in p})
            elif kind=="message" and p.get("role")=="assistant" and p.get("phase")=="final_answer":
                public.append({k:p[k] for k in ("type","role","phase","content") if k in p})
        elif event.get("type")=="event_msg" and p.get("type")=="token_count" and p.get("info"):
            usage.append(p["info"])
    agents.append({**entry,"model":"gpt-6-luna","public_trace":public,"usage":usage,
        "outcome":"Not executed: SQL MCP absent in subagent toolset"})
(OUT/"luna_environment_attempts.json").write_text(json.dumps({"agents":agents,
    "limits":"Failed availability attempts only; initial system/developer context not fully reconstructible from public logs; no native model success or token improvement claim"},ensure_ascii=False,indent=2)+"\n")
assert "1089 passed, 4 skipped, 14 warnings" in Path("/tmp/v381-phase123-full.log").read_text()
assert "0 errors, 0 warnings" in Path("/tmp/v381-phase123-pyright.log").read_text()
assert "Installed prompt resources and routing guidance valid" in Path("/tmp/v381-phase123-prompt.log").read_text()
source={p.relative_to(ROOT).as_posix():digest(p.read_bytes()) for p in sorted((ROOT/"src/sql_safety_executor").rglob("*")) if p.is_file() and p.suffix in {".py",".md"}}
installed=read("installed_wheel.json");assert installed["import_outside_repository"] and all(len(r["requests"])==6 for r in installed["calls"])
automation={"version":"3.8.1","source_sha256":source,"full_suite":{"passed":1089,"skipped":4,"warnings":14,"seconds":176.51,"mysql_optin":False},
    "pyright":{"errors":0,"warnings":0},"prompt_contract":"passed","installed_calls":12,
    "sqlglot_runtime_dependency":False,"authorizer_installed":False,
    "model_trials":{"route":"task-local required stdio CLI","baseline_passed":3,"after_passed":3,"native_mcp_calls":18,"reference":"luna_cli_comparison.json"},
    "resident_host":"Awaiting maintainer restart; old unknown_function observed"}
native_path=OUT/"native_after_restart.json"
if native_path.exists():
    native=json.loads(native_path.read_text())
    assert native["checks"]["passed"]==len(native["records"])==13 and native["checks"]["failed"]==0
    automation["resident_host"]="Maintainer restart confirmed; primary Host native acceptance passed"
    automation["resident_host_checks"]={"passed":13,"failed":0,"reference":"native_after_restart.json"}
(OUT/"automation.json").write_text(json.dumps(automation,ensure_ascii=False,indent=2)+"\n")
for p in Path("/tmp").glob("v381-phase123-*.log"):
    (OUT/(p.name+".gz")).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in Path(__file__).parent.glob("*.py"):
    (OUT/(p.name+".gz")).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
manifest={"version":"3.8.1","source_reference":"automation.json#source_sha256",
    "recording_profile":"Public decoded application results/metadata and logs; not complete transport frames",
    "history":"Preceding evidence batches unchanged; initial fixture failures and overlapping timing probes retained",
    "omitted":["Internal model reasoning and credentials","Full protocol frames/notifications/IDs and original omitted-vs-null presence",
               "Complete initial model system/developer injection and outer programmatic-tool orchestration unavailable in public CLI events"],"artifacts":[]}
for p in sorted(OUT.iterdir()):
    if p.name=="manifest.json":continue
    data=p.read_bytes();row={"path":p.name,"bytes":len(data),"sha256":digest(data)}
    if p.suffix==".gz":
        raw=gzip.decompress(data);row.update(uncompressed_bytes=len(raw),uncompressed_sha256=digest(raw))
    manifest["artifacts"].append(row)
(OUT/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n")
print("Archived source/checks/cost and failed model environment attempts:",len(manifest["artifacts"]),"artifacts")
