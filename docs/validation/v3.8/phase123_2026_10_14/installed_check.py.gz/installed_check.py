"""Verified temporary build tools and an actual non-editable wheel install."""
import asyncio
import gzip
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sqlite3
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = ROOT / "docs/validation/v3.8/phase123_2026_10_14"
OUTPUT.mkdir(parents=True, exist_ok=True)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def fetch_json(url):
    with urllib.request.urlopen(url, timeout=30) as response:
        return json.load(response)

def download(url):
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url, timeout=30) as response:
                chunks = []
                while chunk := response.read(16384):
                    chunks.append(chunk)
                return b"".join(chunks)
        except (OSError, TimeoutError):
            if attempt == 2:
                raise

def pack(result):
    return {"isError": result.is_error, "structuredContent": result.structured_content,
            "content": [item.model_dump(mode="json", exclude_none=True) for item in result.content],
            "meta": result.meta}

async def check_installed(target, fixture, logs):
    from fastmcp import Client
    from fastmcp.client.transports import StdioTransport
    records = []
    for mode in ("legacy", "auto"):
        transport = StdioTransport(command=sys.executable,
            args=["-m", "sql_safety_executor", "serve", "--config", str(fixture / "server.toml")],
            env={"PYTHONPATH": str(target)}, cwd=str(fixture), keep_alive=False,
            log_file=logs / f"installed-{mode}.log")
        async with Client(transport, mode=mode) as client:
            sql = "WITH F AS (SELECT id FROM orders) SELECT id FROM f"
            requests = [("query", {"sql": sql}), ("list_skills", {"detail_level": "full"}),
                        ("execute_query_skill", {"skill_name": "case-probe", "params": {}}),
                        ("query", {"sql":"SELECT SLEEP(0)"}),
                        ("query", {"sql":"SELECT GET_LOCK(\'probe\',0)"}),
                        ("query", {"sql":"WITH SLEEP(n) AS (SELECT 7) SELECT n FROM SLEEP"})]
            results = [pack(await client.call_tool(tool, arguments, raise_on_error=False)) for tool, arguments in requests]
            assert results[0]["structuredContent"]["data"] == [{"id": 1}]
            row = results[1]["structuredContent"]["skills"][0]
            assert row["executable"] and row["tables"] == ["orders"]
            assert row["declared_tables"] == [] and row["inferred_tables"] == ["orders"]
            assert results[2]["structuredContent"]["data"] == [{"id": 1}]
            assert results[3]["structuredContent"]["error_code"] == "expensive_function_denied"
            assert results[4]["structuredContent"]["error_code"] == "lock_function_denied"
            assert results[5]["structuredContent"]["data"] == [{"n":7}]
            records.append({"protocol": client.protocol_version, "requests": [{"tool": t, "arguments": a} for t, a in requests], "responses": results})
    return records

with tempfile.TemporaryDirectory(prefix="v381-cte-install-") as directory:
    stage = Path(directory)
    deps = stage / "build-deps"
    deps.mkdir()
    downloads = []
    cache = ROOT / "local_archive/v381_review/followup_20261013_tools/build_download_cache"
    cache.mkdir(exist_ok=True)
    previous = json.loads((ROOT / "docs/validation/v3.8/review_2026_10_14/installed_wheel.json").read_text())
    for record in previous["build_tools"][:3]:
        cached = cache / record["filename"]
        data = cached.read_bytes()
        assert sha(data) == record["sha256"]
        wheel = stage / record["filename"]
        wheel.write_bytes(data)
        with zipfile.ZipFile(wheel) as archive:
            assert all((deps / item.filename).resolve().is_relative_to(deps) for item in archive.infolist())
            archive.extractall(deps)
        downloads.append({**record, "origin": "Verified existing local build-tool cache", "temporary_only": True})
    # Reuse only the existing pure-Python pip tool, not that environment's
    # Python 3.13 dependencies. This is a build tool, not runtime compatibility.
    local_pip = ROOT / "local_archive/v381_review/af3420f_reviews_20261012/af3420f_full/tkv/lib/python3.13/site-packages"
    shutil.copytree(local_pip / "pip", deps / "pip", ignore=shutil.ignore_patterns("__pycache__"))
    pip_info = next(local_pip.glob("pip-*.dist-info"))
    shutil.copytree(pip_info, deps / pip_info.name)
    pip_files = sorted(p for p in (deps / "pip").rglob("*") if p.is_file())
    downloads.append({"package": "pip", "version": pip_info.name[4:-10],
                      "origin": "Existing local review environment; only pure-Python pip and its dist-info copied into temporary build tools",
                      "source_sha256": sha(b"".join(p.relative_to(deps).as_posix().encode() + b"\0" + p.read_bytes() for p in pip_files)),
                      "temporary_copy_only": True})
    task_env = os.environ.copy()
    task_env["PYTHONPATH"] = str(deps)
    artifacts = stage / "dist"
    logs = stage / "logs"
    logs.mkdir()
    with (logs / "build.log").open("w") as stream:
        subprocess.run([sys.executable, "-m", "build", "--no-isolation", "--outdir", str(artifacts), str(ROOT)],
                       env=task_env, cwd=stage, stdout=stream, stderr=subprocess.STDOUT, check=True)
    wheel = next(artifacts.glob("*.whl"))
    target = stage / "installed"
    with (logs / "install.log").open("w") as stream:
        subprocess.run([sys.executable, "-m", "pip", "--isolated", "--disable-pip-version-check", "--no-cache-dir", "install", "--no-deps", "--no-index", "--no-compile", "--target", str(target), str(wheel)],
                       env=task_env, cwd=stage, stdout=stream, stderr=subprocess.STDOUT, check=True)
    installed_env = os.environ.copy()
    installed_env["PYTHONPATH"] = str(target)
    import_check = subprocess.check_output([sys.executable, "-c",
        "import json,sql_safety_executor;print(json.dumps({'version':sql_safety_executor.__version__,'file':sql_safety_executor.__file__}))"],
        env=installed_env, cwd=stage, text=True)
    imported = json.loads(import_check)
    assert imported["version"] == "3.8.1" and Path(imported["file"]).is_relative_to(target)
    fixture = stage / "fixture"
    fixture.mkdir()
    with sqlite3.connect(fixture / "fixture.sqlite") as conn:
        conn.executescript("CREATE TABLE orders(id INTEGER); INSERT INTO orders VALUES(1);")
    skill = fixture / "skills" / "case-probe"
    skill.mkdir(parents=True)
    (skill / "skill_def.md").write_text("---\nname: case-probe\ntype: query\nsource: query.sql\nrisk: low\ndescription: Installed CTE test\nparams: {}\n---\n")
    (skill / "query.sql").write_text("WITH F AS (SELECT id FROM orders) SELECT id FROM f")
    (fixture / "server.toml").write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="demo"\n')
    (fixture / "connections.toml").write_text('schema_version=1\n[connections.demo]\ntype="sqlite"\n[connections.demo.sqlite]\npath="fixture.sqlite"\n[connections.demo.read]\nmode="allowlist"\ntables=["orders"]\n')
    (fixture / "skills.toml").write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=true\n[skills.audit]\npath="audit.jsonl"\n')
    records = asyncio.run(check_installed(target, fixture, logs))
    artifact_records = [{"filename": item.name, "sha256": sha(item.read_bytes()), "bytes": item.stat().st_size} for item in artifacts.iterdir()]
    for log in logs.iterdir():
        (OUTPUT / (log.name + ".gz")).write_bytes(gzip.compress(log.read_bytes(), mtime=0))
    result = {"version": "3.8.1", "non_editable_pip_target_install": True, "import_outside_repository": True,
              "build_tools": downloads, "artifacts": artifact_records, "calls": records,
              "recording_profile": "Application results including content blocks/meta; not a complete JSON-RPC trace",
              "temporary_build_and_fixture_directories_removed_on_exit": True}
    (OUTPUT / "installed_wheel.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print("sdist/wheel built; non-editable outside-repository install and both-protocol stdio CTE checks passed.")
