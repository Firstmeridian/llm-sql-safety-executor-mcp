"""Read-only matrix for postfix predicate COLLATE; no production-code changes."""
from pathlib import Path
import argparse
import asyncio
import gzip
import hashlib
import inspect
import json
import sqlite3
import sys
import tempfile


async def main(args):
    sys.path.insert(0, str(args.source))
    import sql_safety_executor as package
    import sqlglot
    from sqlglot.parser import Parser
    from fastmcp import Client
    from sql_safety_executor import create_server, load_config
    from sql_safety_executor.core.analysis import _tokens, analyze_sql
    from sql_safety_executor.database.semantics import DialectContext
    directory = Path(package.__file__).resolve().parent
    assert directory == args.source / "sql_safety_executor"
    plan = json.loads(args.plan.read_text())
    context = DialectContext("sqlite")
    truth = []
    with sqlite3.connect(":memory:") as native:
        native.row_factory = sqlite3.Row
        for spec in plan["cases"]:
            sql = spec["sql"]
            rows = [dict(row) for row in native.execute(sql)]
            analysis = analyze_sql(sql, context)
            try:
                dialect, tokens = _tokens(sql, context)
                trees = dialect.parser().parse(tokens, sql)
                ast = {"success": True, "repr": repr(trees[0])}
            except Exception as error:
                ast = {"success": False, "type": type(error).__name__, "error": str(error)}
            truth.append({**spec, "sqlite_rows": rows, "analysis": {
                "status": analysis.status, "kind": analysis.statement_kind,
                "relations": [repr(r) for r in analysis.relations],
                "functions": sorted(analysis.functions)}, "ast": ast})
    records = []
    with tempfile.TemporaryDirectory(prefix="v382-range-collate-") as temporary:
        directory_tmp = Path(temporary)
        (directory_tmp / "server.toml").write_text('schema_version=1\n[files]\nconnections="connections.toml"\n[server]\ndefault_connection="demo"\n')
        (directory_tmp / "connections.toml").write_text('schema_version=1\n[connections.demo]\ntype="sqlite"\nsqlite.path="fixture.sqlite"\nread.mode="all"\n')
        server = create_server(load_config(directory_tmp / "server.toml"))
        try:
            for mode in ("auto", "legacy"):
                async with Client(server, mode=mode) as client:
                    for spec, independent in zip(plan["cases"], truth, strict=True):
                        response = await client.call_tool("query", {"connection_id": "demo", "sql": spec["sql"]}, raise_on_error=False)
                        data = response.structured_content
                        assert not response.is_error
                        assert json.loads(next(c.text for c in response.content if c.type == "text")) == data
                        if data["success"]:
                            assert data["data"] == independent["sqlite_rows"], spec["name"]
                        records.append({"name": spec["name"], "mode": mode,
                            "protocol": client.protocol_version, "structured": data,
                            "content": [c.model_dump(mode="json", exclude_none=True) for c in response.content],
                            "isError": response.is_error})
        finally:
            server.gateway_runtime.close()
    output = {"stage": args.stage, "package_path": str(directory), "version": package.__version__,
        "source_sha256": {p.relative_to(directory).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(directory.rglob("*")) if p.is_file() and p.suffix in (".py", ".md")},
        "sqlglot_version": sqlglot.__version__, "sqlite_version": sqlite3.sqlite_version,
        "upstream_parse_range": inspect.getsource(Parser._parse_range),
        "upstream_parse_range_file": inspect.getsourcefile(Parser._parse_range),
        "upstream_parse_range_line": inspect.getsourcelines(Parser._parse_range)[1],
        "independent": truth, "records": records,
        "scope": "Private in-process Client with actual import-path assertion. Current dependencies reused for both sources. Not historical dependency replay, wheel/stdio, configured writes or model task."}
    assert not args.output.exists()
    args.output.write_bytes(gzip.compress((json.dumps(output, ensure_ascii=False, indent=2) + "\n").encode(), mtime=0))
    print(json.dumps({"stage": args.stage, "cases": len(truth), "calls": len(records),
        "success": sum(r["structured"]["success"] for r in records),
        "parse_refusals": sum(r["structured"].get("error_code") == "sql_parse_failed" for r in records)}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=lambda x: Path(x).resolve(), required=True)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--stage", required=True)
    asyncio.run(main(parser.parse_args()))
