"""Seal a read-only predicate COLLATE assessment, preserving all earlier evidence."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[4]
BATCH = Path(__file__).resolve().parents[1]
LOCAL = BATCH / "evidence"
PUBLIC = ROOT / "docs/validation/v3.8/v382_predicate_collate_review_2026_10_18"
RESTART = ROOT / "docs/validation/v3.8/v382_collate_2026_10_18/resident_restart"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    blob = path.read_bytes()
    return json.loads(gzip.decompress(blob) if path.suffix == ".gz" else blob)


def check(path):
    base = path.parent.parent if "local_archive" in path.parts else path.parent
    files = read(path)["files"]
    for name, item in files.items():
        p = base / name
        assert sha(p) == item["sha256"] and p.stat().st_size == item["bytes"], p
    return len(files)


def main():
    assert not PUBLIC.exists()
    restart = read(RESTART / "verification.json")
    preserved = dict(restart["preserved_manifests"])
    p = RESTART / "manifest.json"
    preserved[str(p.relative_to(ROOT))] = {"sha256": sha(p), "files": check(p)}
    for name, info in preserved.items():
        p = ROOT / name
        assert sha(p) == info["sha256"] and check(p) == info["files"], p
    assert sum(info["files"] for info in preserved.values()) == 560
    current, baseline, skills, native = (read(LOCAL / f) for f in [
        "current.json.gz", "baseline.json.gz", "skills.json.gz", "native.json"])
    frozen_before = read(ROOT / "docs/validation/v3.8/v382_collate_2026_10_18/evidence/source_before.json")
    assert baseline["source_sha256"] == frozen_before["source_sha256"]
    assert current["source_sha256"] == skills["source_sha256"] == restart["runtime_resources"]
    for name, expected in current["source_sha256"].items():
        assert sha(ROOT / "src/sql_safety_executor" / name) == expected, name
    assert len(current["source_sha256"]) == 75
    cases = read(LOCAL / "plan.json")["cases"]
    assert len(cases) == len(current["independent"]) == len(baseline["independent"]) == 57
    assert [(c["name"], c["sql"], c["sqlite_rows"]) for c in current["independent"]] == [
        (c["name"], c["sql"], c["sqlite_rows"]) for c in baseline["independent"]]
    statuses = {}
    for label, doc, expected in [("current", current, (60,54)), ("e49cd0e", baseline, (56,58))]:
        assert len(doc["records"]) == 114
        success = sum(r["structured"]["success"] for r in doc["records"])
        refused = sum(r["structured"].get("error_code") == "sql_parse_failed" for r in doc["records"])
        assert (success, refused) == expected
        assert {r["protocol"] for r in doc["records"]} == {"2026-07-28","2025-11-25"}
        for row in doc["records"]:
            assert not row["isError"]
            assert json.loads(row["content"][0]["text"]) == row["structured"]
        statuses[label] = {"calls":114, "success":success, "sql_parse_failed":refused}
    differences = [{"name":a["name"],"mode":a["mode"],"before_success":a["structured"]["success"],
                    "after_success":b["structured"]["success"]}
                   for a,b in zip(baseline["records"],current["records"],strict=True)
                   if a["structured"]["success"] != b["structured"]["success"]]
    assert len(differences) == 4 and {r["name"] for r in differences} == {"prior_is_fix","prior_escape_fix"}
    assert len(skills["records"]) == 18 and sum(r["isError"] for r in skills["records"]) == 8
    for row in skills["records"]:
        if row["isError"]:
            assert row["structured"] is None and "not found" in row["content"][0]["text"]
        else:
            assert json.loads(row["content"][0]["text"]) == row["structured"]
    assert len(native["records"]) == 15
    for row in native["records"]:
        result = row["result"]; data = result["structuredContent"]
        assert result["isError"] is False and json.loads(result["content"][0]["text"]) == data
        assert data["connection_id"] == "analytics_demo_sqlite" and data["db_type"] == "sqlite"
        assert data["query"] == row["arguments"]["sql"]
    assert sum(r["result"]["structuredContent"]["success"] for r in native["records"]) == 9
    assert sum(r["result"]["structuredContent"].get("error_code") == "sql_parse_failed" for r in native["records"]) == 6
    before_path = Path(read(LOCAL / "baseline_source.json")["path"])
    assert before_path.parent == Path("/tmp") and before_path.name.startswith("v382-predicate-before-")
    for name, expected in baseline["source_sha256"].items():
        assert sha(before_path / "src/sql_safety_executor" / name) == expected, name
    shutil.rmtree(before_path)
    verification = {
        "version":"3.8.2","base_commit":"e49cd0eebb9bdf56ac6c114522af5b8743ba3bbf",
        "sealed_utc":datetime.now(timezone.utc).isoformat(),
        "status":"assessment_only_existing_P3_confirmed","risk":"DRR-2026-110",
        "runtime_code_changes_this_batch":False,"runtime_resources":current["source_sha256"],
        "source_baseline_resources":baseline["source_sha256"],"cases":57,"client_results":statuses,
        "baseline_to_current_differences":differences,"skill_calls":18,
        "skill_expected_tool_errors":8,"native_calls":15,"native_success":9,"native_parse_refusals":6,
        "new_adjacent_cases":["IN subquery","empty IN list","row-value IN","predicate chaining","repeated COLLATE"],
        "preserved_sealed_files":560,"preserved_manifests":preserved,
        "scope_limits":[
            "Only analysis, disposable fixtures, evidence and documentation; no runtime/test/dependency/version/config/grant change.",
            "Two real in-process Client modes use the same current dependency environment; no fresh wheel/stdio or historical dependency replay.",
            "Actual native SQL calls are constants on the previously resolved analytics_demo_sqlite; no configured writes or new native Skill fixture.",
            "Eight Skill-not-found tool errors reflect two definitions skipped at startup; raw tool errors are retained, not recast as structured policy results.",
            "27 of 57 current forms falsely refuse in both modes; this selected matrix is not a real-task failure rate.",
            "Previously scoped DRR-109 IS/ESCAPE acceptance remains valid; this separate full-predicate limitation is open.",
            "No new Luna business tasks, live MySQL, full regression or cost A/B; unchanged runtime hashes retain previous test attribution.",
            "Application records do not capture full transport frames or attest the native protocol."
        ]}
    PUBLIC.mkdir()
    for p in sorted(LOCAL.iterdir()):
        if not p.is_file():continue
        target=PUBLIC / p.name
        if p.suffix == ".log":
            target = PUBLIC / (p.name+".gz")
            target.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
        elif p.name == "native.json":
            (PUBLIC / "native.json.gz").write_bytes(gzip.compress(p.read_bytes(),mtime=0))
        else:
            target.write_bytes(p.read_bytes())
    for p in sorted((BATCH / "scripts").glob("*.py")):
        (PUBLIC / (p.name+".gz")).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
    (PUBLIC / "verification.json").write_text(json.dumps(verification,ensure_ascii=False,indent=2)+"\n")
    files={p.relative_to(PUBLIC).as_posix():{"sha256":sha(p),"bytes":p.stat().st_size}
           for p in sorted(PUBLIC.iterdir()) if p.is_file()}
    (PUBLIC / "manifest.json").write_text(json.dumps({"sealed_utc":verification["sealed_utc"],
        "scope":"Read-only assessment; prior closed scopes and failures remain unchanged.","files":files},ensure_ascii=False,indent=2)+"\n")
    assert check(PUBLIC / "manifest.json") == len(files)
    print(json.dumps({"cases":57,"client_calls":228,"skill_calls":18,"native_calls":15,
        "preserved_files":560,"new_sealed_files":len(files),"risk":"DRR-2026-110","status":"open P3"}))


if __name__ == "__main__":
    main()
