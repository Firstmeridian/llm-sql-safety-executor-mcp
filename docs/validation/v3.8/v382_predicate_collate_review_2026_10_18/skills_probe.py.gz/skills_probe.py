"""Check the effect on private Query Skill discovery, detail and execution."""
import asyncio
import gzip
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "src"))
from fastmcp import Client
from sql_safety_executor import create_server, load_config


async def main():
    records = []
    sqls = {
        "isnull-direct": "SELECT n FROM orders WHERE NULL ISNULL COLLATE NOCASE",
        "isnull-paren": "SELECT n FROM orders WHERE (NULL ISNULL) COLLATE NOCASE",
        "in-direct": "SELECT n FROM orders WHERE 7 IN (7) COLLATE NOCASE",
        "in-paren": "SELECT n FROM orders WHERE (7 IN (7)) COLLATE NOCASE"}
    with tempfile.TemporaryDirectory(prefix="v382-range-skills-") as temporary:
        folder = Path(temporary)
        with sqlite3.connect(folder / "fixture.sqlite") as db:
            db.executescript("CREATE TABLE orders(n); INSERT INTO orders VALUES(7);")
        (folder / "server.toml").write_text('schema_version=1\n[files]\nconnections="connections.toml"\nskills="skills.toml"\n[server]\ndefault_connection="demo"\n')
        (folder / "connections.toml").write_text('schema_version=1\n[connections.demo]\ntype="sqlite"\nsqlite.path="fixture.sqlite"\nread.mode="allowlist"\nread.tables=["orders"]\n')
        (folder / "skills.toml").write_text('schema_version=1\n[skills]\nenabled=true\ndirectory="skills"\n[skills.readiness]\ncheck_schema=true\n[skills.audit]\npath="audit.jsonl"\n')
        for name, sql in sqls.items():
            skill = folder / "skills" / name
            skill.mkdir(parents=True)
            (skill / "skill_def.md").write_text(
                f"---\nname: {name}\ntype: query\nsource: query.sql\nrisk: low\ndescription: Private predicate collation\nparams: {{}}\n---\n")
            (skill / "query.sql").write_text(sql)
        server = create_server(load_config(folder / "server.toml"))
        try:
            for mode in ("auto", "legacy"):
                async with Client(server, mode=mode) as client:
                    async def call(tool, arguments):
                        response = await client.call_tool(tool, arguments, raise_on_error=False)
                        records.append({"mode": mode, "protocol": client.protocol_version, "tool": tool,
                            "arguments": arguments, "structured": response.structured_content, "isError": response.is_error,
                            "content": [c.model_dump(mode="json", exclude_none=True) for c in response.content]})
                        return response.structured_content
                    found = await call("list_skills", {"connection_id": "demo", "detail_level": "full"})
                    assert {s["name"] for s in found["skills"]} == {"isnull-paren", "in-paren"}, found
                    for name in sqls:
                        await call("get_skill_detail", {"connection_id": "demo", "skill_name": name, "detail_level": "full"})
                        result = await call("execute_query_skill", {"connection_id": "demo", "skill_name": name, "params": {}})
                        if name.endswith("-paren"):
                            assert result["success"] and result["data"] == [{"n": 7}], result
        finally:
            server.gateway_runtime.close()
    assert len(records) == 18
    out = Path(__file__).resolve().parents[1] / "evidence/skills.json.gz"
    assert not out.exists()
    package = ROOT / "src/sql_safety_executor"
    document = {"scope": "Current source, private in-process Client, only disposable fixtures; not configured native Skill verification.",
        "definitions": sqls, "records": records, "calls": len(records),
        "source_sha256": {p.relative_to(package).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(package.rglob("*")) if p.is_file() and p.suffix in (".py", ".md")}}
    out.write_bytes(gzip.compress((json.dumps(document, ensure_ascii=False, indent=2) + "\n").encode(),mtime=0))
    print(json.dumps({"calls": len(records), "expected_discovery": ["in-paren", "isnull-paren"],
        "executions": [{"mode": r["mode"], "name": r["arguments"].get("skill_name"), "structured": r["structured"]} for r in records if r["tool"] == "execute_query_skill"]}))


if __name__ == "__main__":
    asyncio.run(main())
