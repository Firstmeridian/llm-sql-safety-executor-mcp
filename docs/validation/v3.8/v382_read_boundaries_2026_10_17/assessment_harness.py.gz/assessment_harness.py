import asyncio
import json
import logging
from pathlib import Path
import sqlite3
import sys
import tempfile
import warnings

sys.path.insert(0, sys.argv[1])
from fastmcp import Client
from sql_safety_executor import create_server, load_config

logging.disable(logging.CRITICAL)
warnings.filterwarnings('ignore')

EXPLAINS = [
    'EXPLAIN UPDATE orders SET n=99',
    'EXPLAIN QUERY PLAN DELETE FROM orders',
    'EXPLAIN INSERT INTO orders VALUES(99)',
    'EXPLAIN SELECT n FROM orders',
]

async def run(mode):
    with tempfile.TemporaryDirectory(prefix='v382-boundary-review-') as temp:
        root = Path(temp)
        with sqlite3.connect(root / 'db.sqlite') as db:
            db.create_function('SLEEP', 1, lambda _: 0)
            db.executescript('''
                CREATE TABLE orders(n INTEGER);
                INSERT INTO orders VALUES(7);
                CREATE VIEW normal_view AS SELECT n FROM orders;
                CREATE VIEW sleep_view AS SELECT n FROM orders WHERE SLEEP(0)=0;
                CREATE VIEW pragma_view AS SELECT seq AS n FROM pragma_database_list;
            ''')
            native = [{'sql': sql, 'plan_rows': len(db.execute(sql).fetchall())} for sql in EXPLAINS]
            native_unchanged = db.execute('SELECT n FROM orders').fetchall() == [(7,)]
        (root / 'server.toml').write_text('''schema_version=1
[files]
connections="connections.toml"
[server]
default_connection="demo"
[tools]
schema=true
table_summary=true
''')
        (root / 'connections.toml').write_text('''schema_version=1
[connections.demo]
type="sqlite"
[connections.demo.sqlite]
path="db.sqlite"
[connections.demo.read]
mode="allowlist"
tables=["orders","main.orders","main.normal_view","main.sleep_view","main.pragma_view"]
''')
        server = create_server(load_config(root / 'server.toml'))
        records = []
        called = []
        try:
            async with Client(server, mode=mode) as client:
                adapter = server.gateway_runtime.registry.get_adapter('demo')
                assert adapter.connect()
                with adapter._engine.connect() as conn:
                    conn.connection.dbapi_connection.create_function('SLEEP', 1, lambda _: called.append(1) or 0)
                async def call(tool, args, label):
                    before = len(called)
                    response = await client.call_tool(tool, args, raise_on_error=False)
                    payload = response.structured_content
                    if payload is None:
                        payload = {'is_error': response.is_error, 'content': str(response.content)[:400]}
                    records.append({'label':label, 'tool':tool, 'success':payload.get('success'),
                        'error_code':payload.get('error_code'), 'error':payload.get('error'),
                        'row_count':payload.get('row_count'), 'data':payload.get('data'),
                        'function_calls':len(called)-before})
                for view in ['normal_view', 'sleep_view', 'pragma_view']:
                    await call('query', {'sql': f'SELECT n FROM main.{view}'}, f'{view}:query')
                    await call('sample', {'table_name':view}, f'{view}:sample')
                    await call('get_table_summary', {'table_name':view,'exact_count':True}, f'{view}:exact')
                    await call('get_table_summary', {'table_name':view}, f'{view}:estimate')
                    await call('describe_table', {'table_name':view}, f'{view}:describe')
                for sql in EXPLAINS:
                    await call('query', {'sql':sql}, sql)
                for sql in ['UPDATE orders SET n=99','DELETE FROM orders','INSERT INTO orders VALUES(99)']:
                    await call('query', {'sql':sql}, sql)
                unchanged = [list(row) for row in adapter.execute('SELECT n FROM main.orders')] == [[7]]
                restored = getattr(adapter, '_active_guard', None) is None and getattr(adapter, '_read_request', None) is None
        finally:
            server.gateway_runtime.close()
        return {'mode':mode,'native_plans':native,'native_data_unchanged':native_unchanged,
            'tool_data_unchanged':unchanged,'guard_restored':restored,'records':records}

async def main():
    result = {'source':sys.argv[1], 'modes':[await run(mode) for mode in ['auto','legacy']]}
    Path(sys.argv[2]).write_text(json.dumps(result, ensure_ascii=False, indent=2))
    print(json.dumps(result, ensure_ascii=False))
asyncio.run(main())
