import asyncio,json,logging
from dataclasses import replace
from pathlib import Path
from fastmcp import Client
from sql_safety_executor import create_server,load_config
logging.disable(logging.CRITICAL)
async def main():
 c=load_config('config/server.toml')
 c=replace(c,server=c.server.model_copy(update={'tools':c.server.tools.model_copy(update={'schema_enabled':True,'table_summary':True})}),skills=c.skills.model_copy(update={'enabled':False,'audit':c.skills.audit.model_copy(update={'enabled':False})}))
 records=[]
 for mode in ('auto','legacy'):
  s=create_server(c)
  try:
   async with Client(s,mode=mode) as client:
    async def call(name,args):
     p=(await client.call_tool(name,dict(args,connection_id='trade_analysis_mysql'))).structured_content
     assert p['success'],p
     records.append({'mode':mode,'tool':name,'success':True})
     return p
    listed=await call('list_tables',{})
    assert listed['tables']
    name=listed['tables'][0]['table_name']
    sample=await call('sample',{'table_name':name})
    raw=await call('query',{'sql':sample['query']})
    assert sample['data']==raw['data']
    exact=await call('get_table_summary',{'table_name':name,'exact_count':True})
    a=s.gateway_runtime.registry.get_adapter('trade_analysis_mysql')
    from sql_safety_executor.database.relations import RelationReference
    relation=a.render_metadata_relation(RelationReference(name,a.metadata_schema))
    count=await call('query',{'sql':f'SELECT COUNT(*) AS n FROM {relation}'})
    assert exact['row_count']==count['data'][0]['n']
    described=await call('describe_table',{'table_name':name})
    assert described['columns']
  finally:s.gateway_runtime.close()
 result={'connection_id':'trade_analysis_mysql','calls':len(records),'records':records,'sample_matches_query':True,'exact_count_matches_query':True,'writes_issued':False,'scope':'Source Client auto/legacy; configured MySQL test alias; no stored routines or private temporary objects added.'}
 Path('/tmp/v382_read_boundary_mysql.json').write_text(json.dumps(result,indent=2))
 print(json.dumps({'passed':True,'calls':len(records)}))
asyncio.run(main())
