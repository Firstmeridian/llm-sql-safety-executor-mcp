"""Reject known-bad source for the target binding contract, not setup failures."""
import importlib.util
import json
from pathlib import Path
from unittest.mock import patch

from sql_safety_executor.core.analysis import analyze_sql
from sql_safety_executor.database.base import DatabaseAdapter
from sql_safety_executor.database.errors import DatabaseQueryError
from sql_safety_executor.database.models import ConnectionPolicy, DatabaseConfig
from sql_safety_executor.database.mysql import MySQLAdapter

HERE = Path(__file__).resolve().parents[1]
baseline = HERE / "baseline/src/sql_safety_executor/database/mysql.py"
spec = importlib.util.spec_from_file_location("sql_safety_executor.database._binding_baseline",baseline)
assert spec and spec.loader
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
records=[]
for stage,cls in [("known_bad",module.MySQLAdapter),("current",MySQLAdapter)]:
    value = cls(DatabaseConfig("fixture","mysql",5,5,ConnectionPolicy(read_mode="all"),
                               mysql_database="fixture",mysql_sql_mode=()))
    analysis = analyze_sql("SELECT 7 AS n",value.analysis_context)
    assert analysis.complete
    # A positive control ensures module loading and execution dispatch work.
    with patch.object(DatabaseAdapter,"execute_read",return_value=[(7,)]) as target:
        assert value.execute_read("SELECT 7 AS n",policy=value._config.policy,analysis=analysis)==[(7,)]
        target.assert_called_once()
    for sql in ["SELECT 99 AS n","select 7 as n","SELECT 7 AS n ",
                "SELECT 7 AS n /* different source */","SELECT n FROM hidden"]:
        error_code=None
        with patch.object(DatabaseAdapter,"execute_read",return_value=[]) as target:
            try: value.execute_read(sql,policy=value._config.policy,analysis=analysis)
            except DatabaseQueryError as error: error_code=error.error_code
            holds=target.call_count==0 and error_code=="session_semantics_unavailable"
            assert holds is (stage=="current"),(stage,sql,error_code,target.call_count)
            records.append({"stage":stage,"actual_sql":sql,"analysis_sql":analysis.source_sql,
                            "executor_calls":target.call_count,"error_code":error_code,"contract_holds":holds})
output=HERE/"evidence/binding_sentinels.json"
assert not output.exists()
output.write_text(json.dumps({"passed":True,"records":records,"database_statements":0,
                             "scope":"Five known-bad contract violations and five current passes; positive dispatch controls; no import/timeouts counted."},indent=2)+"\n")
print("Binding sentinels passed: 5 known-bad violations, 5 current rejections, positive controls.")
