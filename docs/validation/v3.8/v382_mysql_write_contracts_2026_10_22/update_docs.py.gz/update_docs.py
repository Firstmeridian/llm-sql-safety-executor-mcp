"""Update active decisions/navigation; keep previous sealed checkpoints intact."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4]
R="docs/validation/v3.8/V3_8_2_MYSQL_WRITE_CONTRACTS_2026_10_22_ZH.md"
def prepend_after(path, marker, insertion):
    p=ROOT/path;text=p.read_text();assert marker in text
    if insertion.strip() in text: return
    p.write_text(text.replace(marker,marker+insertion,1))

prepend_after("REFACTORING_LOG.md","**Date:** December 2, 2025 (Updated: October 22, 2026)\n",f"""

## v3.8.2 Exact read-analysis binding and live InnoDB write gate (October 22, 2026)

- [Fixes] DRR-144 requires MySQL analysis.source_sql to equal the exact original SQL, alongside completeness/session checks, before dispatch. Match SQLite's existing contract; keep original SQL/params and supported matching calls. Current MCP callers were consistent; no prior production bypass claim.
- [Integration Verification] Source/normal wheel each pass14 native-oracle commit/rollback groups,19 faults (five real server errors, two own-session disconnects,12 labelled client injections), three races and96 application calls/32 preview-confirm-replay flows. Unknown can accompany unchanged or committed data, with one adapter attempt and consumed-token replay rejection. Explicitly enable the four previous optional MySQL tests:4 pass/0 skip, separate from the default full3505 pass/4 skip.
- [Contract Decisions] Owner confirms three stabilization gates: transactional-business truth across lifecycle failures; cross-entry source/context/object binding with valid capability preserved; independent oracles and known-bad sentinels that fail on the target contract. AUTO_INCREMENT gaps are allowed; no production full-database comparison. Complete stabilization remains broader than these two tasks.
- [Validation and Docs] Twelve new binding regressions,25 binding/session tests, five known-bad/current sentinel pairs, clean types/prompts and77 identical installed resources. Temporary fixture schemas removed; configurations/grants/old seals stay intact. No write-adapter, dependency, prompt or mandatory Agent-step change; no new model/performance claim. Six limited resident checks await owner restart. [Evidence, costs and scope]({R}).
""")
prepend_after("REFACTORING_LOG_ZH.md","**创建日期：** 2025-12-02；**最近更新：** 2026-10-22\n",f"""

## v3.8.2 原 SQL 读取绑定与真实 InnoDB 写入门槛（2026-10-22）

- [功能修复] DRR-144：MySQL 在完整性／会话核验外要求 analysis.source_sql 等于待执行原 SQL，错配在基础执行器前拒绝；与 SQLite 契约一致，保留原 SQL／参数及合法匹配调用。此前 MCP 调用一致，不宣称修复已发生的授权绕过。
- [集成验证] 源码／正常wheel各14组原生对照的提交／回滚、19项故障（真实服务器5、自建会话断开2、定向客户端注入12）、3次竞争及96次应用调用／32个预览→确认→重放流程。unknown对应未变／已提交两种真值，适配器只执行一次、令牌已消费并拒绝重放；四项原可选MySQL实测显式启用4通过／0跳过，与默认全量3505通过／4跳过分开。
- [约定与决议] 维护者确认三项稳定性门槛：生命周期故障后的事务性业务真值、跨入口原SQL／上下文／对象绑定并保留合法能力、独立真值及因目标契约破坏而失败的旧版本哨兵。允许自增空洞；独立比较仅用于测试，不加入生产全库比较。本轮两项完成不代表全面稳定性收敛结束。
- [研究验证与文档] 新增12项绑定回归，绑定／会话25项及五组旧坏／当前哨兵通过，类型／提示通过，77资源与安装一致；临时库清理，配置／grant／旧封存保持。不改写入适配器、依赖、提示或Agent必需步骤，无新模型／性能声明；维护者重启后待做六项限定驻留复验。[证据、代价与范围]({R})。
""")

for name,marker,insertion in [
    ("README.md","- **SQLite writes**:","- **Read-analysis binding**: MySQL also verifies the exact original SQL before executing supplied analysis; valid matching calls and original parameters are preserved.\n"),
    ("README_ZH.md","- **SQLite 写入**：","- **读取分析绑定**：MySQL 同步核验分析对应的原 SQL；合法匹配调用和原参数保持正常，错配在执行器前拒绝。\n"),
]:
    p=ROOT/name;t=p.read_text()
    if insertion.strip() not in t:
        at=t.index(marker);p.write_text(t[:at]+insertion+t[at:])

for name,line in [
    ("docs/README.md",f"- [v3.8.2 MySQL binding and real InnoDB write gate](validation/v3.8/{Path(R).name}) — exact-source check, native failure truth, unknown/token lifecycle and confirmed release-gate definitions; source/package passed, resident restart pending.\n"),
    ("docs/README_ZH.md",f"- [v3.8.2 MySQL 原 SQL 绑定与真实 InnoDB 写入门槛](validation/v3.8/{Path(R).name})：绑定修复、真实故障／独立真值、unknown／令牌及已确认门槛定义；源码／安装通过，驻留待重启。\n"),
]:
    p=ROOT/name;t=p.read_text();marker="- [v3.8.2 SQLite";at=t.index(marker);p.write_text(t[:at]+line+t[at:])

prepend_after("docs/releases/RELEASE_NOTES_v3_8.md","# v3.8.2 — Dialect/session semantics and execution authorization (October 16, 2026)\n",f"""

### October 22 exact MySQL analysis binding and real InnoDB gate

| Aspect | Decision and result |
| --- | --- |
| Why / Change | DRR-144's internal source mismatch could reach MySQL's base executor. Add exact analysis.source_sql equality beside completeness/context; no prior exposed MCP failure reproduced. |
| Contract | Preserve original SQL/params and supported matching calls. Owner confirms independent transactional-business truth, cross-entry binding and effective known-bad sentinels; AUTO_INCREMENT gaps are allowed and comparisons stay test-only. |
| Validation | Source/wheel each14 write groups,19 faults,3 races and96 calls/32 preview-confirm-replay flows; real server errors/disconnects separated from client injections. Explicit live MySQL tests4/4; default full3505 pass/4 skip, clean types/prompts and77 resources match. |
| Compromises / Scope | No write-adapter/config/grant/prompt/dependency or mandatory Agent-step change. No new model/performance claim; unknown commit injection is in-process, not a network-partition test. Six limited native checks await owner restart. [Evidence and agreed gate definitions](../validation/v3.8/{Path(R).name}). |
""")

prepend_after("docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md","## SQLite 写入事务与完成态计数（2026-10-22，DRR-142／143）",f"""

此节保持SQLite契约；同日后续DRR-144／145已补MySQL原SQL绑定和真实InnoDB门槛。两后端execute_read都核对分析完整性、当前方言／会话及analysis.source_sql；内部已分析对象不得与另一SQL组合执行。匹配调用保留原SQL和绑定参数，不增加Agent步骤。事务性业务真值由测试独立连接观察，包含触发器／级联，排除自增分配等非回滚状态；不加入生产全库比较。真实服务器错误、物理自建会话断开和定向客户端注入分列记录；新矩阵通过不能泛化为所有引擎／模式／故障。三门槛定义已经维护者确认，全面跨入口收敛尚未结束。[MySQL补修、门槛定义与当前验收](../validation/v3.8/{Path(R).name})。
""")

p=ROOT/"docs/security/V3_8_SECURITY.md"
t=p.read_text()
t+=f"\nOctober22 follow-up DRR-144/145: MySQL now checks exact original-SQL binding as SQLite already did; old consistent MCP callers were not a reproduced bypass. Source/package real InnoDB gates verify business/trigger/cascade truth, actual errors and own-session loss, separately labelled client faults, unknown before/after commit, one attempt and consumed-token rejection. Test-only observers exclude non-rollback AUTO_INCREMENT allocation, with no production full-database comparison. Broad cross-entry stabilization and untested engine/fault profiles remain separate; limited native refresh awaits owner restart. [Confirmed contracts and evidence](../validation/v3.8/{Path(R).name}).\n"
p.write_text(t)

for name,english in [("docs/security/DESIGN_RISK_REGISTER.md",True),("docs/security/DESIGN_RISK_REGISTER_ZH.md",False)]:
    p=ROOT/name;lines=p.read_text().splitlines()
    at=next(i for i,l in enumerate(lines) if l.startswith("| DRR-2026-144 |"))
    lines[at]=(f"| DRR-2026-144 | Implemented; source/package passed; limited native restart pending | Add exact analysis.source_sql equality to MySQL execute_read, matching SQLite. Current MCP callers previously passed consistent SQL; no production bypass reproduced. |12 new regressions, five known-bad/current spy pairs with positive controls, live initial/reuse/reconnect checks and77 wheel resources agree. Original SQL/params and valid matching calls remain unchanged. [Repair and limits](../validation/v3.8/{Path(R).name}). |" if english else
               f"| DRR-2026-144 | 已修复；源码／安装通过，限定驻留待重启 | MySQL execute_read 补 analysis.source_sql 精确相等，与SQLite一致；此前MCP调用一致，无生产授权绕过复现。 | 新增12回归、五组旧坏／当前spy及正向控制、真机初始／复用／重连通过，77wheel资源一致；原SQL／参数及合法匹配调用保持。[修复与限制](../validation/v3.8/{Path(R).name})。 |")
    lines.insert(at+1,(f"| DRR-2026-145 | Declared live verification gap closed; not a new defect claim | Real MySQL8.0.25/InnoDB matrix independently checks transactions, counts, trigger/cascade effects, failures and cleanup. Owner confirms three release gates; no production full-DB comparison and AUTO_INCREMENT gaps allowed. | Source/wheel each14 groups,19 faults,3 races and96 application calls/32 flows; unknown has durable/unchanged controls, one execution and token replay denial. Explicit optional live4/4 differs from default four skips. Real errors/disconnects versus client injections and remaining scope are explicit; full stabilization remains incomplete. [Evidence](../validation/v3.8/{Path(R).name}). |" if english else
                     f"| DRR-2026-145 | 已补齐声明的真机验证缺口；非新缺陷结论 | MySQL8.0.25／InnoDB独立核对事务、计数、触发器／级联、故障及清理；维护者确认三门槛定义，自增空洞允许、无生产全库比较。 | 源码／wheel各14组、19故障、3竞争及96应用调用／32流程；unknown已提交／未变两对照、只执行一次及令牌重放拒绝。原可选四项另显式4/4，与默认四跳过分开；真实错误／断连与客户端注入分列，全面稳定性收敛尚未结束。[证据](../validation/v3.8/{Path(R).name})。 |"))
    p.write_text("\n".join(lines)+"\n")

p=ROOT/"docs/guides/TEST_MCP_CLIENT_GUIDE.md"
t=p.read_text()+f"""

## Live MySQL/InnoDB write gate (October22, DRR-144/145)

Run `tests/test_read_analysis_binding_v382.py` for exact-source rejection before base dispatch, unchanged matching SQL/params, context/completeness/write controls and SQLite preconnect parity. Do not accept an import failure or an unrelated exception as a killed binding sentinel.

For the approved test account, run `scripts/validation/mysql_writes.py --config /absolute/test/server.toml --alias test_mysql --source /absolute/repository/src --legacy-tests --output /fresh/source.json.gz`. The script creates one random owned mcp_contract_* schema, requires CREATE/DROP DATABASE and TRIGGER plus observation of its own lock wait in INNODB_TRX, and drops only its exact created schema. It never changes configured business tables, grants or global settings. Observe fixture authorization before running against another server; no silent skip/fallback for missing access. The four legacy opt-in tests receive credentials only through the subprocess environment and run inside this private schema; do not treat default optional skips as integration passes.

Use the normal installed-wheel interpreter without --source for the same matrix. Run a fresh `--section unknown-clients` output per source/wheel for two in-process injected commit-ack controls, both classifiers and Client modes. Data truth comes from independent native PyMySQL with the explicit FOUND_ROWS contract; it shares no project parser, policy or value-mapping helpers. Read binding also covers pool reuse/reconnect. Check specific actual server errno and real LOCK WAIT, injection hits, token consumption, target Invalid preview_token rejection and independent final data; an unrelated tool error does not pass replay validation. Serialize/redact application results rather than claiming complete frames or model usage.

Treat committed/rolled_back/unknown as evidence contracts. Compare transactional business rows, trigger audits and cascades after cleanup; allow consumed AUTO_INCREMENT gaps and other explicitly non-transactional allocation state. This is a test oracle, not a production full-database comparison. Do not automatically retry unknown or reuse consumed tokens. Keep real server errors/session disconnects separate from labelled client faults; this matrix does not simulate arbitrary network partitions or cover other engines/isolation profiles. Freeze one limited restart plan after source/package checks; public tools cannot inject the internal analysis object. [Current gate definitions, evidence and limits](../validation/v3.8/{Path(R).name}).
"""
p.write_text(t)

p=ROOT/"local_archive/v382_review/handoff/commit-message-v382.txt"
t=p.read_text().replace("- unify managed parsing and session binds with explicit sqlparse rollback", "- bind read analysis to exact SQL; unify managed parsing with explicit sqlparse fallback")
t=t.replace("- verify live grants, approval tokens and package/restart behavior", "- verify real InnoDB faults, live grants, one-use tokens and package/restart behavior")
p.write_text(t)

p=ROOT/"local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md"
t=p.read_text()
at=t.index("\n",t.index("> 2026-10-22 当前："))
start=t.index("> 2026-10-22 当前：")
t=t[:start]+"> 2026-10-22 当前：DRR-144已补原SQL绑定，DRR-145真实MySQL/InnoDB门槛通过；全量3505／4跳过，四项MySQL另显式4/4，源码／wheel各96调用／32流程。生产仅改MySQL读取入口；待维护者一次手动重启后六项限定复验。此前SQLite12/12及未修DRR-144的判断保持历史范围。"+t[at:]
old="**DRR-142／143源码／安装与维护者重启后限定原生12/12均通过，当前无需再重启。先看下方最新稳定性复评，后续建议尚未批准实施。**"
new="**先完成本批DRR-144源码改动后的维护者手动重启／六项限定复验；源码和正常安装已通过。三项门槛定义已确认，本轮只完成DRR-144及MySQL/InnoDB矩阵，全面收敛尚未结束。**"
assert old in t;t=t.replace(old,new,1)
marker="## 最新补充：重启闭环与稳定性复评（2026-10-22）"
new=f"""## 当前最新：DRR-144／145绑定修复与真实InnoDB门槛（2026-10-22）

只改mysql.execute_read：analysis.source_sql必须等于执行原SQL，完整性／上下文继续核验；原匹配调用、参数、授权和写入适配器不改。12新增回归／25绑定会话通过；五组旧坏错配会下传、当前拒绝，正向控制有效。原报告的“内部加固尚未实施”保留历史，不是当前状态。

真实MySQL8.0.25、随机独立InnoDB schema：源码／正常wheel各14原生对照组、19故障（真实服务器5＋自建物理断开2＋客户端定向注入12）、3竞争、96应用调用／32流程。普通72调用含两分类器／模式／进程内与stdio；unknown另24调用仅进程内，真实提交前后故障对应未变／已变两状态，均unknown、只执行一次、token消费后目标拒绝重放。四项MySQL旧可选另显式4/4，全量3505／4可选跳过分开；类型0/0、提示通过，77资源一致，临时schema残留0。准备错误／沙盒失败／中断及旧81封存2677记录保留；不反复安装、导入或重跑已过检查。

维护者确认三门槛的验收定义；未变只约束事务性业务行及触发器／级联，自增探针观察1、3中间空洞符合语义。不加入生产全库比较，不扩大误拒以充数；独立真值不复用被测分析／授权，注入必须实际命中、坏哨兵因目标契约失败。全面稳定性收敛仍未完成，当前只完成两项授权范围；无新模型token／性能／自然语言引导声明。版本仍3.8.2，真实TOML／grant不改，未暂存／提交。

待维护者手动重启当前Codex SQL MCP再按冻结六项做连接／常量／继续拒绝／SQLite对照；不确认已有配置库写入，不能拿原生常量成功证明内部错配分支或全部内存源码身份。原工具缓存根因未新增确认。无需Full access；网络／类型／进程通信用定点升级权限完成。

[当前公开报告](../../../{R})、[本地批次](../20261022_mysql_write_contracts/reports/README_ZH.md)、[六项冻结计划](../20261022_mysql_write_contracts/evidence/resident_plan.json)。统一英文分组commit草案已纳入精确绑定及真实InnoDB门槛；旧SQLite事务与模型失败证据各自保持。

"""
assert marker in t;t=t.replace(marker,new+marker,1);p.write_text(t)

p=ROOT/"local_archive/v382_review/README.md"
t=p.read_text();marker="- [SQLite真实写入事务与RETURNING补修]"
at=t.index(marker)
t=t[:at]+"- [MySQL原SQL绑定与真实InnoDB写入门槛](20261022_mysql_write_contracts/reports/README_ZH.md)（DRR-144／145；3505／4可选跳过，MySQL旧可选另显式4/4，源码／wheel各96调用；当前待本批一次重启）\n"+t[at:]
t=t.replace("当前待维护者重启，未写配置库", "该批重启12/12已通过，实际写入仍属私有夹具；历史检查点保留",1)
p.write_text(t)
