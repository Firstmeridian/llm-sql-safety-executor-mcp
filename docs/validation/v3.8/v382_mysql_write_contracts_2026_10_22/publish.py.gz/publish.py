"""Seal the new batch only; preserve old failed/pending evidence unchanged."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

HERE=Path(__file__).resolve().parents[1]
ROOT=HERE.parents[2]
E=HERE/"evidence"
PUBLIC=ROOT/"docs/validation/v3.8/v382_mysql_write_contracts_2026_10_22"
PUBLIC.mkdir(exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def packed(source,destination): destination.write_bytes(gzip.compress(source.read_bytes(),mtime=0))
main="V3_8_2_MYSQL_WRITE_CONTRACTS_2026_10_22_ZH.md"

(HERE/"reports/README_ZH.md").write_text(f"""# DRR-144／145：原SQL绑定与真实InnoDB写入门槛

维护者批准的两项工作已完成源码／安装验收：MySQL execute_read新增analysis.source_sql精确相等；真实MySQL8.0.25／InnoDB独立临时库验证事务、行数、触发器／级联、故障与令牌。生产只改database/mysql.py，不改写入适配器、授权／配置／依赖／提示或Agent必需步骤。

源码／正常wheel各14组提交／回滚、19故障（真实服务器5、自建会话断开2、定向客户端注入12）、3次竞争，以及96应用调用／32流程。普通72调用覆盖两分类器／两Client模式／进程内和独立stdio；unknown另24调用仅进程内，分别核对未变／已提交两种真值、只执行一次、令牌消费并目标拒绝重放。原可选MySQL另显式4/4；默认全量3505通过／4跳过、类型0/0、提示及77资源匹配。自增回滚后出现1、3的合法空洞，业务行未留99。

三项稳定性门槛的验收定义已经确认；只约束事务性业务真值，独立比较是测试判据，不加入生产全库比较。全面稳定性收敛尚未完成，不将本批两个范围的通过泛化为所有模式／引擎／故障或新的模型效果。

[公开报告](../../../../docs/validation/v3.8/{main})、[可核查公开归档](../../../../docs/validation/v3.8/v382_mysql_write_contracts_2026_10_22/README.md)、[最终核验](../evidence/checks.json)、[六项驻留计划](../evidence/resident_plan.json)、[统一英文提交草案](../../handoff/commit-message-v382.txt)。所有临时schema已删除，三TOML未变，81旧封存2677记录完整，另124旧manifest文件摘要保持。新记录含脱敏应用结果，不是完整协议帧／模型token；准备失败、沙盒中断、测试脚本错误和最终通过均保留。

当前仅待维护者一次手动重启后的六项限定原生复验；不在配置库确认写入，不用常量成功冒充内部错配分支证明。无Full access需求，定点授权完成网络／类型／进程通信；未暂存／提交，版本仍v3.8.2。
""")

entries=[]
for folder in (E,HERE/"scripts"):
    for path in sorted(folder.iterdir()):
        if not path.is_file() or path.name in {"documentation_checks.json"}: continue
        destination=PUBLIC/(path.name if path.suffix==".gz" else path.name+".gz")
        if path.suffix==".gz": destination.write_bytes(path.read_bytes())
        else: packed(path,destination)
        entries.append(destination.name)
for source,name in [(ROOT/"scripts/validation/mysql_writes.py","mysql_writes.py.gz"),
                    (ROOT/"tests/test_read_analysis_binding_v382.py","test_read_analysis_binding_v382.py.gz"),
                    (ROOT/"src/sql_safety_executor/database/mysql.py","mysql_current.py.gz"),
                    (HERE/"baseline/src/sql_safety_executor/database/mysql.py","mysql_baseline.py.gz")]:
    packed(source,PUBLIC/name);entries.append(name)
docs=[ROOT/name for name in [
    "README.md","README_ZH.md","REFACTORING_LOG.md","REFACTORING_LOG_ZH.md",
    "docs/README.md","docs/README_ZH.md","docs/releases/RELEASE_NOTES_v3_8.md",
    "docs/security/V3_8_SECURITY.md","docs/security/DESIGN_RISK_REGISTER.md","docs/security/DESIGN_RISK_REGISTER_ZH.md",
    "docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md","docs/guides/TEST_MCP_CLIENT_GUIDE.md",
    "docs/validation/v3.8/"+main,"local_archive/v382_review/README.md",
    "local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md",
    "local_archive/v382_review/handoff/commit-message-v382.txt"]]
snap=E/"docs";snap.mkdir(exist_ok=True)
for path in docs: packed(path,snap/(str(path.relative_to(ROOT)).replace("/","__")+".gz"))
packed(ROOT/"docs/validation/v3.8"/main,PUBLIC/"assessment.md.gz")
(PUBLIC/"README.md").write_text(f"""# Exact SQL binding and real MySQL/InnoDB gate — October 22, 2026

DRR-144 adds only exact analysis.source_sql binding to MySQL's existing read preconditions. Current consistent MCP callers were not a reproduced bypass. DRR-145 closes the explicitly declared live verification gap without claiming a new production defect or complete stabilization.

Source and normal wheel each pass14 native-oracle write groups,19 faults (five actual server errors, two own-session disconnects and12 labelled client injections), three races, and96 application calls/32 preview-confirm-replay flows. Ordinary72 calls cover in-process/stdio, auto/legacy and both managed classifiers; the extra24 unknown calls use in-process labelled commit-ack injection with real durable/unchanged controls, one attempt and spent-token rejection. Native PyMySQL oracles compare business/trigger/cascade data independently of project analysis/policy/results; AUTO_INCREMENT gaps are permitted. No production full-DB comparison, new Agent step or configuration switch.

Full3505 regressions pass/four optional skips; the four existing opt-in MySQL tests separately pass4/4 in the disposable schema. Types/prompts pass,77 installed resources match; fixture schemas removed and configs/grants/existing business tables unchanged. Preserve preparation errors, interrupted sandbox checks and old81 seals/2677 records. Application records redact tokens and are not complete protocol frames or model usage. No new performance/model claim. Six limited native checks await the owner restart; their eventual success cannot directly prove the internal source-mismatch branch.

See the [contract, gate definitions and limits](../{main}), [final checks](checks.json.gz), [frozen resident plan](resident_plan.json.gz) and [documentation check](documentation_checks.json.gz). Core rerunnable gate: decompress mysql_writes.py.gz to the repository scripts/validation path or use that tracked path, select an explicitly approved test alias, pass --source for source or omit it under the normal wheel interpreter. Use fresh output paths; --section unknown-clients is the distinct in-process fault supplement. The script requires disposable-schema/trigger privileges and actual lock-wait observation, fails rather than silently skipping missing access, and deletes only the exact schema it created.

Evidence and supporting scripts (gzip; manifest contains encoded/decoded hashes):

"""+"\n".join(f"- [{name}]({name})" for name in entries)+"\n\n- [Report snapshot](assessment.md.gz)\n- [Manifest](manifest.json)\n")

links=0
for path in docs+[HERE/"reports/README_ZH.md",PUBLIC/"README.md"]:
    if path.suffix!=".md": continue
    for value in re.findall(r"\[[^\]\n]*\]\(([^)\n]+)\)",path.read_text()):
        value=value.strip().strip("<>")
        if re.match(r"[a-zA-Z]+:",value) or value.startswith("#"): continue
        value=unquote(value.split("#",1)[0])
        if not value or path==PUBLIC/"README.md" and value in {"manifest.json","documentation_checks.json.gz"}: continue
        destination=Path(value) if value.startswith("/") else path.parent/value
        assert destination.exists(),(str(path),value)
        links+=1
ids=[]
for name in ["docs/security/DESIGN_RISK_REGISTER.md","docs/security/DESIGN_RISK_REGISTER_ZH.md"]:
    text=(ROOT/name).read_text()
    rows=re.findall(r"^\| (DRR-2026-\d+) \|",text,re.M)
    assert len(rows)==len(set(rows)) and rows.count("DRR-2026-144")==rows.count("DRR-2026-145")==1
    assert re.search(r"^\| DRR-2026-144 .*\n\| DRR-2026-145 ",text,re.M)
    ids.append(rows)
assert set(ids[0])==set(ids[1])
diff=subprocess.run(["git","diff","--check"],cwd=ROOT,capture_output=True,text=True)
assert diff.returncode==0,diff.stdout+diff.stderr
checks={"passed":True,"links_checked":links,"diff_check":"passed","bilingual_risk_ids":"same unique IDs;144/145 contiguous",
        "commit_draft":"updated; English groups; exact read binding and live InnoDB gate",
        "documents":{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in docs}}
(E/"documentation_checks.json").write_text(json.dumps(checks,ensure_ascii=False,indent=2)+"\n")
packed(E/"documentation_checks.json",PUBLIC/"documentation_checks.json.gz")
for folder in (PUBLIC,HERE):
    files={}
    for path in sorted(folder.rglob("*")):
        if not path.is_file() or path.name=="manifest.json" or "__pycache__" in path.parts: continue
        raw=path.read_bytes();meta={"bytes":len(raw),"sha256":sha(raw)}
        if path.suffix==".gz":
            decoded=gzip.decompress(raw);meta.update(decoded_bytes=len(decoded),decoded_sha256=sha(decoded))
        files[str(path.relative_to(folder))]=meta
    (folder/"manifest.json").write_text(json.dumps({"date":"2026-10-22","checkpoint":"DRR144 repair and live InnoDB gate; resident pending",
        "append_rule":"Retain failures and old seals; after owner restart create a separate resident_restart supplement, never rewrite this pending checkpoint.","files":files},ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"passed":True,"links":links,"public_files":len(json.loads((PUBLIC/"manifest.json").read_text())["files"]),
                  "private_files":len(json.loads((HERE/"manifest.json").read_text())["files"])},ensure_ascii=False))
