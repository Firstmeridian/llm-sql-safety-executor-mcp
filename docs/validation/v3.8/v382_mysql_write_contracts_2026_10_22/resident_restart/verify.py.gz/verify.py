"""Verify this six-call supplement; never rewrite the sealed parent checkpoint."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

HERE = Path(__file__).resolve().parents[1]
ROOT = next(p for p in HERE.parents if (p / "pyproject.toml").is_file())
PARENT = HERE.parent
E = HERE / "evidence"
PUBLIC = ROOT / "docs/validation/v3.8/v382_mysql_write_contracts_2026_10_22/resident_restart"
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def read(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == ".gz" else raw)


def audit_manifest(path):
    manifest = read(path)
    records = manifest["files"]
    items = records.items() if isinstance(records, dict) else ((r["path"], r) for r in records)
    resolved = {}
    count = 0
    for name, meta in items:
        entry = next(p for p in (path.parent / name, path.parent.parent / name, ROOT / name) if p.is_file())
        resolved[name] = entry
        raw = entry.read_bytes()
        assert sha(raw) == (meta["sha256"] if isinstance(meta, dict) else meta), (path, name)
        if isinstance(meta, dict):
            if "bytes" in meta:
                assert len(raw) == meta["bytes"]
            if "decoded_sha256" in meta:
                decoded = gzip.decompress(raw)
                assert sha(decoded) == meta["decoded_sha256"] and len(decoded) == meta["decoded_bytes"]
        count += 1
    for name, meta in manifest.get("compressed_decoded_records", {}).items():
        decoded = gzip.decompress(resolved[name].read_bytes())
        assert sha(decoded) == meta.get("decoded_sha256", meta.get("sha256"))
        assert len(decoded) == meta.get("decoded_bytes", meta.get("bytes"))
    return count


base = read(PARENT / "evidence/baseline.json")
resources = {str(p.relative_to(ROOT / "src/sql_safety_executor")): sha(p.read_bytes())
             for p in (ROOT / "src/sql_safety_executor").rglob("*")
             if p.is_file() and p.suffix in {".py", ".md"}}
installed = read(PARENT / "evidence/installed_resources.json")
assert resources == installed["installed"]["resources"] and len(resources) == 77
for name, digest in base["configuration"].items():
    assert sha((ROOT / name).read_bytes()) == digest, name
digests = dict(base["prior_seals"])
for path in (PARENT / "manifest.json", PUBLIC.parent / "manifest.json"):
    digests[str(path.relative_to(ROOT))] = sha(path.read_bytes())
for name, digest in digests.items():
    assert sha((ROOT / name).read_bytes()) == digest, name

sqlite = ROOT / "local_archive/v382_review/20261022_sqlite_write_repair"
certified = list(read(sqlite / "evidence/final_checks.json")["prior_manifests"])
for folder in (sqlite, ROOT / "docs/validation/v3.8/v382_sqlite_write_transactions_2026_10_22",
               sqlite / "resident_restart", ROOT / "docs/validation/v3.8/v382_sqlite_write_transactions_2026_10_22/resident_restart",
               PARENT, PUBLIC.parent):
    name = str((folder / "manifest.json").relative_to(ROOT))
    certified.append({"manifest": name, "sha256": digests[name]})
assert len(certified) == len({r["manifest"] for r in certified}) == 83
count = 0
for spec in certified:
    path = ROOT / spec["manifest"]
    assert sha(path.read_bytes()) == spec["sha256"]
    count += audit_manifest(path)
assert count == 2785, count

frozen = read(PARENT / "evidence/resident_plan.json")
calls = read(E / "native_calls.json")["records"]
assert len(calls) == len(frozen["checks"]) == 6
native = []
for index, (record, spec) in enumerate(zip(calls, frozen["checks"], strict=True), 1):
    assert record["tool"] == spec["tool"] and record["arguments"] == spec["arguments"]
    assert record["expected"] == spec["expected"] and "error" not in record
    packet = record["result"]
    assert packet.get("isError") is False
    structured = packet["structuredContent"]
    texts = [json.loads(b["text"]) for b in packet["content"] if b["type"] == "text"]
    assert texts == [structured], index
    if spec["expected"] == "connected":
        assert structured["all_connected"] and structured["results"]["sakila_mysql"]["connected"]
    elif spec["expected"] == "7":
        assert structured["success"] and structured["data"] == [{"n": 7}]
        assert structured["row_count"] == structured["total_rows"] == 1 and not structured["truncated"]
    else:
        assert structured["success"] is False and structured["error_code"] == spec["expected"]
    native.append({"index": index, "tool": spec["tool"], "arguments": spec["arguments"],
                   "expected": spec["expected"], "passed": True, "text_structured_agree": True})

before = {"date": "2026-10-22", "resources": resources, "configuration": base["configuration"],
          "prior_manifest_digests": digests, "certified_manifests": certified,
          "fully_verified_prior_seals": 83, "prior_sealed_records": count,
          "parent_report_sha256": sha((ROOT / "docs/validation/v3.8/V3_8_2_MYSQL_WRITE_CONTRACTS_2026_10_22_ZH.md").read_bytes())}
before_path = E / "before.json"
if before_path.exists():
    assert read(before_path) == before, "Baseline changed; preserve evidence and investigate"
else:
    before_path.write_text(json.dumps(before, ensure_ascii=False, indent=2) + "\n")

documents = [ROOT / name for name in (
    "REFACTORING_LOG.md", "REFACTORING_LOG_ZH.md", "docs/README.md", "docs/README_ZH.md",
    "docs/releases/RELEASE_NOTES_v3_8.md", "docs/security/V3_8_SECURITY.md",
    "docs/security/DESIGN_RISK_REGISTER.md", "docs/security/DESIGN_RISK_REGISTER_ZH.md",
    "docs/architecture/V3_8_2_SQL_SEMANTICS_ZH.md", "docs/guides/TEST_MCP_CLIENT_GUIDE.md",
    "docs/validation/v3.8/V3_8_2_STABILIZATION_PLAN_2026_10_22_ZH.md",
    "local_archive/v382_review/README.md",
    "local_archive/v382_review/handoff/session-handoff-v381-v382-20261019-ZH.md",
    "local_archive/v382_review/handoff/commit-message-v382.txt")]
links = 0
for path in documents + [HERE / "reports/README_ZH.md", PUBLIC / "README.md"]:
    if path.suffix != ".md":
        continue
    for value in re.findall(r"\[[^\]\n]*\]\(([^)\n]+)\)", path.read_text()):
        value = value.strip().strip("<>")
        if re.match(r"[a-zA-Z]+:", value) or value.startswith("#"):
            continue
        value = unquote(value.split("#", 1)[0])
        if not value:
            continue
        if path == HERE / "reports/README_ZH.md" and value == "../evidence/checks.json":
            continue
        if path == PUBLIC / "README.md" and value in {"manifest.json", "native_calls.json.gz", "checks.json.gz", "before.json.gz", "verify.py.gz"}:
            continue
        target = Path(value) if value.startswith("/") else path.parent / value
        assert target.exists(), (str(path), value)
        links += 1
ids = []
for name in ("docs/security/DESIGN_RISK_REGISTER.md", "docs/security/DESIGN_RISK_REGISTER_ZH.md"):
    text = (ROOT / name).read_text()
    rows = re.findall(r"^\| (DRR-2026-\d+) \|", text, re.M)
    assert len(rows) == len(set(rows))
    assert re.search(r"^\| DRR-2026-144 .*\n\| DRR-2026-145 ", text, re.M)
    ids.append(set(rows))
assert ids[0] == ids[1]
diff = subprocess.run(["git", "diff", "--check"], cwd=ROOT, capture_output=True, text=True)
assert diff.returncode == 0, diff.stdout + diff.stderr

result = {"passed": True, "native_passed": 6, "native_total": 6, "native": native,
          "runtime_resources_unchanged": 77, "private_configuration_unchanged": len(base["configuration"]),
          "source_still_matches_frozen_installed_resources": True,
          "prior_manifest_digests_unchanged": len(digests), "fully_verified_prior_seals": 83,
          "prior_sealed_records": count, "parent_pending_report_unchanged": True,
          "documentation_links_checked": links, "bilingual_risk_ids": "same; unique;144/145 contiguous",
          "diff_check": "passed", "new_runtime_changes": 0, "configured_confirmed_writes": 0,
          "new_model_trials": 0, "new_performance_claim": False,
          "stabilization": "concrete finite plan recorded; S0 scoped complete; S1-S4 not yet accepted",
          "scope": "No exposed analysis-mismatch argument; native constants do not attest that internal branch or all in-memory resources. Packets are not full wire frames."}
(E / "checks.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
snap = E / "docs"
snap.mkdir(exist_ok=True)
for path in documents:
    name = str(path.relative_to(ROOT)).replace("/", "__") + ".gz"
    (snap / name).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for path in (E / "native_calls.json", E / "before.json", E / "checks.json", Path(__file__)):
    (PUBLIC / (path.name + ".gz")).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for folder in (HERE, PUBLIC):
    files = {}
    for path in sorted(folder.rglob("*")):
        if not path.is_file() or path.name == "manifest.json" or "__pycache__" in path.parts:
            continue
        raw = path.read_bytes()
        meta = {"bytes": len(raw), "sha256": sha(raw)}
        if path.suffix == ".gz":
            decoded = gzip.decompress(raw)
            meta.update(decoded_bytes=len(decoded), decoded_sha256=sha(decoded))
        files[str(path.relative_to(folder))] = meta
    destination = folder / "manifest.json"
    assert not destination.exists(), "Never rewrite a sealed checkpoint"
    destination.write_text(json.dumps({"date": "2026-10-22", "checkpoint": "Six native checks passed; finite stabilization plan recorded; remaining gates pending",
        "append_rule": "Never rewrite the parent pending checkpoint or these records; create a new supplement for later work.",
        "files": files}, ensure_ascii=False, indent=2) + "\n")
new_records = sum(audit_manifest(folder / "manifest.json") for folder in (HERE, PUBLIC))
print(json.dumps({**result, "new_seals": 2, "new_records": new_records,
                  "cumulative_certified_seals": 85, "cumulative_records": count + new_records}, ensure_ascii=False))
