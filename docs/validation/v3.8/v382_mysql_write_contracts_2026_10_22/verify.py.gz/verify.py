"""Audit production delta, native oracle results, installed parity and old seals."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil

HERE=Path(__file__).resolve().parents[1]
ROOT=HERE.parents[2]
E=HERE/"evidence"
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(path): return json.loads(gzip.decompress(path.read_bytes()) if path.suffix==".gz" else path.read_bytes())

base=read(E/"baseline.json")
current={str(p.relative_to(ROOT/"src/sql_safety_executor")):sha(p.read_bytes())
         for p in (ROOT/"src/sql_safety_executor").rglob("*") if p.is_file() and p.suffix in {".py",".md"}}
assert [name for name,digest in base["resources"].items() if current[name]!=digest]==["database/mysql.py"]
assert len(current)==77
for name,digest in base["configuration"].items(): assert sha((ROOT/name).read_bytes())==digest
for name,digest in base["prior_seals"].items(): assert sha((ROOT/name).read_bytes())==digest,name
installed=read(E/"installed_resources.json")
assert installed["installed"]["resources"]==current
dist=E/"distributions";dist.mkdir(exist_ok=True)
for suffix in ("*.whl","*.tar.gz"):
    for path in Path(installed["wheel"]).parent.glob(suffix): shutil.copyfile(path,dist/path.name)

source=read(E/"source_attempt3.json.gz")
wheel=read(E/"installed_final.json.gz")
unknown=[read(E/name) for name in ("source_unknown.json.gz","installed_unknown.json.gz")]
for stage in (source,wheel):
    assert stage["passed"] and stage["disposable_schema_removed"] and stage["resources"]==current
    assert stage["engines"]==["InnoDB"] and stage["server"]["version"]=="8.0.25"
    assert len(stage["read_binding"])==3 and len(stage["matrix"])==14 and len(stage["faults"])==19
    for row in stage["matrix"]:
        a,b=row["phases"]
        assert a["result"]["outcome"]=="committed" and a["post_cleanup_truth"]==row["native_after"]
        assert b["result"]["outcome"]=="rolled_back" and b["post_cleanup_truth"]==row["native_before"]
    assert len(stage["concurrency"])==3 and stage["sequence_gap"]["rollback_gap_observed"]
    assert len(stage["client_records"])==72
assert source["matrix"]==wheel["matrix"]
assert source["faults"]==wheel["faults"]
assert source["legacy_integration"]["passed"]==4 and source["legacy_integration"]["skipped"]==0

def stable(value):
    if isinstance(value,dict): return {k:stable(v) for k,v in value.items() if k not in {"execution_ms","preview_token_expires_at"}}
    if isinstance(value,list): return [stable(v) for v in value]
    return value

def check_clients(stage,expected):
    rows=stage["client_records"]
    assert len(rows)==expected and len(rows)%3==0
    for i in range(0,len(rows),3):
        preview,confirm,replay=rows[i:i+3]
        assert not preview["isError"] and preview["result"]["execution_outcome"]=="not_executed"
        assert not confirm["isError"] and confirm["meta"]["preview_token_consumed"] is True
        assert confirm["result"]["success"] is (confirm["result"]["execution_outcome"]=="committed")
        assert replay["isError"] and any("Invalid preview_token" in b.get("text","") for b in replay["content"])
        for record in (preview,confirm):
            text=next(b["text"] for b in record["content"] if b["type"]=="text")
            assert json.loads(text)==record["result"]
        assert preview["result"]["preview_token"]=="<redacted>"
        assert confirm["arguments"]["preview_token"]==replay["arguments"]["preview_token"]=="<redacted>"
for stage in (source,wheel): check_clients(stage,72)
for stage in unknown:
    assert stage["passed"] and stage["disposable_schema_removed"] and stage["resources"]==current
    check_clients(stage,24)
    assert len(stage["client_truth"])==8
    for row in stage["client_truth"]:
        assert row["adapter_write_attempts"]==1
        after=row["after_confirm_and_replay"]
        if row["case"]=="unknown-before": assert after==row["native_before"]
        else: assert after["orders"]==[[1,99,"one"],[2,8,"two"]] and len(after["audit"])==1
        if "after_server_cleanup" in row: assert row["after_server_cleanup"]==after
for a,b in [(source,wheel),tuple(unknown)]:
    for left,right in zip(a["client_records"],b["client_records"],strict=True):
        for field in ("transport","parser","mode","tool","arguments","result","meta","isError"):
            assert stable(left[field])==stable(right[field]),field
sentinels=read(E/"binding_sentinels.json")
assert sentinels["passed"] and sentinels["database_statements"]==0 and len(sentinels["records"])==10
assert sum(r["contract_holds"] for r in sentinels["records"])==5
assert read(E/"postflight.json")["remaining_contract_fixture_schemas"]==0
assert "3505 passed, 4 skipped" in (E/"full_tests_final.log").read_text()
assert "25 passed" in (E/"binding_final.log").read_text()
assert "0 errors, 0 warnings" in (E/"types_final.log").read_text()
assert "Installed prompt resources and routing guidance valid." in (E/"prompts.log").read_text()

parent=ROOT/"local_archive/v382_review/20261022_sqlite_write_repair"
certified=read(parent/"evidence/final_checks.json")["prior_manifests"]
for folder in [parent,ROOT/"docs/validation/v3.8/v382_sqlite_write_transactions_2026_10_22",
               parent/"resident_restart",ROOT/"docs/validation/v3.8/v382_sqlite_write_transactions_2026_10_22/resident_restart"]:
    name=str((folder/"manifest.json").relative_to(ROOT))
    certified.append({"manifest":name,"sha256":base["prior_seals"][name]})
count=0
for spec in certified:
    path=ROOT/spec["manifest"]
    assert sha(path.read_bytes())==spec["sha256"]
    record=read(path)
    items=record["files"].items() if isinstance(record["files"],dict) else ((r["path"],r) for r in record["files"])
    resolved={}
    for name,meta in items:
        entry=next(p for p in [path.parent/name,path.parent.parent/name,ROOT/name] if p.is_file())
        resolved[name]=entry;raw=entry.read_bytes()
        assert sha(raw)==(meta["sha256"] if isinstance(meta,dict) else meta),(path,name)
        if isinstance(meta,dict):
            if "bytes" in meta: assert len(raw)==meta["bytes"]
            if "decoded_sha256" in meta:
                raw=gzip.decompress(raw);assert sha(raw)==meta["decoded_sha256"] and len(raw)==meta["decoded_bytes"]
        count+=1
    for name,meta in record.get("compressed_decoded_records",{}).items():
        raw=gzip.decompress(resolved[name].read_bytes())
        assert sha(raw)==meta.get("decoded_sha256",meta.get("sha256")) and len(raw)==meta.get("decoded_bytes",meta.get("bytes"))
assert len(certified)==81 and count==2677,(len(certified),count)
plan={"status":"pending owner manual restart","scope":"Read-only constants, expected denials and connection check only; no configured confirmed write. Internal analysis mismatch is not an exposed tool argument.","checks":[
    {"tool":"check_connection","arguments":{"connection_id":"sakila_mysql"},"expected":"connected"},
    {"tool":"query","arguments":{"connection_id":"sakila_mysql","sql":"SELECT 7 AS n"},"expected":"7"},
    {"tool":"query","arguments":{"connection_id":"sakila_mysql","sql":"SELECT SLEEP(1)"},"expected":"expensive_function_denied"},
    {"tool":"query","arguments":{"connection_id":"sakila_mysql","sql":"UPDATE film SET title=title WHERE 1=0"},"expected":"read_only_required"},
    {"tool":"query","arguments":{"connection_id":"sqlite_features_sqlite","sql":"SELECT 7 AS n"},"expected":"7"},
    {"tool":"query","arguments":{"connection_id":"sqlite_features_sqlite","sql":"SELECT SLEEP(1)"},"expected":"expensive_function_denied"}]}
(E/"resident_plan.json").write_text(json.dumps(plan,ensure_ascii=False,indent=2)+"\n")
result={"passed":True,"runtime_delta":["database/mysql.py"],"resources":77,"configuration_unchanged":3,
        "source_installed_semantics_agree":True,"matrix_groups_per_stage":14,"faults_per_stage":19,
        "real_server_errors_per_stage":5,"own_session_disconnects_per_stage":2,"labelled_client_injections_per_stage":12,
        "races_per_stage":3,"application_calls_per_stage":96,"flows_per_stage":32,
        "unknown_client_scope":"inprocess only; both classifiers and modes; real DB with labelled commit-ack injection; no automatic retry; consumed token rejects replay",
        "full_regression_passed":3505,"default_optional_skipped":4,"explicit_live_optional_tests_passed":4,
        "explicit_live_optional_skipped":0,"binding_regressions_added":12,"binding_and_session_tests_passed":25,
        "types":"0 errors, 0 warnings","prompts":"passed","sentinels":"5 known-bad violations and5 current rejections, positive controls; zero database",
        "prior_manifest_digests_unchanged":len(base["prior_seals"]),"fully_verified_prior_seals":81,"prior_sealed_records":2677,
        "fixture_schemas_remaining":0,"existing_business_table_writes":0,"new_model_trials":0,"new_performance_claim":False,
        "resident":"pending owner restart and six frozen limited checks; private real-write evidence stays source/package scoped"}
(E/"checks.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(result,ensure_ascii=False))
