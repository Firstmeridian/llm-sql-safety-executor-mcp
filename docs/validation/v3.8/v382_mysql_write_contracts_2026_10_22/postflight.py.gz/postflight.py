"""Read-only cleanup audit; no deletion of schemas found by name matching."""
from pathlib import Path
import json
from sql_safety_executor import load_config
from sql_safety_executor.database.mysql import MySQLAdapter

value=MySQLAdapter(load_config(Path("config/server.toml")).connections["sakila_mysql"])
try:
    assert value.connect()
    with value._engine.connect() as con:
        count=con.exec_driver_sql("SELECT COUNT(*) FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME REGEXP '^mcp_contract_[0-9a-f]{16}$'").scalar_one()
    assert count==0,"Disposable fixture schemas remain; inspect without deleting unrelated objects"
    record={"passed":True,"remaining_contract_fixture_schemas":count,"operation":"read-only observation, no pattern-based deletion"}
    Path("local_archive/v382_review/20261022_mysql_write_contracts/evidence/postflight.json").write_text(json.dumps(record,indent=2)+"\n")
    print(json.dumps(record))
except Exception as error:
    print(json.dumps({"passed":False,"error_class":type(error).__name__}))
    raise SystemExit(1) from None
finally:value.close()
