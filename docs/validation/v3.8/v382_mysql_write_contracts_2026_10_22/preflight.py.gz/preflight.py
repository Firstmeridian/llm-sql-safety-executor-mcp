"""Read-only preflight; never print host/account/password or server error text."""
from pathlib import Path
import json
from sql_safety_executor import load_config
from sql_safety_executor.database.mysql import MySQLAdapter

adapter = MySQLAdapter(load_config(Path("config/server.toml")).connections["sakila_mysql"])
try:
    assert adapter.connect()
    with adapter._engine.connect() as con:
        row = con.exec_driver_sql("SELECT VERSION(), @@session.autocommit, @@session.transaction_isolation, @@global.innodb_rollback_on_timeout").one()
    record = {"connected":True,"version":row[0],"autocommit":row[1],"isolation":row[2],"innodb_rollback_on_timeout":row[3]}
    Path("local_archive/v382_review/20261022_mysql_write_contracts/evidence/preflight.json").write_text(json.dumps(record,indent=2)+"\n")
    print(json.dumps(record))
except Exception as error:
    print(json.dumps({"connected":False,"error_class":type(error).__name__}))
    raise SystemExit(1) from None
finally:
    adapter.close()
